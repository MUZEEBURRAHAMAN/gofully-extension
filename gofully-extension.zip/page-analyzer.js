(function() {
	//#region src/content/page-analyzer.ts
	function getPageDimensions() {
		const body = document.body;
		const html = document.documentElement;
		return {
			scrollWidth: Math.max(body.scrollWidth, body.offsetWidth, html.clientWidth, html.scrollWidth, html.offsetWidth),
			scrollHeight: Math.max(body.scrollHeight, body.offsetHeight, html.clientHeight, html.scrollHeight, html.offsetHeight),
			viewportWidth: window.innerWidth,
			viewportHeight: window.innerHeight,
			devicePixelRatio: window.devicePixelRatio || 1
		};
	}
	chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
		if (message.type === "GET_PAGE_INFO") {
			sendResponse({
				type: "PAGE_INFO",
				payload: getPageDimensions()
			});
			return true;
		}
		return false;
	});
	//#endregion
})();
