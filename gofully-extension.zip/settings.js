import { t as DEFAULT_SETTINGS } from "./chunks/types-BTm3mIuc.js";
import { n as watchTheme, t as applyTheme } from "./chunks/theme-DcC2xsTw.js";
import { r as watchLanguage, t as initI18n } from "./chunks/i18n-CC-Poaaa.js";
//#region src/settings/settings.ts
applyTheme();
watchTheme();
initI18n();
watchLanguage(() => {});
var currentTheme = DEFAULT_SETTINGS.theme;
var DEFAULT_EDITOR_SHORTCUTS = {
	select: "v",
	arrow: "a",
	rectangle: "r",
	ellipse: "e",
	callout: "c",
	line: "l",
	freedraw: "p",
	text: "t",
	spotlight: "s",
	blur: "b",
	step: "n",
	crop: "x",
	highlight: "h"
};
var SHORTCUT_LABELS = {
	select: "Select",
	arrow: "Arrow",
	rectangle: "Rectangle",
	ellipse: "Ellipse",
	callout: "Callout",
	line: "Line",
	freedraw: "Pen",
	text: "Text",
	spotlight: "Spotlight",
	blur: "Blur",
	step: "Step Number",
	crop: "Crop",
	highlight: "Highlighter"
};
var editorShortcuts = { ...DEFAULT_EDITOR_SHORTCUTS };
var elements = {
	defaultAction: document.getElementById("defaultAction"),
	captureDelay: document.getElementById("captureDelay"),
	lazyLoadWait: document.getElementById("lazyLoadWait"),
	pngSaveAs: document.getElementById("pngSaveAs"),
	pdfPageSize: document.getElementById("pdfPageSize"),
	pdfWatermark: document.getElementById("pdfWatermark"),
	captureSound: document.getElementById("captureSound"),
	captureCountdown: document.getElementById("captureCountdown"),
	skipStickyHeaders: document.getElementById("skipStickyHeaders"),
	defaultExportFormat: document.getElementById("defaultExportFormat"),
	captureStamp: document.getElementById("captureStamp"),
	ocrLanguage: document.getElementById("ocrLanguage"),
	uiLanguage: document.getElementById("uiLanguage"),
	savedToast: document.getElementById("savedToast")
};
async function loadSettings() {
	let storedSettings = (await chrome.storage.sync.get("settings")).settings;
	if (!storedSettings && chrome.storage.local) storedSettings = (await chrome.storage.local.get("settings")).settings;
	const settings = {
		...DEFAULT_SETTINGS,
		...storedSettings || {}
	};
	elements.defaultAction.value = settings.defaultAction;
	elements.captureDelay.value = String(settings.captureDelay);
	elements.lazyLoadWait.value = String(settings.lazyLoadWait);
	elements.pngSaveAs.value = String(settings.pngSaveAs);
	elements.pdfPageSize.value = settings.pdfPageSize;
	elements.pdfWatermark.checked = settings.pdfWatermark;
	elements.captureSound.checked = settings.captureSound;
	elements.captureCountdown.value = String(settings.captureCountdown);
	elements.skipStickyHeaders.checked = settings.skipStickyHeaders;
	elements.defaultExportFormat.value = settings.defaultExportFormat;
	elements.captureStamp.checked = settings.captureStamp;
	elements.ocrLanguage.value = settings.ocrLanguage;
	editorShortcuts = {
		...DEFAULT_EDITOR_SHORTCUTS,
		...settings.editorShortcuts || {}
	};
	renderShortcutRows();
	currentTheme = settings.theme;
	document.querySelectorAll("#themeSeg button").forEach((b) => {
		b.classList.toggle("active", b.dataset.themeChoice === currentTheme);
	});
	elements.uiLanguage.value = settings.language;
}
async function saveSettings() {
	const settings = {
		defaultAction: elements.defaultAction.value,
		captureDelay: parseInt(elements.captureDelay.value),
		lazyLoadWait: parseInt(elements.lazyLoadWait.value),
		pngSaveAs: elements.pngSaveAs.value === "true",
		pdfPageSize: elements.pdfPageSize.value,
		pdfWatermark: elements.pdfWatermark.checked,
		scrollPadding: 0,
		captureSound: elements.captureSound.checked,
		captureCountdown: parseInt(elements.captureCountdown.value),
		skipStickyHeaders: elements.skipStickyHeaders.checked,
		defaultExportFormat: elements.defaultExportFormat.value,
		editorShortcuts,
		captureStamp: elements.captureStamp.checked,
		theme: currentTheme,
		ocrLanguage: elements.ocrLanguage.value,
		language: elements.uiLanguage.value
	};
	await chrome.storage.sync.set({ settings });
	try {
		if (chrome.storage.local) await chrome.storage.local.set({ settings });
	} catch {}
	showSavedToast();
}
function showSavedToast() {
	elements.savedToast.classList.add("show");
	setTimeout(() => elements.savedToast.classList.remove("show"), 2e3);
}
var RESERVED_KEYS = /* @__PURE__ */ new Set([
	"escape",
	"enter",
	"delete",
	"backspace",
	"tab"
]);
function renderShortcutRows() {
	const container = document.getElementById("editorShortcutRows");
	if (!container) return;
	container.innerHTML = "";
	Object.keys(DEFAULT_EDITOR_SHORTCUTS).forEach((tool) => {
		const row = document.createElement("div");
		row.className = "shortcut-edit-row";
		const label = document.createElement("span");
		label.textContent = SHORTCUT_LABELS[tool] || tool;
		const keyBtn = document.createElement("button");
		keyBtn.className = "shortcut-key-btn";
		keyBtn.dataset.tool = tool;
		keyBtn.textContent = editorShortcuts[tool].toUpperCase();
		keyBtn.addEventListener("click", () => startListening(keyBtn, tool));
		row.appendChild(label);
		row.appendChild(keyBtn);
		container.appendChild(row);
	});
}
var cancelCurrentListen = null;
function startListening(btn, tool) {
	cancelCurrentListen?.();
	btn.classList.add("listening");
	btn.classList.remove("conflict");
	btn.textContent = "Press a key…";
	const handler = (e) => {
		e.preventDefault();
		e.stopPropagation();
		const key = e.key.toLowerCase();
		if (key === "escape") {
			cancelListening();
			return;
		}
		if (!/^[a-z0-9]$/.test(key) || RESERVED_KEYS.has(key)) {
			btn.classList.add("conflict");
			btn.textContent = "Use A-Z / 0-9";
			return;
		}
		const conflictTool = Object.keys(editorShortcuts).find((t) => t !== tool && editorShortcuts[t] === key);
		if (conflictTool) {
			btn.classList.add("conflict");
			btn.textContent = `Used by ${SHORTCUT_LABELS[conflictTool]}`;
			return;
		}
		editorShortcuts[tool] = key;
		cancelListening();
		saveSettings();
	};
	const clickAwayHandler = (e) => {
		if (e.target !== btn) cancelListening();
	};
	function cancelListening() {
		document.removeEventListener("keydown", handler, true);
		document.removeEventListener("click", clickAwayHandler, true);
		btn.classList.remove("listening", "conflict");
		btn.textContent = editorShortcuts[tool].toUpperCase();
		cancelCurrentListen = null;
	}
	cancelCurrentListen = cancelListening;
	document.addEventListener("keydown", handler, true);
	setTimeout(() => document.addEventListener("click", clickAwayHandler, true), 0);
}
document.querySelectorAll("#themeSeg button").forEach((b) => {
	b.addEventListener("click", () => {
		document.querySelectorAll("#themeSeg button").forEach((x) => x.classList.remove("active"));
		b.classList.add("active");
		currentTheme = b.dataset.themeChoice;
		saveSettings();
		applyTheme();
	});
});
document.getElementById("resetShortcutsBtn")?.addEventListener("click", () => {
	editorShortcuts = { ...DEFAULT_EDITOR_SHORTCUTS };
	renderShortcutRows();
	saveSettings();
});
[
	elements.defaultAction,
	elements.captureDelay,
	elements.lazyLoadWait,
	elements.pngSaveAs,
	elements.pdfPageSize,
	elements.pdfWatermark,
	elements.captureSound,
	elements.captureCountdown,
	elements.skipStickyHeaders,
	elements.defaultExportFormat,
	elements.captureStamp,
	elements.ocrLanguage,
	elements.uiLanguage
].forEach((el) => el.addEventListener("change", saveSettings));
loadSettings();
//#endregion
