//#region src/types.ts
var DEFAULT_SETTINGS = {
	defaultAction: "result-bar",
	pngSaveAs: false,
	pdfPageSize: "a4",
	pdfWatermark: false,
	captureDelay: 150,
	scrollPadding: 0,
	lazyLoadWait: 2e3,
	captureSound: true,
	captureCountdown: 0,
	skipStickyHeaders: false,
	defaultExportFormat: "png"
};
//#endregion
//#region src/settings/settings.ts
var elements = {
	defaultAction: document.getElementById("defaultAction"),
	captureDelay: document.getElementById("captureDelay"),
	lazyLoadWait: document.getElementById("lazyLoadWait"),
	pngSaveAs: document.getElementById("pngSaveAs"),
	pdfPageSize: document.getElementById("pdfPageSize"),
	pdfWatermark: document.getElementById("pdfWatermark"),
	captureSound: document.getElementById("captureSound"),
	captureCountdown: document.getElementById("captureCountdown"),
	skipStickyHeaders: document.getElementById("skipStickyHeaders"),
	defaultExportFormat: document.getElementById("defaultExportFormat"),
	savedToast: document.getElementById("savedToast")
};
async function loadSettings() {
	const stored = await chrome.storage.sync.get("settings");
	const settings = {
		...DEFAULT_SETTINGS,
		...stored.settings || {}
	};
	elements.defaultAction.value = settings.defaultAction;
	elements.captureDelay.value = String(settings.captureDelay);
	elements.lazyLoadWait.value = String(settings.lazyLoadWait);
	elements.pngSaveAs.value = String(settings.pngSaveAs);
	elements.pdfPageSize.value = settings.pdfPageSize;
	elements.pdfWatermark.checked = settings.pdfWatermark;
	elements.captureSound.checked = settings.captureSound;
	elements.captureCountdown.value = String(settings.captureCountdown);
	elements.skipStickyHeaders.checked = settings.skipStickyHeaders;
	elements.defaultExportFormat.value = settings.defaultExportFormat;
}
async function saveSettings() {
	const settings = {
		defaultAction: elements.defaultAction.value,
		captureDelay: parseInt(elements.captureDelay.value),
		lazyLoadWait: parseInt(elements.lazyLoadWait.value),
		pngSaveAs: elements.pngSaveAs.value === "true",
		pdfPageSize: elements.pdfPageSize.value,
		pdfWatermark: elements.pdfWatermark.checked,
		scrollPadding: 0,
		captureSound: elements.captureSound.checked,
		captureCountdown: parseInt(elements.captureCountdown.value),
		skipStickyHeaders: elements.skipStickyHeaders.checked,
		defaultExportFormat: elements.defaultExportFormat.value
	};
	await chrome.storage.sync.set({ settings });
	showSavedToast();
}
function showSavedToast() {
	elements.savedToast.classList.add("show");
	setTimeout(() => elements.savedToast.classList.remove("show"), 2e3);
}
[
	elements.defaultAction,
	elements.captureDelay,
	elements.lazyLoadWait,
	elements.pngSaveAs,
	elements.pdfPageSize,
	elements.pdfWatermark,
	elements.captureSound,
	elements.captureCountdown,
	elements.skipStickyHeaders,
	elements.defaultExportFormat
].forEach((el) => el.addEventListener("change", saveSettings));
loadSettings();
//#endregion
