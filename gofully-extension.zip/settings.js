//#region src/types.ts
var DEFAULT_SETTINGS = {
	defaultAction: "result-bar",
	pngSaveAs: false,
	pdfPageSize: "a4",
	pdfWatermark: false,
	captureDelay: 150,
	scrollPadding: 0,
	lazyLoadWait: 2e3
};
//#endregion
//#region src/settings/settings.ts
var elements = {
	defaultAction: document.getElementById("defaultAction"),
	captureDelay: document.getElementById("captureDelay"),
	lazyLoadWait: document.getElementById("lazyLoadWait"),
	pngSaveAs: document.getElementById("pngSaveAs"),
	pdfPageSize: document.getElementById("pdfPageSize"),
	pdfWatermark: document.getElementById("pdfWatermark"),
	savedToast: document.getElementById("savedToast")
};
async function loadSettings() {
	const stored = await chrome.storage.sync.get("settings");
	const settings = {
		...DEFAULT_SETTINGS,
		...stored.settings || {}
	};
	elements.defaultAction.value = settings.defaultAction;
	elements.captureDelay.value = String(settings.captureDelay);
	elements.lazyLoadWait.value = String(settings.lazyLoadWait);
	elements.pngSaveAs.value = String(settings.pngSaveAs);
	elements.pdfPageSize.value = settings.pdfPageSize;
	elements.pdfWatermark.checked = settings.pdfWatermark;
}
async function saveSettings() {
	const settings = {
		defaultAction: elements.defaultAction.value,
		captureDelay: parseInt(elements.captureDelay.value),
		lazyLoadWait: parseInt(elements.lazyLoadWait.value),
		pngSaveAs: elements.pngSaveAs.value === "true",
		pdfPageSize: elements.pdfPageSize.value,
		pdfWatermark: elements.pdfWatermark.checked,
		scrollPadding: 0
	};
	await chrome.storage.sync.set({ settings });
	showSavedToast();
}
function showSavedToast() {
	elements.savedToast.classList.add("show");
	setTimeout(() => elements.savedToast.classList.remove("show"), 2e3);
}
[
	elements.defaultAction,
	elements.captureDelay,
	elements.lazyLoadWait,
	elements.pngSaveAs,
	elements.pdfPageSize,
	elements.pdfWatermark
].forEach((el) => {
	el.addEventListener("change", saveSettings);
});
loadSettings();
//#endregion
