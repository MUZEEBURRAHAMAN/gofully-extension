(function() {
	//#region src/content/lazy-loader.ts
	async function preScrollForLazyContent(maxWait = 2e3) {
		const totalHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
		const viewportHeight = window.innerHeight;
		const steps = Math.ceil(totalHeight / viewportHeight);
		const originalX = window.scrollX;
		const originalY = window.scrollY;
		for (let i = 0; i <= steps; i++) {
			window.scrollTo(0, i * viewportHeight);
			await sleep(50);
		}
		window.scrollTo(originalX, originalY);
		await waitForNetworkIdle(maxWait);
	}
	function sleep(ms) {
		return new Promise((r) => setTimeout(r, ms));
	}
	async function waitForNetworkIdle(timeout) {
		return new Promise((resolve) => {
			let timer;
			let pending = 0;
			const observer = new PerformanceObserver((list) => {
				for (const entry of list.getEntries()) if (entry.entryType === "resource") {
					pending++;
					clearTimeout(timer);
					timer = setTimeout(() => {
						pending = 0;
						observer.disconnect();
						resolve();
					}, 500);
				}
			});
			try {
				observer.observe({ entryTypes: ["resource"] });
			} catch {}
			timer = setTimeout(() => {
				observer.disconnect();
				resolve();
			}, timeout);
		});
	}
	chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
		if (message.type === "PRE_SCROLL_LAZY") {
			preScrollForLazyContent(message.payload?.maxWait ?? 2e3).then(() => sendResponse({ done: true }));
			return true;
		}
		return false;
	});
	//#endregion
})();
