const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["chunks/html2canvas-DxQrDcbn.js","chunks/rolldown-runtime-CEgmsyvS.js","chunks/index.es-DJwz8Ydb.js"])))=>i.map(i=>d[i]);
import { o as __toESM } from "./rolldown-runtime-CEgmsyvS.js";
//#region node_modules/@babel/runtime/helpers/esm/typeof.js
function _typeof(o) {
	"@babel/helpers - typeof";
	return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof(o);
}
//#endregion
//#region node_modules/fflate/esm/browser.js
var u8 = Uint8Array;
var u16 = Uint16Array;
var i32 = Int32Array;
var fleb = new u8([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0,
	0,
	0,
	0
]);
var fdeb = new u8([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13,
	0,
	0
]);
var clim = new u8([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]);
var freb = function(eb, start) {
	var b = new u16(31);
	for (var i = 0; i < 31; ++i) b[i] = start += 1 << eb[i - 1];
	var r = new i32(b[30]);
	for (var i = 1; i < 30; ++i) for (var j = b[i]; j < b[i + 1]; ++j) r[j] = j - b[i] << 5 | i;
	return {
		b,
		r
	};
};
var _a = freb(fleb, 2);
var fl = _a.b;
var revfl = _a.r;
fl[28] = 258, revfl[258] = 28;
var _b = freb(fdeb, 0);
_b.b;
var revfd = _b.r;
var rev = new u16(32768);
for (var i$1 = 0; i$1 < 32768; ++i$1) {
	var x$1 = (i$1 & 43690) >> 1 | (i$1 & 21845) << 1;
	x$1 = (x$1 & 52428) >> 2 | (x$1 & 13107) << 2;
	x$1 = (x$1 & 61680) >> 4 | (x$1 & 3855) << 4;
	rev[i$1] = ((x$1 & 65280) >> 8 | (x$1 & 255) << 8) >> 1;
}
var hMap = (function(cd, mb, r) {
	var s = cd.length;
	var i = 0;
	var l = new u16(mb);
	for (; i < s; ++i) if (cd[i]) ++l[cd[i] - 1];
	var le = new u16(mb);
	for (i = 1; i < mb; ++i) le[i] = le[i - 1] + l[i - 1] << 1;
	var co;
	if (r) {
		co = new u16(1 << mb);
		var rvb = 15 - mb;
		for (i = 0; i < s; ++i) if (cd[i]) {
			var sv = i << 4 | cd[i];
			var r_1 = mb - cd[i];
			var v = le[cd[i] - 1]++ << r_1;
			for (var m = v | (1 << r_1) - 1; v <= m; ++v) co[rev[v] >> rvb] = sv;
		}
	} else {
		co = new u16(s);
		for (i = 0; i < s; ++i) if (cd[i]) co[i] = rev[le[cd[i] - 1]++] >> 15 - cd[i];
	}
	return co;
});
var flt = new u8(288);
for (var i$1 = 0; i$1 < 144; ++i$1) flt[i$1] = 8;
for (var i$1 = 144; i$1 < 256; ++i$1) flt[i$1] = 9;
for (var i$1 = 256; i$1 < 280; ++i$1) flt[i$1] = 7;
for (var i$1 = 280; i$1 < 288; ++i$1) flt[i$1] = 8;
var fdt = new u8(32);
for (var i$1 = 0; i$1 < 32; ++i$1) fdt[i$1] = 5;
var flm = /*#__PURE__*/ hMap(flt, 9, 0);
var fdm = /*#__PURE__*/ hMap(fdt, 5, 0);
var shft = function(p) {
	return (p + 7) / 8 | 0;
};
var slc = function(v, s, e) {
	if (s == null || s < 0) s = 0;
	if (e == null || e > v.length) e = v.length;
	return new u8(v.subarray(s, e));
};
var wbits = function(d, p, v) {
	v <<= p & 7;
	var o = p / 8 | 0;
	d[o] |= v;
	d[o + 1] |= v >> 8;
};
var wbits16 = function(d, p, v) {
	v <<= p & 7;
	var o = p / 8 | 0;
	d[o] |= v;
	d[o + 1] |= v >> 8;
	d[o + 2] |= v >> 16;
};
var hTree = function(d, mb) {
	var t = [];
	for (var i = 0; i < d.length; ++i) if (d[i]) t.push({
		s: i,
		f: d[i]
	});
	var s = t.length;
	var t2 = t.slice();
	if (!s) return {
		t: et$1,
		l: 0
	};
	if (s == 1) {
		var v = new u8(t[0].s + 1);
		v[t[0].s] = 1;
		return {
			t: v,
			l: 1
		};
	}
	t.sort(function(a, b) {
		return a.f - b.f;
	});
	t.push({
		s: -1,
		f: 25001
	});
	var l = t[0], r = t[1], i0 = 0, i1 = 1, i2 = 2;
	t[0] = {
		s: -1,
		f: l.f + r.f,
		l,
		r
	};
	while (i1 != s - 1) {
		l = t[t[i0].f < t[i2].f ? i0++ : i2++];
		r = t[i0 != i1 && t[i0].f < t[i2].f ? i0++ : i2++];
		t[i1++] = {
			s: -1,
			f: l.f + r.f,
			l,
			r
		};
	}
	var maxSym = t2[0].s;
	for (var i = 1; i < s; ++i) if (t2[i].s > maxSym) maxSym = t2[i].s;
	var tr = new u16(maxSym + 1);
	var mbt = ln(t[i1 - 1], tr, 0);
	if (mbt > mb) {
		var i = 0, dt = 0;
		var lft = mbt - mb, cst = 1 << lft;
		t2.sort(function(a, b) {
			return tr[b.s] - tr[a.s] || a.f - b.f;
		});
		for (; i < s; ++i) {
			var i2_1 = t2[i].s;
			if (tr[i2_1] > mb) {
				dt += cst - (1 << mbt - tr[i2_1]);
				tr[i2_1] = mb;
			} else break;
		}
		dt >>= lft;
		while (dt > 0) {
			var i2_2 = t2[i].s;
			if (tr[i2_2] < mb) dt -= 1 << mb - tr[i2_2]++ - 1;
			else ++i;
		}
		for (; i >= 0 && dt; --i) {
			var i2_3 = t2[i].s;
			if (tr[i2_3] == mb) {
				--tr[i2_3];
				++dt;
			}
		}
		mbt = mb;
	}
	return {
		t: new u8(tr),
		l: mbt
	};
};
var ln = function(n, l, d) {
	return n.s == -1 ? Math.max(ln(n.l, l, d + 1), ln(n.r, l, d + 1)) : l[n.s] = d;
};
var lc = function(c) {
	var s = c.length;
	while (s && !c[--s]);
	var cl = new u16(++s);
	var cli = 0, cln = c[0], cls = 1;
	var w = function(v) {
		cl[cli++] = v;
	};
	for (var i = 1; i <= s; ++i) if (c[i] == cln && i != s) ++cls;
	else {
		if (!cln && cls > 2) {
			for (; cls > 138; cls -= 138) w(32754);
			if (cls > 2) {
				w(cls > 10 ? cls - 11 << 5 | 28690 : cls - 3 << 5 | 12305);
				cls = 0;
			}
		} else if (cls > 3) {
			w(cln), --cls;
			for (; cls > 6; cls -= 6) w(8304);
			if (cls > 2) w(cls - 3 << 5 | 8208), cls = 0;
		}
		while (cls--) w(cln);
		cls = 1;
		cln = c[i];
	}
	return {
		c: cl.subarray(0, cli),
		n: s
	};
};
var clen = function(cf, cl) {
	var l = 0;
	for (var i = 0; i < cl.length; ++i) l += cf[i] * cl[i];
	return l;
};
var wfblk = function(out, pos, dat) {
	var s = dat.length;
	var o = shft(pos + 2);
	out[o] = s & 255;
	out[o + 1] = s >> 8;
	out[o + 2] = out[o] ^ 255;
	out[o + 3] = out[o + 1] ^ 255;
	for (var i = 0; i < s; ++i) out[o + i + 4] = dat[i];
	return (o + 4 + s) * 8;
};
var wblk = function(dat, out, final, syms, lf, df, eb, li, bs, bl, p) {
	wbits(out, p++, final);
	++lf[256];
	var _a = hTree(lf, 15), dlt = _a.t, mlb = _a.l;
	var _b = hTree(df, 15), ddt = _b.t, mdb = _b.l;
	var _c = lc(dlt), lclt = _c.c, nlc = _c.n;
	var _d = lc(ddt), lcdt = _d.c, ndc = _d.n;
	var lcfreq = new u16(19);
	for (var i = 0; i < lclt.length; ++i) ++lcfreq[lclt[i] & 31];
	for (var i = 0; i < lcdt.length; ++i) ++lcfreq[lcdt[i] & 31];
	var _e = hTree(lcfreq, 7), lct = _e.t, mlcb = _e.l;
	var nlcc = 19;
	for (; nlcc > 4 && !lct[clim[nlcc - 1]]; --nlcc);
	var flen = bl + 5 << 3;
	var ftlen = clen(lf, flt) + clen(df, fdt) + eb;
	var dtlen = clen(lf, dlt) + clen(df, ddt) + eb + 14 + 3 * nlcc + clen(lcfreq, lct) + 2 * lcfreq[16] + 3 * lcfreq[17] + 7 * lcfreq[18];
	if (bs >= 0 && flen <= ftlen && flen <= dtlen) return wfblk(out, p, dat.subarray(bs, bs + bl));
	var lm, ll, dm, dl;
	wbits(out, p, 1 + (dtlen < ftlen)), p += 2;
	if (dtlen < ftlen) {
		lm = hMap(dlt, mlb, 0), ll = dlt, dm = hMap(ddt, mdb, 0), dl = ddt;
		var llm = hMap(lct, mlcb, 0);
		wbits(out, p, nlc - 257);
		wbits(out, p + 5, ndc - 1);
		wbits(out, p + 10, nlcc - 4);
		p += 14;
		for (var i = 0; i < nlcc; ++i) wbits(out, p + 3 * i, lct[clim[i]]);
		p += 3 * nlcc;
		var lcts = [lclt, lcdt];
		for (var it = 0; it < 2; ++it) {
			var clct = lcts[it];
			for (var i = 0; i < clct.length; ++i) {
				var len = clct[i] & 31;
				wbits(out, p, llm[len]), p += lct[len];
				if (len > 15) wbits(out, p, clct[i] >> 5 & 127), p += clct[i] >> 12;
			}
		}
	} else lm = flm, ll = flt, dm = fdm, dl = fdt;
	for (var i = 0; i < li; ++i) {
		var sym = syms[i];
		if (sym > 255) {
			var len = sym >> 18 & 31;
			wbits16(out, p, lm[len + 257]), p += ll[len + 257];
			if (len > 7) wbits(out, p, sym >> 23 & 31), p += fleb[len];
			var dst = sym & 31;
			wbits16(out, p, dm[dst]), p += dl[dst];
			if (dst > 3) wbits16(out, p, sym >> 5 & 8191), p += fdeb[dst];
		} else wbits16(out, p, lm[sym]), p += ll[sym];
	}
	wbits16(out, p, lm[256]);
	return p + ll[256];
};
var deo = /*#__PURE__*/ new i32([
	65540,
	131080,
	131088,
	131104,
	262176,
	1048704,
	1048832,
	2114560,
	2117632
]);
var et$1 = /*#__PURE__*/ new u8(0);
var dflt = function(dat, lvl, plvl, pre, post, st) {
	var s = st.z || dat.length;
	var o = new u8(pre + s + 5 * (1 + Math.ceil(s / 7e3)) + post);
	var w = o.subarray(pre, o.length - post);
	var lst = st.l;
	var pos = (st.r || 0) & 7;
	if (lvl) {
		if (pos) w[0] = st.r >> 3;
		var opt = deo[lvl - 1];
		var n = opt >> 13, c = opt & 8191;
		var msk_1 = (1 << plvl) - 1;
		var prev = st.p || new u16(32768), head = st.h || new u16(msk_1 + 1);
		var bs1_1 = Math.ceil(plvl / 3), bs2_1 = 2 * bs1_1;
		var hsh = function(i) {
			return (dat[i] ^ dat[i + 1] << bs1_1 ^ dat[i + 2] << bs2_1) & msk_1;
		};
		var syms = new i32(25e3);
		var lf = new u16(288), df = new u16(32);
		var lc_1 = 0, eb = 0, i = st.i || 0, li = 0, wi = st.w || 0, bs = 0;
		for (; i + 2 < s; ++i) {
			var hv = hsh(i);
			var imod = i & 32767, pimod = head[hv];
			prev[imod] = pimod;
			head[hv] = imod;
			if (wi <= i) {
				var rem = s - i;
				if ((lc_1 > 7e3 || li > 24576) && (rem > 423 || !lst)) {
					pos = wblk(dat, w, 0, syms, lf, df, eb, li, bs, i - bs, pos);
					li = lc_1 = eb = 0, bs = i;
					for (var j = 0; j < 286; ++j) lf[j] = 0;
					for (var j = 0; j < 30; ++j) df[j] = 0;
				}
				var l = 2, d = 0, ch_1 = c, dif = imod - pimod & 32767;
				if (rem > 2 && hv == hsh(i - dif)) {
					var maxn = Math.min(n, rem) - 1;
					var maxd = Math.min(32767, i);
					var ml = Math.min(258, rem);
					while (dif <= maxd && --ch_1 && imod != pimod) {
						if (dat[i + l] == dat[i + l - dif]) {
							var nl = 0;
							for (; nl < ml && dat[i + nl] == dat[i + nl - dif]; ++nl);
							if (nl > l) {
								l = nl, d = dif;
								if (nl > maxn) break;
								var mmd = Math.min(dif, nl - 2);
								var md = 0;
								for (var j = 0; j < mmd; ++j) {
									var ti = i - dif + j & 32767;
									var cd = ti - prev[ti] & 32767;
									if (cd > md) md = cd, pimod = ti;
								}
							}
						}
						imod = pimod, pimod = prev[imod];
						dif += imod - pimod & 32767;
					}
				}
				if (d) {
					syms[li++] = 268435456 | revfl[l] << 18 | revfd[d];
					var lin = revfl[l] & 31, din = revfd[d] & 31;
					eb += fleb[lin] + fdeb[din];
					++lf[257 + lin];
					++df[din];
					wi = i + l;
					++lc_1;
				} else {
					syms[li++] = dat[i];
					++lf[dat[i]];
				}
			}
		}
		for (i = Math.max(i, wi); i < s; ++i) {
			syms[li++] = dat[i];
			++lf[dat[i]];
		}
		pos = wblk(dat, w, lst, syms, lf, df, eb, li, bs, i - bs, pos);
		if (!lst) {
			st.r = pos & 7 | w[pos / 8 | 0] << 3;
			pos -= 7;
			st.h = head, st.p = prev, st.i = i, st.w = wi;
		}
	} else {
		for (var i = st.w || 0; i < s + lst; i += 65535) {
			var e = i + 65535;
			if (e >= s) {
				w[pos / 8 | 0] = lst;
				e = s;
			}
			pos = wfblk(w, pos + 1, dat.subarray(i, e));
		}
		st.i = s;
	}
	return slc(o, 0, pre + shft(pos) + post);
};
var adler = function() {
	var a = 1, b = 0;
	return {
		p: function(d) {
			var n = a, m = b;
			var l = d.length | 0;
			for (var i = 0; i != l;) {
				var e = Math.min(i + 2655, l);
				for (; i < e; ++i) m += n += d[i];
				n = (n & 65535) + 15 * (n >> 16), m = (m & 65535) + 15 * (m >> 16);
			}
			a = n, b = m;
		},
		d: function() {
			a %= 65521, b %= 65521;
			return (a & 255) << 24 | (a & 65280) << 8 | (b & 255) << 8 | b >> 8;
		}
	};
};
var dopt = function(dat, opt, pre, post, st) {
	if (!st) {
		st = { l: 1 };
		if (opt.dictionary) {
			var dict = opt.dictionary.subarray(-32768);
			var newDat = new u8(dict.length + dat.length);
			newDat.set(dict);
			newDat.set(dat, dict.length);
			dat = newDat;
			st.w = dict.length;
		}
	}
	return dflt(dat, opt.level == null ? 6 : opt.level, opt.mem == null ? st.l ? Math.ceil(Math.max(8, Math.min(13, Math.log(dat.length))) * 1.5) : 20 : 12 + opt.mem, pre, post, st);
};
var wbytes = function(d, b, v) {
	for (; v; ++b) d[b] = v, v >>>= 8;
};
var zlh = function(c, o) {
	var lv = o.level, fl = lv == 0 ? 0 : lv < 6 ? 1 : lv == 9 ? 3 : 2;
	c[0] = 120, c[1] = fl << 6 | (o.dictionary && 32);
	c[1] |= 31 - (c[0] << 8 | c[1]) % 31;
	if (o.dictionary) {
		var h = adler();
		h.p(o.dictionary);
		wbytes(c, 2, h.d());
	}
};
/**
* Compress data with Zlib
* @param data The data to compress
* @param opts The compression options
* @returns The zlib-compressed version of the data
*/
function zlibSync(data, opts) {
	if (!opts) opts = {};
	var a = adler();
	a.p(data);
	var d = dopt(data, opts, opts.dictionary ? 6 : 2, 4);
	return zlh(d, opts), wbytes(d, d.length - 4, a.d()), d;
}
var td = typeof TextDecoder != "undefined" && /*#__PURE__*/ new TextDecoder();
try {
	td.decode(et$1, { stream: true });
} catch (e) {}
//#endregion
//#region node_modules/@babel/runtime/helpers/esm/arrayWithHoles.js
function _arrayWithHoles(r) {
	if (Array.isArray(r)) return r;
}
//#endregion
//#region node_modules/@babel/runtime/helpers/esm/iterableToArrayLimit.js
function _iterableToArrayLimit(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = !0, o = !1;
		try {
			if (i = (t = t.call(r)).next, 0 === l) {
				if (Object(t) !== t) return;
				f = !1;
			} else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = !0, n = r;
		} finally {
			try {
				if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
//#endregion
//#region node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js
function _arrayLikeToArray(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
//#endregion
//#region node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js
function _unsupportedIterableToArray(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
	}
}
//#endregion
//#region node_modules/@babel/runtime/helpers/esm/nonIterableRest.js
function _nonIterableRest() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
//#endregion
//#region node_modules/@babel/runtime/helpers/esm/slicedToArray.js
function _slicedToArray(r, e) {
	return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
}
//#endregion
//#region node_modules/iobuffer/lib-esm/text.js
function decode(bytes, encoding = "utf8") {
	return new TextDecoder(encoding).decode(bytes);
}
var encoder = new TextEncoder();
function encode(str) {
	return encoder.encode(str);
}
//#endregion
//#region node_modules/iobuffer/lib-esm/IOBuffer.js
var defaultByteLength = 8192;
var hostBigEndian = (() => {
	const array = /* @__PURE__ */ new Uint8Array(4);
	const view = new Uint32Array(array.buffer);
	return !((view[0] = 1) & array[0]);
})();
var typedArrays = {
	int8: globalThis.Int8Array,
	uint8: globalThis.Uint8Array,
	int16: globalThis.Int16Array,
	uint16: globalThis.Uint16Array,
	int32: globalThis.Int32Array,
	uint32: globalThis.Uint32Array,
	uint64: globalThis.BigUint64Array,
	int64: globalThis.BigInt64Array,
	float32: globalThis.Float32Array,
	float64: globalThis.Float64Array
};
var IOBuffer = class IOBuffer {
	/**
	* Reference to the internal ArrayBuffer object.
	*/
	buffer;
	/**
	* Byte length of the internal ArrayBuffer.
	*/
	byteLength;
	/**
	* Byte offset of the internal ArrayBuffer.
	*/
	byteOffset;
	/**
	* Byte length of the internal ArrayBuffer.
	*/
	length;
	/**
	* The current offset of the buffer's pointer.
	*/
	offset;
	lastWrittenByte;
	littleEndian;
	_data;
	_mark;
	_marks;
	/**
	* Create a new IOBuffer.
	* @param data - The data to construct the IOBuffer with.
	* If data is a number, it will be the new buffer's length<br>
	* If data is `undefined`, the buffer will be initialized with a default length of 8Kb<br>
	* If data is an ArrayBuffer, SharedArrayBuffer, an ArrayBufferView (Typed Array), an IOBuffer instance,
	* or a Node.js Buffer, a view will be created over the underlying ArrayBuffer.
	* @param options - An object for the options.
	* @returns A new IOBuffer instance.
	*/
	constructor(data = defaultByteLength, options = {}) {
		let dataIsGiven = false;
		if (typeof data === "number") data = new ArrayBuffer(data);
		else {
			dataIsGiven = true;
			this.lastWrittenByte = data.byteLength;
		}
		const offset = options.offset ? options.offset >>> 0 : 0;
		const byteLength = data.byteLength - offset;
		let dvOffset = offset;
		if (ArrayBuffer.isView(data) || data instanceof IOBuffer) {
			if (data.byteLength !== data.buffer.byteLength) dvOffset = data.byteOffset + offset;
			data = data.buffer;
		}
		if (dataIsGiven) this.lastWrittenByte = byteLength;
		else this.lastWrittenByte = 0;
		this.buffer = data;
		this.length = byteLength;
		this.byteLength = byteLength;
		this.byteOffset = dvOffset;
		this.offset = 0;
		this.littleEndian = true;
		this._data = new DataView(this.buffer, dvOffset, byteLength);
		this._mark = 0;
		this._marks = [];
	}
	/**
	* Checks if the memory allocated to the buffer is sufficient to store more
	* bytes after the offset.
	* @param byteLength - The needed memory in bytes.
	* @returns `true` if there is sufficient space and `false` otherwise.
	*/
	available(byteLength = 1) {
		return this.offset + byteLength <= this.length;
	}
	/**
	* Check if little-endian mode is used for reading and writing multi-byte
	* values.
	* @returns `true` if little-endian mode is used, `false` otherwise.
	*/
	isLittleEndian() {
		return this.littleEndian;
	}
	/**
	* Set little-endian mode for reading and writing multi-byte values.
	* @returns This.
	*/
	setLittleEndian() {
		this.littleEndian = true;
		return this;
	}
	/**
	* Check if big-endian mode is used for reading and writing multi-byte values.
	* @returns `true` if big-endian mode is used, `false` otherwise.
	*/
	isBigEndian() {
		return !this.littleEndian;
	}
	/**
	* Switches to big-endian mode for reading and writing multi-byte values.
	* @returns This.
	*/
	setBigEndian() {
		this.littleEndian = false;
		return this;
	}
	/**
	* Move the pointer n bytes forward.
	* @param n - Number of bytes to skip.
	* @returns This.
	*/
	skip(n = 1) {
		this.offset += n;
		return this;
	}
	/**
	* Move the pointer n bytes backward.
	* @param n - Number of bytes to move back.
	* @returns This.
	*/
	back(n = 1) {
		this.offset -= n;
		return this;
	}
	/**
	* Move the pointer to the given offset.
	* @param offset - The offset to move to.
	* @returns This.
	*/
	seek(offset) {
		this.offset = offset;
		return this;
	}
	/**
	* Store the current pointer offset.
	* @see {@link IOBuffer#reset}
	* @returns This.
	*/
	mark() {
		this._mark = this.offset;
		return this;
	}
	/**
	* Move the pointer back to the last pointer offset set by mark.
	* @see {@link IOBuffer#mark}
	* @returns This.
	*/
	reset() {
		this.offset = this._mark;
		return this;
	}
	/**
	* Push the current pointer offset to the mark stack.
	* @see {@link IOBuffer#popMark}
	* @returns This.
	*/
	pushMark() {
		this._marks.push(this.offset);
		return this;
	}
	/**
	* Pop the last pointer offset from the mark stack, and set the current
	* pointer offset to the popped value.
	* @see {@link IOBuffer#pushMark}
	* @returns This.
	*/
	popMark() {
		const offset = this._marks.pop();
		if (offset === void 0) throw new Error("Mark stack empty");
		this.seek(offset);
		return this;
	}
	/**
	* Move the pointer offset back to 0.
	* @returns This.
	*/
	rewind() {
		this.offset = 0;
		return this;
	}
	/**
	* Make sure the buffer has sufficient memory to write a given byteLength at
	* the current pointer offset.
	* If the buffer's memory is insufficient, this method will create a new
	* buffer (a copy) with a length that is twice (byteLength + current offset).
	* @param byteLength - The needed memory in bytes.
	* @returns This.
	*/
	ensureAvailable(byteLength = 1) {
		if (!this.available(byteLength)) {
			const newLength = (this.offset + byteLength) * 2;
			const newArray = new Uint8Array(newLength);
			newArray.set(new Uint8Array(this.buffer));
			this.buffer = newArray.buffer;
			this.length = newLength;
			this.byteLength = newLength;
			this._data = new DataView(this.buffer);
		}
		return this;
	}
	/**
	* Read a byte and return false if the byte's value is 0, or true otherwise.
	* Moves pointer forward by one byte.
	* @returns The read boolean.
	*/
	readBoolean() {
		return this.readUint8() !== 0;
	}
	/**
	* Read a signed 8-bit integer and move pointer forward by 1 byte.
	* @returns The read byte.
	*/
	readInt8() {
		return this._data.getInt8(this.offset++);
	}
	/**
	* Read an unsigned 8-bit integer and move pointer forward by 1 byte.
	* @returns The read byte.
	*/
	readUint8() {
		return this._data.getUint8(this.offset++);
	}
	/**
	* Alias for {@link IOBuffer#readUint8}.
	* @returns The read byte.
	*/
	readByte() {
		return this.readUint8();
	}
	/**
	* Read `n` bytes and move pointer forward by `n` bytes.
	* @param n - Number of bytes to read.
	* @returns The read bytes.
	*/
	readBytes(n = 1) {
		return this.readArray(n, "uint8");
	}
	/**
	* Creates an array of corresponding to the type `type` and size `size`.
	* For example type `uint8` will create a `Uint8Array`.
	* @param size - size of the resulting array
	* @param type - number type of elements to read
	* @returns The read array.
	*/
	readArray(size, type) {
		const bytes = typedArrays[type].BYTES_PER_ELEMENT * size;
		const offset = this.byteOffset + this.offset;
		const slice = this.buffer.slice(offset, offset + bytes);
		if (this.littleEndian === hostBigEndian && type !== "uint8" && type !== "int8") {
			const slice = new Uint8Array(this.buffer.slice(offset, offset + bytes));
			slice.reverse();
			const returnArray = new typedArrays[type](slice.buffer);
			this.offset += bytes;
			returnArray.reverse();
			return returnArray;
		}
		const returnArray = new typedArrays[type](slice);
		this.offset += bytes;
		return returnArray;
	}
	/**
	* Read a 16-bit signed integer and move pointer forward by 2 bytes.
	* @returns The read value.
	*/
	readInt16() {
		const value = this._data.getInt16(this.offset, this.littleEndian);
		this.offset += 2;
		return value;
	}
	/**
	* Read a 16-bit unsigned integer and move pointer forward by 2 bytes.
	* @returns The read value.
	*/
	readUint16() {
		const value = this._data.getUint16(this.offset, this.littleEndian);
		this.offset += 2;
		return value;
	}
	/**
	* Read a 32-bit signed integer and move pointer forward by 4 bytes.
	* @returns The read value.
	*/
	readInt32() {
		const value = this._data.getInt32(this.offset, this.littleEndian);
		this.offset += 4;
		return value;
	}
	/**
	* Read a 32-bit unsigned integer and move pointer forward by 4 bytes.
	* @returns The read value.
	*/
	readUint32() {
		const value = this._data.getUint32(this.offset, this.littleEndian);
		this.offset += 4;
		return value;
	}
	/**
	* Read a 32-bit floating number and move pointer forward by 4 bytes.
	* @returns The read value.
	*/
	readFloat32() {
		const value = this._data.getFloat32(this.offset, this.littleEndian);
		this.offset += 4;
		return value;
	}
	/**
	* Read a 64-bit floating number and move pointer forward by 8 bytes.
	* @returns The read value.
	*/
	readFloat64() {
		const value = this._data.getFloat64(this.offset, this.littleEndian);
		this.offset += 8;
		return value;
	}
	/**
	* Read a 64-bit signed integer number and move pointer forward by 8 bytes.
	* @returns The read value.
	*/
	readBigInt64() {
		const value = this._data.getBigInt64(this.offset, this.littleEndian);
		this.offset += 8;
		return value;
	}
	/**
	* Read a 64-bit unsigned integer number and move pointer forward by 8 bytes.
	* @returns The read value.
	*/
	readBigUint64() {
		const value = this._data.getBigUint64(this.offset, this.littleEndian);
		this.offset += 8;
		return value;
	}
	/**
	* Read a 1-byte ASCII character and move pointer forward by 1 byte.
	* @returns The read character.
	*/
	readChar() {
		return String.fromCharCode(this.readInt8());
	}
	/**
	* Read `n` 1-byte ASCII characters and move pointer forward by `n` bytes.
	* @param n - Number of characters to read.
	* @returns The read characters.
	*/
	readChars(n = 1) {
		let result = "";
		for (let i = 0; i < n; i++) result += this.readChar();
		return result;
	}
	/**
	* Read the next `n` bytes, return a UTF-8 decoded string and move pointer
	* forward by `n` bytes.
	* @param n - Number of bytes to read.
	* @returns The decoded string.
	*/
	readUtf8(n = 1) {
		return decode(this.readBytes(n));
	}
	/**
	* Read the next `n` bytes, return a string decoded with `encoding` and move pointer
	* forward by `n` bytes.
	* If no encoding is passed, the function is equivalent to @see {@link IOBuffer#readUtf8}
	* @param n - Number of bytes to read.
	* @param encoding - The encoding to use. Default is 'utf8'.
	* @returns The decoded string.
	*/
	decodeText(n = 1, encoding = "utf8") {
		return decode(this.readBytes(n), encoding);
	}
	/**
	* Write 0xff if the passed value is truthy, 0x00 otherwise and move pointer
	* forward by 1 byte.
	* @param value - The value to write.
	* @returns This.
	*/
	writeBoolean(value) {
		this.writeUint8(value ? 255 : 0);
		return this;
	}
	/**
	* Write `value` as an 8-bit signed integer and move pointer forward by 1 byte.
	* @param value - The value to write.
	* @returns This.
	*/
	writeInt8(value) {
		this.ensureAvailable(1);
		this._data.setInt8(this.offset++, value);
		this._updateLastWrittenByte();
		return this;
	}
	/**
	* Write `value` as an 8-bit unsigned integer and move pointer forward by 1
	* byte.
	* @param value - The value to write.
	* @returns This.
	*/
	writeUint8(value) {
		this.ensureAvailable(1);
		this._data.setUint8(this.offset++, value);
		this._updateLastWrittenByte();
		return this;
	}
	/**
	* An alias for {@link IOBuffer#writeUint8}.
	* @param value - The value to write.
	* @returns This.
	*/
	writeByte(value) {
		return this.writeUint8(value);
	}
	/**
	* Write all elements of `bytes` as uint8 values and move pointer forward by
	* `bytes.length` bytes.
	* @param bytes - The array of bytes to write.
	* @returns This.
	*/
	writeBytes(bytes) {
		this.ensureAvailable(bytes.length);
		for (let i = 0; i < bytes.length; i++) this._data.setUint8(this.offset++, bytes[i]);
		this._updateLastWrittenByte();
		return this;
	}
	/**
	* Write `value` as a 16-bit signed integer and move pointer forward by 2
	* bytes.
	* @param value - The value to write.
	* @returns This.
	*/
	writeInt16(value) {
		this.ensureAvailable(2);
		this._data.setInt16(this.offset, value, this.littleEndian);
		this.offset += 2;
		this._updateLastWrittenByte();
		return this;
	}
	/**
	* Write `value` as a 16-bit unsigned integer and move pointer forward by 2
	* bytes.
	* @param value - The value to write.
	* @returns This.
	*/
	writeUint16(value) {
		this.ensureAvailable(2);
		this._data.setUint16(this.offset, value, this.littleEndian);
		this.offset += 2;
		this._updateLastWrittenByte();
		return this;
	}
	/**
	* Write `value` as a 32-bit signed integer and move pointer forward by 4
	* bytes.
	* @param value - The value to write.
	* @returns This.
	*/
	writeInt32(value) {
		this.ensureAvailable(4);
		this._data.setInt32(this.offset, value, this.littleEndian);
		this.offset += 4;
		this._updateLastWrittenByte();
		return this;
	}
	/**
	* Write `value` as a 32-bit unsigned integer and move pointer forward by 4
	* bytes.
	* @param value - The value to write.
	* @returns This.
	*/
	writeUint32(value) {
		this.ensureAvailable(4);
		this._data.setUint32(this.offset, value, this.littleEndian);
		this.offset += 4;
		this._updateLastWrittenByte();
		return this;
	}
	/**
	* Write `value` as a 32-bit floating number and move pointer forward by 4
	* bytes.
	* @param value - The value to write.
	* @returns This.
	*/
	writeFloat32(value) {
		this.ensureAvailable(4);
		this._data.setFloat32(this.offset, value, this.littleEndian);
		this.offset += 4;
		this._updateLastWrittenByte();
		return this;
	}
	/**
	* Write `value` as a 64-bit floating number and move pointer forward by 8
	* bytes.
	* @param value - The value to write.
	* @returns This.
	*/
	writeFloat64(value) {
		this.ensureAvailable(8);
		this._data.setFloat64(this.offset, value, this.littleEndian);
		this.offset += 8;
		this._updateLastWrittenByte();
		return this;
	}
	/**
	* Write `value` as a 64-bit signed bigint and move pointer forward by 8
	* bytes.
	* @param value - The value to write.
	* @returns This.
	*/
	writeBigInt64(value) {
		this.ensureAvailable(8);
		this._data.setBigInt64(this.offset, value, this.littleEndian);
		this.offset += 8;
		this._updateLastWrittenByte();
		return this;
	}
	/**
	* Write `value` as a 64-bit unsigned bigint and move pointer forward by 8
	* bytes.
	* @param value - The value to write.
	* @returns This.
	*/
	writeBigUint64(value) {
		this.ensureAvailable(8);
		this._data.setBigUint64(this.offset, value, this.littleEndian);
		this.offset += 8;
		this._updateLastWrittenByte();
		return this;
	}
	/**
	* Write the charCode of `str`'s first character as an 8-bit unsigned integer
	* and move pointer forward by 1 byte.
	* @param str - The character to write.
	* @returns This.
	*/
	writeChar(str) {
		return this.writeUint8(str.charCodeAt(0));
	}
	/**
	* Write the charCodes of all `str`'s characters as 8-bit unsigned integers
	* and move pointer forward by `str.length` bytes.
	* @param str - The characters to write.
	* @returns This.
	*/
	writeChars(str) {
		for (let i = 0; i < str.length; i++) this.writeUint8(str.charCodeAt(i));
		return this;
	}
	/**
	* UTF-8 encode and write `str` to the current pointer offset and move pointer
	* forward according to the encoded length.
	* @param str - The string to write.
	* @returns This.
	*/
	writeUtf8(str) {
		return this.writeBytes(encode(str));
	}
	/**
	* Export a Uint8Array view of the internal buffer.
	* The view starts at the byte offset and its length
	* is calculated to stop at the last written byte or the original length.
	* @returns A new Uint8Array view.
	*/
	toArray() {
		return new Uint8Array(this.buffer, this.byteOffset, this.lastWrittenByte);
	}
	/**
	*  Get the total number of bytes written so far, regardless of the current offset.
	* @returns - Total number of bytes.
	*/
	getWrittenByteLength() {
		return this.lastWrittenByte - this.byteOffset;
	}
	/**
	* Update the last written byte offset
	* @private
	*/
	_updateLastWrittenByte() {
		if (this.offset > this.lastWrittenByte) this.lastWrittenByte = this.offset;
	}
};
//#endregion
//#region node_modules/pako/dist/pako.esm.mjs
/*! pako 2.2.0 https://github.com/nodeca/pako @license (MIT AND Zlib) */
var Z_FIXED$1 = 4;
var Z_BINARY = 0;
var Z_TEXT = 1;
var Z_UNKNOWN$1 = 2;
function zero$1(buf) {
	let len = buf.length;
	while (--len >= 0) buf[len] = 0;
}
var LENGTH_CODES$1 = 29;
var LITERALS$1 = 256;
var L_CODES$1 = 286;
var D_CODES$1 = 30;
var BL_CODES$1 = 19;
var HEAP_SIZE$1 = 573;
var MAX_BITS$1 = 15;
var Buf_size = 16;
var MAX_BL_BITS = 7;
var END_BLOCK = 256;
var REP_3_6 = 16;
var REPZ_3_10 = 17;
var REPZ_11_138 = 18;
var extra_lbits = new Uint8Array([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0
]);
var extra_dbits = new Uint8Array([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13
]);
var extra_blbits = new Uint8Array([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2,
	3,
	7
]);
var bl_order = new Uint8Array([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]);
var DIST_CODE_LEN = 512;
var static_ltree = new Array(576);
zero$1(static_ltree);
var static_dtree = new Array(60);
zero$1(static_dtree);
var _dist_code = new Array(DIST_CODE_LEN);
zero$1(_dist_code);
var _length_code = new Array(256);
zero$1(_length_code);
var base_length = new Array(LENGTH_CODES$1);
zero$1(base_length);
var base_dist = new Array(D_CODES$1);
zero$1(base_dist);
function StaticTreeDesc(static_tree, extra_bits, extra_base, elems, max_length) {
	this.static_tree = static_tree;
	this.extra_bits = extra_bits;
	this.extra_base = extra_base;
	this.elems = elems;
	this.max_length = max_length;
	this.has_stree = static_tree && static_tree.length;
}
var static_l_desc;
var static_d_desc;
var static_bl_desc;
function TreeDesc(dyn_tree, stat_desc) {
	this.dyn_tree = dyn_tree;
	this.max_code = 0;
	this.stat_desc = stat_desc;
}
var d_code = (dist) => {
	return dist < 256 ? _dist_code[dist] : _dist_code[256 + (dist >>> 7)];
};
var put_short = (s, w) => {
	s.pending_buf[s.pending++] = w & 255;
	s.pending_buf[s.pending++] = w >>> 8 & 255;
};
var send_bits = (s, value, length) => {
	if (s.bi_valid > Buf_size - length) {
		s.bi_buf |= value << s.bi_valid & 65535;
		put_short(s, s.bi_buf);
		s.bi_buf = value >> Buf_size - s.bi_valid;
		s.bi_valid += length - Buf_size;
	} else {
		s.bi_buf |= value << s.bi_valid & 65535;
		s.bi_valid += length;
	}
};
var send_code = (s, c, tree) => {
	send_bits(s, tree[c * 2], tree[c * 2 + 1]);
};
var bi_reverse = (code, len) => {
	let res = 0;
	do {
		res |= code & 1;
		code >>>= 1;
		res <<= 1;
	} while (--len > 0);
	return res >>> 1;
};
var bi_flush = (s) => {
	if (s.bi_valid === 16) {
		put_short(s, s.bi_buf);
		s.bi_buf = 0;
		s.bi_valid = 0;
	} else if (s.bi_valid >= 8) {
		s.pending_buf[s.pending++] = s.bi_buf & 255;
		s.bi_buf >>= 8;
		s.bi_valid -= 8;
	}
};
var gen_bitlen = (s, desc) => {
	const tree = desc.dyn_tree;
	const max_code = desc.max_code;
	const stree = desc.stat_desc.static_tree;
	const has_stree = desc.stat_desc.has_stree;
	const extra = desc.stat_desc.extra_bits;
	const base = desc.stat_desc.extra_base;
	const max_length = desc.stat_desc.max_length;
	let h;
	let n, m;
	let bits;
	let xbits;
	let f;
	let overflow = 0;
	for (bits = 0; bits <= MAX_BITS$1; bits++) s.bl_count[bits] = 0;
	tree[s.heap[s.heap_max] * 2 + 1] = 0;
	for (h = s.heap_max + 1; h < HEAP_SIZE$1; h++) {
		n = s.heap[h];
		bits = tree[tree[n * 2 + 1] * 2 + 1] + 1;
		if (bits > max_length) {
			bits = max_length;
			overflow++;
		}
		tree[n * 2 + 1] = bits;
		if (n > max_code) continue;
		s.bl_count[bits]++;
		xbits = 0;
		if (n >= base) xbits = extra[n - base];
		f = tree[n * 2];
		s.opt_len += f * (bits + xbits);
		if (has_stree) s.static_len += f * (stree[n * 2 + 1] + xbits);
	}
	if (overflow === 0) return;
	do {
		bits = max_length - 1;
		while (s.bl_count[bits] === 0) bits--;
		s.bl_count[bits]--;
		s.bl_count[bits + 1] += 2;
		s.bl_count[max_length]--;
		overflow -= 2;
	} while (overflow > 0);
	for (bits = max_length; bits !== 0; bits--) {
		n = s.bl_count[bits];
		while (n !== 0) {
			m = s.heap[--h];
			if (m > max_code) continue;
			if (tree[m * 2 + 1] !== bits) {
				s.opt_len += (bits - tree[m * 2 + 1]) * tree[m * 2];
				tree[m * 2 + 1] = bits;
			}
			n--;
		}
	}
};
var gen_codes = (tree, max_code, bl_count) => {
	const next_code = new Array(16);
	let code = 0;
	let bits;
	let n;
	for (bits = 1; bits <= MAX_BITS$1; bits++) {
		code = code + bl_count[bits - 1] << 1;
		next_code[bits] = code;
	}
	for (n = 0; n <= max_code; n++) {
		let len = tree[n * 2 + 1];
		if (len === 0) continue;
		tree[n * 2] = bi_reverse(next_code[len]++, len);
	}
};
var tr_static_init = () => {
	let n;
	let bits;
	let length;
	let code;
	let dist;
	const bl_count = new Array(16);
	length = 0;
	for (code = 0; code < 28; code++) {
		base_length[code] = length;
		for (n = 0; n < 1 << extra_lbits[code]; n++) _length_code[length++] = code;
	}
	_length_code[length - 1] = code;
	dist = 0;
	for (code = 0; code < 16; code++) {
		base_dist[code] = dist;
		for (n = 0; n < 1 << extra_dbits[code]; n++) _dist_code[dist++] = code;
	}
	dist >>= 7;
	for (; code < D_CODES$1; code++) {
		base_dist[code] = dist << 7;
		for (n = 0; n < 1 << extra_dbits[code] - 7; n++) _dist_code[256 + dist++] = code;
	}
	for (bits = 0; bits <= MAX_BITS$1; bits++) bl_count[bits] = 0;
	n = 0;
	while (n <= 143) {
		static_ltree[n * 2 + 1] = 8;
		n++;
		bl_count[8]++;
	}
	while (n <= 255) {
		static_ltree[n * 2 + 1] = 9;
		n++;
		bl_count[9]++;
	}
	while (n <= 279) {
		static_ltree[n * 2 + 1] = 7;
		n++;
		bl_count[7]++;
	}
	while (n <= 287) {
		static_ltree[n * 2 + 1] = 8;
		n++;
		bl_count[8]++;
	}
	gen_codes(static_ltree, 287, bl_count);
	for (n = 0; n < D_CODES$1; n++) {
		static_dtree[n * 2 + 1] = 5;
		static_dtree[n * 2] = bi_reverse(n, 5);
	}
	static_l_desc = new StaticTreeDesc(static_ltree, extra_lbits, 257, L_CODES$1, MAX_BITS$1);
	static_d_desc = new StaticTreeDesc(static_dtree, extra_dbits, 0, D_CODES$1, MAX_BITS$1);
	static_bl_desc = new StaticTreeDesc(new Array(0), extra_blbits, 0, BL_CODES$1, MAX_BL_BITS);
};
var init_block = (s) => {
	let n;
	for (n = 0; n < L_CODES$1; n++) s.dyn_ltree[n * 2] = 0;
	for (n = 0; n < D_CODES$1; n++) s.dyn_dtree[n * 2] = 0;
	for (n = 0; n < BL_CODES$1; n++) s.bl_tree[n * 2] = 0;
	s.dyn_ltree[END_BLOCK * 2] = 1;
	s.opt_len = s.static_len = 0;
	s.sym_next = s.matches = 0;
};
var bi_windup = (s) => {
	if (s.bi_valid > 8) put_short(s, s.bi_buf);
	else if (s.bi_valid > 0) s.pending_buf[s.pending++] = s.bi_buf;
	s.bi_buf = 0;
	s.bi_valid = 0;
};
var smaller = (tree, n, m, depth) => {
	const _n2 = n * 2;
	const _m2 = m * 2;
	return tree[_n2] < tree[_m2] || tree[_n2] === tree[_m2] && depth[n] <= depth[m];
};
var pqdownheap = (s, tree, k) => {
	const v = s.heap[k];
	let j = k << 1;
	while (j <= s.heap_len) {
		if (j < s.heap_len && smaller(tree, s.heap[j + 1], s.heap[j], s.depth)) j++;
		if (smaller(tree, v, s.heap[j], s.depth)) break;
		s.heap[k] = s.heap[j];
		k = j;
		j <<= 1;
	}
	s.heap[k] = v;
};
var compress_block = (s, ltree, dtree) => {
	let dist;
	let lc;
	let sx = 0;
	let code;
	let extra;
	if (s.sym_next !== 0) do {
		dist = s.pending_buf[s.sym_buf + sx++] & 255;
		dist += (s.pending_buf[s.sym_buf + sx++] & 255) << 8;
		lc = s.pending_buf[s.sym_buf + sx++];
		if (dist === 0) send_code(s, lc, ltree);
		else {
			code = _length_code[lc];
			send_code(s, code + LITERALS$1 + 1, ltree);
			extra = extra_lbits[code];
			if (extra !== 0) {
				lc -= base_length[code];
				send_bits(s, lc, extra);
			}
			dist--;
			code = d_code(dist);
			send_code(s, code, dtree);
			extra = extra_dbits[code];
			if (extra !== 0) {
				dist -= base_dist[code];
				send_bits(s, dist, extra);
			}
		}
	} while (sx < s.sym_next);
	send_code(s, END_BLOCK, ltree);
};
var build_tree = (s, desc) => {
	const tree = desc.dyn_tree;
	const stree = desc.stat_desc.static_tree;
	const has_stree = desc.stat_desc.has_stree;
	const elems = desc.stat_desc.elems;
	let n, m;
	let max_code = -1;
	let node;
	s.heap_len = 0;
	s.heap_max = HEAP_SIZE$1;
	for (n = 0; n < elems; n++) if (tree[n * 2] !== 0) {
		s.heap[++s.heap_len] = max_code = n;
		s.depth[n] = 0;
	} else tree[n * 2 + 1] = 0;
	while (s.heap_len < 2) {
		node = s.heap[++s.heap_len] = max_code < 2 ? ++max_code : 0;
		tree[node * 2] = 1;
		s.depth[node] = 0;
		s.opt_len--;
		if (has_stree) s.static_len -= stree[node * 2 + 1];
	}
	desc.max_code = max_code;
	for (n = s.heap_len >> 1; n >= 1; n--) pqdownheap(s, tree, n);
	node = elems;
	do {
		/*** pqremove ***/
		n = s.heap[1];
		s.heap[1] = s.heap[s.heap_len--];
		pqdownheap(s, tree, 1);
		m = s.heap[1];
		s.heap[--s.heap_max] = n;
		s.heap[--s.heap_max] = m;
		tree[node * 2] = tree[n * 2] + tree[m * 2];
		s.depth[node] = (s.depth[n] >= s.depth[m] ? s.depth[n] : s.depth[m]) + 1;
		tree[n * 2 + 1] = tree[m * 2 + 1] = node;
		s.heap[1] = node++;
		pqdownheap(s, tree, 1);
	} while (s.heap_len >= 2);
	s.heap[--s.heap_max] = s.heap[1];
	gen_bitlen(s, desc);
	gen_codes(tree, max_code, s.bl_count);
};
var scan_tree = (s, tree, max_code) => {
	let n;
	let prevlen = -1;
	let curlen;
	let nextlen = tree[1];
	let count = 0;
	let max_count = 7;
	let min_count = 4;
	if (nextlen === 0) {
		max_count = 138;
		min_count = 3;
	}
	tree[(max_code + 1) * 2 + 1] = 65535;
	for (n = 0; n <= max_code; n++) {
		curlen = nextlen;
		nextlen = tree[(n + 1) * 2 + 1];
		if (++count < max_count && curlen === nextlen) continue;
		else if (count < min_count) s.bl_tree[curlen * 2] += count;
		else if (curlen !== 0) {
			if (curlen !== prevlen) s.bl_tree[curlen * 2]++;
			s.bl_tree[32]++;
		} else if (count <= 10) s.bl_tree[34]++;
		else s.bl_tree[36]++;
		count = 0;
		prevlen = curlen;
		if (nextlen === 0) {
			max_count = 138;
			min_count = 3;
		} else if (curlen === nextlen) {
			max_count = 6;
			min_count = 3;
		} else {
			max_count = 7;
			min_count = 4;
		}
	}
};
var send_tree = (s, tree, max_code) => {
	let n;
	let prevlen = -1;
	let curlen;
	let nextlen = tree[1];
	let count = 0;
	let max_count = 7;
	let min_count = 4;
	if (nextlen === 0) {
		max_count = 138;
		min_count = 3;
	}
	for (n = 0; n <= max_code; n++) {
		curlen = nextlen;
		nextlen = tree[(n + 1) * 2 + 1];
		if (++count < max_count && curlen === nextlen) continue;
		else if (count < min_count) do
			send_code(s, curlen, s.bl_tree);
		while (--count !== 0);
		else if (curlen !== 0) {
			if (curlen !== prevlen) {
				send_code(s, curlen, s.bl_tree);
				count--;
			}
			send_code(s, REP_3_6, s.bl_tree);
			send_bits(s, count - 3, 2);
		} else if (count <= 10) {
			send_code(s, REPZ_3_10, s.bl_tree);
			send_bits(s, count - 3, 3);
		} else {
			send_code(s, REPZ_11_138, s.bl_tree);
			send_bits(s, count - 11, 7);
		}
		count = 0;
		prevlen = curlen;
		if (nextlen === 0) {
			max_count = 138;
			min_count = 3;
		} else if (curlen === nextlen) {
			max_count = 6;
			min_count = 3;
		} else {
			max_count = 7;
			min_count = 4;
		}
	}
};
var build_bl_tree = (s) => {
	let max_blindex;
	scan_tree(s, s.dyn_ltree, s.l_desc.max_code);
	scan_tree(s, s.dyn_dtree, s.d_desc.max_code);
	build_tree(s, s.bl_desc);
	for (max_blindex = 18; max_blindex >= 3; max_blindex--) if (s.bl_tree[bl_order[max_blindex] * 2 + 1] !== 0) break;
	s.opt_len += 3 * (max_blindex + 1) + 5 + 5 + 4;
	return max_blindex;
};
var send_all_trees = (s, lcodes, dcodes, blcodes) => {
	let rank;
	send_bits(s, lcodes - 257, 5);
	send_bits(s, dcodes - 1, 5);
	send_bits(s, blcodes - 4, 4);
	for (rank = 0; rank < blcodes; rank++) send_bits(s, s.bl_tree[bl_order[rank] * 2 + 1], 3);
	send_tree(s, s.dyn_ltree, lcodes - 1);
	send_tree(s, s.dyn_dtree, dcodes - 1);
};
var detect_data_type = (s) => {
	let block_mask = 4093624447;
	let n;
	for (n = 0; n <= 31; n++, block_mask >>>= 1) if (block_mask & 1 && s.dyn_ltree[n * 2] !== 0) return Z_BINARY;
	if (s.dyn_ltree[18] !== 0 || s.dyn_ltree[20] !== 0 || s.dyn_ltree[26] !== 0) return Z_TEXT;
	for (n = 32; n < LITERALS$1; n++) if (s.dyn_ltree[n * 2] !== 0) return Z_TEXT;
	return Z_BINARY;
};
var static_init_done = false;
var _tr_init$1 = (s) => {
	if (!static_init_done) {
		tr_static_init();
		static_init_done = true;
	}
	s.l_desc = new TreeDesc(s.dyn_ltree, static_l_desc);
	s.d_desc = new TreeDesc(s.dyn_dtree, static_d_desc);
	s.bl_desc = new TreeDesc(s.bl_tree, static_bl_desc);
	s.bi_buf = 0;
	s.bi_valid = 0;
	init_block(s);
};
var _tr_stored_block$1 = (s, buf, stored_len, last) => {
	send_bits(s, 0 + (last ? 1 : 0), 3);
	bi_windup(s);
	put_short(s, stored_len);
	put_short(s, ~stored_len);
	if (stored_len) s.pending_buf.set(s.window.subarray(buf, buf + stored_len), s.pending);
	s.pending += stored_len;
};
var _tr_align$1 = (s) => {
	send_bits(s, 2, 3);
	send_code(s, END_BLOCK, static_ltree);
	bi_flush(s);
};
var _tr_flush_block$1 = (s, buf, stored_len, last) => {
	let opt_lenb, static_lenb;
	let max_blindex = 0;
	if (s.level > 0) {
		if (s.strm.data_type === Z_UNKNOWN$1) s.strm.data_type = detect_data_type(s);
		build_tree(s, s.l_desc);
		build_tree(s, s.d_desc);
		max_blindex = build_bl_tree(s);
		opt_lenb = s.opt_len + 3 + 7 >>> 3;
		static_lenb = s.static_len + 3 + 7 >>> 3;
		if (static_lenb <= opt_lenb) opt_lenb = static_lenb;
	} else opt_lenb = static_lenb = stored_len + 5;
	if (stored_len + 4 <= opt_lenb && buf !== -1) _tr_stored_block$1(s, buf, stored_len, last);
	else if (s.strategy === Z_FIXED$1 || static_lenb === opt_lenb) {
		send_bits(s, 2 + (last ? 1 : 0), 3);
		compress_block(s, static_ltree, static_dtree);
	} else {
		send_bits(s, 4 + (last ? 1 : 0), 3);
		send_all_trees(s, s.l_desc.max_code + 1, s.d_desc.max_code + 1, max_blindex + 1);
		compress_block(s, s.dyn_ltree, s.dyn_dtree);
	}
	init_block(s);
	if (last) bi_windup(s);
};
var _tr_tally$1 = (s, dist, lc) => {
	s.pending_buf[s.sym_buf + s.sym_next++] = dist;
	s.pending_buf[s.sym_buf + s.sym_next++] = dist >> 8;
	s.pending_buf[s.sym_buf + s.sym_next++] = lc;
	if (dist === 0) s.dyn_ltree[lc * 2]++;
	else {
		s.matches++;
		dist--;
		s.dyn_ltree[(_length_code[lc] + LITERALS$1 + 1) * 2]++;
		s.dyn_dtree[d_code(dist) * 2]++;
	}
	return s.sym_next === s.sym_end;
};
var trees = {
	_tr_init: _tr_init$1,
	_tr_stored_block: _tr_stored_block$1,
	_tr_flush_block: _tr_flush_block$1,
	_tr_tally: _tr_tally$1,
	_tr_align: _tr_align$1
};
var adler32 = (adler, buf, len, pos) => {
	let s1 = adler & 65535 | 0, s2 = adler >>> 16 & 65535 | 0, n = 0;
	while (len !== 0) {
		n = len > 2e3 ? 2e3 : len;
		len -= n;
		do {
			s1 = s1 + buf[pos++] | 0;
			s2 = s2 + s1 | 0;
		} while (--n);
		s1 %= 65521;
		s2 %= 65521;
	}
	return s1 | s2 << 16 | 0;
};
var adler32_1 = adler32;
var makeTable = () => {
	let c, table = [];
	for (var n = 0; n < 256; n++) {
		c = n;
		for (var k = 0; k < 8; k++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
		table[n] = c;
	}
	return table;
};
var crcTable$1 = new Uint32Array(makeTable());
var crc32 = (crc, buf, len, pos) => {
	const t = crcTable$1;
	const end = pos + len;
	crc ^= -1;
	for (let i = pos; i < end; i++) crc = crc >>> 8 ^ t[(crc ^ buf[i]) & 255];
	return crc ^ -1;
};
var crc32_1 = crc32;
var messages = {
	2: "need dictionary",
	1: "stream end",
	0: "",
	"-1": "file error",
	"-2": "stream error",
	"-3": "data error",
	"-4": "insufficient memory",
	"-5": "buffer error",
	"-6": "incompatible version"
};
var constants$2 = {
	Z_NO_FLUSH: 0,
	Z_PARTIAL_FLUSH: 1,
	Z_SYNC_FLUSH: 2,
	Z_FULL_FLUSH: 3,
	Z_FINISH: 4,
	Z_BLOCK: 5,
	Z_TREES: 6,
	Z_OK: 0,
	Z_STREAM_END: 1,
	Z_NEED_DICT: 2,
	Z_ERRNO: -1,
	Z_STREAM_ERROR: -2,
	Z_DATA_ERROR: -3,
	Z_MEM_ERROR: -4,
	Z_BUF_ERROR: -5,
	Z_NO_COMPRESSION: 0,
	Z_BEST_SPEED: 1,
	Z_BEST_COMPRESSION: 9,
	Z_DEFAULT_COMPRESSION: -1,
	Z_FILTERED: 1,
	Z_HUFFMAN_ONLY: 2,
	Z_RLE: 3,
	Z_FIXED: 4,
	Z_DEFAULT_STRATEGY: 0,
	Z_BINARY: 0,
	Z_TEXT: 1,
	Z_UNKNOWN: 2,
	Z_DEFLATED: 8
};
var { _tr_init, _tr_stored_block, _tr_flush_block, _tr_tally, _tr_align } = trees;
var { Z_NO_FLUSH: Z_NO_FLUSH$2, Z_PARTIAL_FLUSH, Z_FULL_FLUSH: Z_FULL_FLUSH$1, Z_FINISH: Z_FINISH$3, Z_BLOCK: Z_BLOCK$1, Z_OK: Z_OK$3, Z_STREAM_END: Z_STREAM_END$3, Z_STREAM_ERROR: Z_STREAM_ERROR$2, Z_DATA_ERROR: Z_DATA_ERROR$2, Z_BUF_ERROR: Z_BUF_ERROR$2, Z_DEFAULT_COMPRESSION: Z_DEFAULT_COMPRESSION$1, Z_FILTERED, Z_HUFFMAN_ONLY, Z_RLE, Z_FIXED, Z_DEFAULT_STRATEGY: Z_DEFAULT_STRATEGY$1, Z_UNKNOWN, Z_DEFLATED: Z_DEFLATED$2 } = constants$2;
var MAX_MEM_LEVEL = 9;
var MAX_WBITS$1 = 15;
var DEF_MEM_LEVEL = 8;
var HEAP_SIZE = 573;
var MIN_MATCH = 3;
var MAX_MATCH = 258;
var MIN_LOOKAHEAD = 262;
var PRESET_DICT = 32;
var INIT_STATE = 42;
var GZIP_STATE = 57;
var EXTRA_STATE = 69;
var NAME_STATE = 73;
var COMMENT_STATE = 91;
var HCRC_STATE = 103;
var BUSY_STATE = 113;
var FINISH_STATE = 666;
var BS_NEED_MORE = 1;
var BS_BLOCK_DONE = 2;
var BS_FINISH_STARTED = 3;
var BS_FINISH_DONE = 4;
var OS_CODE = 3;
var err = (strm, errorCode) => {
	strm.msg = messages[errorCode];
	return errorCode;
};
var rank = (f) => {
	return f * 2 - (f > 4 ? 9 : 0);
};
var zero = (buf) => {
	let len = buf.length;
	while (--len >= 0) buf[len] = 0;
};
var slide_hash = (s) => {
	let n, m;
	let p;
	let wsize = s.w_size;
	n = s.hash_size;
	p = n;
	do {
		m = s.head[--p];
		s.head[p] = m >= wsize ? m - wsize : 0;
	} while (--n);
	n = wsize;
	p = n;
	do {
		m = s.prev[--p];
		s.prev[p] = m >= wsize ? m - wsize : 0;
	} while (--n);
};
var HASH = (s, prev, data) => (prev << s.hash_shift ^ data) & s.hash_mask;
var INSERT_STRING = (s, str) => {
	let h;
	if (s.legacy_hash) h = s.ins_h = HASH(s, s.ins_h, s.window[str + MIN_MATCH - 1]);
	else {
		const w = s.window;
		const value = w[str] | w[str + 1] << 8 | w[str + 2] << 16 | w[str + 3] << 24;
		h = s.ins_h = Math.imul(value, 66521) + 66521 >>> 16 & s.hash_mask;
	}
	const hash_head = s.prev[str & s.w_mask] = s.head[h];
	s.head[h] = str;
	return hash_head;
};
var flush_pending = (strm) => {
	const s = strm.state;
	let len = s.pending;
	if (len > strm.avail_out) len = strm.avail_out;
	if (len === 0) return;
	strm.output.set(s.pending_buf.subarray(s.pending_out, s.pending_out + len), strm.next_out);
	strm.next_out += len;
	s.pending_out += len;
	strm.total_out += len;
	strm.avail_out -= len;
	s.pending -= len;
	if (s.pending === 0) s.pending_out = 0;
};
var flush_block_only = (s, last) => {
	_tr_flush_block(s, s.block_start >= 0 ? s.block_start : -1, s.strstart - s.block_start, last);
	s.block_start = s.strstart;
	flush_pending(s.strm);
};
var put_byte = (s, b) => {
	s.pending_buf[s.pending++] = b;
};
var putShortMSB = (s, b) => {
	s.pending_buf[s.pending++] = b >>> 8 & 255;
	s.pending_buf[s.pending++] = b & 255;
};
var read_buf = (strm, buf, start, size) => {
	let len = strm.avail_in;
	if (len > size) len = size;
	if (len === 0) return 0;
	strm.avail_in -= len;
	buf.set(strm.input.subarray(strm.next_in, strm.next_in + len), start);
	if (strm.state.wrap === 1) strm.adler = adler32_1(strm.adler, buf, len, start);
	else if (strm.state.wrap === 2) strm.adler = crc32_1(strm.adler, buf, len, start);
	strm.next_in += len;
	strm.total_in += len;
	return len;
};
var longest_match = (s, cur_match) => {
	let chain_length = s.max_chain_length;
	let scan = s.strstart;
	let match;
	let len;
	let best_len = s.prev_length;
	let nice_match = s.nice_match;
	const limit = s.strstart > s.w_size - MIN_LOOKAHEAD ? s.strstart - (s.w_size - MIN_LOOKAHEAD) : 0;
	const _win = s.window;
	const wmask = s.w_mask;
	const prev = s.prev;
	const strend = s.strstart + MAX_MATCH;
	let scan_end1 = _win[scan + best_len - 1];
	let scan_end = _win[scan + best_len];
	if (s.prev_length >= s.good_match) chain_length >>= 2;
	if (nice_match > s.lookahead) nice_match = s.lookahead;
	do {
		match = cur_match;
		if (_win[match + best_len] !== scan_end || _win[match + best_len - 1] !== scan_end1 || _win[match] !== _win[scan] || _win[++match] !== _win[scan + 1]) continue;
		scan += 2;
		match++;
		do		;
while (_win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && _win[++scan] === _win[++match] && scan < strend);
		len = MAX_MATCH - (strend - scan);
		scan = strend - MAX_MATCH;
		if (len > best_len) {
			s.match_start = cur_match;
			best_len = len;
			if (len >= nice_match) break;
			scan_end1 = _win[scan + best_len - 1];
			scan_end = _win[scan + best_len];
		}
	} while ((cur_match = prev[cur_match & wmask]) > limit && --chain_length !== 0);
	if (best_len <= s.lookahead) return best_len;
	return s.lookahead;
};
var fill_window = (s) => {
	const _w_size = s.w_size;
	let n, more, str;
	do {
		more = s.window_size - s.lookahead - s.strstart;
		if (s.strstart >= _w_size + (_w_size - MIN_LOOKAHEAD)) {
			s.window.set(s.window.subarray(_w_size, _w_size + _w_size - more), 0);
			s.match_start -= _w_size;
			s.strstart -= _w_size;
			s.block_start -= _w_size;
			if (s.insert > s.strstart) s.insert = s.strstart;
			slide_hash(s);
			more += _w_size;
		}
		if (s.strm.avail_in === 0) break;
		n = read_buf(s.strm, s.window, s.strstart + s.lookahead, more);
		s.lookahead += n;
		if (!s.legacy_hash) {
			if (s.lookahead + s.insert > MIN_MATCH) {
				str = s.strstart - s.insert;
				while (s.insert) {
					INSERT_STRING(s, str);
					str++;
					s.insert--;
					if (s.lookahead + s.insert <= MIN_MATCH) break;
				}
			}
		} else if (s.lookahead + s.insert >= MIN_MATCH) {
			str = s.strstart - s.insert;
			s.ins_h = s.window[str];
			s.ins_h = HASH(s, s.ins_h, s.window[str + 1]);
			while (s.insert) {
				INSERT_STRING(s, str);
				str++;
				s.insert--;
				if (s.lookahead + s.insert < MIN_MATCH) break;
			}
		}
	} while (s.lookahead < MIN_LOOKAHEAD && s.strm.avail_in !== 0);
};
var deflate_stored = (s, flush) => {
	let min_block = s.pending_buf_size - 5 > s.w_size ? s.w_size : s.pending_buf_size - 5;
	let len, left, have, last = 0;
	let used = s.strm.avail_in;
	do {
		len = 65535;
		have = s.bi_valid + 42 >> 3;
		if (s.strm.avail_out < have) break;
		have = s.strm.avail_out - have;
		left = s.strstart - s.block_start;
		if (len > left + s.strm.avail_in) len = left + s.strm.avail_in;
		if (len > have) len = have;
		if (len < min_block && (len === 0 && flush !== Z_FINISH$3 || flush === Z_NO_FLUSH$2 || len !== left + s.strm.avail_in)) break;
		last = flush === Z_FINISH$3 && len === left + s.strm.avail_in ? 1 : 0;
		_tr_stored_block(s, 0, 0, last);
		s.pending_buf[s.pending - 4] = len;
		s.pending_buf[s.pending - 3] = len >> 8;
		s.pending_buf[s.pending - 2] = ~len;
		s.pending_buf[s.pending - 1] = ~len >> 8;
		flush_pending(s.strm);
		if (left) {
			if (left > len) left = len;
			s.strm.output.set(s.window.subarray(s.block_start, s.block_start + left), s.strm.next_out);
			s.strm.next_out += left;
			s.strm.avail_out -= left;
			s.strm.total_out += left;
			s.block_start += left;
			len -= left;
		}
		if (len) {
			read_buf(s.strm, s.strm.output, s.strm.next_out, len);
			s.strm.next_out += len;
			s.strm.avail_out -= len;
			s.strm.total_out += len;
		}
	} while (last === 0);
	used -= s.strm.avail_in;
	if (used) {
		if (used >= s.w_size) {
			s.matches = 2;
			s.window.set(s.strm.input.subarray(s.strm.next_in - s.w_size, s.strm.next_in), 0);
			s.strstart = s.w_size;
			s.insert = s.strstart;
		} else {
			if (s.window_size - s.strstart <= used) {
				s.strstart -= s.w_size;
				s.window.set(s.window.subarray(s.w_size, s.w_size + s.strstart), 0);
				if (s.matches < 2) s.matches++;
				if (s.insert > s.strstart) s.insert = s.strstart;
			}
			s.window.set(s.strm.input.subarray(s.strm.next_in - used, s.strm.next_in), s.strstart);
			s.strstart += used;
			s.insert += used > s.w_size - s.insert ? s.w_size - s.insert : used;
		}
		s.block_start = s.strstart;
	}
	if (s.high_water < s.strstart) s.high_water = s.strstart;
	if (last) return BS_FINISH_DONE;
	if (flush !== Z_NO_FLUSH$2 && flush !== Z_FINISH$3 && s.strm.avail_in === 0 && s.strstart === s.block_start) return BS_BLOCK_DONE;
	have = s.window_size - s.strstart;
	if (s.strm.avail_in > have && s.block_start >= s.w_size) {
		s.block_start -= s.w_size;
		s.strstart -= s.w_size;
		s.window.set(s.window.subarray(s.w_size, s.w_size + s.strstart), 0);
		if (s.matches < 2) s.matches++;
		have += s.w_size;
		if (s.insert > s.strstart) s.insert = s.strstart;
	}
	if (have > s.strm.avail_in) have = s.strm.avail_in;
	if (have) {
		read_buf(s.strm, s.window, s.strstart, have);
		s.strstart += have;
		s.insert += have > s.w_size - s.insert ? s.w_size - s.insert : have;
	}
	if (s.high_water < s.strstart) s.high_water = s.strstart;
	have = s.bi_valid + 42 >> 3;
	have = s.pending_buf_size - have > 65535 ? 65535 : s.pending_buf_size - have;
	min_block = have > s.w_size ? s.w_size : have;
	left = s.strstart - s.block_start;
	if (left >= min_block || (left || flush === Z_FINISH$3) && flush !== Z_NO_FLUSH$2 && s.strm.avail_in === 0 && left <= have) {
		len = left > have ? have : left;
		last = flush === Z_FINISH$3 && s.strm.avail_in === 0 && len === left ? 1 : 0;
		_tr_stored_block(s, s.block_start, len, last);
		s.block_start += len;
		flush_pending(s.strm);
	}
	return last ? BS_FINISH_STARTED : BS_NEED_MORE;
};
var deflate_fast = (s, flush) => {
	let hash_head;
	let bflush;
	for (;;) {
		if (s.lookahead < MIN_LOOKAHEAD) {
			fill_window(s);
			if (s.lookahead < MIN_LOOKAHEAD && flush === Z_NO_FLUSH$2) return BS_NEED_MORE;
			if (s.lookahead === 0) break;
		}
		hash_head = 0;
		if (s.lookahead >= MIN_MATCH) hash_head = INSERT_STRING(s, s.strstart);
		if (hash_head !== 0 && s.strstart - hash_head <= s.w_size - MIN_LOOKAHEAD) s.match_length = longest_match(s, hash_head);
		if (s.match_length >= MIN_MATCH) {
			/*** _tr_tally_dist(s, s.strstart - s.match_start,
			s.match_length - MIN_MATCH, bflush); ***/
			bflush = _tr_tally(s, s.strstart - s.match_start, s.match_length - MIN_MATCH);
			s.lookahead -= s.match_length;
			if (s.match_length <= s.max_lazy_match && s.lookahead >= MIN_MATCH) {
				s.match_length--;
				do {
					s.strstart++;
					hash_head = INSERT_STRING(s, s.strstart);
				} while (--s.match_length !== 0);
				s.strstart++;
			} else {
				s.strstart += s.match_length;
				s.match_length = 0;
				if (s.legacy_hash) {
					s.ins_h = s.window[s.strstart];
					s.ins_h = HASH(s, s.ins_h, s.window[s.strstart + 1]);
				}
			}
		} else {
			/*** _tr_tally_lit(s, s.window[s.strstart], bflush); ***/
			bflush = _tr_tally(s, 0, s.window[s.strstart]);
			s.lookahead--;
			s.strstart++;
		}
		if (bflush) {
			/*** FLUSH_BLOCK(s, 0); ***/
			flush_block_only(s, false);
			if (s.strm.avail_out === 0) return BS_NEED_MORE;
		}
	}
	s.insert = s.strstart < 2 ? s.strstart : 2;
	if (flush === Z_FINISH$3) {
		/*** FLUSH_BLOCK(s, 1); ***/
		flush_block_only(s, true);
		if (s.strm.avail_out === 0) return BS_FINISH_STARTED;
		return BS_FINISH_DONE;
	}
	if (s.sym_next) {
		/*** FLUSH_BLOCK(s, 0); ***/
		flush_block_only(s, false);
		if (s.strm.avail_out === 0) return BS_NEED_MORE;
	}
	return BS_BLOCK_DONE;
};
var deflate_slow = (s, flush) => {
	let hash_head;
	let bflush;
	let max_insert;
	for (;;) {
		if (s.lookahead < MIN_LOOKAHEAD) {
			fill_window(s);
			if (s.lookahead < MIN_LOOKAHEAD && flush === Z_NO_FLUSH$2) return BS_NEED_MORE;
			if (s.lookahead === 0) break;
		}
		hash_head = 0;
		if (s.lookahead >= MIN_MATCH) hash_head = INSERT_STRING(s, s.strstart);
		s.prev_length = s.match_length;
		s.prev_match = s.match_start;
		s.match_length = 2;
		if (hash_head !== 0 && s.prev_length < s.max_lazy_match && s.strstart - hash_head <= s.w_size - MIN_LOOKAHEAD) {
			s.match_length = longest_match(s, hash_head);
			if (s.match_length <= 5 && (s.strategy === Z_FILTERED || s.match_length === MIN_MATCH && s.strstart - s.match_start > 4096)) s.match_length = 2;
		}
		if (s.prev_length >= MIN_MATCH && s.match_length <= s.prev_length) {
			max_insert = s.strstart + s.lookahead - MIN_MATCH;
			/***_tr_tally_dist(s, s.strstart - 1 - s.prev_match,
			s.prev_length - MIN_MATCH, bflush);***/
			bflush = _tr_tally(s, s.strstart - 1 - s.prev_match, s.prev_length - MIN_MATCH);
			s.lookahead -= s.prev_length - 1;
			s.prev_length -= 2;
			do
				if (++s.strstart <= max_insert) hash_head = INSERT_STRING(s, s.strstart);
			while (--s.prev_length !== 0);
			s.match_available = 0;
			s.match_length = 2;
			s.strstart++;
			if (bflush) {
				/*** FLUSH_BLOCK(s, 0); ***/
				flush_block_only(s, false);
				if (s.strm.avail_out === 0) return BS_NEED_MORE;
			}
		} else if (s.match_available) {
			/*** _tr_tally_lit(s, s.window[s.strstart-1], bflush); ***/
			bflush = _tr_tally(s, 0, s.window[s.strstart - 1]);
			if (bflush)
 /*** FLUSH_BLOCK_ONLY(s, 0) ***/
			flush_block_only(s, false);
			s.strstart++;
			s.lookahead--;
			if (s.strm.avail_out === 0) return BS_NEED_MORE;
		} else {
			s.match_available = 1;
			s.strstart++;
			s.lookahead--;
		}
	}
	if (s.match_available) {
		/*** _tr_tally_lit(s, s.window[s.strstart-1], bflush); ***/
		bflush = _tr_tally(s, 0, s.window[s.strstart - 1]);
		s.match_available = 0;
	}
	s.insert = s.strstart < 2 ? s.strstart : 2;
	if (flush === Z_FINISH$3) {
		/*** FLUSH_BLOCK(s, 1); ***/
		flush_block_only(s, true);
		if (s.strm.avail_out === 0) return BS_FINISH_STARTED;
		return BS_FINISH_DONE;
	}
	if (s.sym_next) {
		/*** FLUSH_BLOCK(s, 0); ***/
		flush_block_only(s, false);
		if (s.strm.avail_out === 0) return BS_NEED_MORE;
	}
	return BS_BLOCK_DONE;
};
var deflate_rle = (s, flush) => {
	let bflush;
	let prev;
	let scan, strend;
	const _win = s.window;
	for (;;) {
		if (s.lookahead <= MAX_MATCH) {
			fill_window(s);
			if (s.lookahead <= MAX_MATCH && flush === Z_NO_FLUSH$2) return BS_NEED_MORE;
			if (s.lookahead === 0) break;
		}
		s.match_length = 0;
		if (s.lookahead >= MIN_MATCH && s.strstart > 0) {
			scan = s.strstart - 1;
			prev = _win[scan];
			if (prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan]) {
				strend = s.strstart + MAX_MATCH;
				do				;
while (prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && prev === _win[++scan] && scan < strend);
				s.match_length = MAX_MATCH - (strend - scan);
				if (s.match_length > s.lookahead) s.match_length = s.lookahead;
			}
		}
		if (s.match_length >= MIN_MATCH) {
			/*** _tr_tally_dist(s, 1, s.match_length - MIN_MATCH, bflush); ***/
			bflush = _tr_tally(s, 1, s.match_length - MIN_MATCH);
			s.lookahead -= s.match_length;
			s.strstart += s.match_length;
			s.match_length = 0;
		} else {
			/*** _tr_tally_lit(s, s.window[s.strstart], bflush); ***/
			bflush = _tr_tally(s, 0, s.window[s.strstart]);
			s.lookahead--;
			s.strstart++;
		}
		if (bflush) {
			/*** FLUSH_BLOCK(s, 0); ***/
			flush_block_only(s, false);
			if (s.strm.avail_out === 0) return BS_NEED_MORE;
		}
	}
	s.insert = 0;
	if (flush === Z_FINISH$3) {
		/*** FLUSH_BLOCK(s, 1); ***/
		flush_block_only(s, true);
		if (s.strm.avail_out === 0) return BS_FINISH_STARTED;
		return BS_FINISH_DONE;
	}
	if (s.sym_next) {
		/*** FLUSH_BLOCK(s, 0); ***/
		flush_block_only(s, false);
		if (s.strm.avail_out === 0) return BS_NEED_MORE;
	}
	return BS_BLOCK_DONE;
};
var deflate_huff = (s, flush) => {
	let bflush;
	for (;;) {
		if (s.lookahead === 0) {
			fill_window(s);
			if (s.lookahead === 0) {
				if (flush === Z_NO_FLUSH$2) return BS_NEED_MORE;
				break;
			}
		}
		s.match_length = 0;
		/*** _tr_tally_lit(s, s.window[s.strstart], bflush); ***/
		bflush = _tr_tally(s, 0, s.window[s.strstart]);
		s.lookahead--;
		s.strstart++;
		if (bflush) {
			/*** FLUSH_BLOCK(s, 0); ***/
			flush_block_only(s, false);
			if (s.strm.avail_out === 0) return BS_NEED_MORE;
		}
	}
	s.insert = 0;
	if (flush === Z_FINISH$3) {
		/*** FLUSH_BLOCK(s, 1); ***/
		flush_block_only(s, true);
		if (s.strm.avail_out === 0) return BS_FINISH_STARTED;
		return BS_FINISH_DONE;
	}
	if (s.sym_next) {
		/*** FLUSH_BLOCK(s, 0); ***/
		flush_block_only(s, false);
		if (s.strm.avail_out === 0) return BS_NEED_MORE;
	}
	return BS_BLOCK_DONE;
};
function Config(good_length, max_lazy, nice_length, max_chain, func) {
	this.good_length = good_length;
	this.max_lazy = max_lazy;
	this.nice_length = nice_length;
	this.max_chain = max_chain;
	this.func = func;
}
var configuration_table = [
	new Config(0, 0, 0, 0, deflate_stored),
	new Config(4, 4, 8, 4, deflate_fast),
	new Config(4, 5, 16, 8, deflate_fast),
	new Config(4, 6, 32, 32, deflate_fast),
	new Config(4, 4, 16, 16, deflate_slow),
	new Config(8, 16, 32, 32, deflate_slow),
	new Config(8, 16, 128, 128, deflate_slow),
	new Config(8, 32, 128, 256, deflate_slow),
	new Config(32, 128, 258, 1024, deflate_slow),
	new Config(32, 258, 258, 4096, deflate_slow)
];
var lm_init = (s) => {
	s.window_size = 2 * s.w_size;
	/*** CLEAR_HASH(s); ***/
	zero(s.head);
	s.max_lazy_match = configuration_table[s.level].max_lazy;
	s.good_match = configuration_table[s.level].good_length;
	s.nice_match = configuration_table[s.level].nice_length;
	s.max_chain_length = configuration_table[s.level].max_chain;
	s.strstart = 0;
	s.block_start = 0;
	s.lookahead = 0;
	s.insert = 0;
	s.match_length = s.prev_length = 2;
	s.match_available = 0;
	s.ins_h = 0;
};
function DeflateState() {
	this.strm = null;
	this.status = 0;
	this.pending_buf = null;
	this.pending_buf_size = 0;
	this.pending_out = 0;
	this.pending = 0;
	this.wrap = 0;
	this.gzhead = null;
	this.gzindex = 0;
	this.method = Z_DEFLATED$2;
	this.last_flush = -1;
	this.w_size = 0;
	this.w_bits = 0;
	this.w_mask = 0;
	this.window = null;
	this.window_size = 0;
	this.prev = null;
	this.head = null;
	this.ins_h = 0;
	this.legacy_hash = 0;
	this.hash_size = 0;
	this.hash_bits = 0;
	this.hash_mask = 0;
	this.hash_shift = 0;
	this.block_start = 0;
	this.match_length = 0;
	this.prev_match = 0;
	this.match_available = 0;
	this.strstart = 0;
	this.match_start = 0;
	this.lookahead = 0;
	this.prev_length = 0;
	this.max_chain_length = 0;
	this.max_lazy_match = 0;
	this.level = 0;
	this.strategy = 0;
	this.good_match = 0;
	this.nice_match = 0;
	this.dyn_ltree = new Uint16Array(HEAP_SIZE * 2);
	this.dyn_dtree = /* @__PURE__ */ new Uint16Array(122);
	this.bl_tree = /* @__PURE__ */ new Uint16Array(78);
	zero(this.dyn_ltree);
	zero(this.dyn_dtree);
	zero(this.bl_tree);
	this.l_desc = null;
	this.d_desc = null;
	this.bl_desc = null;
	this.bl_count = /* @__PURE__ */ new Uint16Array(16);
	this.heap = /* @__PURE__ */ new Uint16Array(573);
	zero(this.heap);
	this.heap_len = 0;
	this.heap_max = 0;
	this.depth = /* @__PURE__ */ new Uint16Array(573);
	zero(this.depth);
	this.sym_buf = 0;
	this.lit_bufsize = 0;
	this.sym_next = 0;
	this.sym_end = 0;
	this.opt_len = 0;
	this.static_len = 0;
	this.matches = 0;
	this.insert = 0;
	this.bi_buf = 0;
	this.bi_valid = 0;
}
var deflateStateCheck = (strm) => {
	if (!strm) return 1;
	const s = strm.state;
	if (!s || s.strm !== strm || s.status !== INIT_STATE && s.status !== GZIP_STATE && s.status !== EXTRA_STATE && s.status !== NAME_STATE && s.status !== COMMENT_STATE && s.status !== HCRC_STATE && s.status !== BUSY_STATE && s.status !== FINISH_STATE) return 1;
	return 0;
};
var deflateResetKeep = (strm) => {
	if (deflateStateCheck(strm)) return err(strm, Z_STREAM_ERROR$2);
	strm.total_in = strm.total_out = 0;
	strm.data_type = Z_UNKNOWN;
	const s = strm.state;
	s.pending = 0;
	s.pending_out = 0;
	if (s.wrap < 0) s.wrap = -s.wrap;
	s.status = s.wrap === 2 ? GZIP_STATE : s.wrap ? INIT_STATE : BUSY_STATE;
	strm.adler = s.wrap === 2 ? 0 : 1;
	s.last_flush = -2;
	_tr_init(s);
	return Z_OK$3;
};
var deflateReset = (strm) => {
	const ret = deflateResetKeep(strm);
	if (ret === Z_OK$3) lm_init(strm.state);
	return ret;
};
var deflateSetHeader = (strm, head) => {
	if (deflateStateCheck(strm) || strm.state.wrap !== 2) return Z_STREAM_ERROR$2;
	strm.state.gzhead = head;
	return Z_OK$3;
};
var deflateInit2 = (strm, level, method, windowBits, memLevel, strategy, legacyHash) => {
	if (!strm) return Z_STREAM_ERROR$2;
	let wrap = 1;
	if (level === Z_DEFAULT_COMPRESSION$1) level = 6;
	if (windowBits < 0) {
		wrap = 0;
		windowBits = -windowBits;
	} else if (windowBits > 15) {
		wrap = 2;
		windowBits -= 16;
	}
	if (memLevel < 1 || memLevel > MAX_MEM_LEVEL || method !== Z_DEFLATED$2 || windowBits < 8 || windowBits > 15 || level < 0 || level > 9 || strategy < 0 || strategy > Z_FIXED || windowBits === 8 && wrap !== 1) return err(strm, Z_STREAM_ERROR$2);
	if (windowBits === 8) windowBits = 9;
	const s = new DeflateState();
	strm.state = s;
	s.strm = strm;
	s.status = INIT_STATE;
	s.wrap = wrap;
	s.gzhead = null;
	s.w_bits = windowBits;
	s.w_size = 1 << s.w_bits;
	s.w_mask = s.w_size - 1;
	s.legacy_hash = legacyHash ? 1 : 0;
	s.hash_bits = memLevel + 7;
	if (!s.legacy_hash && s.hash_bits < 15) s.hash_bits = 15;
	s.hash_size = 1 << s.hash_bits;
	s.hash_mask = s.hash_size - 1;
	s.hash_shift = ~~((s.hash_bits + MIN_MATCH - 1) / MIN_MATCH);
	s.window = new Uint8Array(s.w_size * 2);
	s.head = new Uint16Array(s.hash_size);
	s.prev = new Uint16Array(s.w_size);
	s.lit_bufsize = 1 << memLevel + 6;
	s.pending_buf_size = s.lit_bufsize * 4;
	s.pending_buf = new Uint8Array(s.pending_buf_size);
	s.sym_buf = s.lit_bufsize;
	s.sym_end = (s.lit_bufsize - 1) * 3;
	s.level = level;
	s.strategy = strategy;
	s.method = method;
	return deflateReset(strm);
};
var deflateInit = (strm, level) => {
	return deflateInit2(strm, level, Z_DEFLATED$2, MAX_WBITS$1, DEF_MEM_LEVEL, Z_DEFAULT_STRATEGY$1);
};
var deflate$2 = (strm, flush) => {
	if (deflateStateCheck(strm) || flush > Z_BLOCK$1 || flush < 0) return strm ? err(strm, Z_STREAM_ERROR$2) : Z_STREAM_ERROR$2;
	const s = strm.state;
	if (!strm.output || strm.avail_in !== 0 && !strm.input || s.status === FINISH_STATE && flush !== Z_FINISH$3) return err(strm, strm.avail_out === 0 ? Z_BUF_ERROR$2 : Z_STREAM_ERROR$2);
	const old_flush = s.last_flush;
	s.last_flush = flush;
	if (s.pending !== 0) {
		flush_pending(strm);
		if (strm.avail_out === 0) {
			s.last_flush = -1;
			return Z_OK$3;
		}
	} else if (strm.avail_in === 0 && rank(flush) <= rank(old_flush) && flush !== Z_FINISH$3) return err(strm, Z_BUF_ERROR$2);
	if (s.status === FINISH_STATE && strm.avail_in !== 0) return err(strm, Z_BUF_ERROR$2);
	if (s.status === INIT_STATE && s.wrap === 0) s.status = BUSY_STATE;
	if (s.status === INIT_STATE) {
		let header = Z_DEFLATED$2 + (s.w_bits - 8 << 4) << 8;
		let level_flags = -1;
		if (s.strategy >= Z_HUFFMAN_ONLY || s.level < 2) level_flags = 0;
		else if (s.level < 6) level_flags = 1;
		else if (s.level === 6) level_flags = 2;
		else level_flags = 3;
		header |= level_flags << 6;
		if (s.strstart !== 0) header |= PRESET_DICT;
		header += 31 - header % 31;
		putShortMSB(s, header);
		if (s.strstart !== 0) {
			putShortMSB(s, strm.adler >>> 16);
			putShortMSB(s, strm.adler & 65535);
		}
		strm.adler = 1;
		s.status = BUSY_STATE;
		flush_pending(strm);
		if (s.pending !== 0) {
			s.last_flush = -1;
			return Z_OK$3;
		}
	}
	if (s.status === GZIP_STATE) {
		strm.adler = 0;
		put_byte(s, 31);
		put_byte(s, 139);
		put_byte(s, 8);
		if (!s.gzhead) {
			put_byte(s, 0);
			put_byte(s, 0);
			put_byte(s, 0);
			put_byte(s, 0);
			put_byte(s, 0);
			put_byte(s, s.level === 9 ? 2 : s.strategy >= Z_HUFFMAN_ONLY || s.level < 2 ? 4 : 0);
			put_byte(s, OS_CODE);
			s.status = BUSY_STATE;
			flush_pending(strm);
			if (s.pending !== 0) {
				s.last_flush = -1;
				return Z_OK$3;
			}
		} else {
			put_byte(s, (s.gzhead.text ? 1 : 0) + (s.gzhead.hcrc ? 2 : 0) + (!s.gzhead.extra ? 0 : 4) + (!s.gzhead.name ? 0 : 8) + (!s.gzhead.comment ? 0 : 16));
			put_byte(s, s.gzhead.time & 255);
			put_byte(s, s.gzhead.time >> 8 & 255);
			put_byte(s, s.gzhead.time >> 16 & 255);
			put_byte(s, s.gzhead.time >> 24 & 255);
			put_byte(s, s.level === 9 ? 2 : s.strategy >= Z_HUFFMAN_ONLY || s.level < 2 ? 4 : 0);
			put_byte(s, s.gzhead.os & 255);
			if (s.gzhead.extra && s.gzhead.extra.length) {
				put_byte(s, s.gzhead.extra.length & 255);
				put_byte(s, s.gzhead.extra.length >> 8 & 255);
			}
			if (s.gzhead.hcrc) strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending, 0);
			s.gzindex = 0;
			s.status = EXTRA_STATE;
		}
	}
	if (s.status === EXTRA_STATE) {
		if (s.gzhead.extra) {
			let beg = s.pending;
			let left = (s.gzhead.extra.length & 65535) - s.gzindex;
			while (s.pending + left > s.pending_buf_size) {
				let copy = s.pending_buf_size - s.pending;
				s.pending_buf.set(s.gzhead.extra.subarray(s.gzindex, s.gzindex + copy), s.pending);
				s.pending = s.pending_buf_size;
				if (s.gzhead.hcrc && s.pending > beg) strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending - beg, beg);
				s.gzindex += copy;
				flush_pending(strm);
				if (s.pending !== 0) {
					s.last_flush = -1;
					return Z_OK$3;
				}
				beg = 0;
				left -= copy;
			}
			let gzhead_extra = new Uint8Array(s.gzhead.extra);
			s.pending_buf.set(gzhead_extra.subarray(s.gzindex, s.gzindex + left), s.pending);
			s.pending += left;
			if (s.gzhead.hcrc && s.pending > beg) strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending - beg, beg);
			s.gzindex = 0;
		}
		s.status = NAME_STATE;
	}
	if (s.status === NAME_STATE) {
		if (s.gzhead.name) {
			let beg = s.pending;
			let val;
			do {
				if (s.pending === s.pending_buf_size) {
					if (s.gzhead.hcrc && s.pending > beg) strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending - beg, beg);
					flush_pending(strm);
					if (s.pending !== 0) {
						s.last_flush = -1;
						return Z_OK$3;
					}
					beg = 0;
				}
				if (s.gzindex < s.gzhead.name.length) val = s.gzhead.name.charCodeAt(s.gzindex++) & 255;
				else val = 0;
				put_byte(s, val);
			} while (val !== 0);
			if (s.gzhead.hcrc && s.pending > beg) strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending - beg, beg);
			s.gzindex = 0;
		}
		s.status = COMMENT_STATE;
	}
	if (s.status === COMMENT_STATE) {
		if (s.gzhead.comment) {
			let beg = s.pending;
			let val;
			do {
				if (s.pending === s.pending_buf_size) {
					if (s.gzhead.hcrc && s.pending > beg) strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending - beg, beg);
					flush_pending(strm);
					if (s.pending !== 0) {
						s.last_flush = -1;
						return Z_OK$3;
					}
					beg = 0;
				}
				if (s.gzindex < s.gzhead.comment.length) val = s.gzhead.comment.charCodeAt(s.gzindex++) & 255;
				else val = 0;
				put_byte(s, val);
			} while (val !== 0);
			if (s.gzhead.hcrc && s.pending > beg) strm.adler = crc32_1(strm.adler, s.pending_buf, s.pending - beg, beg);
		}
		s.status = HCRC_STATE;
	}
	if (s.status === HCRC_STATE) {
		if (s.gzhead.hcrc) {
			if (s.pending + 2 > s.pending_buf_size) {
				flush_pending(strm);
				if (s.pending !== 0) {
					s.last_flush = -1;
					return Z_OK$3;
				}
			}
			put_byte(s, strm.adler & 255);
			put_byte(s, strm.adler >> 8 & 255);
			strm.adler = 0;
		}
		s.status = BUSY_STATE;
		flush_pending(strm);
		if (s.pending !== 0) {
			s.last_flush = -1;
			return Z_OK$3;
		}
	}
	if (strm.avail_in !== 0 || s.lookahead !== 0 || flush !== Z_NO_FLUSH$2 && s.status !== FINISH_STATE) {
		let bstate = s.level === 0 ? deflate_stored(s, flush) : s.strategy === Z_HUFFMAN_ONLY ? deflate_huff(s, flush) : s.strategy === Z_RLE ? deflate_rle(s, flush) : configuration_table[s.level].func(s, flush);
		if (bstate === BS_FINISH_STARTED || bstate === BS_FINISH_DONE) s.status = FINISH_STATE;
		if (bstate === BS_NEED_MORE || bstate === BS_FINISH_STARTED) {
			if (strm.avail_out === 0) s.last_flush = -1;
			return Z_OK$3;
		}
		if (bstate === BS_BLOCK_DONE) {
			if (flush === Z_PARTIAL_FLUSH) _tr_align(s);
			else if (flush !== Z_BLOCK$1) {
				_tr_stored_block(s, 0, 0, false);
				if (flush === Z_FULL_FLUSH$1) {
					/*** CLEAR_HASH(s); ***/ zero(s.head);
					if (s.lookahead === 0) {
						s.strstart = 0;
						s.block_start = 0;
						s.insert = 0;
					}
				}
			}
			flush_pending(strm);
			if (strm.avail_out === 0) {
				s.last_flush = -1;
				return Z_OK$3;
			}
		}
	}
	if (flush !== Z_FINISH$3) return Z_OK$3;
	if (s.wrap <= 0) return Z_STREAM_END$3;
	if (s.wrap === 2) {
		put_byte(s, strm.adler & 255);
		put_byte(s, strm.adler >> 8 & 255);
		put_byte(s, strm.adler >> 16 & 255);
		put_byte(s, strm.adler >> 24 & 255);
		put_byte(s, strm.total_in & 255);
		put_byte(s, strm.total_in >> 8 & 255);
		put_byte(s, strm.total_in >> 16 & 255);
		put_byte(s, strm.total_in >> 24 & 255);
	} else {
		putShortMSB(s, strm.adler >>> 16);
		putShortMSB(s, strm.adler & 65535);
	}
	flush_pending(strm);
	if (s.wrap > 0) s.wrap = -s.wrap;
	return s.pending !== 0 ? Z_OK$3 : Z_STREAM_END$3;
};
var deflateEnd = (strm) => {
	if (deflateStateCheck(strm)) return Z_STREAM_ERROR$2;
	const status = strm.state.status;
	strm.state = null;
	return status === BUSY_STATE ? err(strm, Z_DATA_ERROR$2) : Z_OK$3;
};
var deflateSetDictionary = (strm, dictionary) => {
	let dictLength = dictionary.length;
	if (deflateStateCheck(strm)) return Z_STREAM_ERROR$2;
	const s = strm.state;
	const wrap = s.wrap;
	if (wrap === 2 || wrap === 1 && s.status !== INIT_STATE || s.lookahead) return Z_STREAM_ERROR$2;
	if (wrap === 1) strm.adler = adler32_1(strm.adler, dictionary, dictLength, 0);
	s.wrap = 0;
	if (dictLength >= s.w_size) {
		if (wrap === 0) {
			/*** CLEAR_HASH(s); ***/
			zero(s.head);
			s.strstart = 0;
			s.block_start = 0;
			s.insert = 0;
		}
		let tmpDict = new Uint8Array(s.w_size);
		tmpDict.set(dictionary.subarray(dictLength - s.w_size, dictLength), 0);
		dictionary = tmpDict;
		dictLength = s.w_size;
	}
	const avail = strm.avail_in;
	const next = strm.next_in;
	const input = strm.input;
	strm.avail_in = dictLength;
	strm.next_in = 0;
	strm.input = dictionary;
	fill_window(s);
	while (s.lookahead >= MIN_MATCH) {
		let str = s.strstart;
		let n = s.lookahead - 2;
		do {
			INSERT_STRING(s, str);
			str++;
		} while (--n);
		s.strstart = str;
		s.lookahead = 2;
		fill_window(s);
	}
	s.strstart += s.lookahead;
	s.block_start = s.strstart;
	s.insert = s.lookahead;
	s.lookahead = 0;
	s.match_length = s.prev_length = 2;
	s.match_available = 0;
	strm.next_in = next;
	strm.input = input;
	strm.avail_in = avail;
	s.wrap = wrap;
	return Z_OK$3;
};
var deflate_1$2 = {
	deflateInit,
	deflateInit2,
	deflateReset,
	deflateResetKeep,
	deflateSetHeader,
	deflate: deflate$2,
	deflateEnd,
	deflateSetDictionary,
	deflateInfo: "pako deflate (from Nodeca project)"
};
var _has = (obj, key) => {
	return Object.prototype.hasOwnProperty.call(obj, key);
};
var assign = function(obj) {
	const sources = Array.prototype.slice.call(arguments, 1);
	while (sources.length) {
		const source = sources.shift();
		if (!source) continue;
		if (typeof source !== "object") throw new TypeError(source + "must be non-object");
		for (const p in source) if (_has(source, p)) obj[p] = source[p];
	}
	return obj;
};
var flattenChunks = (chunks) => {
	let len = 0;
	for (let i = 0, l = chunks.length; i < l; i++) len += chunks[i].length;
	const result = new Uint8Array(len);
	for (let i = 0, pos = 0, l = chunks.length; i < l; i++) {
		let chunk = chunks[i];
		result.set(chunk, pos);
		pos += chunk.length;
	}
	return result;
};
var common = {
	assign,
	flattenChunks
};
var STR_APPLY_UIA_OK = true;
try {
	String.fromCharCode.apply(null, /* @__PURE__ */ new Uint8Array(1));
} catch (__) {
	STR_APPLY_UIA_OK = false;
}
var _utf8len = /* @__PURE__ */ new Uint8Array(256);
for (let q = 0; q < 256; q++) _utf8len[q] = q >= 252 ? 6 : q >= 248 ? 5 : q >= 240 ? 4 : q >= 224 ? 3 : q >= 192 ? 2 : 1;
_utf8len[254] = _utf8len[255] = 1;
var string2buf = (str) => {
	if (typeof TextEncoder === "function" && TextEncoder.prototype.encode) return new TextEncoder().encode(str);
	let buf, c, c2, m_pos, i, str_len = str.length, buf_len = 0;
	for (m_pos = 0; m_pos < str_len; m_pos++) {
		c = str.charCodeAt(m_pos);
		if ((c & 64512) === 55296 && m_pos + 1 < str_len) {
			c2 = str.charCodeAt(m_pos + 1);
			if ((c2 & 64512) === 56320) {
				c = 65536 + (c - 55296 << 10) + (c2 - 56320);
				m_pos++;
			}
		}
		buf_len += c < 128 ? 1 : c < 2048 ? 2 : c < 65536 ? 3 : 4;
	}
	buf = new Uint8Array(buf_len);
	for (i = 0, m_pos = 0; i < buf_len; m_pos++) {
		c = str.charCodeAt(m_pos);
		if ((c & 64512) === 55296 && m_pos + 1 < str_len) {
			c2 = str.charCodeAt(m_pos + 1);
			if ((c2 & 64512) === 56320) {
				c = 65536 + (c - 55296 << 10) + (c2 - 56320);
				m_pos++;
			}
		}
		if (c < 128) buf[i++] = c;
		else if (c < 2048) {
			buf[i++] = 192 | c >>> 6;
			buf[i++] = 128 | c & 63;
		} else if (c < 65536) {
			buf[i++] = 224 | c >>> 12;
			buf[i++] = 128 | c >>> 6 & 63;
			buf[i++] = 128 | c & 63;
		} else {
			buf[i++] = 240 | c >>> 18;
			buf[i++] = 128 | c >>> 12 & 63;
			buf[i++] = 128 | c >>> 6 & 63;
			buf[i++] = 128 | c & 63;
		}
	}
	return buf;
};
var buf2binstring = (buf, len) => {
	if (len < 65534) {
		if (buf.subarray && STR_APPLY_UIA_OK) return String.fromCharCode.apply(null, buf.length === len ? buf : buf.subarray(0, len));
	}
	let result = "";
	for (let i = 0; i < len; i++) result += String.fromCharCode(buf[i]);
	return result;
};
var buf2string = (buf, max) => {
	const len = max || buf.length;
	if (typeof TextDecoder === "function" && TextDecoder.prototype.decode) return new TextDecoder().decode(buf.subarray(0, max));
	let i, out;
	const utf16buf = new Array(len * 2);
	for (out = 0, i = 0; i < len;) {
		let c = buf[i++];
		if (c < 128) {
			utf16buf[out++] = c;
			continue;
		}
		let c_len = _utf8len[c];
		if (c_len > 4) {
			utf16buf[out++] = 65533;
			i += c_len - 1;
			continue;
		}
		c &= c_len === 2 ? 31 : c_len === 3 ? 15 : 7;
		while (c_len > 1 && i < len) {
			c = c << 6 | buf[i++] & 63;
			c_len--;
		}
		if (c_len > 1) {
			utf16buf[out++] = 65533;
			continue;
		}
		if (c < 65536) utf16buf[out++] = c;
		else {
			c -= 65536;
			utf16buf[out++] = 55296 | c >> 10 & 1023;
			utf16buf[out++] = 56320 | c & 1023;
		}
	}
	return buf2binstring(utf16buf, out);
};
var utf8border = (buf, max) => {
	max = max || buf.length;
	if (max > buf.length) max = buf.length;
	let pos = max - 1;
	while (pos >= 0 && (buf[pos] & 192) === 128) pos--;
	if (pos < 0) return max;
	if (pos === 0) return max;
	return pos + _utf8len[buf[pos]] > max ? pos : max;
};
var strings = {
	string2buf,
	buf2string,
	utf8border
};
function ZStream() {
	this.input = null;
	this.next_in = 0;
	this.avail_in = 0;
	this.total_in = 0;
	this.output = null;
	this.next_out = 0;
	this.avail_out = 0;
	this.total_out = 0;
	this.msg = "";
	this.state = null;
	this.data_type = 2;
	this.adler = 0;
}
var zstream = ZStream;
var toString$1 = Object.prototype.toString;
var { Z_NO_FLUSH: Z_NO_FLUSH$1, Z_SYNC_FLUSH, Z_FULL_FLUSH, Z_FINISH: Z_FINISH$2, Z_OK: Z_OK$2, Z_STREAM_END: Z_STREAM_END$2, Z_DEFAULT_COMPRESSION, Z_DEFAULT_STRATEGY, Z_DEFLATED: Z_DEFLATED$1 } = constants$2;
var defaultOptions$1 = {
	level: Z_DEFAULT_COMPRESSION,
	method: Z_DEFLATED$1,
	chunkSize: 16384,
	windowBits: 15,
	memLevel: 8,
	strategy: Z_DEFAULT_STRATEGY,
	legacyHash: true
};
/**
* class Deflate
*
* Generic JS-style wrapper for zlib calls. If you don't need
* streaming behaviour - use more simple functions: [[deflate]],
* [[deflateRaw]] and [[gzip]].
**/
/**
* Deflate.result -> Uint8Array
*
* Compressed result, generated by default [[Deflate#onData]]
* and [[Deflate#onEnd]] handlers. Filled after you push last chunk
* (call [[Deflate#push]] with `Z_FINISH` / `true` param).
**/
/**
* Deflate.err -> Number
*
* Error code after deflate finished. 0 (Z_OK) on success.
* You will not need it in real life, because deflate errors
* are possible only on wrong options or bad `onData` / `onEnd`
* custom handlers.
**/
/**
* Deflate.msg -> String
*
* Error message, if [[Deflate.err]] != 0
**/
/**
* new Deflate(options)
* - options (Object): zlib deflate options.
*
* Creates new deflator instance with specified params. Throws exception
* on bad params. Supported options:
*
* - `level`
* - `windowBits`
* - `memLevel`
* - `strategy`
* - `dictionary`
*
* [http://zlib.net/manual.html#Advanced](http://zlib.net/manual.html#Advanced)
* for more information on these.
*
* - `legacyHash` (Boolean) - use the classic zlib hash (default), which matches
*   canonical zlib output byte-for-byte. Set to `false` to use the faster
*   ANZAC++ hash, which matches recent (chromium) node.js output instead.
*
* Additional options, for internal needs:
*
* - `chunkSize` - size of generated data chunks (16K by default)
* - `raw` (Boolean) - do raw deflate
* - `gzip` (Boolean) - create gzip wrapper
* - `header` (Object) - custom header for gzip
*   - `text` (Boolean) - true if compressed data believed to be text
*   - `time` (Number) - modification time, unix timestamp
*   - `os` (Number) - operation system code
*   - `extra` (Array) - array of bytes with extra data (max 65536)
*   - `name` (String) - file name (binary string)
*   - `comment` (String) - comment (binary string)
*   - `hcrc` (Boolean) - true if header crc should be added
*
* ##### Example:
*
* ```javascript
* const pako = require('pako')
*   , chunk1 = new Uint8Array([1,2,3,4,5,6,7,8,9])
*   , chunk2 = new Uint8Array([10,11,12,13,14,15,16,17,18,19]);
*
* const deflate = new pako.Deflate({ level: 3});
*
* deflate.push(chunk1, false);
* deflate.push(chunk2, true);  // true -> last chunk
*
* if (deflate.err) { throw new Error(deflate.err); }
*
* console.log(deflate.result);
* ```
**/
function Deflate$1(options) {
	this.options = common.assign({}, defaultOptions$1, options || {});
	let opt = this.options;
	if (opt.raw && opt.windowBits > 0) opt.windowBits = -opt.windowBits;
	else if (opt.gzip && opt.windowBits > 0 && opt.windowBits < 16) opt.windowBits += 16;
	this.err = 0;
	this.msg = "";
	this.ended = false;
	this.chunks = [];
	this.strm = new zstream();
	this.strm.avail_out = 0;
	let status = deflate_1$2.deflateInit2(this.strm, opt.level, opt.method, opt.windowBits, opt.memLevel, opt.strategy, opt.legacyHash);
	if (status !== Z_OK$2) throw new Error(messages[status]);
	if (opt.header) deflate_1$2.deflateSetHeader(this.strm, opt.header);
	if (opt.dictionary) {
		let dict;
		if (typeof opt.dictionary === "string") dict = strings.string2buf(opt.dictionary);
		else if (toString$1.call(opt.dictionary) === "[object ArrayBuffer]") dict = new Uint8Array(opt.dictionary);
		else dict = opt.dictionary;
		status = deflate_1$2.deflateSetDictionary(this.strm, dict);
		if (status !== Z_OK$2) throw new Error(messages[status]);
		this._dict_set = true;
	}
}
/**
* Deflate#push(data[, flush_mode]) -> Boolean
* - data (Uint8Array|ArrayBuffer|String): input data. Strings will be
*   converted to utf8 byte sequence.
* - flush_mode (Number|Boolean): 0..6 for corresponding Z_NO_FLUSH..Z_TREE modes.
*   See constants. Skipped or `false` means Z_NO_FLUSH, `true` means Z_FINISH.
*
* Sends input data to deflate pipe, generating [[Deflate#onData]] calls with
* new compressed chunks. Returns `true` on success. The last data block must
* have `flush_mode` Z_FINISH (or `true`). That will flush internal pending
* buffers and call [[Deflate#onEnd]].
*
* On fail call [[Deflate#onEnd]] with error code and return false.
*
* ##### Example
*
* ```javascript
* push(chunk, false); // push one of data chunks
* ...
* push(chunk, true);  // push last chunk
* ```
**/
Deflate$1.prototype.push = function(data, flush_mode) {
	const strm = this.strm;
	const chunkSize = this.options.chunkSize;
	let status, _flush_mode;
	if (this.ended) return false;
	if (flush_mode === ~~flush_mode) _flush_mode = flush_mode;
	else _flush_mode = flush_mode === true ? Z_FINISH$2 : Z_NO_FLUSH$1;
	if (typeof data === "string") strm.input = strings.string2buf(data);
	else if (toString$1.call(data) === "[object ArrayBuffer]") strm.input = new Uint8Array(data);
	else strm.input = data;
	strm.next_in = 0;
	strm.avail_in = strm.input.length;
	for (;;) {
		if (strm.avail_out === 0) {
			strm.output = new Uint8Array(chunkSize);
			strm.next_out = 0;
			strm.avail_out = chunkSize;
		}
		if ((_flush_mode === Z_SYNC_FLUSH || _flush_mode === Z_FULL_FLUSH) && strm.avail_out <= 6) {
			this.onData(strm.output.subarray(0, strm.next_out));
			strm.avail_out = 0;
			continue;
		}
		status = deflate_1$2.deflate(strm, _flush_mode);
		if (status === Z_STREAM_END$2) {
			if (strm.next_out > 0) this.onData(strm.output.subarray(0, strm.next_out));
			status = deflate_1$2.deflateEnd(this.strm);
			this.onEnd(status);
			this.ended = true;
			return status === Z_OK$2;
		}
		if (strm.avail_out === 0) {
			this.onData(strm.output);
			continue;
		}
		if (_flush_mode > 0 && strm.next_out > 0) {
			this.onData(strm.output.subarray(0, strm.next_out));
			strm.avail_out = 0;
			continue;
		}
		if (strm.avail_in === 0) break;
	}
	return true;
};
/**
* Deflate#onData(chunk) -> Void
* - chunk (Uint8Array): output data.
*
* By default, stores data blocks in `chunks[]` property and glue
* those in `onEnd`. Override this handler, if you need another behaviour.
**/
Deflate$1.prototype.onData = function(chunk) {
	this.chunks.push(chunk);
};
/**
* Deflate#onEnd(status) -> Void
* - status (Number): deflate status. 0 (Z_OK) on success,
*   other if not.
*
* Called once after you tell deflate that the input stream is
* complete (Z_FINISH). By default - join collected chunks,
* free memory and fill `results` / `err` properties.
**/
Deflate$1.prototype.onEnd = function(status) {
	if (status === Z_OK$2) this.result = common.flattenChunks(this.chunks);
	this.chunks = [];
	this.err = status;
	this.msg = this.strm.msg;
};
/**
* deflate(data[, options]) -> Uint8Array
* - data (Uint8Array|ArrayBuffer|String): input data to compress.
* - options (Object): zlib deflate options.
*
* Compress `data` with deflate algorithm and `options`.
*
* Supported options are:
*
* - level
* - windowBits
* - memLevel
* - strategy
* - dictionary
*
* [http://zlib.net/manual.html#Advanced](http://zlib.net/manual.html#Advanced)
* for more information on these.
*
* Sugar (options):
*
* - `raw` (Boolean) - say that we work with raw stream, if you don't wish to specify
*   negative windowBits implicitly.
*
* ##### Example:
*
* ```javascript
* const pako = require('pako')
* const data = new Uint8Array([1,2,3,4,5,6,7,8,9]);
*
* console.log(pako.deflate(data));
* ```
**/
function deflate$1(input, options) {
	const deflator = new Deflate$1(options);
	deflator.push(input, true);
	if (deflator.err) throw deflator.msg || messages[deflator.err];
	return deflator.result;
}
/**
* deflateRaw(data[, options]) -> Uint8Array
* - data (Uint8Array|ArrayBuffer|String): input data to compress.
* - options (Object): zlib deflate options.
*
* The same as [[deflate]], but creates raw data, without wrapper
* (header and adler32 crc).
**/
function deflateRaw$1(input, options) {
	options = options || {};
	options.raw = true;
	return deflate$1(input, options);
}
/**
* gzip(data[, options]) -> Uint8Array
* - data (Uint8Array|ArrayBuffer|String): input data to compress.
* - options (Object): zlib deflate options.
*
* The same as [[deflate]], but create gzip wrapper instead of
* deflate one.
**/
function gzip$1(input, options) {
	options = options || {};
	options.gzip = true;
	return deflate$1(input, options);
}
var deflate_1$1 = {
	Deflate: Deflate$1,
	deflate: deflate$1,
	deflateRaw: deflateRaw$1,
	gzip: gzip$1,
	constants: constants$2
};
var BAD$1 = 16209;
var TYPE$1 = 16191;
var inffast = function inflate_fast(strm, start) {
	let _in;
	let last;
	let _out;
	let beg;
	let end;
	let dmax;
	let wsize;
	let whave;
	let wnext;
	let s_window;
	let hold;
	let bits;
	let lcode;
	let dcode;
	let lmask;
	let dmask;
	let here;
	let op;
	let len;
	let dist;
	let from;
	let from_source;
	let input, output;
	const state = strm.state;
	_in = strm.next_in;
	input = strm.input;
	last = _in + (strm.avail_in - 5);
	_out = strm.next_out;
	output = strm.output;
	beg = _out - (start - strm.avail_out);
	end = _out + (strm.avail_out - 257);
	dmax = state.dmax;
	wsize = state.wsize;
	whave = state.whave;
	wnext = state.wnext;
	s_window = state.window;
	hold = state.hold;
	bits = state.bits;
	lcode = state.lencode;
	dcode = state.distcode;
	lmask = (1 << state.lenbits) - 1;
	dmask = (1 << state.distbits) - 1;
	top: do {
		if (bits < 15) {
			hold += input[_in++] << bits;
			bits += 8;
			hold += input[_in++] << bits;
			bits += 8;
		}
		here = lcode[hold & lmask];
		dolen: for (;;) {
			op = here >>> 24;
			hold >>>= op;
			bits -= op;
			op = here >>> 16 & 255;
			if (op === 0) output[_out++] = here & 65535;
			else if (op & 16) {
				len = here & 65535;
				op &= 15;
				if (op) {
					if (bits < op) {
						hold += input[_in++] << bits;
						bits += 8;
					}
					len += hold & (1 << op) - 1;
					hold >>>= op;
					bits -= op;
				}
				if (bits < 15) {
					hold += input[_in++] << bits;
					bits += 8;
					hold += input[_in++] << bits;
					bits += 8;
				}
				here = dcode[hold & dmask];
				dodist: for (;;) {
					op = here >>> 24;
					hold >>>= op;
					bits -= op;
					op = here >>> 16 & 255;
					if (op & 16) {
						dist = here & 65535;
						op &= 15;
						if (bits < op) {
							hold += input[_in++] << bits;
							bits += 8;
							if (bits < op) {
								hold += input[_in++] << bits;
								bits += 8;
							}
						}
						dist += hold & (1 << op) - 1;
						if (dist > dmax) {
							strm.msg = "invalid distance too far back";
							state.mode = BAD$1;
							break top;
						}
						hold >>>= op;
						bits -= op;
						op = _out - beg;
						if (dist > op) {
							op = dist - op;
							if (op > whave) {
								if (state.sane) {
									strm.msg = "invalid distance too far back";
									state.mode = BAD$1;
									break top;
								}
							}
							from = 0;
							from_source = s_window;
							if (wnext === 0) {
								from += wsize - op;
								if (op < len) {
									len -= op;
									do
										output[_out++] = s_window[from++];
									while (--op);
									from = _out - dist;
									from_source = output;
								}
							} else if (wnext < op) {
								from += wsize + wnext - op;
								op -= wnext;
								if (op < len) {
									len -= op;
									do
										output[_out++] = s_window[from++];
									while (--op);
									from = 0;
									if (wnext < len) {
										op = wnext;
										len -= op;
										do
											output[_out++] = s_window[from++];
										while (--op);
										from = _out - dist;
										from_source = output;
									}
								}
							} else {
								from += wnext - op;
								if (op < len) {
									len -= op;
									do
										output[_out++] = s_window[from++];
									while (--op);
									from = _out - dist;
									from_source = output;
								}
							}
							while (len > 2) {
								output[_out++] = from_source[from++];
								output[_out++] = from_source[from++];
								output[_out++] = from_source[from++];
								len -= 3;
							}
							if (len) {
								output[_out++] = from_source[from++];
								if (len > 1) output[_out++] = from_source[from++];
							}
						} else {
							from = _out - dist;
							do {
								output[_out++] = output[from++];
								output[_out++] = output[from++];
								output[_out++] = output[from++];
								len -= 3;
							} while (len > 2);
							if (len) {
								output[_out++] = output[from++];
								if (len > 1) output[_out++] = output[from++];
							}
						}
					} else if ((op & 64) === 0) {
						here = dcode[(here & 65535) + (hold & (1 << op) - 1)];
						continue dodist;
					} else {
						strm.msg = "invalid distance code";
						state.mode = BAD$1;
						break top;
					}
					break;
				}
			} else if ((op & 64) === 0) {
				here = lcode[(here & 65535) + (hold & (1 << op) - 1)];
				continue dolen;
			} else if (op & 32) {
				state.mode = TYPE$1;
				break top;
			} else {
				strm.msg = "invalid literal/length code";
				state.mode = BAD$1;
				break top;
			}
			break;
		}
	} while (_in < last && _out < end);
	len = bits >> 3;
	_in -= len;
	bits -= len << 3;
	hold &= (1 << bits) - 1;
	strm.next_in = _in;
	strm.next_out = _out;
	strm.avail_in = _in < last ? 5 + (last - _in) : 5 - (_in - last);
	strm.avail_out = _out < end ? 257 + (end - _out) : 257 - (_out - end);
	state.hold = hold;
	state.bits = bits;
};
var MAXBITS = 15;
var ENOUGH_LENS$1 = 852;
var ENOUGH_DISTS$1 = 592;
var CODES$1 = 0;
var LENS$1 = 1;
var DISTS$1 = 2;
var lbase = new Uint16Array([
	3,
	4,
	5,
	6,
	7,
	8,
	9,
	10,
	11,
	13,
	15,
	17,
	19,
	23,
	27,
	31,
	35,
	43,
	51,
	59,
	67,
	83,
	99,
	115,
	131,
	163,
	195,
	227,
	258,
	0,
	0
]);
var lext = new Uint8Array([
	16,
	16,
	16,
	16,
	16,
	16,
	16,
	16,
	17,
	17,
	17,
	17,
	18,
	18,
	18,
	18,
	19,
	19,
	19,
	19,
	20,
	20,
	20,
	20,
	21,
	21,
	21,
	21,
	16,
	199,
	75
]);
var dbase = new Uint16Array([
	1,
	2,
	3,
	4,
	5,
	7,
	9,
	13,
	17,
	25,
	33,
	49,
	65,
	97,
	129,
	193,
	257,
	385,
	513,
	769,
	1025,
	1537,
	2049,
	3073,
	4097,
	6145,
	8193,
	12289,
	16385,
	24577,
	0,
	0
]);
var dext = new Uint8Array([
	16,
	16,
	16,
	16,
	17,
	17,
	18,
	18,
	19,
	19,
	20,
	20,
	21,
	21,
	22,
	22,
	23,
	23,
	24,
	24,
	25,
	25,
	26,
	26,
	27,
	27,
	28,
	28,
	29,
	29,
	64,
	64
]);
var inflate_table = (type, lens, lens_index, codes, table, table_index, work, opts) => {
	const bits = opts.bits;
	let len = 0;
	let sym = 0;
	let min = 0, max = 0;
	let root = 0;
	let curr = 0;
	let drop = 0;
	let left = 0;
	let used = 0;
	let huff = 0;
	let incr;
	let fill;
	let low;
	let mask;
	let next;
	let base = null;
	let match;
	const count = /* @__PURE__ */ new Uint16Array(16);
	const offs = /* @__PURE__ */ new Uint16Array(16);
	let extra = null;
	let here_bits, here_op, here_val;
	for (len = 0; len <= MAXBITS; len++) count[len] = 0;
	for (sym = 0; sym < codes; sym++) count[lens[lens_index + sym]]++;
	root = bits;
	for (max = MAXBITS; max >= 1; max--) if (count[max] !== 0) break;
	if (root > max) root = max;
	if (max === 0) {
		table[table_index++] = 20971520;
		table[table_index++] = 20971520;
		opts.bits = 1;
		return 0;
	}
	for (min = 1; min < max; min++) if (count[min] !== 0) break;
	if (root < min) root = min;
	left = 1;
	for (len = 1; len <= MAXBITS; len++) {
		left <<= 1;
		left -= count[len];
		if (left < 0) return -1;
	}
	if (left > 0 && (type === CODES$1 || max !== 1)) return -1;
	offs[1] = 0;
	for (len = 1; len < MAXBITS; len++) offs[len + 1] = offs[len] + count[len];
	for (sym = 0; sym < codes; sym++) if (lens[lens_index + sym] !== 0) work[offs[lens[lens_index + sym]]++] = sym;
	if (type === CODES$1) {
		base = extra = work;
		match = 20;
	} else if (type === LENS$1) {
		base = lbase;
		extra = lext;
		match = 257;
	} else {
		base = dbase;
		extra = dext;
		match = 0;
	}
	huff = 0;
	sym = 0;
	len = min;
	next = table_index;
	curr = root;
	drop = 0;
	low = -1;
	used = 1 << root;
	mask = used - 1;
	if (type === LENS$1 && used > ENOUGH_LENS$1 || type === DISTS$1 && used > ENOUGH_DISTS$1) return 1;
	for (;;) {
		here_bits = len - drop;
		if (work[sym] + 1 < match) {
			here_op = 0;
			here_val = work[sym];
		} else if (work[sym] >= match) {
			here_op = extra[work[sym] - match];
			here_val = base[work[sym] - match];
		} else {
			here_op = 96;
			here_val = 0;
		}
		incr = 1 << len - drop;
		fill = 1 << curr;
		min = fill;
		do {
			fill -= incr;
			table[next + (huff >> drop) + fill] = here_bits << 24 | here_op << 16 | here_val | 0;
		} while (fill !== 0);
		incr = 1 << len - 1;
		while (huff & incr) incr >>= 1;
		if (incr !== 0) {
			huff &= incr - 1;
			huff += incr;
		} else huff = 0;
		sym++;
		if (--count[len] === 0) {
			if (len === max) break;
			len = lens[lens_index + work[sym]];
		}
		if (len > root && (huff & mask) !== low) {
			if (drop === 0) drop = root;
			next += min;
			curr = len - drop;
			left = 1 << curr;
			while (curr + drop < max) {
				left -= count[curr + drop];
				if (left <= 0) break;
				curr++;
				left <<= 1;
			}
			used += 1 << curr;
			if (type === LENS$1 && used > ENOUGH_LENS$1 || type === DISTS$1 && used > ENOUGH_DISTS$1) return 1;
			low = huff & mask;
			table[low] = root << 24 | curr << 16 | next - table_index | 0;
		}
	}
	if (huff !== 0) table[next + huff] = len - drop << 24 | 4194304;
	opts.bits = root;
	return 0;
};
var inftrees = inflate_table;
var CODES = 0;
var LENS = 1;
var DISTS = 2;
var { Z_FINISH: Z_FINISH$1, Z_BLOCK, Z_TREES, Z_OK: Z_OK$1, Z_STREAM_END: Z_STREAM_END$1, Z_NEED_DICT: Z_NEED_DICT$1, Z_STREAM_ERROR: Z_STREAM_ERROR$1, Z_DATA_ERROR: Z_DATA_ERROR$1, Z_MEM_ERROR: Z_MEM_ERROR$1, Z_BUF_ERROR: Z_BUF_ERROR$1, Z_DEFLATED } = constants$2;
var HEAD = 16180;
var FLAGS = 16181;
var TIME = 16182;
var OS = 16183;
var EXLEN = 16184;
var EXTRA = 16185;
var NAME = 16186;
var COMMENT = 16187;
var HCRC = 16188;
var DICTID = 16189;
var DICT = 16190;
var TYPE = 16191;
var TYPEDO = 16192;
var STORED = 16193;
var COPY_ = 16194;
var COPY = 16195;
var TABLE = 16196;
var LENLENS = 16197;
var CODELENS = 16198;
var LEN_ = 16199;
var LEN = 16200;
var LENEXT = 16201;
var DIST = 16202;
var DISTEXT = 16203;
var MATCH = 16204;
var LIT = 16205;
var CHECK = 16206;
var LENGTH = 16207;
var DONE = 16208;
var BAD = 16209;
var MEM = 16210;
var SYNC = 16211;
var ENOUGH_LENS = 852;
var ENOUGH_DISTS = 592;
var DEF_WBITS = 15;
var zswap32 = (q) => {
	return (q >>> 24 & 255) + (q >>> 8 & 65280) + ((q & 65280) << 8) + ((q & 255) << 24);
};
function InflateState() {
	this.strm = null;
	this.mode = 0;
	this.last = false;
	this.wrap = 0;
	this.havedict = false;
	this.flags = 0;
	this.dmax = 0;
	this.check = 0;
	this.total = 0;
	this.head = null;
	this.wbits = 0;
	this.wsize = 0;
	this.whave = 0;
	this.wnext = 0;
	this.window = null;
	this.hold = 0;
	this.bits = 0;
	this.length = 0;
	this.offset = 0;
	this.extra = 0;
	this.lencode = null;
	this.distcode = null;
	this.lenbits = 0;
	this.distbits = 0;
	this.ncode = 0;
	this.nlen = 0;
	this.ndist = 0;
	this.have = 0;
	this.next = null;
	this.lens = /* @__PURE__ */ new Uint16Array(320);
	this.work = /* @__PURE__ */ new Uint16Array(288);
	this.lendyn = null;
	this.distdyn = null;
	this.sane = 0;
	this.back = 0;
	this.was = 0;
}
var inflateStateCheck = (strm) => {
	if (!strm) return 1;
	const state = strm.state;
	if (!state || state.strm !== strm || state.mode < HEAD || state.mode > SYNC) return 1;
	return 0;
};
var inflateResetKeep = (strm) => {
	if (inflateStateCheck(strm)) return Z_STREAM_ERROR$1;
	const state = strm.state;
	strm.total_in = strm.total_out = state.total = 0;
	strm.msg = "";
	if (state.wrap) strm.adler = state.wrap & 1;
	state.mode = HEAD;
	state.last = 0;
	state.havedict = 0;
	state.flags = -1;
	state.dmax = 32768;
	state.head = null;
	state.hold = 0;
	state.bits = 0;
	state.lencode = state.lendyn = new Int32Array(ENOUGH_LENS);
	state.distcode = state.distdyn = new Int32Array(ENOUGH_DISTS);
	state.sane = 1;
	state.back = -1;
	return Z_OK$1;
};
var inflateReset = (strm) => {
	if (inflateStateCheck(strm)) return Z_STREAM_ERROR$1;
	const state = strm.state;
	state.wsize = 0;
	state.whave = 0;
	state.wnext = 0;
	return inflateResetKeep(strm);
};
var inflateReset2 = (strm, windowBits) => {
	let wrap;
	if (inflateStateCheck(strm)) return Z_STREAM_ERROR$1;
	const state = strm.state;
	if (windowBits < 0) {
		wrap = 0;
		windowBits = -windowBits;
	} else {
		wrap = (windowBits >> 4) + 5;
		if (windowBits < 48) windowBits &= 15;
	}
	if (windowBits && (windowBits < 8 || windowBits > 15)) return Z_STREAM_ERROR$1;
	if (state.window !== null && state.wbits !== windowBits) state.window = null;
	state.wrap = wrap;
	state.wbits = windowBits;
	return inflateReset(strm);
};
var inflateInit2 = (strm, windowBits) => {
	if (!strm) return Z_STREAM_ERROR$1;
	const state = new InflateState();
	strm.state = state;
	state.strm = strm;
	state.window = null;
	state.mode = HEAD;
	const ret = inflateReset2(strm, windowBits);
	if (ret !== Z_OK$1) strm.state = null;
	return ret;
};
var inflateInit = (strm) => {
	return inflateInit2(strm, DEF_WBITS);
};
var virgin = true;
var lenfix;
var distfix;
var fixedtables = (state) => {
	if (virgin) {
		lenfix = /* @__PURE__ */ new Int32Array(512);
		distfix = /* @__PURE__ */ new Int32Array(32);
		let sym = 0;
		while (sym < 144) state.lens[sym++] = 8;
		while (sym < 256) state.lens[sym++] = 9;
		while (sym < 280) state.lens[sym++] = 7;
		while (sym < 288) state.lens[sym++] = 8;
		inftrees(LENS, state.lens, 0, 288, lenfix, 0, state.work, { bits: 9 });
		sym = 0;
		while (sym < 32) state.lens[sym++] = 5;
		inftrees(DISTS, state.lens, 0, 32, distfix, 0, state.work, { bits: 5 });
		virgin = false;
	}
	state.lencode = lenfix;
	state.lenbits = 9;
	state.distcode = distfix;
	state.distbits = 5;
};
var updatewindow = (strm, src, end, copy) => {
	let dist;
	const state = strm.state;
	if (state.window === null) state.window = new Uint8Array(1 << state.wbits);
	if (state.wsize === 0) {
		state.wsize = 1 << state.wbits;
		state.wnext = 0;
		state.whave = 0;
	}
	if (copy >= state.wsize) {
		state.window.set(src.subarray(end - state.wsize, end), 0);
		state.wnext = 0;
		state.whave = state.wsize;
	} else {
		dist = state.wsize - state.wnext;
		if (dist > copy) dist = copy;
		state.window.set(src.subarray(end - copy, end - copy + dist), state.wnext);
		copy -= dist;
		if (copy) {
			state.window.set(src.subarray(end - copy, end), 0);
			state.wnext = copy;
			state.whave = state.wsize;
		} else {
			state.wnext += dist;
			if (state.wnext === state.wsize) state.wnext = 0;
			if (state.whave < state.wsize) state.whave += dist;
		}
	}
	return 0;
};
var inflate$2 = (strm, flush) => {
	let state;
	let input, output;
	let next;
	let put;
	let have, left;
	let hold;
	let bits;
	let _in, _out;
	let copy;
	let from;
	let from_source;
	let here = 0;
	let here_bits, here_op, here_val;
	let last_bits, last_op, last_val;
	let len;
	let ret;
	const hbuf = /* @__PURE__ */ new Uint8Array(4);
	let opts;
	let n;
	const order = new Uint8Array([
		16,
		17,
		18,
		0,
		8,
		7,
		9,
		6,
		10,
		5,
		11,
		4,
		12,
		3,
		13,
		2,
		14,
		1,
		15
	]);
	if (inflateStateCheck(strm) || !strm.output || !strm.input && strm.avail_in !== 0) return Z_STREAM_ERROR$1;
	state = strm.state;
	if (state.mode === TYPE) state.mode = TYPEDO;
	put = strm.next_out;
	output = strm.output;
	left = strm.avail_out;
	next = strm.next_in;
	input = strm.input;
	have = strm.avail_in;
	hold = state.hold;
	bits = state.bits;
	_in = have;
	_out = left;
	ret = Z_OK$1;
	inf_leave: for (;;) switch (state.mode) {
		case HEAD:
			if (state.wrap === 0) {
				state.mode = TYPEDO;
				break;
			}
			while (bits < 16) {
				if (have === 0) break inf_leave;
				have--;
				hold += input[next++] << bits;
				bits += 8;
			}
			if (state.wrap & 2 && hold === 35615) {
				if (state.wbits === 0) state.wbits = 15;
				state.check = 0;
				hbuf[0] = hold & 255;
				hbuf[1] = hold >>> 8 & 255;
				state.check = crc32_1(state.check, hbuf, 2, 0);
				hold = 0;
				bits = 0;
				state.mode = FLAGS;
				break;
			}
			if (state.head) state.head.done = false;
			if (!(state.wrap & 1) || (((hold & 255) << 8) + (hold >> 8)) % 31) {
				strm.msg = "incorrect header check";
				state.mode = BAD;
				break;
			}
			if ((hold & 15) !== Z_DEFLATED) {
				strm.msg = "unknown compression method";
				state.mode = BAD;
				break;
			}
			hold >>>= 4;
			bits -= 4;
			len = (hold & 15) + 8;
			if (state.wbits === 0) state.wbits = len;
			if (len > 15 || len > state.wbits) {
				strm.msg = "invalid window size";
				state.mode = BAD;
				break;
			}
			state.dmax = 1 << state.wbits;
			state.flags = 0;
			strm.adler = state.check = 1;
			state.mode = hold & 512 ? DICTID : TYPE;
			hold = 0;
			bits = 0;
			break;
		case FLAGS:
			while (bits < 16) {
				if (have === 0) break inf_leave;
				have--;
				hold += input[next++] << bits;
				bits += 8;
			}
			state.flags = hold;
			if ((state.flags & 255) !== Z_DEFLATED) {
				strm.msg = "unknown compression method";
				state.mode = BAD;
				break;
			}
			if (state.flags & 57344) {
				strm.msg = "unknown header flags set";
				state.mode = BAD;
				break;
			}
			if (state.head) state.head.text = hold >> 8 & 1;
			if (state.flags & 512 && state.wrap & 4) {
				hbuf[0] = hold & 255;
				hbuf[1] = hold >>> 8 & 255;
				state.check = crc32_1(state.check, hbuf, 2, 0);
			}
			hold = 0;
			bits = 0;
			state.mode = TIME;
		case TIME:
			while (bits < 32) {
				if (have === 0) break inf_leave;
				have--;
				hold += input[next++] << bits;
				bits += 8;
			}
			if (state.head) state.head.time = hold;
			if (state.flags & 512 && state.wrap & 4) {
				hbuf[0] = hold & 255;
				hbuf[1] = hold >>> 8 & 255;
				hbuf[2] = hold >>> 16 & 255;
				hbuf[3] = hold >>> 24 & 255;
				state.check = crc32_1(state.check, hbuf, 4, 0);
			}
			hold = 0;
			bits = 0;
			state.mode = OS;
		case OS:
			while (bits < 16) {
				if (have === 0) break inf_leave;
				have--;
				hold += input[next++] << bits;
				bits += 8;
			}
			if (state.head) {
				state.head.xflags = hold & 255;
				state.head.os = hold >> 8;
			}
			if (state.flags & 512 && state.wrap & 4) {
				hbuf[0] = hold & 255;
				hbuf[1] = hold >>> 8 & 255;
				state.check = crc32_1(state.check, hbuf, 2, 0);
			}
			hold = 0;
			bits = 0;
			state.mode = EXLEN;
		case EXLEN:
			if (state.flags & 1024) {
				while (bits < 16) {
					if (have === 0) break inf_leave;
					have--;
					hold += input[next++] << bits;
					bits += 8;
				}
				state.length = hold;
				if (state.head) state.head.extra_len = hold;
				if (state.flags & 512 && state.wrap & 4) {
					hbuf[0] = hold & 255;
					hbuf[1] = hold >>> 8 & 255;
					state.check = crc32_1(state.check, hbuf, 2, 0);
				}
				hold = 0;
				bits = 0;
			} else if (state.head) state.head.extra = null;
			state.mode = EXTRA;
		case EXTRA:
			if (state.flags & 1024) {
				copy = state.length;
				if (copy > have) copy = have;
				if (copy) {
					if (state.head) {
						len = state.head.extra_len - state.length;
						if (!state.head.extra) state.head.extra = new Uint8Array(state.head.extra_len);
						state.head.extra.set(input.subarray(next, next + copy), len);
					}
					if (state.flags & 512 && state.wrap & 4) state.check = crc32_1(state.check, input, copy, next);
					have -= copy;
					next += copy;
					state.length -= copy;
				}
				if (state.length) break inf_leave;
			}
			state.length = 0;
			state.mode = NAME;
		case NAME:
			if (state.flags & 2048) {
				if (have === 0) break inf_leave;
				copy = 0;
				do {
					len = input[next + copy++];
					if (state.head && len && state.length < 65536) state.head.name += String.fromCharCode(len);
				} while (len && copy < have);
				if (state.flags & 512 && state.wrap & 4) state.check = crc32_1(state.check, input, copy, next);
				have -= copy;
				next += copy;
				if (len) break inf_leave;
			} else if (state.head) state.head.name = null;
			state.length = 0;
			state.mode = COMMENT;
		case COMMENT:
			if (state.flags & 4096) {
				if (have === 0) break inf_leave;
				copy = 0;
				do {
					len = input[next + copy++];
					if (state.head && len && state.length < 65536) state.head.comment += String.fromCharCode(len);
				} while (len && copy < have);
				if (state.flags & 512 && state.wrap & 4) state.check = crc32_1(state.check, input, copy, next);
				have -= copy;
				next += copy;
				if (len) break inf_leave;
			} else if (state.head) state.head.comment = null;
			state.mode = HCRC;
		case HCRC:
			if (state.flags & 512) {
				while (bits < 16) {
					if (have === 0) break inf_leave;
					have--;
					hold += input[next++] << bits;
					bits += 8;
				}
				if (state.wrap & 4 && hold !== (state.check & 65535)) {
					strm.msg = "header crc mismatch";
					state.mode = BAD;
					break;
				}
				hold = 0;
				bits = 0;
			}
			if (state.head) {
				state.head.hcrc = state.flags >> 9 & 1;
				state.head.done = true;
			}
			strm.adler = state.check = 0;
			state.mode = TYPE;
			break;
		case DICTID:
			while (bits < 32) {
				if (have === 0) break inf_leave;
				have--;
				hold += input[next++] << bits;
				bits += 8;
			}
			strm.adler = state.check = zswap32(hold);
			hold = 0;
			bits = 0;
			state.mode = DICT;
		case DICT:
			if (state.havedict === 0) {
				strm.next_out = put;
				strm.avail_out = left;
				strm.next_in = next;
				strm.avail_in = have;
				state.hold = hold;
				state.bits = bits;
				return Z_NEED_DICT$1;
			}
			strm.adler = state.check = 1;
			state.mode = TYPE;
		case TYPE: if (flush === Z_BLOCK || flush === Z_TREES) break inf_leave;
		case TYPEDO:
			if (state.last) {
				hold >>>= bits & 7;
				bits -= bits & 7;
				state.mode = CHECK;
				break;
			}
			while (bits < 3) {
				if (have === 0) break inf_leave;
				have--;
				hold += input[next++] << bits;
				bits += 8;
			}
			state.last = hold & 1;
			hold >>>= 1;
			bits -= 1;
			switch (hold & 3) {
				case 0:
					state.mode = STORED;
					break;
				case 1:
					fixedtables(state);
					state.mode = LEN_;
					if (flush === Z_TREES) {
						hold >>>= 2;
						bits -= 2;
						break inf_leave;
					}
					break;
				case 2:
					state.mode = TABLE;
					break;
				case 3:
					strm.msg = "invalid block type";
					state.mode = BAD;
			}
			hold >>>= 2;
			bits -= 2;
			break;
		case STORED:
			hold >>>= bits & 7;
			bits -= bits & 7;
			while (bits < 32) {
				if (have === 0) break inf_leave;
				have--;
				hold += input[next++] << bits;
				bits += 8;
			}
			if ((hold & 65535) !== (hold >>> 16 ^ 65535)) {
				strm.msg = "invalid stored block lengths";
				state.mode = BAD;
				break;
			}
			state.length = hold & 65535;
			hold = 0;
			bits = 0;
			state.mode = COPY_;
			if (flush === Z_TREES) break inf_leave;
		case COPY_: state.mode = COPY;
		case COPY:
			copy = state.length;
			if (copy) {
				if (copy > have) copy = have;
				if (copy > left) copy = left;
				if (copy === 0) break inf_leave;
				output.set(input.subarray(next, next + copy), put);
				have -= copy;
				next += copy;
				left -= copy;
				put += copy;
				state.length -= copy;
				break;
			}
			state.mode = TYPE;
			break;
		case TABLE:
			while (bits < 14) {
				if (have === 0) break inf_leave;
				have--;
				hold += input[next++] << bits;
				bits += 8;
			}
			state.nlen = (hold & 31) + 257;
			hold >>>= 5;
			bits -= 5;
			state.ndist = (hold & 31) + 1;
			hold >>>= 5;
			bits -= 5;
			state.ncode = (hold & 15) + 4;
			hold >>>= 4;
			bits -= 4;
			if (state.nlen > 286 || state.ndist > 30) {
				strm.msg = "too many length or distance symbols";
				state.mode = BAD;
				break;
			}
			state.have = 0;
			state.mode = LENLENS;
		case LENLENS:
			while (state.have < state.ncode) {
				while (bits < 3) {
					if (have === 0) break inf_leave;
					have--;
					hold += input[next++] << bits;
					bits += 8;
				}
				state.lens[order[state.have++]] = hold & 7;
				hold >>>= 3;
				bits -= 3;
			}
			while (state.have < 19) state.lens[order[state.have++]] = 0;
			state.lencode = state.lendyn;
			state.lenbits = 7;
			opts = { bits: state.lenbits };
			ret = inftrees(CODES, state.lens, 0, 19, state.lencode, 0, state.work, opts);
			state.lenbits = opts.bits;
			if (ret) {
				strm.msg = "invalid code lengths set";
				state.mode = BAD;
				break;
			}
			state.have = 0;
			state.mode = CODELENS;
		case CODELENS:
			while (state.have < state.nlen + state.ndist) {
				for (;;) {
					here = state.lencode[hold & (1 << state.lenbits) - 1];
					here_bits = here >>> 24;
					here_op = here >>> 16 & 255;
					here_val = here & 65535;
					if (here_bits <= bits) break;
					if (have === 0) break inf_leave;
					have--;
					hold += input[next++] << bits;
					bits += 8;
				}
				if (here_val < 16) {
					hold >>>= here_bits;
					bits -= here_bits;
					state.lens[state.have++] = here_val;
				} else {
					if (here_val === 16) {
						n = here_bits + 2;
						while (bits < n) {
							if (have === 0) break inf_leave;
							have--;
							hold += input[next++] << bits;
							bits += 8;
						}
						hold >>>= here_bits;
						bits -= here_bits;
						if (state.have === 0) {
							strm.msg = "invalid bit length repeat";
							state.mode = BAD;
							break;
						}
						len = state.lens[state.have - 1];
						copy = 3 + (hold & 3);
						hold >>>= 2;
						bits -= 2;
					} else if (here_val === 17) {
						n = here_bits + 3;
						while (bits < n) {
							if (have === 0) break inf_leave;
							have--;
							hold += input[next++] << bits;
							bits += 8;
						}
						hold >>>= here_bits;
						bits -= here_bits;
						len = 0;
						copy = 3 + (hold & 7);
						hold >>>= 3;
						bits -= 3;
					} else {
						n = here_bits + 7;
						while (bits < n) {
							if (have === 0) break inf_leave;
							have--;
							hold += input[next++] << bits;
							bits += 8;
						}
						hold >>>= here_bits;
						bits -= here_bits;
						len = 0;
						copy = 11 + (hold & 127);
						hold >>>= 7;
						bits -= 7;
					}
					if (state.have + copy > state.nlen + state.ndist) {
						strm.msg = "invalid bit length repeat";
						state.mode = BAD;
						break;
					}
					while (copy--) state.lens[state.have++] = len;
				}
			}
			if (state.mode === BAD) break;
			if (state.lens[256] === 0) {
				strm.msg = "invalid code -- missing end-of-block";
				state.mode = BAD;
				break;
			}
			state.lenbits = 9;
			opts = { bits: state.lenbits };
			ret = inftrees(LENS, state.lens, 0, state.nlen, state.lencode, 0, state.work, opts);
			state.lenbits = opts.bits;
			if (ret) {
				strm.msg = "invalid literal/lengths set";
				state.mode = BAD;
				break;
			}
			state.distbits = 6;
			state.distcode = state.distdyn;
			opts = { bits: state.distbits };
			ret = inftrees(DISTS, state.lens, state.nlen, state.ndist, state.distcode, 0, state.work, opts);
			state.distbits = opts.bits;
			if (ret) {
				strm.msg = "invalid distances set";
				state.mode = BAD;
				break;
			}
			state.mode = LEN_;
			if (flush === Z_TREES) break inf_leave;
		case LEN_: state.mode = LEN;
		case LEN:
			if (have >= 6 && left >= 258) {
				strm.next_out = put;
				strm.avail_out = left;
				strm.next_in = next;
				strm.avail_in = have;
				state.hold = hold;
				state.bits = bits;
				inffast(strm, _out);
				put = strm.next_out;
				output = strm.output;
				left = strm.avail_out;
				next = strm.next_in;
				input = strm.input;
				have = strm.avail_in;
				hold = state.hold;
				bits = state.bits;
				if (state.mode === TYPE) state.back = -1;
				break;
			}
			state.back = 0;
			for (;;) {
				here = state.lencode[hold & (1 << state.lenbits) - 1];
				here_bits = here >>> 24;
				here_op = here >>> 16 & 255;
				here_val = here & 65535;
				if (here_bits <= bits) break;
				if (have === 0) break inf_leave;
				have--;
				hold += input[next++] << bits;
				bits += 8;
			}
			if (here_op && (here_op & 240) === 0) {
				last_bits = here_bits;
				last_op = here_op;
				last_val = here_val;
				for (;;) {
					here = state.lencode[last_val + ((hold & (1 << last_bits + last_op) - 1) >> last_bits)];
					here_bits = here >>> 24;
					here_op = here >>> 16 & 255;
					here_val = here & 65535;
					if (last_bits + here_bits <= bits) break;
					if (have === 0) break inf_leave;
					have--;
					hold += input[next++] << bits;
					bits += 8;
				}
				hold >>>= last_bits;
				bits -= last_bits;
				state.back += last_bits;
			}
			hold >>>= here_bits;
			bits -= here_bits;
			state.back += here_bits;
			state.length = here_val;
			if (here_op === 0) {
				state.mode = LIT;
				break;
			}
			if (here_op & 32) {
				state.back = -1;
				state.mode = TYPE;
				break;
			}
			if (here_op & 64) {
				strm.msg = "invalid literal/length code";
				state.mode = BAD;
				break;
			}
			state.extra = here_op & 15;
			state.mode = LENEXT;
		case LENEXT:
			if (state.extra) {
				n = state.extra;
				while (bits < n) {
					if (have === 0) break inf_leave;
					have--;
					hold += input[next++] << bits;
					bits += 8;
				}
				state.length += hold & (1 << state.extra) - 1;
				hold >>>= state.extra;
				bits -= state.extra;
				state.back += state.extra;
			}
			state.was = state.length;
			state.mode = DIST;
		case DIST:
			for (;;) {
				here = state.distcode[hold & (1 << state.distbits) - 1];
				here_bits = here >>> 24;
				here_op = here >>> 16 & 255;
				here_val = here & 65535;
				if (here_bits <= bits) break;
				if (have === 0) break inf_leave;
				have--;
				hold += input[next++] << bits;
				bits += 8;
			}
			if ((here_op & 240) === 0) {
				last_bits = here_bits;
				last_op = here_op;
				last_val = here_val;
				for (;;) {
					here = state.distcode[last_val + ((hold & (1 << last_bits + last_op) - 1) >> last_bits)];
					here_bits = here >>> 24;
					here_op = here >>> 16 & 255;
					here_val = here & 65535;
					if (last_bits + here_bits <= bits) break;
					if (have === 0) break inf_leave;
					have--;
					hold += input[next++] << bits;
					bits += 8;
				}
				hold >>>= last_bits;
				bits -= last_bits;
				state.back += last_bits;
			}
			hold >>>= here_bits;
			bits -= here_bits;
			state.back += here_bits;
			if (here_op & 64) {
				strm.msg = "invalid distance code";
				state.mode = BAD;
				break;
			}
			state.offset = here_val;
			state.extra = here_op & 15;
			state.mode = DISTEXT;
		case DISTEXT:
			if (state.extra) {
				n = state.extra;
				while (bits < n) {
					if (have === 0) break inf_leave;
					have--;
					hold += input[next++] << bits;
					bits += 8;
				}
				state.offset += hold & (1 << state.extra) - 1;
				hold >>>= state.extra;
				bits -= state.extra;
				state.back += state.extra;
			}
			if (state.offset > state.dmax) {
				strm.msg = "invalid distance too far back";
				state.mode = BAD;
				break;
			}
			state.mode = MATCH;
		case MATCH:
			if (left === 0) break inf_leave;
			copy = _out - left;
			if (state.offset > copy) {
				copy = state.offset - copy;
				if (copy > state.whave) {
					if (state.sane) {
						strm.msg = "invalid distance too far back";
						state.mode = BAD;
						break;
					}
				}
				if (copy > state.wnext) {
					copy -= state.wnext;
					from = state.wsize - copy;
				} else from = state.wnext - copy;
				if (copy > state.length) copy = state.length;
				from_source = state.window;
			} else {
				from_source = output;
				from = put - state.offset;
				copy = state.length;
			}
			if (copy > left) copy = left;
			left -= copy;
			state.length -= copy;
			do
				output[put++] = from_source[from++];
			while (--copy);
			if (state.length === 0) state.mode = LEN;
			break;
		case LIT:
			if (left === 0) break inf_leave;
			output[put++] = state.length;
			left--;
			state.mode = LEN;
			break;
		case CHECK:
			if (state.wrap) {
				while (bits < 32) {
					if (have === 0) break inf_leave;
					have--;
					hold |= input[next++] << bits;
					bits += 8;
				}
				_out -= left;
				strm.total_out += _out;
				state.total += _out;
				if (state.wrap & 4 && _out) strm.adler = state.check = state.flags ? crc32_1(state.check, output, _out, put - _out) : adler32_1(state.check, output, _out, put - _out);
				_out = left;
				if (state.wrap & 4 && (state.flags ? hold : zswap32(hold)) !== state.check) {
					strm.msg = "incorrect data check";
					state.mode = BAD;
					break;
				}
				hold = 0;
				bits = 0;
			}
			state.mode = LENGTH;
		case LENGTH:
			if (state.wrap && state.flags) {
				while (bits < 32) {
					if (have === 0) break inf_leave;
					have--;
					hold += input[next++] << bits;
					bits += 8;
				}
				if (state.wrap & 4 && hold !== (state.total & 4294967295)) {
					strm.msg = "incorrect length check";
					state.mode = BAD;
					break;
				}
				hold = 0;
				bits = 0;
			}
			state.mode = DONE;
		case DONE:
			ret = Z_STREAM_END$1;
			break inf_leave;
		case BAD:
			ret = Z_DATA_ERROR$1;
			break inf_leave;
		case MEM: return Z_MEM_ERROR$1;
		case SYNC:
		default: return Z_STREAM_ERROR$1;
	}
	strm.next_out = put;
	strm.avail_out = left;
	strm.next_in = next;
	strm.avail_in = have;
	state.hold = hold;
	state.bits = bits;
	if (state.wsize || _out !== strm.avail_out && state.mode < BAD && (state.mode < CHECK || flush !== Z_FINISH$1)) {
		if (updatewindow(strm, strm.output, strm.next_out, _out - strm.avail_out));
	}
	_in -= strm.avail_in;
	_out -= strm.avail_out;
	strm.total_in += _in;
	strm.total_out += _out;
	state.total += _out;
	if (state.wrap & 4 && _out) strm.adler = state.check = state.flags ? crc32_1(state.check, output, _out, strm.next_out - _out) : adler32_1(state.check, output, _out, strm.next_out - _out);
	strm.data_type = state.bits + (state.last ? 64 : 0) + (state.mode === TYPE ? 128 : 0) + (state.mode === LEN_ || state.mode === COPY_ ? 256 : 0);
	if ((_in === 0 && _out === 0 || flush === Z_FINISH$1) && ret === Z_OK$1) ret = Z_BUF_ERROR$1;
	return ret;
};
var inflateEnd = (strm) => {
	if (inflateStateCheck(strm)) return Z_STREAM_ERROR$1;
	let state = strm.state;
	if (state.window) state.window = null;
	strm.state = null;
	return Z_OK$1;
};
var inflateGetHeader = (strm, head) => {
	if (inflateStateCheck(strm)) return Z_STREAM_ERROR$1;
	const state = strm.state;
	if ((state.wrap & 2) === 0) return Z_STREAM_ERROR$1;
	state.head = head;
	head.done = false;
	return Z_OK$1;
};
var inflateSetDictionary = (strm, dictionary) => {
	const dictLength = dictionary.length;
	let state;
	let dictid;
	let ret;
	if (inflateStateCheck(strm)) return Z_STREAM_ERROR$1;
	state = strm.state;
	if (state.wrap !== 0 && state.mode !== DICT) return Z_STREAM_ERROR$1;
	if (state.mode === DICT) {
		dictid = 1;
		dictid = adler32_1(dictid, dictionary, dictLength, 0);
		if (dictid !== state.check) return Z_DATA_ERROR$1;
	}
	ret = updatewindow(strm, dictionary, dictLength, dictLength);
	if (ret) {
		state.mode = MEM;
		return Z_MEM_ERROR$1;
	}
	state.havedict = 1;
	return Z_OK$1;
};
var inflate_1$2 = {
	inflateReset,
	inflateReset2,
	inflateResetKeep,
	inflateInit,
	inflateInit2,
	inflate: inflate$2,
	inflateEnd,
	inflateGetHeader,
	inflateSetDictionary,
	inflateInfo: "pako inflate (from Nodeca project)"
};
function GZheader() {
	this.text = 0;
	this.time = 0;
	this.xflags = 0;
	this.os = 0;
	this.extra = null;
	this.extra_len = 0;
	this.name = "";
	this.comment = "";
	this.hcrc = 0;
	this.done = false;
}
var gzheader = GZheader;
var toString = Object.prototype.toString;
var { Z_NO_FLUSH, Z_FINISH, Z_OK, Z_STREAM_END, Z_NEED_DICT, Z_STREAM_ERROR, Z_DATA_ERROR, Z_MEM_ERROR, Z_BUF_ERROR } = constants$2;
var defaultOptions = {
	chunkSize: 65536,
	windowBits: 15,
	to: ""
};
/**
* class Inflate
*
* Generic JS-style wrapper for zlib calls. If you don't need
* streaming behaviour - use more simple functions: [[inflate]]
* and [[inflateRaw]].
**/
/**
* Inflate.result -> Uint8Array|String
*
* Uncompressed result, generated by default [[Inflate#onData]]
* and [[Inflate#onEnd]] handlers. Filled after you push last chunk
* (call [[Inflate#push]] with `Z_FINISH` / `true` param).
**/
/**
* Inflate.err -> Number
*
* Error code after inflate finished. 0 (Z_OK) on success.
* Should be checked if broken data possible.
**/
/**
* Inflate.msg -> String
*
* Error message, if [[Inflate.err]] != 0
**/
/**
* new Inflate(options)
* - options (Object): zlib inflate options.
*
* Creates new inflator instance with specified params. Throws exception
* on bad params. Supported options:
*
* - `windowBits`
* - `dictionary`
*
* [http://zlib.net/manual.html#Advanced](http://zlib.net/manual.html#Advanced)
* for more information on these.
*
* Additional options, for internal needs:
*
* - `chunkSize` - size of generated data chunks (16K by default)
* - `raw` (Boolean) - do raw inflate
* - `to` (String) - if equal to 'string', then result will be converted
*   from utf8 to utf16 (javascript) string. When string output requested,
*   chunk length can differ from `chunkSize`, depending on content.
*
* By default, when no options set, autodetect deflate/gzip data format via
* wrapper header.
*
* ##### Example:
*
* ```javascript
* const pako = require('pako')
* const chunk1 = new Uint8Array([1,2,3,4,5,6,7,8,9])
* const chunk2 = new Uint8Array([10,11,12,13,14,15,16,17,18,19]);
*
* const inflate = new pako.Inflate({ level: 3});
*
* inflate.push(chunk1, false);
* inflate.push(chunk2, true);  // true -> last chunk
*
* if (inflate.err) { throw new Error(inflate.err); }
*
* console.log(inflate.result);
* ```
**/
function Inflate$1(options) {
	this.options = common.assign({}, defaultOptions, options || {});
	const opt = this.options;
	if (opt.raw && opt.windowBits >= 0 && opt.windowBits < 16) {
		opt.windowBits = -opt.windowBits;
		if (opt.windowBits === 0) opt.windowBits = -15;
	}
	if (opt.windowBits >= 0 && opt.windowBits < 16 && !(options && options.windowBits)) opt.windowBits += 32;
	if (opt.windowBits > 15 && opt.windowBits < 48) {
		if ((opt.windowBits & 15) === 0) opt.windowBits |= 15;
	}
	this.err = 0;
	this.msg = "";
	this.ended = false;
	this.chunks = [];
	this.strm = new zstream();
	this.strm.avail_out = 0;
	let status = inflate_1$2.inflateInit2(this.strm, opt.windowBits);
	if (status !== Z_OK) throw new Error(messages[status]);
	this.header = new gzheader();
	inflate_1$2.inflateGetHeader(this.strm, this.header);
	if (opt.dictionary) {
		if (typeof opt.dictionary === "string") opt.dictionary = strings.string2buf(opt.dictionary);
		else if (toString.call(opt.dictionary) === "[object ArrayBuffer]") opt.dictionary = new Uint8Array(opt.dictionary);
		if (opt.raw) {
			status = inflate_1$2.inflateSetDictionary(this.strm, opt.dictionary);
			if (status !== Z_OK) throw new Error(messages[status]);
		}
	}
}
/**
* Inflate#push(data[, flush_mode]) -> Boolean
* - data (Uint8Array|ArrayBuffer): input data
* - flush_mode (Number|Boolean): 0..6 for corresponding Z_NO_FLUSH..Z_TREE
*   flush modes. See constants. Skipped or `false` means Z_NO_FLUSH,
*   `true` means Z_FINISH.
*
* Sends input data to inflate pipe, generating [[Inflate#onData]] calls with
* new output chunks. Returns `true` on success. If end of stream detected,
* [[Inflate#onEnd]] will be called.
*
* `flush_mode` is not needed for normal operation, because end of stream
* detected automatically. You may try to use it for advanced things, but
* this functionality was not tested.
*
* On fail call [[Inflate#onEnd]] with error code and return false.
*
* ##### Example
*
* ```javascript
* push(chunk, false); // push one of data chunks
* ...
* push(chunk, true);  // push last chunk
* ```
**/
Inflate$1.prototype.push = function(data, flush_mode) {
	const strm = this.strm;
	const chunkSize = this.options.chunkSize;
	const dictionary = this.options.dictionary;
	let status, _flush_mode, last_avail_out;
	if (this.ended) return false;
	if (flush_mode === ~~flush_mode) _flush_mode = flush_mode;
	else _flush_mode = flush_mode === true ? Z_FINISH : Z_NO_FLUSH;
	if (toString.call(data) === "[object ArrayBuffer]") strm.input = new Uint8Array(data);
	else strm.input = data;
	strm.next_in = 0;
	strm.avail_in = strm.input.length;
	for (;;) {
		if (strm.avail_out === 0) {
			strm.output = new Uint8Array(chunkSize);
			strm.next_out = 0;
			strm.avail_out = chunkSize;
		}
		status = inflate_1$2.inflate(strm, _flush_mode);
		if (status === Z_NEED_DICT && dictionary) {
			status = inflate_1$2.inflateSetDictionary(strm, dictionary);
			if (status === Z_OK) status = inflate_1$2.inflate(strm, _flush_mode);
			else if (status === Z_DATA_ERROR) status = Z_NEED_DICT;
		}
		while (strm.avail_in > 0 && status === Z_STREAM_END && strm.state.wrap & 2 && strm.state.flags !== 0 && strm.input[strm.next_in] !== 0) {
			inflate_1$2.inflateReset(strm);
			status = inflate_1$2.inflate(strm, _flush_mode);
		}
		switch (status) {
			case Z_STREAM_ERROR:
			case Z_DATA_ERROR:
			case Z_NEED_DICT:
			case Z_MEM_ERROR:
				this.onEnd(status);
				this.ended = true;
				return false;
		}
		last_avail_out = strm.avail_out;
		if (strm.next_out) {
			if (strm.avail_out === 0 || status === Z_STREAM_END || _flush_mode > 0) {
				if (this.options.to === "string") {
					let next_out_utf8 = strings.utf8border(strm.output, strm.next_out);
					let tail = strm.next_out - next_out_utf8;
					let utf8str = strings.buf2string(strm.output, next_out_utf8);
					strm.next_out = tail;
					strm.avail_out = chunkSize - tail;
					if (tail) strm.output.set(strm.output.subarray(next_out_utf8, next_out_utf8 + tail), 0);
					this.onData(utf8str);
				} else {
					this.onData(strm.output.length === strm.next_out ? strm.output : strm.output.subarray(0, strm.next_out));
					strm.avail_out = 0;
					strm.next_out = 0;
				}
			}
		}
		if ((status === Z_OK || status === Z_BUF_ERROR) && last_avail_out === 0) continue;
		if (status === Z_STREAM_END) {
			status = inflate_1$2.inflateEnd(this.strm);
			this.onEnd(status);
			this.ended = true;
			return true;
		}
		if (strm.avail_in === 0) {
			if (_flush_mode === Z_FINISH) {
				status = inflate_1$2.inflateEnd(this.strm);
				this.onEnd(status === Z_OK ? Z_BUF_ERROR : status);
				this.ended = true;
				return false;
			}
			break;
		}
	}
	return true;
};
/**
* Inflate#onData(chunk) -> Void
* - chunk (Uint8Array|String): output data. When string output requested,
*   each chunk will be string.
*
* By default, stores data blocks in `chunks[]` property and glue
* those in `onEnd`. Override this handler, if you need another behaviour.
**/
Inflate$1.prototype.onData = function(chunk) {
	this.chunks.push(chunk);
};
/**
* Inflate#onEnd(status) -> Void
* - status (Number): inflate status. 0 (Z_OK) on success,
*   other if not.
*
* Called either after you tell inflate that the input stream is
* complete (Z_FINISH). By default - join collected chunks,
* free memory and fill `results` / `err` properties.
**/
Inflate$1.prototype.onEnd = function(status) {
	if (status === Z_OK) {
		if (this.options.to === "string") this.result = this.chunks.join("");
		else this.result = common.flattenChunks(this.chunks);
	}
	this.chunks = [];
	this.err = status;
	this.msg = this.strm.msg;
};
/**
* inflate(data[, options]) -> Uint8Array|String
* - data (Uint8Array|ArrayBuffer): input data to decompress.
* - options (Object): zlib inflate options.
*
* Decompress `data` with inflate/ungzip and `options`. Autodetect
* format via wrapper header by default. That's why we don't provide
* separate `ungzip` method.
*
* Supported options are:
*
* - windowBits
*
* [http://zlib.net/manual.html#Advanced](http://zlib.net/manual.html#Advanced)
* for more information.
*
* Sugar (options):
*
* - `raw` (Boolean) - say that we work with raw stream, if you don't wish to specify
*   negative windowBits implicitly.
* - `to` (String) - if equal to 'string', then result will be converted
*   from utf8 to utf16 (javascript) string. When string output requested,
*   chunk length can differ from `chunkSize`, depending on content.
*
*
* ##### Example:
*
* ```javascript
* const pako = require('pako');
* const input = pako.deflate(new Uint8Array([1,2,3,4,5,6,7,8,9]));
* let output;
*
* try {
*   output = pako.inflate(input);
* } catch (err) {
*   console.log(err);
* }
* ```
**/
function inflate$1(input, options) {
	const inflator = new Inflate$1(options);
	inflator.push(input, true);
	if (inflator.err) throw inflator.msg || messages[inflator.err];
	return inflator.result;
}
/**
* inflateRaw(data[, options]) -> Uint8Array|String
* - data (Uint8Array|ArrayBuffer): input data to decompress.
* - options (Object): zlib inflate options.
*
* The same as [[inflate]], but creates raw data, without wrapper
* (header and adler32 crc).
**/
function inflateRaw$1(input, options) {
	options = options || {};
	options.raw = true;
	return inflate$1(input, options);
}
var inflate_1$1 = {
	Inflate: Inflate$1,
	inflate: inflate$1,
	inflateRaw: inflateRaw$1,
	ungzip: inflate$1,
	constants: constants$2
};
var { Deflate, deflate, deflateRaw, gzip } = deflate_1$1;
var { Inflate, inflate, inflateRaw, ungzip } = inflate_1$1;
var Inflate_1 = Inflate;
var inflate_1 = inflate;
//#endregion
//#region node_modules/fast-png/lib-esm/helpers/crc.js
var crcTable = [];
for (let n = 0; n < 256; n++) {
	let c = n;
	for (let k = 0; k < 8; k++) if (c & 1) c = 3988292384 ^ c >>> 1;
	else c = c >>> 1;
	crcTable[n] = c;
}
var initialCrc = 4294967295;
function updateCrc(currentCrc, data, length) {
	let c = currentCrc;
	for (let n = 0; n < length; n++) c = crcTable[(c ^ data[n]) & 255] ^ c >>> 8;
	return c;
}
function crc(data, length) {
	return (updateCrc(initialCrc, data, length) ^ initialCrc) >>> 0;
}
function checkCrc(buffer, crcLength, chunkName) {
	const expectedCrc = buffer.readUint32();
	const actualCrc = crc(new Uint8Array(buffer.buffer, buffer.byteOffset + buffer.offset - crcLength - 4, crcLength), crcLength);
	if (actualCrc !== expectedCrc) throw new Error(`CRC mismatch for chunk ${chunkName}. Expected ${expectedCrc}, found ${actualCrc}`);
}
//#endregion
//#region node_modules/fast-png/lib-esm/helpers/unfilter.js
function unfilterNone(currentLine, newLine, bytesPerLine) {
	for (let i = 0; i < bytesPerLine; i++) newLine[i] = currentLine[i];
}
function unfilterSub(currentLine, newLine, bytesPerLine, bytesPerPixel) {
	let i = 0;
	for (; i < bytesPerPixel; i++) newLine[i] = currentLine[i];
	for (; i < bytesPerLine; i++) newLine[i] = currentLine[i] + newLine[i - bytesPerPixel] & 255;
}
function unfilterUp(currentLine, newLine, prevLine, bytesPerLine) {
	let i = 0;
	if (prevLine.length === 0) for (; i < bytesPerLine; i++) newLine[i] = currentLine[i];
	else for (; i < bytesPerLine; i++) newLine[i] = currentLine[i] + prevLine[i] & 255;
}
function unfilterAverage(currentLine, newLine, prevLine, bytesPerLine, bytesPerPixel) {
	let i = 0;
	if (prevLine.length === 0) {
		for (; i < bytesPerPixel; i++) newLine[i] = currentLine[i];
		for (; i < bytesPerLine; i++) newLine[i] = currentLine[i] + (newLine[i - bytesPerPixel] >> 1) & 255;
	} else {
		for (; i < bytesPerPixel; i++) newLine[i] = currentLine[i] + (prevLine[i] >> 1) & 255;
		for (; i < bytesPerLine; i++) newLine[i] = currentLine[i] + (newLine[i - bytesPerPixel] + prevLine[i] >> 1) & 255;
	}
}
function unfilterPaeth(currentLine, newLine, prevLine, bytesPerLine, bytesPerPixel) {
	let i = 0;
	if (prevLine.length === 0) {
		for (; i < bytesPerPixel; i++) newLine[i] = currentLine[i];
		for (; i < bytesPerLine; i++) newLine[i] = currentLine[i] + newLine[i - bytesPerPixel] & 255;
	} else {
		for (; i < bytesPerPixel; i++) newLine[i] = currentLine[i] + prevLine[i] & 255;
		for (; i < bytesPerLine; i++) newLine[i] = currentLine[i] + paethPredictor(newLine[i - bytesPerPixel], prevLine[i], prevLine[i - bytesPerPixel]) & 255;
	}
}
function paethPredictor(a, b, c) {
	const p = a + b - c;
	const pa = Math.abs(p - a);
	const pb = Math.abs(p - b);
	const pc = Math.abs(p - c);
	if (pa <= pb && pa <= pc) return a;
	else if (pb <= pc) return b;
	else return c;
}
//#endregion
//#region node_modules/fast-png/lib-esm/helpers/applyUnfilter.js
/**
* Apllies filter on scanline based on the filter type.
* @param filterType - The filter type to apply.
* @param currentLine - The current line of pixel data.
* @param newLine - The new line of pixel data.
* @param prevLine - The previous line of pixel data.
* @param passLineBytes - The number of bytes in the pass line.
* @param bytesPerPixel - The number of bytes per pixel.
*/
function applyUnfilter(filterType, currentLine, newLine, prevLine, passLineBytes, bytesPerPixel) {
	switch (filterType) {
		case 0:
			unfilterNone(currentLine, newLine, passLineBytes);
			break;
		case 1:
			unfilterSub(currentLine, newLine, passLineBytes, bytesPerPixel);
			break;
		case 2:
			unfilterUp(currentLine, newLine, prevLine, passLineBytes);
			break;
		case 3:
			unfilterAverage(currentLine, newLine, prevLine, passLineBytes, bytesPerPixel);
			break;
		case 4:
			unfilterPaeth(currentLine, newLine, prevLine, passLineBytes, bytesPerPixel);
			break;
		default: throw new Error(`Unsupported filter: ${filterType}`);
	}
}
//#endregion
//#region node_modules/fast-png/lib-esm/helpers/decodeInterlaceAdam7.js
var uint16$1 = new Uint16Array([255]);
var osIsLittleEndian$1 = new Uint8Array(uint16$1.buffer)[0] === 255;
/**
* Decodes the Adam7 interlaced PNG data.
*
* @param params - DecodeInterlaceNullParams
* @returns - array of pixel data.
*/
function decodeInterlaceAdam7(params) {
	const { data, width, height, channels, depth } = params;
	const passes = [
		{
			x: 0,
			y: 0,
			xStep: 8,
			yStep: 8
		},
		{
			x: 4,
			y: 0,
			xStep: 8,
			yStep: 8
		},
		{
			x: 0,
			y: 4,
			xStep: 4,
			yStep: 8
		},
		{
			x: 2,
			y: 0,
			xStep: 4,
			yStep: 4
		},
		{
			x: 0,
			y: 2,
			xStep: 2,
			yStep: 4
		},
		{
			x: 1,
			y: 0,
			xStep: 2,
			yStep: 2
		},
		{
			x: 0,
			y: 1,
			xStep: 1,
			yStep: 2
		}
	];
	const bytesPerPixel = Math.ceil(depth / 8) * channels;
	const resultData = new Uint8Array(height * width * bytesPerPixel);
	let offset = 0;
	for (let passIndex = 0; passIndex < 7; passIndex++) {
		const pass = passes[passIndex];
		const passWidth = Math.ceil((width - pass.x) / pass.xStep);
		const passHeight = Math.ceil((height - pass.y) / pass.yStep);
		if (passWidth <= 0 || passHeight <= 0) continue;
		const passLineBytes = passWidth * bytesPerPixel;
		const prevLine = new Uint8Array(passLineBytes);
		for (let y = 0; y < passHeight; y++) {
			const filterType = data[offset++];
			const currentLine = data.subarray(offset, offset + passLineBytes);
			offset += passLineBytes;
			const newLine = new Uint8Array(passLineBytes);
			applyUnfilter(filterType, currentLine, newLine, prevLine, passLineBytes, bytesPerPixel);
			prevLine.set(newLine);
			for (let x = 0; x < passWidth; x++) {
				const outputX = pass.x + x * pass.xStep;
				const outputY = pass.y + y * pass.yStep;
				if (outputX >= width || outputY >= height) continue;
				for (let i = 0; i < bytesPerPixel; i++) resultData[(outputY * width + outputX) * bytesPerPixel + i] = newLine[x * bytesPerPixel + i];
			}
		}
	}
	if (depth === 16) {
		const uint16Data = new Uint16Array(resultData.buffer);
		if (osIsLittleEndian$1) for (let k = 0; k < uint16Data.length; k++) uint16Data[k] = swap16$1(uint16Data[k]);
		return uint16Data;
	} else return resultData;
}
function swap16$1(val) {
	return (val & 255) << 8 | val >> 8 & 255;
}
//#endregion
//#region node_modules/fast-png/lib-esm/helpers/decodeInterlaceNull.js
var uint16 = new Uint16Array([255]);
var osIsLittleEndian = new Uint8Array(uint16.buffer)[0] === 255;
var empty = /* @__PURE__ */ new Uint8Array(0);
function decodeInterlaceNull(params) {
	const { data, width, height, channels, depth } = params;
	const bytesPerPixel = Math.ceil(depth / 8) * channels;
	const bytesPerLine = Math.ceil(depth / 8 * channels * width);
	const newData = new Uint8Array(height * bytesPerLine);
	let prevLine = empty;
	let offset = 0;
	let currentLine;
	let newLine;
	for (let i = 0; i < height; i++) {
		currentLine = data.subarray(offset + 1, offset + 1 + bytesPerLine);
		newLine = newData.subarray(i * bytesPerLine, (i + 1) * bytesPerLine);
		switch (data[offset]) {
			case 0:
				unfilterNone(currentLine, newLine, bytesPerLine);
				break;
			case 1:
				unfilterSub(currentLine, newLine, bytesPerLine, bytesPerPixel);
				break;
			case 2:
				unfilterUp(currentLine, newLine, prevLine, bytesPerLine);
				break;
			case 3:
				unfilterAverage(currentLine, newLine, prevLine, bytesPerLine, bytesPerPixel);
				break;
			case 4:
				unfilterPaeth(currentLine, newLine, prevLine, bytesPerLine, bytesPerPixel);
				break;
			default: throw new Error(`Unsupported filter: ${data[offset]}`);
		}
		prevLine = newLine;
		offset += bytesPerLine + 1;
	}
	if (depth === 16) {
		const uint16Data = new Uint16Array(newData.buffer);
		if (osIsLittleEndian) for (let k = 0; k < uint16Data.length; k++) uint16Data[k] = swap16(uint16Data[k]);
		return uint16Data;
	} else return newData;
}
function swap16(val) {
	return (val & 255) << 8 | val >> 8 & 255;
}
//#endregion
//#region node_modules/fast-png/lib-esm/helpers/signature.js
var pngSignature = Uint8Array.of(137, 80, 78, 71, 13, 10, 26, 10);
function checkSignature(buffer) {
	if (!hasPngSignature(buffer.readBytes(pngSignature.length))) throw new Error("wrong PNG signature");
}
function hasPngSignature(array) {
	if (array.length < pngSignature.length) return false;
	for (let i = 0; i < pngSignature.length; i++) if (array[i] !== pngSignature[i]) return false;
	return true;
}
//#endregion
//#region node_modules/fast-png/lib-esm/helpers/text.js
var textChunkName = "tEXt";
var NULL = 0;
var latin1Decoder = new TextDecoder("latin1");
function validateKeyword(keyword) {
	validateLatin1(keyword);
	if (keyword.length === 0 || keyword.length > 79) throw new Error("keyword length must be between 1 and 79");
}
var latin1Regex = /^[\u0000-\u00FF]*$/;
function validateLatin1(text) {
	if (!latin1Regex.test(text)) throw new Error("invalid latin1 text");
}
function decodetEXt(text, buffer, length) {
	const keyword = readKeyword(buffer);
	text[keyword] = readLatin1(buffer, length - keyword.length - 1);
}
function readKeyword(buffer) {
	buffer.mark();
	while (buffer.readByte() !== NULL);
	const end = buffer.offset;
	buffer.reset();
	const keyword = latin1Decoder.decode(buffer.readBytes(end - buffer.offset - 1));
	buffer.skip(1);
	validateKeyword(keyword);
	return keyword;
}
function readLatin1(buffer, length) {
	return latin1Decoder.decode(buffer.readBytes(length));
}
//#endregion
//#region node_modules/fast-png/lib-esm/internalTypes.js
var ColorType = {
	UNKNOWN: -1,
	GREYSCALE: 0,
	TRUECOLOUR: 2,
	INDEXED_COLOUR: 3,
	GREYSCALE_ALPHA: 4,
	TRUECOLOUR_ALPHA: 6
};
var CompressionMethod = {
	UNKNOWN: -1,
	DEFLATE: 0
};
var FilterMethod = {
	UNKNOWN: -1,
	ADAPTIVE: 0
};
var InterlaceMethod = {
	UNKNOWN: -1,
	NO_INTERLACE: 0,
	ADAM7: 1
};
var DisposeOpType = {
	NONE: 0,
	BACKGROUND: 1,
	PREVIOUS: 2
};
var BlendOpType = {
	SOURCE: 0,
	OVER: 1
};
//#endregion
//#region node_modules/fast-png/lib-esm/PngDecoder.js
var PngDecoder = class extends IOBuffer {
	_checkCrc;
	_inflator;
	_png;
	_apng;
	_end;
	_hasPalette;
	_palette;
	_hasTransparency;
	_transparency;
	_compressionMethod;
	_filterMethod;
	_interlaceMethod;
	_colorType;
	_isAnimated;
	_numberOfFrames;
	_numberOfPlays;
	_frames;
	_writingDataChunks;
	constructor(data, options = {}) {
		super(data);
		const { checkCrc = false } = options;
		this._checkCrc = checkCrc;
		this._inflator = new Inflate_1();
		this._png = {
			width: -1,
			height: -1,
			channels: -1,
			data: /* @__PURE__ */ new Uint8Array(0),
			depth: 1,
			text: {}
		};
		this._apng = {
			width: -1,
			height: -1,
			channels: -1,
			depth: 1,
			numberOfFrames: 1,
			numberOfPlays: 0,
			text: {},
			frames: []
		};
		this._end = false;
		this._hasPalette = false;
		this._palette = [];
		this._hasTransparency = false;
		this._transparency = /* @__PURE__ */ new Uint16Array(0);
		this._compressionMethod = CompressionMethod.UNKNOWN;
		this._filterMethod = FilterMethod.UNKNOWN;
		this._interlaceMethod = InterlaceMethod.UNKNOWN;
		this._colorType = ColorType.UNKNOWN;
		this._isAnimated = false;
		this._numberOfFrames = 1;
		this._numberOfPlays = 0;
		this._frames = [];
		this._writingDataChunks = false;
		this.setBigEndian();
	}
	decode() {
		checkSignature(this);
		while (!this._end) {
			const length = this.readUint32();
			const type = this.readChars(4);
			this.decodeChunk(length, type);
		}
		this.decodeImage();
		return this._png;
	}
	decodeApng() {
		checkSignature(this);
		while (!this._end) {
			const length = this.readUint32();
			const type = this.readChars(4);
			this.decodeApngChunk(length, type);
		}
		this.decodeApngImage();
		return this._apng;
	}
	decodeChunk(length, type) {
		const offset = this.offset;
		switch (type) {
			case "IHDR":
				this.decodeIHDR();
				break;
			case "PLTE":
				this.decodePLTE(length);
				break;
			case "IDAT":
				this.decodeIDAT(length);
				break;
			case "IEND":
				this._end = true;
				break;
			case "tRNS":
				this.decodetRNS(length);
				break;
			case "iCCP":
				this.decodeiCCP(length);
				break;
			case textChunkName:
				decodetEXt(this._png.text, this, length);
				break;
			case "pHYs":
				this.decodepHYs();
				break;
			default: this.skip(length);
		}
		if (this.offset - offset !== length) throw new Error(`Length mismatch while decoding chunk ${type}`);
		if (this._checkCrc) checkCrc(this, length + 4, type);
		else this.skip(4);
	}
	decodeApngChunk(length, type) {
		const offset = this.offset;
		if (type !== "fdAT" && type !== "IDAT" && this._writingDataChunks) this.pushDataToFrame();
		switch (type) {
			case "acTL":
				this.decodeACTL();
				break;
			case "fcTL":
				this.decodeFCTL();
				break;
			case "fdAT":
				this.decodeFDAT(length);
				break;
			default:
				this.decodeChunk(length, type);
				this.offset = offset + length;
		}
		if (this.offset - offset !== length) throw new Error(`Length mismatch while decoding chunk ${type}`);
		if (this._checkCrc) checkCrc(this, length + 4, type);
		else this.skip(4);
	}
	decodeIHDR() {
		const image = this._png;
		image.width = this.readUint32();
		image.height = this.readUint32();
		image.depth = checkBitDepth(this.readUint8());
		const colorType = this.readUint8();
		this._colorType = colorType;
		let channels;
		switch (colorType) {
			case ColorType.GREYSCALE:
				channels = 1;
				break;
			case ColorType.TRUECOLOUR:
				channels = 3;
				break;
			case ColorType.INDEXED_COLOUR:
				channels = 1;
				break;
			case ColorType.GREYSCALE_ALPHA:
				channels = 2;
				break;
			case ColorType.TRUECOLOUR_ALPHA:
				channels = 4;
				break;
			case ColorType.UNKNOWN:
			default: throw new Error(`Unknown color type: ${colorType}`);
		}
		this._png.channels = channels;
		this._compressionMethod = this.readUint8();
		if (this._compressionMethod !== CompressionMethod.DEFLATE) throw new Error(`Unsupported compression method: ${this._compressionMethod}`);
		this._filterMethod = this.readUint8();
		this._interlaceMethod = this.readUint8();
	}
	decodeACTL() {
		this._numberOfFrames = this.readUint32();
		this._numberOfPlays = this.readUint32();
		this._isAnimated = true;
	}
	decodeFCTL() {
		const image = {
			sequenceNumber: this.readUint32(),
			width: this.readUint32(),
			height: this.readUint32(),
			xOffset: this.readUint32(),
			yOffset: this.readUint32(),
			delayNumber: this.readUint16(),
			delayDenominator: this.readUint16(),
			disposeOp: this.readUint8(),
			blendOp: this.readUint8(),
			data: /* @__PURE__ */ new Uint8Array(0)
		};
		this._frames.push(image);
	}
	decodePLTE(length) {
		if (length % 3 !== 0) throw new RangeError(`PLTE field length must be a multiple of 3. Got ${length}`);
		const l = length / 3;
		this._hasPalette = true;
		const palette = [];
		this._palette = palette;
		for (let i = 0; i < l; i++) palette.push([
			this.readUint8(),
			this.readUint8(),
			this.readUint8()
		]);
	}
	decodeIDAT(length) {
		this._writingDataChunks = true;
		const dataLength = length;
		const dataOffset = this.offset + this.byteOffset;
		this._inflator.push(new Uint8Array(this.buffer, dataOffset, dataLength));
		if (this._inflator.err) throw new Error(`Error while decompressing the data: ${this._inflator.err}`);
		this.skip(length);
	}
	decodeFDAT(length) {
		this._writingDataChunks = true;
		let dataLength = length;
		let dataOffset = this.offset + this.byteOffset;
		dataOffset += 4;
		dataLength -= 4;
		this._inflator.push(new Uint8Array(this.buffer, dataOffset, dataLength));
		if (this._inflator.err) throw new Error(`Error while decompressing the data: ${this._inflator.err}`);
		this.skip(length);
	}
	decodetRNS(length) {
		switch (this._colorType) {
			case ColorType.GREYSCALE:
			case ColorType.TRUECOLOUR:
				if (length % 2 !== 0) throw new RangeError(`tRNS chunk length must be a multiple of 2. Got ${length}`);
				if (length / 2 > this._png.width * this._png.height) throw new Error(`tRNS chunk contains more alpha values than there are pixels (${length / 2} vs ${this._png.width * this._png.height})`);
				this._hasTransparency = true;
				this._transparency = new Uint16Array(length / 2);
				for (let i = 0; i < length / 2; i++) this._transparency[i] = this.readUint16();
				break;
			case ColorType.INDEXED_COLOUR: {
				if (length > this._palette.length) throw new Error(`tRNS chunk contains more alpha values than there are palette colors (${length} vs ${this._palette.length})`);
				let i = 0;
				for (; i < length; i++) {
					const alpha = this.readByte();
					this._palette[i].push(alpha);
				}
				for (; i < this._palette.length; i++) this._palette[i].push(255);
				break;
			}
			case ColorType.UNKNOWN:
			case ColorType.GREYSCALE_ALPHA:
			case ColorType.TRUECOLOUR_ALPHA:
			default: throw new Error(`tRNS chunk is not supported for color type ${this._colorType}`);
		}
	}
	decodeiCCP(length) {
		const name = readKeyword(this);
		const compressionMethod = this.readUint8();
		if (compressionMethod !== CompressionMethod.DEFLATE) throw new Error(`Unsupported iCCP compression method: ${compressionMethod}`);
		const compressedProfile = this.readBytes(length - name.length - 2);
		this._png.iccEmbeddedProfile = {
			name,
			profile: inflate_1(compressedProfile)
		};
	}
	decodepHYs() {
		const ppuX = this.readUint32();
		const ppuY = this.readUint32();
		const unitSpecifier = this.readByte();
		this._png.resolution = {
			x: ppuX,
			y: ppuY,
			unit: unitSpecifier
		};
	}
	decodeApngImage() {
		this._apng.width = this._png.width;
		this._apng.height = this._png.height;
		this._apng.channels = this._png.channels;
		this._apng.depth = this._png.depth;
		this._apng.numberOfFrames = this._numberOfFrames;
		this._apng.numberOfPlays = this._numberOfPlays;
		this._apng.text = this._png.text;
		this._apng.resolution = this._png.resolution;
		for (let i = 0; i < this._numberOfFrames; i++) {
			const newFrame = {
				sequenceNumber: this._frames[i].sequenceNumber,
				delayNumber: this._frames[i].delayNumber,
				delayDenominator: this._frames[i].delayDenominator,
				data: this._apng.depth === 8 ? new Uint8Array(this._apng.width * this._apng.height * this._apng.channels) : new Uint16Array(this._apng.width * this._apng.height * this._apng.channels)
			};
			const frame = this._frames.at(i);
			if (frame) {
				frame.data = decodeInterlaceNull({
					data: frame.data,
					width: frame.width,
					height: frame.height,
					channels: this._apng.channels,
					depth: this._apng.depth
				});
				if (this._hasPalette) this._apng.palette = this._palette;
				if (this._hasTransparency) this._apng.transparency = this._transparency;
				if (i === 0 || frame.xOffset === 0 && frame.yOffset === 0 && frame.width === this._png.width && frame.height === this._png.height) newFrame.data = frame.data;
				else {
					const prevFrame = this._apng.frames.at(i - 1);
					this.disposeFrame(frame, prevFrame, newFrame);
					this.addFrameDataToCanvas(newFrame, frame);
				}
				this._apng.frames.push(newFrame);
			}
		}
		return this._apng;
	}
	disposeFrame(frame, prevFrame, imageFrame) {
		switch (frame.disposeOp) {
			case DisposeOpType.NONE: break;
			case DisposeOpType.BACKGROUND:
				for (let row = 0; row < this._png.height; row++) for (let col = 0; col < this._png.width; col++) {
					const index = (row * frame.width + col) * this._png.channels;
					for (let channel = 0; channel < this._png.channels; channel++) imageFrame.data[index + channel] = 0;
				}
				break;
			case DisposeOpType.PREVIOUS:
				imageFrame.data.set(prevFrame.data);
				break;
			default: throw new Error("Unknown disposeOp");
		}
	}
	addFrameDataToCanvas(imageFrame, frame) {
		const maxValue = 1 << this._png.depth;
		const calculatePixelIndices = (row, col) => {
			return {
				index: ((row + frame.yOffset) * this._png.width + frame.xOffset + col) * this._png.channels,
				frameIndex: (row * frame.width + col) * this._png.channels
			};
		};
		switch (frame.blendOp) {
			case BlendOpType.SOURCE:
				for (let row = 0; row < frame.height; row++) for (let col = 0; col < frame.width; col++) {
					const { index, frameIndex } = calculatePixelIndices(row, col);
					for (let channel = 0; channel < this._png.channels; channel++) imageFrame.data[index + channel] = frame.data[frameIndex + channel];
				}
				break;
			case BlendOpType.OVER:
				for (let row = 0; row < frame.height; row++) for (let col = 0; col < frame.width; col++) {
					const { index, frameIndex } = calculatePixelIndices(row, col);
					for (let channel = 0; channel < this._png.channels; channel++) {
						const sourceAlpha = frame.data[frameIndex + this._png.channels - 1] / maxValue;
						const foregroundValue = channel % (this._png.channels - 1) === 0 ? 1 : frame.data[frameIndex + channel];
						const value = Math.floor(sourceAlpha * foregroundValue + (1 - sourceAlpha) * imageFrame.data[index + channel]);
						imageFrame.data[index + channel] += value;
					}
				}
				break;
			default: throw new Error("Unknown blendOp");
		}
	}
	decodeImage() {
		if (this._inflator.err) throw new Error(`Error while decompressing the data: ${this._inflator.err}`);
		const data = this._isAnimated ? (this._frames?.at(0)).data : this._inflator.result;
		if (this._filterMethod !== FilterMethod.ADAPTIVE) throw new Error(`Filter method ${this._filterMethod} not supported`);
		if (this._interlaceMethod === InterlaceMethod.NO_INTERLACE) this._png.data = decodeInterlaceNull({
			data,
			width: this._png.width,
			height: this._png.height,
			channels: this._png.channels,
			depth: this._png.depth
		});
		else if (this._interlaceMethod === InterlaceMethod.ADAM7) this._png.data = decodeInterlaceAdam7({
			data,
			width: this._png.width,
			height: this._png.height,
			channels: this._png.channels,
			depth: this._png.depth
		});
		else throw new Error(`Interlace method ${this._interlaceMethod} not supported`);
		if (this._hasPalette) this._png.palette = this._palette;
		if (this._hasTransparency) this._png.transparency = this._transparency;
	}
	pushDataToFrame() {
		const result = this._inflator.result;
		const lastFrame = this._frames.at(-1);
		if (lastFrame) lastFrame.data = result;
		else this._frames.push({
			sequenceNumber: 0,
			width: this._png.width,
			height: this._png.height,
			xOffset: 0,
			yOffset: 0,
			delayNumber: 0,
			delayDenominator: 0,
			disposeOp: DisposeOpType.NONE,
			blendOp: BlendOpType.SOURCE,
			data: result
		});
		this._inflator = new Inflate_1();
		this._writingDataChunks = false;
	}
};
function checkBitDepth(value) {
	if (value !== 1 && value !== 2 && value !== 4 && value !== 8 && value !== 16) throw new Error(`invalid bit depth: ${value}`);
	return value;
}
//#endregion
//#region node_modules/fast-png/lib-esm/types.js
var ResolutionUnitSpecifier;
(function(ResolutionUnitSpecifier) {
	/**
	* Unit is unknown
	*/
	ResolutionUnitSpecifier[ResolutionUnitSpecifier["UNKNOWN"] = 0] = "UNKNOWN";
	/**
	* Unit is the metre
	*/
	ResolutionUnitSpecifier[ResolutionUnitSpecifier["METRE"] = 1] = "METRE";
})(ResolutionUnitSpecifier || (ResolutionUnitSpecifier = {}));
//#endregion
//#region node_modules/fast-png/lib-esm/index.js
function decodePng(data, options) {
	return new PngDecoder(data, options).decode();
}
//#endregion
//#region \0vite/preload-helper.js
var scriptRel = "modulepreload";
var assetsURL = function(dep) {
	return "/" + dep;
};
var seen = {};
var __vitePreload = function preload(baseModule, deps, importerUrl) {
	let promise = Promise.resolve();
	if (deps && deps.length > 0) {
		const links = document.getElementsByTagName("link");
		const cspNonceMeta = document.querySelector("meta[property=csp-nonce]");
		const cspNonce = cspNonceMeta?.nonce || cspNonceMeta?.getAttribute("nonce");
		function allSettled(promises) {
			return Promise.all(promises.map((p) => Promise.resolve(p).then((value) => ({
				status: "fulfilled",
				value
			}), (reason) => ({
				status: "rejected",
				reason
			}))));
		}
		function importMetaResolve(specifier) {
			if (import.meta.resolve) return import.meta.resolve(specifier);
			return new URL(
				specifier,
				/** #__KEEP__ */
				import.meta.url
			).href;
		}
		promise = allSettled(deps.map((dep) => {
			dep = assetsURL(dep, importerUrl);
			dep = importMetaResolve(dep);
			if (dep in seen) return;
			seen[dep] = true;
			const isCss = dep.endsWith(".css");
			for (let i = links.length - 1; i >= 0; i--) {
				const link = links[i];
				if (link.href === dep && (!isCss || link.rel === "stylesheet")) return;
			}
			const link = document.createElement("link");
			link.rel = isCss ? "stylesheet" : scriptRel;
			if (!isCss) link.as = "script";
			link.crossOrigin = "";
			link.href = dep;
			if (cspNonce) link.setAttribute("nonce", cspNonce);
			document.head.appendChild(link);
			if (isCss) return new Promise((res, rej) => {
				link.addEventListener("load", res);
				link.addEventListener("error", () => rej(/* @__PURE__ */ new Error(`Unable to preload CSS for ${dep}`)));
			});
		}));
	}
	function handlePreloadError(err) {
		const e = new Event("vite:preloadError", { cancelable: true });
		e.payload = err;
		window.dispatchEvent(e);
		if (!e.defaultPrevented) throw err;
	}
	return promise.then((res) => {
		for (const item of res || []) {
			if (item.status !== "rejected") continue;
			handlePreloadError(item.reason);
		}
		return baseModule().catch(handlePreloadError);
	});
};
//#endregion
//#region node_modules/jspdf/dist/jspdf.es.min.js
/** @license
*
* jsPDF - PDF Document creation from JavaScript
* Version 4.2.1 Built on 2026-03-17T11:11:27.057Z
*                      CommitID 00000000
*
* Copyright (c) 2010-2025 James Hall <james@parall.ax>, https://github.com/MrRio/jsPDF
*               2015-2025 yWorks GmbH, http://www.yworks.com
*               2015-2025 Lukas Holländer <lukas.hollaender@yworks.com>, https://github.com/HackbrettXXX
*               2016-2018 Aras Abbasi <aras.abbasi@gmail.com>
*               2010 Aaron Spike, https://github.com/acspike
*               2012 Willow Systems Corporation, https://github.com/willowsystems
*               2012 Pablo Hess, https://github.com/pablohess
*               2012 Florian Jenett, https://github.com/fjenett
*               2013 Warren Weckesser, https://github.com/warrenweckesser
*               2013 Youssef Beddad, https://github.com/lifof
*               2013 Lee Driscoll, https://github.com/lsdriscoll
*               2013 Stefan Slonevskiy, https://github.com/stefslon
*               2013 Jeremy Morel, https://github.com/jmorel
*               2013 Christoph Hartmann, https://github.com/chris-rock
*               2014 Juan Pablo Gaviria, https://github.com/juanpgaviria
*               2014 James Makes, https://github.com/dollaruw
*               2014 Diego Casorran, https://github.com/diegocr
*               2014 Steven Spungin, https://github.com/Flamenco
*               2014 Kenneth Glassey, https://github.com/Gavvers
*
* Permission is hereby granted, free of charge, to any person obtaining
* a copy of this software and associated documentation files (the
* "Software"), to deal in the Software without restriction, including
* without limitation the rights to use, copy, modify, merge, publish,
* distribute, sublicense, and/or sell copies of the Software, and to
* permit persons to whom the Software is furnished to do so, subject to
* the following conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
* LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
* OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
* WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
* Contributor(s):
*    siefkenj, ahwolf, rickygu, Midnith, saintclair, eaparango,
*    kim3er, mfo, alnorth, Flamenco
*/
var i = function() {
	return "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : this;
}();
function a() {
	i.console && "function" == typeof i.console.log && i.console.log.apply(i.console, arguments);
}
var o = {
	log: a,
	warn: function(t) {
		i.console && ("function" == typeof i.console.warn ? i.console.warn.apply(i.console, arguments) : a.call(null, arguments));
	},
	error: function(t) {
		i.console && ("function" == typeof i.console.error ? i.console.error.apply(i.console, arguments) : a(t));
	}
};
function s(t, e, r) {
	var n = new XMLHttpRequest();
	n.open("GET", t), n.responseType = "blob", n.onload = function() {
		l(n.response, e, r);
	}, n.onerror = function() {
		o.error("could not download file");
	}, n.send();
}
function u(t) {
	var e = new XMLHttpRequest();
	e.open("HEAD", t, !1);
	try {
		e.send();
	} catch (r) {}
	return e.status >= 200 && e.status <= 299;
}
function c(t) {
	try {
		t.dispatchEvent(new MouseEvent("click"));
	} catch (r) {
		var e = document.createEvent("MouseEvents");
		e.initMouseEvent("click", !0, !0, window, 0, 0, 0, 80, 20, !1, !1, !1, !1, 0, null), t.dispatchEvent(e);
	}
}
var l = i.saveAs || ("object" !== ("undefined" == typeof window ? "undefined" : _typeof(window)) || window !== i ? function() {} : "undefined" != typeof HTMLAnchorElement && "download" in HTMLAnchorElement.prototype ? function(t, e, r) {
	var n = i.URL || i.webkitURL, a = document.createElement("a");
	e = e || t.name || "download", a.download = e, a.rel = "noopener", "string" == typeof t ? (a.href = t, a.origin !== location.origin ? u(a.href) ? s(t, e, r) : c(a, a.target = "_blank") : c(a)) : (a.href = n.createObjectURL(t), setTimeout(function() {
		n.revokeObjectURL(a.href);
	}, 4e4), setTimeout(function() {
		c(a);
	}, 0));
} : "msSaveOrOpenBlob" in navigator ? function(e, r, n) {
	if (r = r || e.name || "download", "string" == typeof e) if (u(e)) s(e, r, n);
	else {
		var i = document.createElement("a");
		i.href = e, i.target = "_blank", setTimeout(function() {
			c(i);
		});
	}
	else navigator.msSaveOrOpenBlob(function(e, r) {
		return void 0 === r ? r = { autoBom: !1 } : "object" !== _typeof(r) && (o.warn("Deprecated: Expected third argument to be a object"), r = { autoBom: !r }), r.autoBom && /^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i.test(e.type) ? new Blob([String.fromCharCode(65279), e], { type: e.type }) : e;
	}(e, n), r);
} : function(e, r, n, a) {
	if ((a = a || open("", "_blank")) && (a.document.title = a.document.body.innerText = "downloading..."), "string" == typeof e) return s(e, r, n);
	var o = "application/octet-stream" === e.type, u = /constructor/i.test(i.HTMLElement) || i.safari, c = /CriOS\/[\d]+/.test(navigator.userAgent);
	if ((c || o && u) && "object" === ("undefined" == typeof FileReader ? "undefined" : _typeof(FileReader))) {
		var l = new FileReader();
		l.onloadend = function() {
			var t = l.result;
			t = c ? t : t.replace(/^data:[^;]*;/, "data:attachment/file;"), a ? a.location.href = t : location = t, a = null;
		}, l.readAsDataURL(e);
	} else {
		var h = i.URL || i.webkitURL, f = h.createObjectURL(e);
		a ? a.location = f : location.href = f, a = null, setTimeout(function() {
			h.revokeObjectURL(f);
		}, 4e4);
	}
});
/**
* A class to parse color values
* @author Stoyan Stefanov <sstoo@gmail.com>
* {@link   http://www.phpied.com/rgb-color-parser-in-javascript/}
* @license Use it if you like it
*/ function h(t) {
	var e;
	t = t || "", this.ok = !1, "#" == t.charAt(0) && (t = t.substr(1, 6)), t = {
		aliceblue: "f0f8ff",
		antiquewhite: "faebd7",
		aqua: "00ffff",
		aquamarine: "7fffd4",
		azure: "f0ffff",
		beige: "f5f5dc",
		bisque: "ffe4c4",
		black: "000000",
		blanchedalmond: "ffebcd",
		blue: "0000ff",
		blueviolet: "8a2be2",
		brown: "a52a2a",
		burlywood: "deb887",
		cadetblue: "5f9ea0",
		chartreuse: "7fff00",
		chocolate: "d2691e",
		coral: "ff7f50",
		cornflowerblue: "6495ed",
		cornsilk: "fff8dc",
		crimson: "dc143c",
		cyan: "00ffff",
		darkblue: "00008b",
		darkcyan: "008b8b",
		darkgoldenrod: "b8860b",
		darkgray: "a9a9a9",
		darkgreen: "006400",
		darkkhaki: "bdb76b",
		darkmagenta: "8b008b",
		darkolivegreen: "556b2f",
		darkorange: "ff8c00",
		darkorchid: "9932cc",
		darkred: "8b0000",
		darksalmon: "e9967a",
		darkseagreen: "8fbc8f",
		darkslateblue: "483d8b",
		darkslategray: "2f4f4f",
		darkturquoise: "00ced1",
		darkviolet: "9400d3",
		deeppink: "ff1493",
		deepskyblue: "00bfff",
		dimgray: "696969",
		dodgerblue: "1e90ff",
		feldspar: "d19275",
		firebrick: "b22222",
		floralwhite: "fffaf0",
		forestgreen: "228b22",
		fuchsia: "ff00ff",
		gainsboro: "dcdcdc",
		ghostwhite: "f8f8ff",
		gold: "ffd700",
		goldenrod: "daa520",
		gray: "808080",
		green: "008000",
		greenyellow: "adff2f",
		honeydew: "f0fff0",
		hotpink: "ff69b4",
		indianred: "cd5c5c",
		indigo: "4b0082",
		ivory: "fffff0",
		khaki: "f0e68c",
		lavender: "e6e6fa",
		lavenderblush: "fff0f5",
		lawngreen: "7cfc00",
		lemonchiffon: "fffacd",
		lightblue: "add8e6",
		lightcoral: "f08080",
		lightcyan: "e0ffff",
		lightgoldenrodyellow: "fafad2",
		lightgrey: "d3d3d3",
		lightgreen: "90ee90",
		lightpink: "ffb6c1",
		lightsalmon: "ffa07a",
		lightseagreen: "20b2aa",
		lightskyblue: "87cefa",
		lightslateblue: "8470ff",
		lightslategray: "778899",
		lightsteelblue: "b0c4de",
		lightyellow: "ffffe0",
		lime: "00ff00",
		limegreen: "32cd32",
		linen: "faf0e6",
		magenta: "ff00ff",
		maroon: "800000",
		mediumaquamarine: "66cdaa",
		mediumblue: "0000cd",
		mediumorchid: "ba55d3",
		mediumpurple: "9370d8",
		mediumseagreen: "3cb371",
		mediumslateblue: "7b68ee",
		mediumspringgreen: "00fa9a",
		mediumturquoise: "48d1cc",
		mediumvioletred: "c71585",
		midnightblue: "191970",
		mintcream: "f5fffa",
		mistyrose: "ffe4e1",
		moccasin: "ffe4b5",
		navajowhite: "ffdead",
		navy: "000080",
		oldlace: "fdf5e6",
		olive: "808000",
		olivedrab: "6b8e23",
		orange: "ffa500",
		orangered: "ff4500",
		orchid: "da70d6",
		palegoldenrod: "eee8aa",
		palegreen: "98fb98",
		paleturquoise: "afeeee",
		palevioletred: "d87093",
		papayawhip: "ffefd5",
		peachpuff: "ffdab9",
		peru: "cd853f",
		pink: "ffc0cb",
		plum: "dda0dd",
		powderblue: "b0e0e6",
		purple: "800080",
		red: "ff0000",
		rosybrown: "bc8f8f",
		royalblue: "4169e1",
		saddlebrown: "8b4513",
		salmon: "fa8072",
		sandybrown: "f4a460",
		seagreen: "2e8b57",
		seashell: "fff5ee",
		sienna: "a0522d",
		silver: "c0c0c0",
		skyblue: "87ceeb",
		slateblue: "6a5acd",
		slategray: "708090",
		snow: "fffafa",
		springgreen: "00ff7f",
		steelblue: "4682b4",
		tan: "d2b48c",
		teal: "008080",
		thistle: "d8bfd8",
		tomato: "ff6347",
		turquoise: "40e0d0",
		violet: "ee82ee",
		violetred: "d02090",
		wheat: "f5deb3",
		white: "ffffff",
		whitesmoke: "f5f5f5",
		yellow: "ffff00",
		yellowgreen: "9acd32"
	}[t = (t = t.replace(/ /g, "")).toLowerCase()] || t;
	for (var r = [
		{
			re: /^rgb\((\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3})\)$/,
			example: ["rgb(123, 234, 45)", "rgb(255,234,245)"],
			process: function(t) {
				return [
					parseInt(t[1]),
					parseInt(t[2]),
					parseInt(t[3])
				];
			}
		},
		{
			re: /^(\w{2})(\w{2})(\w{2})$/,
			example: ["#00ff00", "336699"],
			process: function(t) {
				return [
					parseInt(t[1], 16),
					parseInt(t[2], 16),
					parseInt(t[3], 16)
				];
			}
		},
		{
			re: /^(\w{1})(\w{1})(\w{1})$/,
			example: ["#fb0", "f0f"],
			process: function(t) {
				return [
					parseInt(t[1] + t[1], 16),
					parseInt(t[2] + t[2], 16),
					parseInt(t[3] + t[3], 16)
				];
			}
		}
	], n = 0; n < r.length; n++) {
		var i = r[n].re, a = r[n].process, o = i.exec(t);
		o && (e = a(o), this.r = e[0], this.g = e[1], this.b = e[2], this.ok = !0);
	}
	this.r = this.r < 0 || isNaN(this.r) ? 0 : this.r > 255 ? 255 : this.r, this.g = this.g < 0 || isNaN(this.g) ? 0 : this.g > 255 ? 255 : this.g, this.b = this.b < 0 || isNaN(this.b) ? 0 : this.b > 255 ? 255 : this.b, this.toRGB = function() {
		return "rgb(" + this.r + ", " + this.g + ", " + this.b + ")";
	}, this.toHex = function() {
		var t = this.r.toString(16), e = this.g.toString(16), r = this.b.toString(16);
		return 1 == t.length && (t = "0" + t), 1 == e.length && (e = "0" + e), 1 == r.length && (r = "0" + r), "#" + t + e + r;
	};
}
var f = i.atob.bind(i);
var d = i.btoa.bind(i);
/**
* @license
* Joseph Myers does not specify a particular license for his work.
*
* Author: Joseph Myers
* Accessed from: http://www.myersdaily.org/joseph/javascript/md5.js
*
* Modified by: Owen Leong
*/
function p(t, e) {
	var r = t[0], n = t[1], i = t[2], a = t[3];
	r = m(r, n, i, a, e[0], 7, -680876936), a = m(a, r, n, i, e[1], 12, -389564586), i = m(i, a, r, n, e[2], 17, 606105819), n = m(n, i, a, r, e[3], 22, -1044525330), r = m(r, n, i, a, e[4], 7, -176418897), a = m(a, r, n, i, e[5], 12, 1200080426), i = m(i, a, r, n, e[6], 17, -1473231341), n = m(n, i, a, r, e[7], 22, -45705983), r = m(r, n, i, a, e[8], 7, 1770035416), a = m(a, r, n, i, e[9], 12, -1958414417), i = m(i, a, r, n, e[10], 17, -42063), n = m(n, i, a, r, e[11], 22, -1990404162), r = m(r, n, i, a, e[12], 7, 1804603682), a = m(a, r, n, i, e[13], 12, -40341101), i = m(i, a, r, n, e[14], 17, -1502002290), r = v(r, n = m(n, i, a, r, e[15], 22, 1236535329), i, a, e[1], 5, -165796510), a = v(a, r, n, i, e[6], 9, -1069501632), i = v(i, a, r, n, e[11], 14, 643717713), n = v(n, i, a, r, e[0], 20, -373897302), r = v(r, n, i, a, e[5], 5, -701558691), a = v(a, r, n, i, e[10], 9, 38016083), i = v(i, a, r, n, e[15], 14, -660478335), n = v(n, i, a, r, e[4], 20, -405537848), r = v(r, n, i, a, e[9], 5, 568446438), a = v(a, r, n, i, e[14], 9, -1019803690), i = v(i, a, r, n, e[3], 14, -187363961), n = v(n, i, a, r, e[8], 20, 1163531501), r = v(r, n, i, a, e[13], 5, -1444681467), a = v(a, r, n, i, e[2], 9, -51403784), i = v(i, a, r, n, e[7], 14, 1735328473), r = b(r, n = v(n, i, a, r, e[12], 20, -1926607734), i, a, e[5], 4, -378558), a = b(a, r, n, i, e[8], 11, -2022574463), i = b(i, a, r, n, e[11], 16, 1839030562), n = b(n, i, a, r, e[14], 23, -35309556), r = b(r, n, i, a, e[1], 4, -1530992060), a = b(a, r, n, i, e[4], 11, 1272893353), i = b(i, a, r, n, e[7], 16, -155497632), n = b(n, i, a, r, e[10], 23, -1094730640), r = b(r, n, i, a, e[13], 4, 681279174), a = b(a, r, n, i, e[0], 11, -358537222), i = b(i, a, r, n, e[3], 16, -722521979), n = b(n, i, a, r, e[6], 23, 76029189), r = b(r, n, i, a, e[9], 4, -640364487), a = b(a, r, n, i, e[12], 11, -421815835), i = b(i, a, r, n, e[15], 16, 530742520), r = y(r, n = b(n, i, a, r, e[2], 23, -995338651), i, a, e[0], 6, -198630844), a = y(a, r, n, i, e[7], 10, 1126891415), i = y(i, a, r, n, e[14], 15, -1416354905), n = y(n, i, a, r, e[5], 21, -57434055), r = y(r, n, i, a, e[12], 6, 1700485571), a = y(a, r, n, i, e[3], 10, -1894986606), i = y(i, a, r, n, e[10], 15, -1051523), n = y(n, i, a, r, e[1], 21, -2054922799), r = y(r, n, i, a, e[8], 6, 1873313359), a = y(a, r, n, i, e[15], 10, -30611744), i = y(i, a, r, n, e[6], 15, -1560198380), n = y(n, i, a, r, e[13], 21, 1309151649), r = y(r, n, i, a, e[4], 6, -145523070), a = y(a, r, n, i, e[11], 10, -1120210379), i = y(i, a, r, n, e[2], 15, 718787259), n = y(n, i, a, r, e[9], 21, -343485551), t[0] = P(r, t[0]), t[1] = P(n, t[1]), t[2] = P(i, t[2]), t[3] = P(a, t[3]);
}
function g(t, e, r, n, i, a) {
	return e = P(P(e, t), P(n, a)), P(e << i | e >>> 32 - i, r);
}
function m(t, e, r, n, i, a, o) {
	return g(e & r | ~e & n, t, e, i, a, o);
}
function v(t, e, r, n, i, a, o) {
	return g(e & n | r & ~n, t, e, i, a, o);
}
function b(t, e, r, n, i, a, o) {
	return g(e ^ r ^ n, t, e, i, a, o);
}
function y(t, e, r, n, i, a, o) {
	return g(r ^ (e | ~n), t, e, i, a, o);
}
function w(t) {
	var e, r = t.length, n = [
		1732584193,
		-271733879,
		-1732584194,
		271733878
	];
	for (e = 64; e <= t.length; e += 64) p(n, N(t.substring(e - 64, e)));
	t = t.substring(e - 64);
	var i = [
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0
	];
	for (e = 0; e < t.length; e++) i[e >> 2] |= t.charCodeAt(e) << (e % 4 << 3);
	if (i[e >> 2] |= 128 << (e % 4 << 3), e > 55) for (p(n, i), e = 0; e < 16; e++) i[e] = 0;
	return i[14] = 8 * r, p(n, i), n;
}
function N(t) {
	var e, r = [];
	for (e = 0; e < 64; e += 4) r[e >> 2] = t.charCodeAt(e) + (t.charCodeAt(e + 1) << 8) + (t.charCodeAt(e + 2) << 16) + (t.charCodeAt(e + 3) << 24);
	return r;
}
var L = "0123456789abcdef".split("");
function x(t) {
	for (var e = "", r = 0; r < 4; r++) e += L[t >> 8 * r + 4 & 15] + L[t >> 8 * r & 15];
	return e;
}
function A(t) {
	return String.fromCharCode(255 & t, (65280 & t) >> 8, (16711680 & t) >> 16, (4278190080 & t) >> 24);
}
function S(t) {
	return w(t).map(A).join("");
}
var _ = "5d41402abc4b2a76b9719d911017c592" != function(t) {
	for (var e = 0; e < t.length; e++) t[e] = x(t[e]);
	return t.join("");
}(w("hello"));
function P(t, e) {
	if (_) {
		var r = (65535 & t) + (65535 & e);
		return (t >> 16) + (e >> 16) + (r >> 16) << 16 | 65535 & r;
	}
	return t + e & 4294967295;
}
/**
* @license
* FPDF is released under a permissive license: there is no usage restriction.
* You may embed it freely in your application (commercial or not), with or
* without modifications.
*
* Reference: http://www.fpdf.org/en/script/script37.php
*/ function k(t, e) {
	var r, n, i, a;
	if (t !== r) {
		for (var o = (i = t, a = 1 + (256 / t.length | 0), new Array(a + 1).join(i)), s = [], u = 0; u < 256; u++) s[u] = u;
		var c = 0;
		for (u = 0; u < 256; u++) {
			var l = s[u];
			c = (c + l + o.charCodeAt(u)) % 256, s[u] = s[c], s[c] = l;
		}
		r = t, n = s;
	} else s = n;
	var h = e.length, f = 0, d = 0, p = "";
	for (u = 0; u < h; u++) d = (d + (l = s[f = (f + 1) % 256])) % 256, s[f] = s[d], s[d] = l, o = s[(s[f] + s[d]) % 256], p += String.fromCharCode(e.charCodeAt(u) ^ o);
	return p;
}
/**
* @license
* Licensed under the MIT License.
* http://opensource.org/licenses/mit-license
* Author: Owen Leong (@owenl131)
* Date: 15 Oct 2020
* References:
* https://www.cs.cmu.edu/~dst/Adobe/Gallery/anon21jul01-pdf-encryption.txt
* https://github.com/foliojs/pdfkit/blob/master/lib/security.js
* http://www.fpdf.org/en/script/script37.php
*/ var F = {
	print: 4,
	modify: 8,
	copy: 16,
	"annot-forms": 32
};
function I(t, e, r, n) {
	this.v = 1, this.r = 2;
	var i = 192;
	t.forEach(function(t) {
		if (void 0 !== F.perm) throw new Error("Invalid permission: " + t);
		i += F[t];
	}), this.padding = "(¿N^NuAd\0NVÿú\b..\0¶Ðh>/\f©þdSiz";
	var a = (e + this.padding).substr(0, 32), o = (r + this.padding).substr(0, 32);
	this.O = this.processOwnerPassword(a, o), this.P = -(1 + (255 ^ i)), this.encryptionKey = S(a + this.O + this.lsbFirstWord(this.P) + this.hexToBytes(n)).substr(0, 5), this.U = k(this.encryptionKey, this.padding);
}
function C(t) {
	if (/[^\u0000-\u00ff]/.test(t)) throw new Error("Invalid PDF Name Object: " + t + ", Only accept ASCII characters.");
	for (var e = "", r = t.length, n = 0; n < r; n++) {
		var i = t.charCodeAt(n);
		e += i < 33 || 35 === i || 37 === i || 40 === i || 41 === i || 47 === i || 60 === i || 62 === i || 91 === i || 93 === i || 123 === i || 125 === i || i > 126 ? "#" + ("0" + i.toString(16)).slice(-2) : t[n];
	}
	return e;
}
function j(e) {
	if ("object" !== _typeof(e)) throw new Error("Invalid Context passed to initialize PubSub (jsPDF-module)");
	var r = {};
	this.subscribe = function(t, e, n) {
		if (n = n || !1, "string" != typeof t || "function" != typeof e || "boolean" != typeof n) throw new Error("Invalid arguments passed to PubSub.subscribe (jsPDF-module)");
		r.hasOwnProperty(t) || (r[t] = {});
		var i = Math.random().toString(35);
		return r[t][i] = [e, !!n], i;
	}, this.unsubscribe = function(t) {
		for (var e in r) if (r[e][t]) return delete r[e][t], 0 === Object.keys(r[e]).length && delete r[e], !0;
		return !1;
	}, this.publish = function(t) {
		if (r.hasOwnProperty(t)) {
			var n = Array.prototype.slice.call(arguments, 1), a = [];
			for (var s in r[t]) {
				var u = r[t][s];
				try {
					u[0].apply(e, n);
				} catch (c) {
					i.console && o.error("jsPDF PubSub Error", c.message, c);
				}
				u[1] && a.push(s);
			}
			a.length && a.forEach(this.unsubscribe);
		}
	}, this.getTopics = function() {
		return r;
	};
}
function O(t) {
	if (!(this instanceof O)) return new O(t);
	var e = "opacity,stroke-opacity".split(",");
	for (var r in t) t.hasOwnProperty(r) && e.indexOf(r) >= 0 && (this[r] = t[r]);
	this.id = "", this.objectNumber = -1;
}
function B(t, e) {
	this.gState = t, this.matrix = e, this.id = "", this.objectNumber = -1;
}
function M(t, e, r, n, i) {
	if (!(this instanceof M)) return new M(t, e, r, n, i);
	this.type = "axial" === t ? 2 : 3, this.coords = e, this.colors = r, B.call(this, n, i);
}
function q(t, e, r, n, i) {
	if (!(this instanceof q)) return new q(t, e, r, n, i);
	this.boundingBox = t, this.xStep = e, this.yStep = r, this.stream = "", this.cloneIndex = 0, B.call(this, n, i);
}
function E(e) {
	var r, n = "string" == typeof arguments[0] ? arguments[0] : "p", a = arguments[1], s = arguments[2], u = arguments[3], c = [], f = 1, p = 16, g = "S", m = null;
	"object" === _typeof(e = e || {}) && (n = e.orientation, a = e.unit || a, s = e.format || s, u = e.compress || e.compressPdf || u, null !== (m = e.encryption || null) && (m.userPassword = m.userPassword || "", m.ownerPassword = m.ownerPassword || "", m.userPermissions = m.userPermissions || []), f = "number" == typeof e.userUnit ? Math.abs(e.userUnit) : 1, void 0 !== e.precision && (r = e.precision), void 0 !== e.floatPrecision && (p = e.floatPrecision), g = e.defaultPathOperation || "S"), c = e.filters || (!0 === u ? ["FlateEncode"] : c), a = a || "mm", n = ("" + (n || "P")).toLowerCase();
	var v = e.putOnlyUsedFonts || !1, b = {}, y = {
		internal: {},
		__private__: {}
	};
	y.__private__.PubSub = j;
	var w = "1.3", N = y.__private__.getPdfVersion = function() {
		return w;
	};
	y.__private__.setPdfVersion = function(t) {
		w = t;
	};
	var L = {
		a0: [2383.94, 3370.39],
		a1: [1683.78, 2383.94],
		a2: [1190.55, 1683.78],
		a3: [841.89, 1190.55],
		a4: [595.28, 841.89],
		a5: [419.53, 595.28],
		a6: [297.64, 419.53],
		a7: [209.76, 297.64],
		a8: [147.4, 209.76],
		a9: [104.88, 147.4],
		a10: [73.7, 104.88],
		b0: [2834.65, 4008.19],
		b1: [2004.09, 2834.65],
		b2: [1417.32, 2004.09],
		b3: [1000.63, 1417.32],
		b4: [708.66, 1000.63],
		b5: [498.9, 708.66],
		b6: [354.33, 498.9],
		b7: [249.45, 354.33],
		b8: [175.75, 249.45],
		b9: [124.72, 175.75],
		b10: [87.87, 124.72],
		c0: [2599.37, 3676.54],
		c1: [1836.85, 2599.37],
		c2: [1298.27, 1836.85],
		c3: [918.43, 1298.27],
		c4: [649.13, 918.43],
		c5: [459.21, 649.13],
		c6: [323.15, 459.21],
		c7: [229.61, 323.15],
		c8: [161.57, 229.61],
		c9: [113.39, 161.57],
		c10: [79.37, 113.39],
		dl: [311.81, 623.62],
		letter: [612, 792],
		"government-letter": [576, 756],
		legal: [612, 1008],
		"junior-legal": [576, 360],
		ledger: [1224, 792],
		tabloid: [792, 1224],
		"credit-card": [153, 243]
	};
	y.__private__.getPageFormats = function() {
		return L;
	};
	var x = y.__private__.getPageFormat = function(t) {
		return L[t];
	};
	s = s || "a4";
	var A = "compat", S = "advanced", _ = A;
	function P() {
		this.saveGraphicsState(), lt(new Wt(St, 0, 0, -St, 0, Pr() * St).toString() + " cm"), this.setFontSize(this.getFontSize() / St), g = "n", _ = S;
	}
	function k() {
		this.restoreGraphicsState(), g = "S", _ = A;
	}
	var F = y.__private__.combineFontStyleAndFontWeight = function(t, e) {
		if ("bold" == t && "normal" == e || "bold" == t && 400 == e || "normal" == t && "italic" == e || "bold" == t && "italic" == e) throw new Error("Invalid Combination of fontweight and fontstyle");
		return e && (t = 400 == e || "normal" === e ? "italic" === t ? "italic" : "normal" : 700 != e && "bold" !== e || "normal" !== t ? (700 == e ? "bold" : e) + "" + t : "bold"), t;
	};
	y.advancedAPI = function(t) {
		var e = _ === A;
		return e && P.call(this), "function" != typeof t || (t(this), e && k.call(this)), this;
	}, y.compatAPI = function(t) {
		var e = _ === S;
		return e && k.call(this), "function" != typeof t || (t(this), e && P.call(this)), this;
	}, y.isAdvancedAPI = function() {
		return _ === S;
	};
	var B, R = function(t) {
		if (_ !== S) throw new Error(t + " is only available in 'advanced' API mode. You need to call advancedAPI() first.");
	}, D = y.roundToPrecision = y.__private__.roundToPrecision = function(t, e) {
		var n = r || e;
		if (isNaN(t) || isNaN(n)) throw new Error("Invalid argument passed to jsPDF.roundToPrecision");
		return t.toFixed(n).replace(/0+$/, "");
	};
	B = y.hpf = y.__private__.hpf = "number" == typeof p ? function(t) {
		if (isNaN(t)) throw new Error("Invalid argument passed to jsPDF.hpf");
		return D(t, p);
	} : "smart" === p ? function(t) {
		if (isNaN(t)) throw new Error("Invalid argument passed to jsPDF.hpf");
		return D(t, t > -1 && t < 1 ? 16 : 5);
	} : function(t) {
		if (isNaN(t)) throw new Error("Invalid argument passed to jsPDF.hpf");
		return D(t, 16);
	};
	var T = y.f2 = y.__private__.f2 = function(t) {
		if (isNaN(t)) throw new Error("Invalid argument passed to jsPDF.f2");
		return D(t, 2);
	}, z = y.__private__.f3 = function(t) {
		if (isNaN(t)) throw new Error("Invalid argument passed to jsPDF.f3");
		return D(t, 3);
	}, U = y.scale = y.__private__.scale = function(t) {
		if (isNaN(t)) throw new Error("Invalid argument passed to jsPDF.scale");
		return _ === A ? t * St : _ === S ? t : void 0;
	}, H = function(t) {
		return U(function(t) {
			return _ === A ? Pr() - t : _ === S ? t : void 0;
		}(t));
	};
	y.__private__.setPrecision = y.setPrecision = function(t) {
		"number" == typeof parseInt(t, 10) && (r = parseInt(t, 10));
	};
	var W, V = "00000000000000000000000000000000", G = y.__private__.getFileId = function() {
		return V;
	}, Y = y.__private__.setFileId = function(t) {
		return V = void 0 !== t && /^[a-fA-F0-9]{32}$/.test(t) ? t.toUpperCase() : V.split("").map(function() {
			return "ABCDEF0123456789".charAt(Math.floor(16 * Math.random()));
		}).join(""), null !== m && (Oe = new I(m.userPermissions, m.userPassword, m.ownerPassword, V)), V;
	};
	y.setFileId = function(t) {
		return Y(t), this;
	}, y.getFileId = function() {
		return G();
	};
	var J = y.__private__.convertDateToPDFDate = function(t) {
		var e = t.getTimezoneOffset(), r = e < 0 ? "+" : "-", n = Math.floor(Math.abs(e / 60)), i = Math.abs(e % 60), a = [
			r,
			Q(n),
			"'",
			Q(i),
			"'"
		].join("");
		return [
			"D:",
			t.getFullYear(),
			Q(t.getMonth() + 1),
			Q(t.getDate()),
			Q(t.getHours()),
			Q(t.getMinutes()),
			Q(t.getSeconds()),
			a
		].join("");
	}, X = y.__private__.convertPDFDateToDate = function(t) {
		var e = parseInt(t.substr(2, 4), 10), r = parseInt(t.substr(6, 2), 10) - 1, n = parseInt(t.substr(8, 2), 10), i = parseInt(t.substr(10, 2), 10), a = parseInt(t.substr(12, 2), 10), o = parseInt(t.substr(14, 2), 10);
		return new Date(e, r, n, i, a, o, 0);
	}, K = y.__private__.setCreationDate = function(t) {
		var e;
		if (void 0 === t && (t = /* @__PURE__ */ new Date()), t instanceof Date) e = J(t);
		else {
			if (!/^D:(20[0-2][0-9]|203[0-7]|19[7-9][0-9])(0[0-9]|1[0-2])([0-2][0-9]|3[0-1])(0[0-9]|1[0-9]|2[0-3])(0[0-9]|[1-5][0-9])(0[0-9]|[1-5][0-9])(\+0[0-9]|\+1[0-4]|-0[0-9]|-1[0-1])'(0[0-9]|[1-5][0-9])'?$/.test(t)) throw new Error("Invalid argument passed to jsPDF.setCreationDate");
			e = t;
		}
		return W = e;
	}, Z = y.__private__.getCreationDate = function(t) {
		var e = W;
		return "jsDate" === t && (e = X(W)), e;
	};
	y.setCreationDate = function(t) {
		return K(t), this;
	}, y.getCreationDate = function(t) {
		return Z(t);
	};
	var $, Q = y.__private__.padd2 = function(t) {
		return ("0" + parseInt(t)).slice(-2);
	}, tt = y.__private__.padd2Hex = function(t) {
		return ("00" + (t = t.toString())).substr(t.length);
	}, et = 0, rt = [], nt = [], it = 0, at = [], ot = [], st = !1, ut = nt;
	y.__private__.setCustomOutputDestination = function(t) {
		st = !0, ut = t;
	};
	var ct = function(t) {
		st || (ut = t);
	};
	y.__private__.resetCustomOutputDestination = function() {
		st = !1, ut = nt;
	};
	var lt = y.__private__.out = function(t) {
		return t = t.toString(), it += t.length + 1, ut.push(t), ut;
	}, ht = y.__private__.write = function(t) {
		return lt(1 === arguments.length ? t.toString() : Array.prototype.join.call(arguments, " "));
	}, ft = y.__private__.getArrayBuffer = function(t) {
		for (var e = t.length, r = new ArrayBuffer(e), n = new Uint8Array(r); e--;) n[e] = t.charCodeAt(e);
		return r;
	}, dt = [
		[
			"Helvetica",
			"helvetica",
			"normal",
			"WinAnsiEncoding"
		],
		[
			"Helvetica-Bold",
			"helvetica",
			"bold",
			"WinAnsiEncoding"
		],
		[
			"Helvetica-Oblique",
			"helvetica",
			"italic",
			"WinAnsiEncoding"
		],
		[
			"Helvetica-BoldOblique",
			"helvetica",
			"bolditalic",
			"WinAnsiEncoding"
		],
		[
			"Courier",
			"courier",
			"normal",
			"WinAnsiEncoding"
		],
		[
			"Courier-Bold",
			"courier",
			"bold",
			"WinAnsiEncoding"
		],
		[
			"Courier-Oblique",
			"courier",
			"italic",
			"WinAnsiEncoding"
		],
		[
			"Courier-BoldOblique",
			"courier",
			"bolditalic",
			"WinAnsiEncoding"
		],
		[
			"Times-Roman",
			"times",
			"normal",
			"WinAnsiEncoding"
		],
		[
			"Times-Bold",
			"times",
			"bold",
			"WinAnsiEncoding"
		],
		[
			"Times-Italic",
			"times",
			"italic",
			"WinAnsiEncoding"
		],
		[
			"Times-BoldItalic",
			"times",
			"bolditalic",
			"WinAnsiEncoding"
		],
		[
			"ZapfDingbats",
			"zapfdingbats",
			"normal",
			null
		],
		[
			"Symbol",
			"symbol",
			"normal",
			null
		]
	];
	y.__private__.getStandardFonts = function() {
		return dt;
	};
	var pt = e.fontSize || 16;
	y.__private__.setFontSize = y.setFontSize = function(t) {
		return pt = _ === S ? t / St : t, this;
	};
	var gt, mt = y.__private__.getFontSize = y.getFontSize = function() {
		return _ === A ? pt : pt * St;
	}, vt = e.R2L || !1;
	y.__private__.setR2L = y.setR2L = function(t) {
		return vt = t, this;
	}, y.__private__.getR2L = y.getR2L = function() {
		return vt;
	};
	var bt, yt = y.__private__.setZoomMode = function(t) {
		if (/^(?:\d+\.\d*|\d*\.\d+|\d+)%$/.test(t)) gt = t;
		else if (isNaN(t)) {
			if (-1 === [
				void 0,
				null,
				"fullwidth",
				"fullheight",
				"fullpage",
				"original"
			].indexOf(t)) throw new Error("zoom must be Integer (e.g. 2), a percentage Value (e.g. 300%) or fullwidth, fullheight, fullpage, original. \"" + t + "\" is not recognized.");
			gt = t;
		} else gt = parseInt(t, 10);
	};
	y.__private__.getZoomMode = function() {
		return gt;
	};
	var wt, Nt = y.__private__.setPageMode = function(t) {
		if (-1 == [
			void 0,
			null,
			"UseNone",
			"UseOutlines",
			"UseThumbs",
			"FullScreen"
		].indexOf(t)) throw new Error("Page mode must be one of UseNone, UseOutlines, UseThumbs, or FullScreen. \"" + t + "\" is not recognized.");
		bt = t;
	};
	y.__private__.getPageMode = function() {
		return bt;
	};
	var Lt = y.__private__.setLayoutMode = function(t) {
		if (-1 == [
			void 0,
			null,
			"continuous",
			"single",
			"twoleft",
			"tworight",
			"two"
		].indexOf(t)) throw new Error("Layout mode must be one of continuous, single, twoleft, tworight. \"" + t + "\" is not recognized.");
		wt = t;
	};
	y.__private__.getLayoutMode = function() {
		return wt;
	}, y.__private__.setDisplayMode = y.setDisplayMode = function(t, e, r) {
		return yt(t), Lt(e), Nt(r), this;
	};
	var xt = {
		title: "",
		subject: "",
		author: "",
		keywords: "",
		creator: ""
	};
	y.__private__.getDocumentProperty = function(t) {
		if (-1 === Object.keys(xt).indexOf(t)) throw new Error("Invalid argument passed to jsPDF.getDocumentProperty");
		return xt[t];
	}, y.__private__.getDocumentProperties = function() {
		return xt;
	}, y.__private__.setDocumentProperties = y.setProperties = y.setDocumentProperties = function(t) {
		for (var e in xt) xt.hasOwnProperty(e) && t[e] && (xt[e] = t[e]);
		return this;
	}, y.__private__.setDocumentProperty = function(t, e) {
		if (-1 === Object.keys(xt).indexOf(t)) throw new Error("Invalid arguments passed to jsPDF.setDocumentProperty");
		return xt[t] = e;
	};
	var At, St, _t, Pt, kt, Ft = {}, It = {}, Ct = [], jt = {}, Ot = {}, Bt = {}, Mt = {}, qt = null, Et = 0, Rt = [], Dt = new j(y), Tt = e.hotfixes || [], zt = {}, Ut = {}, Ht = [], Wt = function t(e, r, n, i, a, o) {
		if (!(this instanceof t)) return new t(e, r, n, i, a, o);
		isNaN(e) && (e = 1), isNaN(r) && (r = 0), isNaN(n) && (n = 0), isNaN(i) && (i = 1), isNaN(a) && (a = 0), isNaN(o) && (o = 0), this._matrix = [
			e,
			r,
			n,
			i,
			a,
			o
		];
	};
	Object.defineProperty(Wt.prototype, "sx", {
		get: function() {
			return this._matrix[0];
		},
		set: function(t) {
			this._matrix[0] = t;
		}
	}), Object.defineProperty(Wt.prototype, "shy", {
		get: function() {
			return this._matrix[1];
		},
		set: function(t) {
			this._matrix[1] = t;
		}
	}), Object.defineProperty(Wt.prototype, "shx", {
		get: function() {
			return this._matrix[2];
		},
		set: function(t) {
			this._matrix[2] = t;
		}
	}), Object.defineProperty(Wt.prototype, "sy", {
		get: function() {
			return this._matrix[3];
		},
		set: function(t) {
			this._matrix[3] = t;
		}
	}), Object.defineProperty(Wt.prototype, "tx", {
		get: function() {
			return this._matrix[4];
		},
		set: function(t) {
			this._matrix[4] = t;
		}
	}), Object.defineProperty(Wt.prototype, "ty", {
		get: function() {
			return this._matrix[5];
		},
		set: function(t) {
			this._matrix[5] = t;
		}
	}), Object.defineProperty(Wt.prototype, "a", {
		get: function() {
			return this._matrix[0];
		},
		set: function(t) {
			this._matrix[0] = t;
		}
	}), Object.defineProperty(Wt.prototype, "b", {
		get: function() {
			return this._matrix[1];
		},
		set: function(t) {
			this._matrix[1] = t;
		}
	}), Object.defineProperty(Wt.prototype, "c", {
		get: function() {
			return this._matrix[2];
		},
		set: function(t) {
			this._matrix[2] = t;
		}
	}), Object.defineProperty(Wt.prototype, "d", {
		get: function() {
			return this._matrix[3];
		},
		set: function(t) {
			this._matrix[3] = t;
		}
	}), Object.defineProperty(Wt.prototype, "e", {
		get: function() {
			return this._matrix[4];
		},
		set: function(t) {
			this._matrix[4] = t;
		}
	}), Object.defineProperty(Wt.prototype, "f", {
		get: function() {
			return this._matrix[5];
		},
		set: function(t) {
			this._matrix[5] = t;
		}
	}), Object.defineProperty(Wt.prototype, "rotation", { get: function() {
		return Math.atan2(this.shx, this.sx);
	} }), Object.defineProperty(Wt.prototype, "scaleX", { get: function() {
		return this.decompose().scale.sx;
	} }), Object.defineProperty(Wt.prototype, "scaleY", { get: function() {
		return this.decompose().scale.sy;
	} }), Object.defineProperty(Wt.prototype, "isIdentity", { get: function() {
		return 1 === this.sx && 0 === this.shy && 0 === this.shx && 1 === this.sy && 0 === this.tx && 0 === this.ty;
	} }), Wt.prototype.join = function(t) {
		return [
			this.sx,
			this.shy,
			this.shx,
			this.sy,
			this.tx,
			this.ty
		].map(B).join(t);
	}, Wt.prototype.multiply = function(t) {
		return new Wt(t.sx * this.sx + t.shy * this.shx, t.sx * this.shy + t.shy * this.sy, t.shx * this.sx + t.sy * this.shx, t.shx * this.shy + t.sy * this.sy, t.tx * this.sx + t.ty * this.shx + this.tx, t.tx * this.shy + t.ty * this.sy + this.ty);
	}, Wt.prototype.decompose = function() {
		var t = this.sx, e = this.shy, r = this.shx, n = this.sy, i = this.tx, a = this.ty, o = Math.sqrt(t * t + e * e), s = (t /= o) * r + (e /= o) * n;
		r -= t * s, n -= e * s;
		var u = Math.sqrt(r * r + n * n);
		return s /= u, t * (n /= u) < e * (r /= u) && (t = -t, e = -e, s = -s, o = -o), {
			scale: new Wt(o, 0, 0, u, 0, 0),
			translate: new Wt(1, 0, 0, 1, i, a),
			rotate: new Wt(t, e, -e, t, 0, 0),
			skew: new Wt(1, 0, s, 1, 0, 0)
		};
	}, Wt.prototype.toString = function(t) {
		return this.join(" ");
	}, Wt.prototype.inversed = function() {
		var t = this.sx, e = this.shy, r = this.shx, n = this.sy, i = this.tx, a = this.ty, o = 1 / (t * n - e * r), s = n * o, u = -e * o, c = -r * o, l = t * o;
		return new Wt(s, u, c, l, -s * i - c * a, -u * i - l * a);
	}, Wt.prototype.applyToPoint = function(t) {
		return new mr(t.x * this.sx + t.y * this.shx + this.tx, t.x * this.shy + t.y * this.sy + this.ty);
	}, Wt.prototype.applyToRectangle = function(t) {
		var e = this.applyToPoint(t), r = this.applyToPoint(new mr(t.x + t.w, t.y + t.h));
		return new vr(e.x, e.y, r.x - e.x, r.y - e.y);
	}, Wt.prototype.clone = function() {
		var t = this.sx, e = this.shy, r = this.shx, n = this.sy, i = this.tx, a = this.ty;
		return new Wt(t, e, r, n, i, a);
	}, y.Matrix = Wt;
	var Vt = y.matrixMult = function(t, e) {
		return e.multiply(t);
	}, Gt = new Wt(1, 0, 0, 1, 0, 0);
	y.unitMatrix = y.identityMatrix = Gt;
	var Yt = function(t, e) {
		if (!Ot[t]) {
			var r = (e instanceof M ? "Sh" : "P") + (Object.keys(jt).length + 1).toString(10);
			e.id = r, Ot[t] = r, jt[r] = e, Dt.publish("addPattern", e);
		}
	};
	y.ShadingPattern = M, y.TilingPattern = q, y.addShadingPattern = function(t, e) {
		return R("addShadingPattern()"), Yt(t, e), this;
	}, y.beginTilingPattern = function(t) {
		R("beginTilingPattern()"), yr(t.boundingBox[0], t.boundingBox[1], t.boundingBox[2] - t.boundingBox[0], t.boundingBox[3] - t.boundingBox[1], t.matrix);
	}, y.endTilingPattern = function(t, e) {
		R("endTilingPattern()"), e.stream = ot[$].join("\n"), Yt(t, e), Dt.publish("endTilingPattern", e), Ht.pop().restore();
	};
	var Jt, Xt = y.__private__.newObject = function() {
		var t = Kt();
		return Zt(t, !0), t;
	}, Kt = y.__private__.newObjectDeferred = function() {
		return et++, rt[et] = function() {
			return it;
		}, et;
	}, Zt = function(t, e) {
		return e = "boolean" == typeof e && e, rt[t] = it, e && lt(t + " 0 obj"), t;
	}, $t = y.__private__.newAdditionalObject = function() {
		var t = {
			objId: Kt(),
			content: ""
		};
		return at.push(t), t;
	}, Qt = Kt(), te = Kt(), ee = y.__private__.decodeColorString = function(t) {
		var e = t.split(" ");
		if (2 !== e.length || "g" !== e[1] && "G" !== e[1]) 5 !== e.length || "k" !== e[4] && "K" !== e[4] || (e = [
			(1 - e[0]) * (1 - e[3]),
			(1 - e[1]) * (1 - e[3]),
			(1 - e[2]) * (1 - e[3]),
			"r"
		]);
		else {
			var r = parseFloat(e[0]);
			e = [
				r,
				r,
				r,
				"r"
			];
		}
		for (var n = "#", i = 0; i < 3; i++) n += ("0" + Math.floor(255 * parseFloat(e[i])).toString(16)).slice(-2);
		return n;
	}, re = y.__private__.encodeColorString = function(e) {
		var r;
		"string" == typeof e && (e = { ch1: e });
		var n = e.ch1, i = e.ch2, a = e.ch3, o = e.ch4, s = "draw" === e.pdfColorType ? [
			"G",
			"RG",
			"K"
		] : [
			"g",
			"rg",
			"k"
		];
		if ("string" == typeof n && "#" !== n.charAt(0)) {
			var u = new h(n);
			if (u.ok) n = u.toHex();
			else if (!/^\d*\.?\d*$/.test(n)) throw new Error("Invalid color \"" + n + "\" passed to jsPDF.encodeColorString.");
		}
		if ("string" == typeof n && /^#[0-9A-Fa-f]{3}$/.test(n) && (n = "#" + n[1] + n[1] + n[2] + n[2] + n[3] + n[3]), "string" == typeof n && /^#[0-9A-Fa-f]{6}$/.test(n)) {
			var c = parseInt(n.substr(1), 16);
			n = c >> 16 & 255, i = c >> 8 & 255, a = 255 & c;
		}
		if (void 0 === i || void 0 === o && n === i && i === a) r = "string" == typeof n ? n + " " + s[0] : 2 === e.precision ? T(n / 255) + " " + s[0] : z(n / 255) + " " + s[0];
		else if (void 0 === o || "object" === _typeof(o)) {
			if (o && !isNaN(o.a) && 0 === o.a) return [
				"1.",
				"1.",
				"1.",
				s[1]
			].join(" ");
			r = "string" == typeof n ? [
				n,
				i,
				a,
				s[1]
			].join(" ") : 2 === e.precision ? [
				T(n / 255),
				T(i / 255),
				T(a / 255),
				s[1]
			].join(" ") : [
				z(n / 255),
				z(i / 255),
				z(a / 255),
				s[1]
			].join(" ");
		} else r = "string" == typeof n ? [
			n,
			i,
			a,
			o,
			s[2]
		].join(" ") : 2 === e.precision ? [
			T(n),
			T(i),
			T(a),
			T(o),
			s[2]
		].join(" ") : [
			z(n),
			z(i),
			z(a),
			z(o),
			s[2]
		].join(" ");
		return r;
	}, ne = y.__private__.getFilters = function() {
		return c;
	}, ie = y.__private__.putStream = function(t) {
		var e = (t = t || {}).data || "", r = t.filters || ne(), n = t.alreadyAppliedFilters || [], i = t.addLength1 || !1, a = e.length, o = t.objectId, s = function(t) {
			return t;
		};
		if (null !== m && void 0 === o) throw new Error("ObjectId must be passed to putStream for file encryption");
		null !== m && (s = Oe.encryptor(o, 0));
		var u = {};
		!0 === r && (r = ["FlateEncode"]);
		var c = t.additionalKeyValues || [], l = (u = void 0 !== E.API.processDataByFilters ? E.API.processDataByFilters(e, r) : {
			data: e,
			reverseChain: []
		}).reverseChain + (Array.isArray(n) ? n.join(" ") : n.toString());
		if (0 !== u.data.length && (c.push({
			key: "Length",
			value: u.data.length
		}), !0 === i && c.push({
			key: "Length1",
			value: a
		})), 0 != l.length) if (l.split("/").length - 1 == 1) c.push({
			key: "Filter",
			value: l
		});
		else {
			c.push({
				key: "Filter",
				value: "[" + l + "]"
			});
			for (var h = 0; h < c.length; h += 1) if ("DecodeParms" === c[h].key) {
				for (var f = [], d = 0; d < u.reverseChain.split("/").length - 1; d += 1) f.push("null");
				f.push(c[h].value), c[h].value = "[" + f.join(" ") + "]";
			}
		}
		lt("<<");
		for (var p = 0; p < c.length; p++) lt("/" + c[p].key + " " + c[p].value);
		lt(">>"), 0 !== u.data.length && (lt("stream"), lt(s(u.data)), lt("endstream"));
	}, ae = y.__private__.putPage = function(t) {
		var e = t.number, r = t.data, n = t.objId, i = t.contentsObjId;
		Zt(n, !0), lt("<</Type /Page"), lt("/Parent " + t.rootDictionaryObjId + " 0 R"), lt("/Resources " + t.resourceDictionaryObjId + " 0 R"), lt("/MediaBox [" + parseFloat(B(t.mediaBox.bottomLeftX)) + " " + parseFloat(B(t.mediaBox.bottomLeftY)) + " " + B(t.mediaBox.topRightX) + " " + B(t.mediaBox.topRightY) + "]"), null !== t.cropBox && lt("/CropBox [" + B(t.cropBox.bottomLeftX) + " " + B(t.cropBox.bottomLeftY) + " " + B(t.cropBox.topRightX) + " " + B(t.cropBox.topRightY) + "]"), null !== t.bleedBox && lt("/BleedBox [" + B(t.bleedBox.bottomLeftX) + " " + B(t.bleedBox.bottomLeftY) + " " + B(t.bleedBox.topRightX) + " " + B(t.bleedBox.topRightY) + "]"), null !== t.trimBox && lt("/TrimBox [" + B(t.trimBox.bottomLeftX) + " " + B(t.trimBox.bottomLeftY) + " " + B(t.trimBox.topRightX) + " " + B(t.trimBox.topRightY) + "]"), null !== t.artBox && lt("/ArtBox [" + B(t.artBox.bottomLeftX) + " " + B(t.artBox.bottomLeftY) + " " + B(t.artBox.topRightX) + " " + B(t.artBox.topRightY) + "]"), "number" == typeof t.userUnit && 1 !== t.userUnit && lt("/UserUnit " + t.userUnit), Dt.publish("putPage", {
			objId: n,
			pageContext: Rt[e],
			pageNumber: e,
			page: r
		}), lt("/Contents " + i + " 0 R"), lt(">>"), lt("endobj");
		var a = r.join("\n");
		return _ === S && (a += "\nQ"), Zt(i, !0), ie({
			data: a,
			filters: ne(),
			objectId: i
		}), lt("endobj"), n;
	}, oe = y.__private__.putPages = function() {
		var t, e, r = [];
		for (t = 1; t <= Et; t++) Rt[t].objId = Kt(), Rt[t].contentsObjId = Kt();
		for (t = 1; t <= Et; t++) r.push(ae({
			number: t,
			data: ot[t],
			objId: Rt[t].objId,
			contentsObjId: Rt[t].contentsObjId,
			mediaBox: Rt[t].mediaBox,
			cropBox: Rt[t].cropBox,
			bleedBox: Rt[t].bleedBox,
			trimBox: Rt[t].trimBox,
			artBox: Rt[t].artBox,
			userUnit: Rt[t].userUnit,
			rootDictionaryObjId: Qt,
			resourceDictionaryObjId: te
		}));
		Zt(Qt, !0), lt("<</Type /Pages");
		var n = "/Kids [";
		for (e = 0; e < Et; e++) n += r[e] + " 0 R ";
		lt(n + "]"), lt("/Count " + Et), lt(">>"), lt("endobj"), Dt.publish("postPutPages");
	}, se = function(t) {
		Dt.publish("putFont", {
			font: t,
			out: lt,
			newObject: Xt,
			putStream: ie
		}), !0 !== t.isAlreadyPutted && (t.objectNumber = Xt(), lt("<<"), lt("/Type /Font"), lt("/BaseFont /" + C(t.postScriptName)), lt("/Subtype /Type1"), "string" == typeof t.encoding && lt("/Encoding /" + t.encoding), lt("/FirstChar 32"), lt("/LastChar 255"), lt(">>"), lt("endobj"));
	}, ue = function(t) {
		t.objectNumber = Xt();
		var e = [];
		e.push({
			key: "Type",
			value: "/XObject"
		}), e.push({
			key: "Subtype",
			value: "/Form"
		}), e.push({
			key: "BBox",
			value: "[" + [
				B(t.x),
				B(t.y),
				B(t.x + t.width),
				B(t.y + t.height)
			].join(" ") + "]"
		}), e.push({
			key: "Matrix",
			value: "[" + t.matrix.toString() + "]"
		});
		ie({
			data: t.pages[1].join("\n"),
			additionalKeyValues: e,
			objectId: t.objectNumber
		}), lt("endobj");
	}, ce = function(t, e) {
		e || (e = 21);
		var r = Xt(), n = function(t, e) {
			var r, n = [], i = 1 / (e - 1);
			for (r = 0; r < 1; r += i) n.push(r);
			if (n.push(1), 0 != t[0].offset) {
				var a = {
					offset: 0,
					color: t[0].color
				};
				t.unshift(a);
			}
			if (1 != t[t.length - 1].offset) {
				var o = {
					offset: 1,
					color: t[t.length - 1].color
				};
				t.push(o);
			}
			for (var s = "", u = 0, c = 0; c < n.length; c++) {
				for (r = n[c]; r > t[u + 1].offset;) u++;
				var l = t[u].offset, h = (r - l) / (t[u + 1].offset - l), f = t[u].color, d = t[u + 1].color;
				s += tt(Math.round((1 - h) * f[0] + h * d[0]).toString(16)) + tt(Math.round((1 - h) * f[1] + h * d[1]).toString(16)) + tt(Math.round((1 - h) * f[2] + h * d[2]).toString(16));
			}
			return s.trim();
		}(t.colors, e), i = [];
		i.push({
			key: "FunctionType",
			value: "0"
		}), i.push({
			key: "Domain",
			value: "[0.0 1.0]"
		}), i.push({
			key: "Size",
			value: "[" + e + "]"
		}), i.push({
			key: "BitsPerSample",
			value: "8"
		}), i.push({
			key: "Range",
			value: "[0.0 1.0 0.0 1.0 0.0 1.0]"
		}), i.push({
			key: "Decode",
			value: "[0.0 1.0 0.0 1.0 0.0 1.0]"
		}), ie({
			data: n,
			additionalKeyValues: i,
			alreadyAppliedFilters: ["/ASCIIHexDecode"],
			objectId: r
		}), lt("endobj"), t.objectNumber = Xt(), lt("<< /ShadingType " + t.type), lt("/ColorSpace /DeviceRGB");
		var a = "/Coords [" + B(parseFloat(t.coords[0])) + " " + B(parseFloat(t.coords[1])) + " ";
		2 === t.type ? a += B(parseFloat(t.coords[2])) + " " + B(parseFloat(t.coords[3])) : a += B(parseFloat(t.coords[2])) + " " + B(parseFloat(t.coords[3])) + " " + B(parseFloat(t.coords[4])) + " " + B(parseFloat(t.coords[5])), lt(a += "]"), t.matrix && lt("/Matrix [" + t.matrix.toString() + "]"), lt("/Function " + r + " 0 R"), lt("/Extend [true true]"), lt(">>"), lt("endobj");
	}, le = function(t, e) {
		var r = Kt(), n = Xt();
		e.push({
			resourcesOid: r,
			objectOid: n
		}), t.objectNumber = n;
		var i = [];
		i.push({
			key: "Type",
			value: "/Pattern"
		}), i.push({
			key: "PatternType",
			value: "1"
		}), i.push({
			key: "PaintType",
			value: "1"
		}), i.push({
			key: "TilingType",
			value: "1"
		}), i.push({
			key: "BBox",
			value: "[" + t.boundingBox.map(B).join(" ") + "]"
		}), i.push({
			key: "XStep",
			value: B(t.xStep)
		}), i.push({
			key: "YStep",
			value: B(t.yStep)
		}), i.push({
			key: "Resources",
			value: r + " 0 R"
		}), t.matrix && i.push({
			key: "Matrix",
			value: "[" + t.matrix.toString() + "]"
		}), ie({
			data: t.stream,
			additionalKeyValues: i,
			objectId: t.objectNumber
		}), lt("endobj");
	}, he = function(t) {
		for (var e in t.objectNumber = Xt(), lt("<<"), t) switch (e) {
			case "opacity":
				lt("/ca " + T(t[e]));
				break;
			case "stroke-opacity": lt("/CA " + T(t[e]));
		}
		lt(">>"), lt("endobj");
	}, fe = function(t) {
		Zt(t.resourcesOid, !0), lt("<<"), lt("/ProcSet [/PDF /Text /ImageB /ImageC /ImageI]"), function() {
			for (var t in lt("/Font <<"), Ft) Ft.hasOwnProperty(t) && (!1 === v || !0 === v && b.hasOwnProperty(t)) && lt("/" + t + " " + Ft[t].objectNumber + " 0 R");
			lt(">>");
		}(), function() {
			if (Object.keys(jt).length > 0) {
				for (var t in lt("/Shading <<"), jt) jt.hasOwnProperty(t) && jt[t] instanceof M && jt[t].objectNumber >= 0 && lt("/" + t + " " + jt[t].objectNumber + " 0 R");
				Dt.publish("putShadingPatternDict"), lt(">>");
			}
		}(), function(t) {
			if (Object.keys(jt).length > 0) {
				for (var e in lt("/Pattern <<"), jt) jt.hasOwnProperty(e) && jt[e] instanceof y.TilingPattern && jt[e].objectNumber >= 0 && jt[e].objectNumber < t && lt("/" + e + " " + jt[e].objectNumber + " 0 R");
				Dt.publish("putTilingPatternDict"), lt(">>");
			}
		}(t.objectOid), function() {
			if (Object.keys(Bt).length > 0) {
				var t;
				for (t in lt("/ExtGState <<"), Bt) Bt.hasOwnProperty(t) && Bt[t].objectNumber >= 0 && lt("/" + t + " " + Bt[t].objectNumber + " 0 R");
				Dt.publish("putGStateDict"), lt(">>");
			}
		}(), function() {
			for (var t in lt("/XObject <<"), zt) zt.hasOwnProperty(t) && zt[t].objectNumber >= 0 && lt("/" + t + " " + zt[t].objectNumber + " 0 R");
			Dt.publish("putXobjectDict"), lt(">>");
		}(), lt(">>"), lt("endobj");
	}, de = function(t) {
		It[t.fontName] = It[t.fontName] || {}, It[t.fontName][t.fontStyle] = t.id;
	}, pe = function(t, e, r, n, i) {
		var a = {
			id: "F" + (Object.keys(Ft).length + 1).toString(10),
			postScriptName: t,
			fontName: e,
			fontStyle: r,
			encoding: n,
			isStandardFont: i || !1,
			metadata: {}
		};
		return Dt.publish("addFont", {
			font: a,
			instance: this
		}), Ft[a.id] = a, de(a), a.id;
	}, ge = y.__private__.pdfEscape = y.pdfEscape = function(t, e) {
		return function(t, e) {
			var r, n, i, a, o, s, u, c, l;
			if (i = (e = e || {}).sourceEncoding || "Unicode", o = e.outputEncoding, (e.autoencode || o) && Ft[At].metadata && Ft[At].metadata[i] && Ft[At].metadata[i].encoding && (a = Ft[At].metadata[i].encoding, !o && Ft[At].encoding && (o = Ft[At].encoding), !o && a.codePages && (o = a.codePages[0]), "string" == typeof o && (o = a[o]), o)) {
				for (u = !1, s = [], r = 0, n = t.length; r < n; r++) (c = o[t.charCodeAt(r)]) ? s.push(String.fromCharCode(c)) : s.push(t[r]), s[r].charCodeAt(0) >> 8 && (u = !0);
				t = s.join("");
			}
			for (r = t.length; void 0 === u && 0 !== r;) t.charCodeAt(r - 1) >> 8 && (u = !0), r--;
			if (!u) return t;
			for (s = e.noBOM ? [] : [254, 255], r = 0, n = t.length; r < n; r++) {
				if ((l = (c = t.charCodeAt(r)) >> 8) >> 8) throw new Error("Character at position " + r + " of string '" + t + "' exceeds 16bits. Cannot be encoded into UCS-2 BE");
				s.push(l), s.push(c - (l << 8));
			}
			return String.fromCharCode.apply(void 0, s);
		}(t, e).replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
	}, me = y.__private__.beginPage = function(t) {
		ot[++Et] = [], Rt[Et] = {
			objId: 0,
			contentsObjId: 0,
			userUnit: Number(f),
			artBox: null,
			bleedBox: null,
			cropBox: null,
			trimBox: null,
			mediaBox: {
				bottomLeftX: 0,
				bottomLeftY: 0,
				topRightX: Number(t[0]),
				topRightY: Number(t[1])
			}
		}, ye(Et), ct(ot[$]);
	}, ve = function(t, e) {
		var r, i, a;
		switch (n = e || n, "string" == typeof t && (r = x(t.toLowerCase()), Array.isArray(r) && (i = r[0], a = r[1])), Array.isArray(t) && (i = t[0] * St, a = t[1] * St), isNaN(i) && (i = s[0], a = s[1]), (i > 14400 || a > 14400) && (o.warn("A page in a PDF can not be wider or taller than 14400 userUnit. jsPDF limits the width/height to 14400"), i = Math.min(14400, i), a = Math.min(14400, a)), s = [i, a], n.substr(0, 1)) {
			case "l":
				a > i && (s = [a, i]);
				break;
			case "p": i > a && (s = [a, i]);
		}
		me(s), Qe(Ze), lt(sr), 0 !== dr && lt(dr + " J"), 0 !== pr && lt(pr + " j"), Dt.publish("addPage", { pageNumber: Et });
	}, be = function(t) {
		t > 0 && t <= Et && (ot.splice(t, 1), Rt.splice(t, 1), Et--, $ > Et && ($ = Et), this.setPage($));
	}, ye = function(t) {
		t > 0 && t <= Et && ($ = t);
	}, we = y.__private__.getNumberOfPages = y.getNumberOfPages = function() {
		return ot.length - 1;
	}, Ne = function(t, e, r) {
		var n, i = void 0;
		return r = r || {}, t = void 0 !== t ? t : Ft[At].fontName, e = void 0 !== e ? e : Ft[At].fontStyle, n = t.toLowerCase(), void 0 !== It[n] && void 0 !== It[n][e] ? i = It[n][e] : void 0 !== It[t] && void 0 !== It[t][e] ? i = It[t][e] : !1 === r.disableWarning && o.warn("Unable to look up font label for font '" + t + "', '" + e + "'. Refer to getFontList() for available fonts."), i || r.noFallback || ((i = It.times[e]) ?? (i = It.times.normal)), i;
	}, Le = y.__private__.putInfo = function() {
		var t = Xt(), e = function(t) {
			return t;
		};
		for (var r in null !== m && (e = Oe.encryptor(t, 0)), lt("<<"), lt("/Producer (" + ge(e("jsPDF " + E.version)) + ")"), xt) xt.hasOwnProperty(r) && xt[r] && lt("/" + r.substr(0, 1).toUpperCase() + r.substr(1) + " (" + ge(e(xt[r])) + ")");
		lt("/CreationDate (" + ge(e(W)) + ")"), lt(">>"), lt("endobj");
	}, xe = y.__private__.putCatalog = function(t) {
		var e = (t = t || {}).rootDictionaryObjId || Qt;
		switch (Xt(), lt("<<"), lt("/Type /Catalog"), lt("/Pages " + e + " 0 R"), gt || (gt = "fullwidth"), gt) {
			case "fullwidth":
				lt("/OpenAction [3 0 R /FitH null]");
				break;
			case "fullheight":
				lt("/OpenAction [3 0 R /FitV null]");
				break;
			case "fullpage":
				lt("/OpenAction [3 0 R /Fit]");
				break;
			case "original":
				lt("/OpenAction [3 0 R /XYZ null null 1]");
				break;
			default:
				var r = "" + gt;
				"%" === r.substr(r.length - 1) && (gt = parseInt(gt) / 100), "number" == typeof gt && lt("/OpenAction [3 0 R /XYZ null null " + T(gt) + "]");
		}
		switch (wt || (wt = "continuous"), wt) {
			case "continuous":
				lt("/PageLayout /OneColumn");
				break;
			case "single":
				lt("/PageLayout /SinglePage");
				break;
			case "two":
			case "twoleft":
				lt("/PageLayout /TwoColumnLeft");
				break;
			case "tworight": lt("/PageLayout /TwoColumnRight");
		}
		bt && lt("/PageMode /" + bt), Dt.publish("putCatalog"), lt(">>"), lt("endobj");
	}, Ae = y.__private__.putTrailer = function() {
		lt("trailer"), lt("<<"), lt("/Size " + (et + 1)), lt("/Root " + et + " 0 R"), lt("/Info " + (et - 1) + " 0 R"), null !== m && lt("/Encrypt " + Oe.oid + " 0 R"), lt("/ID [ <" + V + "> <" + V + "> ]"), lt(">>");
	}, Se = y.__private__.putHeader = function() {
		lt("%PDF-" + w), lt("%ºß¬à");
	}, _e = y.__private__.putXRef = function() {
		var t = "0000000000";
		lt("xref"), lt("0 " + (et + 1)), lt("0000000000 65535 f ");
		for (var e = 1; e <= et; e++) "function" == typeof rt[e] ? lt((t + rt[e]()).slice(-10) + " 00000 n ") : void 0 !== rt[e] ? lt((t + rt[e]).slice(-10) + " 00000 n ") : lt("0000000000 00000 n ");
	}, Pe = y.__private__.buildDocument = function() {
		var t;
		et = 0, it = 0, nt = [], rt = [], at = [], Qt = Kt(), te = Kt(), ct(nt), Dt.publish("buildDocument"), Se(), oe(), function() {
			Dt.publish("putAdditionalObjects");
			for (var t = 0; t < at.length; t++) {
				var e = at[t];
				Zt(e.objId, !0), lt(e.content), lt("endobj");
			}
			Dt.publish("postPutAdditionalObjects");
		}(), t = [], function() {
			for (var t in Ft) Ft.hasOwnProperty(t) && (!1 === v || !0 === v && b.hasOwnProperty(t)) && se(Ft[t]);
		}(), function() {
			var t;
			for (t in Bt) Bt.hasOwnProperty(t) && he(Bt[t]);
		}(), function() {
			for (var t in zt) zt.hasOwnProperty(t) && ue(zt[t]);
		}(), function(t) {
			var e;
			for (e in jt) jt.hasOwnProperty(e) && (jt[e] instanceof M ? ce(jt[e]) : jt[e] instanceof q && le(jt[e], t));
		}(t), Dt.publish("putResources"), t.forEach(fe), fe({
			resourcesOid: te,
			objectOid: Number.MAX_SAFE_INTEGER
		}), Dt.publish("postPutResources"), null !== m && (Oe.oid = Xt(), lt("<<"), lt("/Filter /Standard"), lt("/V " + Oe.v), lt("/R " + Oe.r), lt("/U <" + Oe.toHexString(Oe.U) + ">"), lt("/O <" + Oe.toHexString(Oe.O) + ">"), lt("/P " + Oe.P), lt(">>"), lt("endobj")), Le(), xe();
		var e = it;
		return _e(), Ae(), lt("startxref"), lt("" + e), lt("%%EOF"), ct(ot[$]), nt.join("\n");
	}, ke = y.__private__.getBlob = function(t) {
		return new Blob([ft(t)], { type: "application/pdf" });
	}, Fe = function(t) {
		for (; t.firstChild;) t.removeChild(t.firstChild);
	}, Ie = function(t) {
		var e, r = t.document, n = r.documentElement, i = r.head, a = r.body;
		return i || (i = r.createElement("head"), n.appendChild(i)), a || (a = r.createElement("body"), n.appendChild(a)), Fe(i), Fe(a), (e = r.createElement("style")).appendChild(r.createTextNode("html, body { padding: 0; margin: 0; } iframe { width: 100%; height: 100%; border: 0;}")), i.appendChild(e), {
			document: r,
			body: a
		};
	}, Ce = y.output = y.__private__.output = (Jt = function(t, e) {
		switch ("string" == typeof (e = e || {}) ? e = { filename: e } : e.filename = e.filename || "generated.pdf", t) {
			case void 0: return Pe();
			case "save":
				y.save(e.filename);
				break;
			case "arraybuffer": return ft(Pe());
			case "blob": return ke(Pe());
			case "bloburi":
			case "bloburl":
				if (void 0 !== i.URL && "function" == typeof i.URL.createObjectURL) return i.URL && i.URL.createObjectURL(ke(Pe())) || void 0;
				o.warn("bloburl is not supported by your system, because URL.createObjectURL is not supported by your browser.");
				break;
			case "datauristring":
			case "dataurlstring":
				var r = "", n = Pe();
				try {
					r = d(n);
				} catch (L) {
					r = d(unescape(encodeURIComponent(n)));
				}
				return "data:application/pdf;filename=" + encodeURIComponent(e.filename) + ";base64," + r;
			case "pdfobjectnewwindow":
				if ("[object Window]" === Object.prototype.toString.call(i)) {
					var a = "https://cdnjs.cloudflare.com/ajax/libs/pdfobject/2.1.1/pdfobject.min.js", s = !e.pdfObjectUrl;
					s || (a = e.pdfObjectUrl);
					var u = i.open();
					if (null !== u) {
						var c = Ie(u), l = c.document.createElement("script"), h = this;
						l.src = a, s && (l.integrity = "sha512-4ze/a9/4jqu+tX9dfOqJYSvyYd5M6qum/3HpCLr+/Jqf0whc37VUbkpNGHR7/8pSnCFw47T1fmIpwBV7UySh3g==", l.crossOrigin = "anonymous"), l.onload = function() {
							u.PDFObject.embed(h.output("dataurlstring"), e);
						}, c.body.appendChild(l);
					}
					return u;
				}
				throw new Error("The option pdfobjectnewwindow just works in a browser-environment.");
			case "pdfjsnewwindow":
				if ("[object Window]" === Object.prototype.toString.call(i)) {
					var f = e.pdfJsUrl || "examples/PDF.js/web/viewer.html", p = i.open();
					if (null !== p) {
						var g = Ie(p), m = g.document.createElement("iframe"), v = -1 === f.indexOf("?") ? "?" : "&";
						h = this, m.id = "pdfViewer", m.width = "500px", m.height = "400px", m.src = f + v + "file=&downloadName=" + encodeURIComponent(e.filename), m.onload = function() {
							p.document.title = e.filename, m.contentWindow.PDFViewerApplication.open(h.output("bloburl"));
						}, g.body.appendChild(m);
					}
					return p;
				}
				throw new Error("The option pdfjsnewwindow just works in a browser-environment.");
			case "dataurlnewwindow":
				if ("[object Window]" !== Object.prototype.toString.call(i)) throw new Error("The option dataurlnewwindow just works in a browser-environment.");
				var b = i.open();
				if (null !== b) {
					var w = Ie(b), N = w.document.createElement("iframe");
					N.src = this.output("datauristring", e), w.body.appendChild(N), b.document.title = e.filename;
				}
				if (b || "undefined" == typeof safari) return b;
				break;
			case "datauri":
			case "dataurl": return i.document.location.href = this.output("datauristring", e);
			default: return null;
		}
	}, Jt.foo = function() {
		try {
			return Jt.apply(this, arguments);
		} catch (r) {
			var t = r.stack || "";
			~t.indexOf(" at ") && (t = t.split(" at ")[1]);
			var e = "Error in function " + t.split("\n")[0].split("<")[0] + ": " + r.message;
			if (!i.console) throw new Error(e);
			i.console.error(e, r), i.alert && alert(e);
		}
	}, Jt.foo.bar = Jt, Jt.foo), je = function(t) {
		return !0 === Array.isArray(Tt) && Tt.indexOf(t) > -1;
	};
	switch (a) {
		case "pt":
			St = 1;
			break;
		case "mm":
			St = 72 / 25.4;
			break;
		case "cm":
			St = 72 / 2.54;
			break;
		case "in":
			St = 72;
			break;
		case "px":
			St = 1 == je("px_scaling") ? .75 : 96 / 72;
			break;
		case "pc":
		case "em":
			St = 12;
			break;
		case "ex":
			St = 6;
			break;
		default:
			if ("number" != typeof a) throw new Error("Invalid unit: " + a);
			St = a;
	}
	var Oe = null;
	K(), Y();
	var Be = y.__private__.getPageInfo = y.getPageInfo = function(t) {
		if (isNaN(t) || t % 1 != 0) throw new Error("Invalid argument passed to jsPDF.getPageInfo");
		return {
			objId: Rt[t].objId,
			pageNumber: t,
			pageContext: Rt[t]
		};
	}, Me = y.__private__.getPageInfoByObjId = function(t) {
		if (isNaN(t) || t % 1 != 0) throw new Error("Invalid argument passed to jsPDF.getPageInfoByObjId");
		for (var e in Rt) if (Rt[e].objId === t) break;
		return Be(e);
	}, qe = y.__private__.getCurrentPageInfo = y.getCurrentPageInfo = function() {
		return {
			objId: Rt[$].objId,
			pageNumber: $,
			pageContext: Rt[$]
		};
	};
	y.addPage = function() {
		return ve.apply(this, arguments), this;
	}, y.setPage = function() {
		return ye.apply(this, arguments), ct.call(this, ot[$]), this;
	}, y.insertPage = function(t) {
		return this.addPage(), this.movePage($, t), this;
	}, y.movePage = function(t, e) {
		var r, n;
		if (t > e) {
			r = ot[t], n = Rt[t];
			for (var i = t; i > e; i--) ot[i] = ot[i - 1], Rt[i] = Rt[i - 1];
			ot[e] = r, Rt[e] = n, this.setPage(e);
		} else if (t < e) {
			r = ot[t], n = Rt[t];
			for (var a = t; a < e; a++) ot[a] = ot[a + 1], Rt[a] = Rt[a + 1];
			ot[e] = r, Rt[e] = n, this.setPage(e);
		}
		return this;
	}, y.deletePage = function() {
		return be.apply(this, arguments), this;
	}, y.__private__.text = y.text = function(e, r, n, i, a) {
		var o, s, u, c, l, h, f, d, p, g = (i = i || {}).scope || this;
		if ("number" == typeof e && "number" == typeof r && ("string" == typeof n || Array.isArray(n))) {
			var m = n;
			n = r, r = e, e = m;
		}
		if (arguments[3] instanceof Wt == 0 ? (u = arguments[4], c = arguments[5], "object" === _typeof(f = arguments[3]) && null !== f || ("string" == typeof u && (c = u, u = null), "string" == typeof f && (c = f, f = null), "number" == typeof f && (u = f, f = null), i = {
			flags: f,
			angle: u,
			align: c
		})) : (R("The transform parameter of text() with a Matrix value"), p = a), isNaN(r) || isNaN(n) || null == e) throw new Error("Invalid arguments passed to jsPDF.text");
		if (0 === e.length) return g;
		var v, y = "", w = "number" == typeof i.lineHeightFactor ? i.lineHeightFactor : Ke, N = g.internal.scaleFactor;
		function L(t) {
			return t = t.split("	").join(Array(i.TabLen || 9).join(" ")), ge(t, f);
		}
		function x(t) {
			for (var e, r = t.concat(), n = [], i = r.length; i--;) "string" == typeof (e = r.shift()) ? n.push(e) : Array.isArray(t) && (1 === e.length || void 0 === e[1] && void 0 === e[2]) ? n.push(e[0]) : n.push([
				e[0],
				e[1],
				e[2]
			]);
			return n;
		}
		function A(t, e) {
			var r;
			if ("string" == typeof t) r = e(t)[0];
			else if (Array.isArray(t)) {
				for (var n, i, a = t.concat(), o = [], s = a.length; s--;) "string" == typeof (n = a.shift()) ? o.push(e(n)[0]) : Array.isArray(n) && "string" == typeof n[0] && (i = e(n[0], n[1], n[2]), o.push([
					i[0],
					i[1],
					i[2]
				]));
				r = o;
			}
			return r;
		}
		var P = !1, k = !0;
		if ("string" == typeof e) P = !0;
		else if (Array.isArray(e)) {
			var F = e.concat();
			s = [];
			for (var I, C = F.length; C--;) ("string" != typeof (I = F.shift()) || Array.isArray(I) && "string" != typeof I[0]) && (k = !1);
			P = k;
		}
		if (!1 === P) throw new Error("Type of text must be string or Array. \"" + e + "\" is not recognized.");
		"string" == typeof e && (e = e.match(/[\r?\n]/) ? e.split(/\r\n|\r|\n/g) : [e]);
		var j = pt / g.internal.scaleFactor, O = j * (w - 1);
		switch (i.baseline) {
			case "bottom":
				n -= O;
				break;
			case "top":
				n += j - O;
				break;
			case "hanging":
				n += j - 2 * O;
				break;
			case "middle": n += j / 2 - O;
		}
		if ((h = i.maxWidth || 0) > 0 && ("string" == typeof e ? e = g.splitTextToSize(e, h) : "[object Array]" === Object.prototype.toString.call(e) && (e = e.reduce(function(t, e) {
			return t.concat(g.splitTextToSize(e, h));
		}, []))), o = {
			text: e,
			x: r,
			y: n,
			options: i,
			mutex: {
				pdfEscape: ge,
				activeFontKey: At,
				fonts: Ft,
				activeFontSize: pt
			}
		}, Dt.publish("preProcessText", o), e = o.text, u = (i = o.options).angle, p instanceof Wt == 0 && u && "number" == typeof u) {
			u *= Math.PI / 180, 0 === i.rotationDirection && (u = -u), _ === S && (u = -u);
			var M = Math.cos(u), q = Math.sin(u);
			p = new Wt(M, q, -q, M, 0, 0);
		} else u && u instanceof Wt && (p = u);
		_ !== S || p || (p = Gt), void 0 !== (l = i.charSpace || hr) && (y += B(U(l)) + " Tc\n", this.setCharSpace(this.getCharSpace() || 0)), void 0 !== (d = i.horizontalScale) && (y += B(100 * d) + " Tz\n"), i.lang;
		var E = -1, D = void 0 !== i.renderingMode ? i.renderingMode : i.stroke, T = g.internal.getCurrentPageInfo().pageContext;
		switch (D) {
			case 0:
			case !1:
			case "fill":
				E = 0;
				break;
			case 1:
			case !0:
			case "stroke":
				E = 1;
				break;
			case 2:
			case "fillThenStroke":
				E = 2;
				break;
			case 3:
			case "invisible":
				E = 3;
				break;
			case 4:
			case "fillAndAddForClipping":
				E = 4;
				break;
			case 5:
			case "strokeAndAddPathForClipping":
				E = 5;
				break;
			case 6:
			case "fillThenStrokeAndAddToPathForClipping":
				E = 6;
				break;
			case 7:
			case "addToPathForClipping": E = 7;
		}
		var z = void 0 !== T.usedRenderingMode ? T.usedRenderingMode : -1;
		-1 !== E ? y += E + " Tr\n" : -1 !== z && (y += "0 Tr\n"), -1 !== E && (T.usedRenderingMode = E), c = i.align || "left";
		var H, W = pt * w, V = g.internal.pageSize.getWidth(), G = Ft[At];
		l = i.charSpace || hr, h = i.maxWidth || 0, f = Object.assign({
			autoencode: !0,
			noBOM: !0
		}, i.flags);
		var Y = [], J = function(t) {
			return g.getStringUnitWidth(t, {
				font: G,
				charSpace: l,
				fontSize: pt,
				doKerning: !1
			}) * pt / N;
		};
		if ("[object Array]" === Object.prototype.toString.call(e)) {
			var X;
			s = x(e), "left" !== c && (H = s.map(J));
			var K, Z = 0;
			if ("right" === c) {
				r -= H[0], e = [], C = s.length;
				for (var $ = 0; $ < C; $++) 0 === $ ? (K = nr(r), X = ir(n)) : (K = U(Z - H[$]), X = -W), e.push([
					s[$],
					K,
					X
				]), Z = H[$];
			} else if ("center" === c) {
				r -= H[0] / 2, e = [], C = s.length;
				for (var Q = 0; Q < C; Q++) 0 === Q ? (K = nr(r), X = ir(n)) : (K = U((Z - H[Q]) / 2), X = -W), e.push([
					s[Q],
					K,
					X
				]), Z = H[Q];
			} else if ("left" === c) {
				e = [], C = s.length;
				for (var tt = 0; tt < C; tt++) e.push(s[tt]);
			} else if ("justify" === c && "Identity-H" === G.encoding) {
				e = [], C = s.length, h = 0 !== h ? h : V;
				for (var et = 0, rt = 0; rt < C; rt++) if (X = 0 === rt ? ir(n) : -W, K = 0 === rt ? nr(r) : et, rt < C - 1) {
					var nt = U((h - H[rt]) / (s[rt].split(" ").length - 1)), it = s[rt].split(" ");
					e.push([
						it[0] + " ",
						K,
						X
					]), et = 0;
					for (var at = 1; at < it.length; at++) {
						var ot = (J(it[at - 1] + " " + it[at]) - J(it[at])) * N + nt;
						at == it.length - 1 ? e.push([
							it[at],
							ot,
							0
						]) : e.push([
							it[at] + " ",
							ot,
							0
						]), et -= ot;
					}
				} else e.push([
					s[rt],
					K,
					X
				]);
				e.push([
					"",
					et,
					0
				]);
			} else {
				if ("justify" !== c) throw new Error("Unrecognized alignment option, use \"left\", \"center\", \"right\" or \"justify\".");
				for (e = [], C = s.length, h = 0 !== h ? h : V, rt = 0; rt < C; rt++) {
					X = 0 === rt ? ir(n) : -W, K = 0 === rt ? nr(r) : 0;
					var st = s[rt].split(" ").length - 1, ut = st > 0 ? (h - H[rt]) / st : 0;
					rt < C - 1 ? Y.push(B(U(ut))) : Y.push(0), e.push([
						s[rt],
						K,
						X
					]);
				}
			}
		}
		!0 === ("boolean" == typeof i.R2L ? i.R2L : vt) && (e = A(e, function(t, e, r) {
			return [
				t.split("").reverse().join(""),
				e,
				r
			];
		})), o = {
			text: e,
			x: r,
			y: n,
			options: i,
			mutex: {
				pdfEscape: ge,
				activeFontKey: At,
				fonts: Ft,
				activeFontSize: pt
			}
		}, Dt.publish("postProcessText", o), e = o.text, v = o.mutex.isHex || !1;
		var ct = Ft[At].encoding;
		"WinAnsiEncoding" !== ct && "StandardEncoding" !== ct || (e = A(e, function(t, e, r) {
			return [
				L(t),
				e,
				r
			];
		})), s = x(e), e = [];
		for (var ht, ft, dt, gt = Array.isArray(s[0]) ? 1 : 0, mt = "", bt = function(t, e, r) {
			var n = "";
			return r instanceof Wt ? (r = "number" == typeof i.angle ? Vt(r, new Wt(1, 0, 0, 1, t, e)) : Vt(new Wt(1, 0, 0, 1, t, e), r), _ === S && (r = Vt(new Wt(1, 0, 0, -1, 0, 0), r)), n = r.join(" ") + " Tm\n") : n = B(t) + " " + B(e) + " Td\n", n;
		}, yt = 0; yt < s.length; yt++) {
			switch (mt = "", gt) {
				case 1:
					dt = (v ? "<" : "(") + s[yt][0] + (v ? ">" : ")"), ht = parseFloat(s[yt][1]), ft = parseFloat(s[yt][2]);
					break;
				case 0: dt = (v ? "<" : "(") + s[yt] + (v ? ">" : ")"), ht = nr(r), ft = ir(n);
			}
			void 0 !== Y && void 0 !== Y[yt] && (mt = Y[yt] + " Tw\n"), 0 === yt ? e.push(mt + bt(ht, ft, p) + dt) : 0 === gt ? e.push(mt + dt) : 1 === gt && e.push(mt + bt(ht, ft, p) + dt);
		}
		e = 0 === gt ? e.join(" Tj\nT* ") : e.join(" Tj\n"), e += " Tj\n";
		var wt = "BT\n/";
		return wt += At + " " + pt + " Tf\n", wt += B(pt * w) + " TL\n", wt += cr + "\n", wt += y, wt += e, lt(wt += "ET"), b[At] = !0, g;
	};
	var Ee = y.__private__.clip = y.clip = function(t) {
		return lt("evenodd" === t ? "W*" : "W"), this;
	};
	y.clipEvenOdd = function() {
		return Ee("evenodd");
	}, y.__private__.discardPath = y.discardPath = function() {
		return lt("n"), this;
	};
	var Re = y.__private__.isValidStyle = function(t) {
		var e = !1;
		return -1 !== [
			void 0,
			null,
			"S",
			"D",
			"F",
			"DF",
			"FD",
			"f",
			"f*",
			"B",
			"B*",
			"n"
		].indexOf(t) && (e = !0), e;
	};
	y.__private__.setDefaultPathOperation = y.setDefaultPathOperation = function(t) {
		return Re(t) && (g = t), this;
	};
	var De = y.__private__.getStyle = y.getStyle = function(t) {
		var e = g;
		switch (t) {
			case "D":
			case "S":
				e = "S";
				break;
			case "F":
				e = "f";
				break;
			case "FD":
			case "DF":
				e = "B";
				break;
			case "f":
			case "f*":
			case "B":
			case "B*": e = t;
		}
		return e;
	}, Te = y.close = function() {
		return lt("h"), this;
	};
	y.stroke = function() {
		return lt("S"), this;
	}, y.fill = function(t) {
		return ze("f", t), this;
	}, y.fillEvenOdd = function(t) {
		return ze("f*", t), this;
	}, y.fillStroke = function(t) {
		return ze("B", t), this;
	}, y.fillStrokeEvenOdd = function(t) {
		return ze("B*", t), this;
	};
	var ze = function(e, r) {
		"object" === _typeof(r) ? We(r, e) : lt(e);
	}, Ue = function(t) {
		null === t || _ === S && void 0 === t || (t = De(t), lt(t));
	};
	function He(t, e, r, n, i) {
		var a = new q(e || this.boundingBox, r || this.xStep, n || this.yStep, this.gState, i || this.matrix);
		a.stream = this.stream;
		return Yt(t + "$$" + this.cloneIndex++ + "$$", a), a;
	}
	var We = function(t, e) {
		var r = Ot[t.key], n = jt[r];
		if (n instanceof M) lt("q"), lt(Ve(e)), n.gState && y.setGState(n.gState), lt(t.matrix.toString() + " cm"), lt("/" + r + " sh"), lt("Q");
		else if (n instanceof q) {
			var i = new Wt(1, 0, 0, -1, 0, Pr());
			t.matrix && (i = i.multiply(t.matrix || Gt), r = He.call(n, t.key, t.boundingBox, t.xStep, t.yStep, i).id), lt("q"), lt("/Pattern cs"), lt("/" + r + " scn"), n.gState && y.setGState(n.gState), lt(e), lt("Q");
		}
	}, Ve = function(t) {
		switch (t) {
			case "f":
			case "F":
			case "n": return "W n";
			case "f*": return "W* n";
			case "B":
			case "S": return "W S";
			case "B*": return "W* S";
		}
	}, Ge = y.moveTo = function(t, e) {
		return lt(B(U(t)) + " " + B(H(e)) + " m"), this;
	}, Ye = y.lineTo = function(t, e) {
		return lt(B(U(t)) + " " + B(H(e)) + " l"), this;
	}, Je = y.curveTo = function(t, e, r, n, i, a) {
		return lt([
			B(U(t)),
			B(H(e)),
			B(U(r)),
			B(H(n)),
			B(U(i)),
			B(H(a)),
			"c"
		].join(" ")), this;
	};
	y.__private__.line = y.line = function(t, e, r, n, i) {
		if (isNaN(t) || isNaN(e) || isNaN(r) || isNaN(n) || !Re(i)) throw new Error("Invalid arguments passed to jsPDF.line");
		return _ === A ? this.lines([[r - t, n - e]], t, e, [1, 1], i || "S") : this.lines([[r - t, n - e]], t, e, [1, 1]).stroke();
	}, y.__private__.lines = y.lines = function(t, e, r, n, i, a) {
		var o, s, u, c, l, h, f, d, p, g, m, v;
		if ("number" == typeof t && (v = r, r = e, e = t, t = v), n = n || [1, 1], a = a || !1, isNaN(e) || isNaN(r) || !Array.isArray(t) || !Array.isArray(n) || !Re(i) || "boolean" != typeof a) throw new Error("Invalid arguments passed to jsPDF.lines");
		for (Ge(e, r), o = n[0], s = n[1], c = t.length, g = e, m = r, u = 0; u < c; u++) 2 === (l = t[u]).length ? (g = l[0] * o + g, m = l[1] * s + m, Ye(g, m)) : (h = l[0] * o + g, f = l[1] * s + m, d = l[2] * o + g, p = l[3] * s + m, g = l[4] * o + g, m = l[5] * s + m, Je(h, f, d, p, g, m));
		return a && Te(), Ue(i), this;
	}, y.path = function(t) {
		for (var e = 0; e < t.length; e++) {
			var r = t[e], n = r.c;
			switch (r.op) {
				case "m":
					Ge(n[0], n[1]);
					break;
				case "l":
					Ye(n[0], n[1]);
					break;
				case "c":
					Je.apply(this, n);
					break;
				case "h": Te();
			}
		}
		return this;
	}, y.__private__.rect = y.rect = function(t, e, r, n, i) {
		if (isNaN(t) || isNaN(e) || isNaN(r) || isNaN(n) || !Re(i)) throw new Error("Invalid arguments passed to jsPDF.rect");
		return _ === A && (n = -n), lt([
			B(U(t)),
			B(H(e)),
			B(U(r)),
			B(U(n)),
			"re"
		].join(" ")), Ue(i), this;
	}, y.__private__.triangle = y.triangle = function(t, e, r, n, i, a, o) {
		if (isNaN(t) || isNaN(e) || isNaN(r) || isNaN(n) || isNaN(i) || isNaN(a) || !Re(o)) throw new Error("Invalid arguments passed to jsPDF.triangle");
		return this.lines([
			[r - t, n - e],
			[i - r, a - n],
			[t - i, e - a]
		], t, e, [1, 1], o, !0), this;
	}, y.__private__.roundedRect = y.roundedRect = function(t, e, r, n, i, a, o) {
		if (isNaN(t) || isNaN(e) || isNaN(r) || isNaN(n) || isNaN(i) || isNaN(a) || !Re(o)) throw new Error("Invalid arguments passed to jsPDF.roundedRect");
		var s = 4 / 3 * (Math.SQRT2 - 1);
		return i = Math.min(i, .5 * r), a = Math.min(a, .5 * n), this.lines([
			[r - 2 * i, 0],
			[
				i * s,
				0,
				i,
				a - a * s,
				i,
				a
			],
			[0, n - 2 * a],
			[
				0,
				a * s,
				-i * s,
				a,
				-i,
				a
			],
			[2 * i - r, 0],
			[
				-i * s,
				0,
				-i,
				-a * s,
				-i,
				-a
			],
			[0, 2 * a - n],
			[
				0,
				-a * s,
				i * s,
				-a,
				i,
				-a
			]
		], t + i, e, [1, 1], o, !0), this;
	}, y.__private__.ellipse = y.ellipse = function(t, e, r, n, i) {
		if (isNaN(t) || isNaN(e) || isNaN(r) || isNaN(n) || !Re(i)) throw new Error("Invalid arguments passed to jsPDF.ellipse");
		var a = 4 / 3 * (Math.SQRT2 - 1) * r, o = 4 / 3 * (Math.SQRT2 - 1) * n;
		return Ge(t + r, e), Je(t + r, e - o, t + a, e - n, t, e - n), Je(t - a, e - n, t - r, e - o, t - r, e), Je(t - r, e + o, t - a, e + n, t, e + n), Je(t + a, e + n, t + r, e + o, t + r, e), Ue(i), this;
	}, y.__private__.circle = y.circle = function(t, e, r, n) {
		if (isNaN(t) || isNaN(e) || isNaN(r) || !Re(n)) throw new Error("Invalid arguments passed to jsPDF.circle");
		return this.ellipse(t, e, r, r, n);
	}, y.setFont = function(t, e, r) {
		return r && (e = F(e, r)), At = Ne(t, e, { disableWarning: !1 }), this;
	};
	var Xe = y.__private__.getFont = y.getFont = function() {
		return Ft[Ne.apply(y, arguments)];
	};
	y.__private__.getFontList = y.getFontList = function() {
		var t, e, r = {};
		for (t in It) if (It.hasOwnProperty(t)) for (e in r[t] = [], It[t]) It[t].hasOwnProperty(e) && r[t].push(e);
		return r;
	}, y.addFont = function(t, e, r, n, i) {
		var a = [
			"StandardEncoding",
			"MacRomanEncoding",
			"Identity-H",
			"WinAnsiEncoding"
		];
		return arguments[3] && -1 !== a.indexOf(arguments[3]) ? i = arguments[3] : arguments[3] && -1 == a.indexOf(arguments[3]) && (r = F(r, n)), pe.call(this, t, e, r, i = i || "Identity-H");
	};
	var Ke, Ze = e.lineWidth || .200025, $e = y.__private__.getLineWidth = y.getLineWidth = function() {
		return Ze;
	}, Qe = y.__private__.setLineWidth = y.setLineWidth = function(t) {
		return Ze = t, lt(B(U(t)) + " w"), this;
	};
	y.__private__.setLineDash = E.API.setLineDash = E.API.setLineDashPattern = function(t, e) {
		if (t = t || [], e = e || 0, isNaN(e) || !Array.isArray(t)) throw new Error("Invalid arguments passed to jsPDF.setLineDash");
		return t = t.map(function(t) {
			return B(U(t));
		}).join(" "), e = B(U(e)), lt("[" + t + "] " + e + " d"), this;
	};
	var tr = y.__private__.getLineHeight = y.getLineHeight = function() {
		return pt * Ke;
	};
	y.__private__.getLineHeight = y.getLineHeight = function() {
		return pt * Ke;
	};
	var er = y.__private__.setLineHeightFactor = y.setLineHeightFactor = function(t) {
		return "number" == typeof (t = t || 1.15) && (Ke = t), this;
	}, rr = y.__private__.getLineHeightFactor = y.getLineHeightFactor = function() {
		return Ke;
	};
	er(e.lineHeight);
	var nr = y.__private__.getHorizontalCoordinate = function(t) {
		return U(t);
	}, ir = y.__private__.getVerticalCoordinate = function(t) {
		return _ === S ? t : Rt[$].mediaBox.topRightY - Rt[$].mediaBox.bottomLeftY - U(t);
	}, ar = y.__private__.getHorizontalCoordinateString = y.getHorizontalCoordinateString = function(t) {
		return B(nr(t));
	}, or = y.__private__.getVerticalCoordinateString = y.getVerticalCoordinateString = function(t) {
		return B(ir(t));
	}, sr = e.strokeColor || "0 G";
	y.__private__.getStrokeColor = y.getDrawColor = function() {
		return ee(sr);
	}, y.__private__.setStrokeColor = y.setDrawColor = function(t, e, r, n) {
		return sr = re({
			ch1: t,
			ch2: e,
			ch3: r,
			ch4: n,
			pdfColorType: "draw",
			precision: 2
		}), lt(sr), this;
	};
	var ur = e.fillColor || "0 g";
	y.__private__.getFillColor = y.getFillColor = function() {
		return ee(ur);
	}, y.__private__.setFillColor = y.setFillColor = function(t, e, r, n) {
		return ur = re({
			ch1: t,
			ch2: e,
			ch3: r,
			ch4: n,
			pdfColorType: "fill",
			precision: 2
		}), lt(ur), this;
	};
	var cr = e.textColor || "0 g", lr = y.__private__.getTextColor = y.getTextColor = function() {
		return ee(cr);
	};
	y.__private__.setTextColor = y.setTextColor = function(t, e, r, n) {
		return cr = re({
			ch1: t,
			ch2: e,
			ch3: r,
			ch4: n,
			pdfColorType: "text",
			precision: 3
		}), this;
	};
	var hr = e.charSpace, fr = y.__private__.getCharSpace = y.getCharSpace = function() {
		return parseFloat(hr || 0);
	};
	y.__private__.setCharSpace = y.setCharSpace = function(t) {
		if (isNaN(t)) throw new Error("Invalid argument passed to jsPDF.setCharSpace");
		return hr = t, this;
	};
	var dr = 0;
	y.CapJoinStyles = {
		0: 0,
		butt: 0,
		but: 0,
		miter: 0,
		1: 1,
		round: 1,
		rounded: 1,
		circle: 1,
		2: 2,
		projecting: 2,
		project: 2,
		square: 2,
		bevel: 2
	}, y.__private__.setLineCap = y.setLineCap = function(t) {
		var e = y.CapJoinStyles[t];
		if (void 0 === e) throw new Error("Line cap style of '" + t + "' is not recognized. See or extend .CapJoinStyles property for valid styles");
		return dr = e, lt(e + " J"), this;
	};
	var pr = 0;
	y.__private__.setLineJoin = y.setLineJoin = function(t) {
		var e = y.CapJoinStyles[t];
		if (void 0 === e) throw new Error("Line join style of '" + t + "' is not recognized. See or extend .CapJoinStyles property for valid styles");
		return pr = e, lt(e + " j"), this;
	}, y.__private__.setLineMiterLimit = y.__private__.setMiterLimit = y.setLineMiterLimit = y.setMiterLimit = function(t) {
		if (t = t || 0, isNaN(t)) throw new Error("Invalid argument passed to jsPDF.setLineMiterLimit");
		return lt(B(U(t)) + " M"), this;
	}, y.GState = O, y.setGState = function(t) {
		(t = "string" == typeof t ? Bt[Mt[t]] : gr(null, t)).equals(qt) || (lt("/" + t.id + " gs"), qt = t);
	};
	var gr = function(t, e) {
		if (!t || !Mt[t]) {
			var r = !1;
			for (var n in Bt) if (Bt.hasOwnProperty(n) && Bt[n].equals(e)) {
				r = !0;
				break;
			}
			if (r) e = Bt[n];
			else {
				var i = "GS" + (Object.keys(Bt).length + 1).toString(10);
				Bt[i] = e, e.id = i;
			}
			return t && (Mt[t] = e.id), Dt.publish("addGState", e), e;
		}
	};
	y.addGState = function(t, e) {
		return gr(t, e), this;
	}, y.saveGraphicsState = function() {
		return lt("q"), Ct.push({
			key: At,
			size: pt,
			color: cr
		}), this;
	}, y.restoreGraphicsState = function() {
		lt("Q");
		var t = Ct.pop();
		return At = t.key, pt = t.size, cr = t.color, qt = null, this;
	}, y.setCurrentTransformationMatrix = function(t) {
		return lt(t.toString() + " cm"), this;
	}, y.comment = function(t) {
		return lt("#" + t), this;
	};
	var mr = function(t, e) {
		var r = t || 0;
		Object.defineProperty(this, "x", {
			enumerable: !0,
			get: function() {
				return r;
			},
			set: function(t) {
				isNaN(t) || (r = parseFloat(t));
			}
		});
		var n = e || 0;
		Object.defineProperty(this, "y", {
			enumerable: !0,
			get: function() {
				return n;
			},
			set: function(t) {
				isNaN(t) || (n = parseFloat(t));
			}
		});
		var i = "pt";
		return Object.defineProperty(this, "type", {
			enumerable: !0,
			get: function() {
				return i;
			},
			set: function(t) {
				i = t.toString();
			}
		}), this;
	}, vr = function(t, e, r, n) {
		mr.call(this, t, e), this.type = "rect";
		var i = r || 0;
		Object.defineProperty(this, "w", {
			enumerable: !0,
			get: function() {
				return i;
			},
			set: function(t) {
				isNaN(t) || (i = parseFloat(t));
			}
		});
		var a = n || 0;
		return Object.defineProperty(this, "h", {
			enumerable: !0,
			get: function() {
				return a;
			},
			set: function(t) {
				isNaN(t) || (a = parseFloat(t));
			}
		}), this;
	}, br = function() {
		this.page = Et, this.currentPage = $, this.pages = ot.slice(0), this.pagesContext = Rt.slice(0), this.x = _t, this.y = Pt, this.matrix = kt, this.width = Nr($), this.height = xr($), this.outputDestination = ut, this.id = "", this.objectNumber = -1;
	};
	br.prototype.restore = function() {
		Et = this.page, $ = this.currentPage, Rt = this.pagesContext, ot = this.pages, _t = this.x, Pt = this.y, kt = this.matrix, Lr($, this.width), Ar($, this.height), ut = this.outputDestination;
	};
	var yr = function(t, e, r, n, i) {
		Ht.push(new br()), Et = $ = 0, ot = [], _t = t, Pt = e, kt = i, me([r, n]);
	};
	for (var wr in y.beginFormObject = function(t, e, r, n, i) {
		return yr(t, e, r, n, i), this;
	}, y.endFormObject = function(t) {
		return function(t) {
			if (Ut[t]) Ht.pop().restore();
			else {
				var e = new br(), r = "Xo" + (Object.keys(zt).length + 1).toString(10);
				e.id = r, Ut[t] = r, zt[r] = e, Dt.publish("addFormObject", e), Ht.pop().restore();
			}
		}(t), this;
	}, y.doFormObject = function(t, e) {
		var r = zt[Ut[t]];
		return lt("q"), lt(e.toString() + " cm"), lt("/" + r.id + " Do"), lt("Q"), this;
	}, y.getFormObject = function(t) {
		var e = zt[Ut[t]];
		return {
			x: e.x,
			y: e.y,
			width: e.width,
			height: e.height,
			matrix: e.matrix
		};
	}, y.save = function(t, e) {
		return t = t || "generated.pdf", (e = e || {}).returnPromise = e.returnPromise || !1, !1 === e.returnPromise ? (l(ke(Pe()), t), "function" == typeof l.unload && i.setTimeout && setTimeout(l.unload, 911), this) : new Promise(function(e, r) {
			try {
				var n = l(ke(Pe()), t);
				"function" == typeof l.unload && i.setTimeout && setTimeout(l.unload, 911), e(n);
			} catch (a) {
				r(a.message);
			}
		});
	}, E.API) E.API.hasOwnProperty(wr) && ("events" === wr && E.API.events.length ? function(t, e) {
		var r, n, i;
		for (i = e.length - 1; -1 !== i; i--) r = e[i][0], n = e[i][1], t.subscribe.apply(t, [r].concat("function" == typeof n ? [n] : n));
	}(Dt, E.API.events) : y[wr] = E.API[wr]);
	function Nr(t) {
		return Rt[t].mediaBox.topRightX - Rt[t].mediaBox.bottomLeftX;
	}
	function Lr(t, e) {
		Rt[t].mediaBox.topRightX = e + Rt[t].mediaBox.bottomLeftX;
	}
	function xr(t) {
		return Rt[t].mediaBox.topRightY - Rt[t].mediaBox.bottomLeftY;
	}
	function Ar(t, e) {
		Rt[t].mediaBox.topRightY = e + Rt[t].mediaBox.bottomLeftY;
	}
	var Sr = y.getPageWidth = function(t) {
		return Nr(t = t || $) / St;
	}, _r = y.setPageWidth = function(t, e) {
		Lr(t, e * St);
	}, Pr = y.getPageHeight = function(t) {
		return xr(t = t || $) / St;
	}, kr = y.setPageHeight = function(t, e) {
		Ar(t, e * St);
	};
	return y.internal = {
		pdfEscape: ge,
		getStyle: De,
		getFont: Xe,
		getFontSize: mt,
		getCharSpace: fr,
		getTextColor: lr,
		getLineHeight: tr,
		getLineHeightFactor: rr,
		getLineWidth: $e,
		write: ht,
		getHorizontalCoordinate: nr,
		getVerticalCoordinate: ir,
		getCoordinateString: ar,
		getVerticalCoordinateString: or,
		collections: {},
		newObject: Xt,
		newAdditionalObject: $t,
		newObjectDeferred: Kt,
		newObjectDeferredBegin: Zt,
		getFilters: ne,
		putStream: ie,
		events: Dt,
		scaleFactor: St,
		pageSize: {
			getWidth: function() {
				return Sr($);
			},
			setWidth: function(t) {
				_r($, t);
			},
			getHeight: function() {
				return Pr($);
			},
			setHeight: function(t) {
				kr($, t);
			}
		},
		encryptionOptions: m,
		encryption: Oe,
		getEncryptor: function(t) {
			return null !== m ? Oe.encryptor(t, 0) : function(t) {
				return t;
			};
		},
		output: Ce,
		getNumberOfPages: we,
		get pages() {
			return ot;
		},
		out: lt,
		f2: T,
		f3: z,
		getPageInfo: Be,
		getPageInfoByObjId: Me,
		getCurrentPageInfo: qe,
		getPDFVersion: N,
		Point: mr,
		Rectangle: vr,
		Matrix: Wt,
		hasHotfix: je
	}, Object.defineProperty(y.internal.pageSize, "width", {
		get: function() {
			return Sr($);
		},
		set: function(t) {
			_r($, t);
		},
		enumerable: !0,
		configurable: !0
	}), Object.defineProperty(y.internal.pageSize, "height", {
		get: function() {
			return Pr($);
		},
		set: function(t) {
			kr($, t);
		},
		enumerable: !0,
		configurable: !0
	}), function(t) {
		for (var e = 0, r = dt.length; e < r; e++) {
			var n = pe.call(this, t[e][0], t[e][1], t[e][2], dt[e][3], !0);
			!1 === v && (b[n] = !0);
			var i = t[e][0].split("-");
			de({
				id: n,
				fontName: i[0],
				fontStyle: i[1] || ""
			});
		}
		Dt.publish("addFonts", {
			fonts: Ft,
			dictionary: It
		});
	}.call(y, dt), At = "F1", ve(s, n), Dt.publish("initialized"), y;
}
I.prototype.lsbFirstWord = function(t) {
	return String.fromCharCode(255 & t, t >> 8 & 255, t >> 16 & 255, t >> 24 & 255);
}, I.prototype.toHexString = function(t) {
	return t.split("").map(function(t) {
		return ("0" + (255 & t.charCodeAt(0)).toString(16)).slice(-2);
	}).join("");
}, I.prototype.hexToBytes = function(t) {
	for (var e = [], r = 0; r < t.length; r += 2) e.push(String.fromCharCode(parseInt(t.substr(r, 2), 16)));
	return e.join("");
}, I.prototype.processOwnerPassword = function(t, e) {
	return k(S(e).substr(0, 5), t);
}, I.prototype.encryptor = function(t, e) {
	var r = S(this.encryptionKey + String.fromCharCode(255 & t, t >> 8 & 255, t >> 16 & 255, 255 & e, e >> 8 & 255)).substr(0, 10);
	return function(t) {
		return k(r, t);
	};
}, O.prototype.equals = function(e) {
	var r, n = "id,objectNumber,equals";
	if (!e || _typeof(e) !== _typeof(this)) return !1;
	var i = 0;
	for (r in this) if (!(n.indexOf(r) >= 0)) {
		if (this.hasOwnProperty(r) && !e.hasOwnProperty(r)) return !1;
		if (this[r] !== e[r]) return !1;
		i++;
	}
	for (r in e) e.hasOwnProperty(r) && n.indexOf(r) < 0 && i--;
	return 0 === i;
}, E.API = { events: [] }, E.version = "4.2.1";
var R = E.API;
var D = 1;
var T = function(t) {
	return t.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
};
var z = function(t) {
	return t.replace(/\\\\/g, "\\").replace(/\\\(/g, "(").replace(/\\\)/g, ")");
};
var U = function(t) {
	return t.toString().replace(/#/g, "#23").replace(/[\s\n\r()<>[\]{}\/%]/g, function(t) {
		var e = t.charCodeAt(0).toString(16).toUpperCase();
		return "#" + (1 === e.length ? "0" + e : e);
	});
};
var H = function(t) {
	return t.toFixed(2);
};
var W = function(t) {
	return t.toFixed(5);
};
R.__acroform__ = {};
var V = function(t, e) {
	t.prototype = Object.create(e.prototype), t.prototype.constructor = t;
};
var G = function(t) {
	return t * D;
};
var Y = function(t) {
	var e = new lt(), r = At.internal.getHeight(t) || 0, n = At.internal.getWidth(t) || 0;
	return e.BBox = [
		0,
		0,
		Number(H(n)),
		Number(H(r))
	], e;
};
var J = R.__acroform__.setBit = function(t, e) {
	if (t = t || 0, e = e || 0, isNaN(t) || isNaN(e)) throw new Error("Invalid arguments passed to jsPDF.API.__acroform__.setBit");
	return t | 1 << e;
};
var X = R.__acroform__.clearBit = function(t, e) {
	if (t = t || 0, e = e || 0, isNaN(t) || isNaN(e)) throw new Error("Invalid arguments passed to jsPDF.API.__acroform__.clearBit");
	return t & ~(1 << e);
};
var K = R.__acroform__.getBit = function(t, e) {
	if (isNaN(t) || isNaN(e)) throw new Error("Invalid arguments passed to jsPDF.API.__acroform__.getBit");
	return t & 1 << e ? 1 : 0;
};
var Z = R.__acroform__.getBitForPdf = function(t, e) {
	if (isNaN(t) || isNaN(e)) throw new Error("Invalid arguments passed to jsPDF.API.__acroform__.getBitForPdf");
	return K(t, e - 1);
};
var $ = R.__acroform__.setBitForPdf = function(t, e) {
	if (isNaN(t) || isNaN(e)) throw new Error("Invalid arguments passed to jsPDF.API.__acroform__.setBitForPdf");
	return J(t, e - 1);
};
var Q = R.__acroform__.clearBitForPdf = function(t, e) {
	if (isNaN(t) || isNaN(e)) throw new Error("Invalid arguments passed to jsPDF.API.__acroform__.clearBitForPdf");
	return X(t, e - 1);
};
var tt = R.__acroform__.calculateCoordinates = function(t, e) {
	var r = e.internal.getHorizontalCoordinate, n = e.internal.getVerticalCoordinate, i = t[0], a = t[1], o = t[2], s = t[3], u = {};
	return u.lowerLeft_X = r(i) || 0, u.lowerLeft_Y = n(a + s) || 0, u.upperRight_X = r(i + o) || 0, u.upperRight_Y = n(a) || 0, [
		Number(H(u.lowerLeft_X)),
		Number(H(u.lowerLeft_Y)),
		Number(H(u.upperRight_X)),
		Number(H(u.upperRight_Y))
	];
};
var et = function(t) {
	if (t.appearanceStreamContent) return t.appearanceStreamContent;
	if (t.V || t.DV) {
		var e = [], n = rt(t, t._V || t.DV), i = t.scope.internal.getFont(t.fontName, t.fontStyle).id;
		e.push("/Tx BMC"), e.push("q"), e.push("BT"), e.push(t.scope.__private__.encodeColorString(t.color)), e.push("/" + i + " " + H(n.fontSize) + " Tf"), e.push("1 0 0 1 0 0 Tm"), e.push(n.text), e.push("ET"), e.push("Q"), e.push("EMC");
		var a = Y(t);
		return a.scope = t.scope, a.stream = e.join("\n"), a;
	}
};
var rt = function(t, e) {
	var r = 0 === t.fontSize ? t.maxFontSize : t.fontSize, n = {
		text: "",
		fontSize: ""
	}, i = (e = ")" == (e = "(" == e.substr(0, 1) ? e.substr(1) : e).substr(e.length - 1) ? e.substr(0, e.length - 1) : e).split(" ");
	i = t.multiline ? i.map(function(t) {
		return t.split("\n");
	}) : i.map(function(t) {
		return [t];
	});
	var a = r, o = At.internal.getHeight(t) || 0;
	o = o < 0 ? -o : o;
	var s = At.internal.getWidth(t) || 0;
	s = s < 0 ? -s : s;
	var u = function(e, r, n) {
		if (e + 1 < i.length) return nt(r + " " + i[e + 1][0], t, n).width <= s - 4;
		return !1;
	};
	a++;
	t: for (; a > 0;) {
		e = "", a--;
		var c, l, h = nt("3", t, a).height, f = t.multiline ? o - a : (o - h) / 2, d = f += 2, p = 0, g = 0, m = 0;
		if (a <= 0) {
			e = "(...) Tj\n", e += "% Width of Text: " + nt(e, t, a = 12).width + ", FieldWidth:" + s + "\n";
			break;
		}
		for (var v = "", b = 0, y = 0; y < i.length; y++) if (i.hasOwnProperty(y)) {
			var w = !1;
			if (1 !== i[y].length && m !== i[y].length - 1) {
				if ((h + 2) * (b + 2) + 2 > o) continue t;
				v += i[y][m], w = !0, g = y, y--;
			} else {
				v = " " == (v += i[y][m] + " ").substr(v.length - 1) ? v.substr(0, v.length - 1) : v;
				var N = parseInt(y), L = u(N, v, a), x = y >= i.length - 1;
				if (L && !x) {
					v += " ", m = 0;
					continue;
				}
				if (L || x) {
					if (x) g = N;
					else if (t.multiline && (h + 2) * (b + 2) + 2 > o) continue t;
				} else {
					if (!t.multiline) continue t;
					if ((h + 2) * (b + 2) + 2 > o) continue t;
					g = N;
				}
			}
			for (var A = "", S = p; S <= g; S++) {
				var _ = i[S];
				if (t.multiline) {
					if (S === g) {
						A += _[m] + " ", m = (m + 1) % _.length;
						continue;
					}
					if (S === p) {
						A += _[_.length - 1] + " ";
						continue;
					}
				}
				A += _[0] + " ";
			}
			switch (A = " " == A.substr(A.length - 1) ? A.substr(0, A.length - 1) : A, l = nt(A, t, a).width, t.textAlign) {
				case "right":
					c = s - l - 2;
					break;
				case "center":
					c = (s - l) / 2;
					break;
				default: c = 2;
			}
			e += H(c) + " " + H(d) + " Td\n", e += "(" + T(A) + ") Tj\n", e += -H(c) + " 0 Td\n", d = -(a + 2), l = 0, p = w ? g : g + 1, b++, v = "";
		}
		break;
	}
	return n.text = e, n.fontSize = a, n;
};
var nt = function(t, e, r) {
	var n = e.scope.internal.getFont(e.fontName, e.fontStyle), i = e.scope.getStringUnitWidth(t, {
		font: n,
		fontSize: parseFloat(r),
		charSpace: 0
	}) * parseFloat(r);
	return {
		height: e.scope.getStringUnitWidth("3", {
			font: n,
			fontSize: parseFloat(r),
			charSpace: 0
		}) * parseFloat(r) * 1.5,
		width: i
	};
};
var it = {
	fields: [],
	xForms: [],
	acroFormDictionaryRoot: null,
	printedOut: !1,
	internal: null,
	isInitialized: !1
};
var at = function(t, e) {
	var r = {
		type: "reference",
		object: t
	};
	void 0 === e.internal.getPageInfo(t.page).pageContext.annotations.find(function(t) {
		return t.type === r.type && t.object === r.object;
	}) && e.internal.getPageInfo(t.page).pageContext.annotations.push(r);
};
var ot = function(e, r) {
	if (r.scope = e, void 0 !== e.internal && (void 0 === e.internal.acroformPlugin || !1 === e.internal.acroformPlugin.isInitialized)) {
		if (ft.FieldNum = 0, e.internal.acroformPlugin = JSON.parse(JSON.stringify(it)), e.internal.acroformPlugin.acroFormDictionaryRoot) throw new Error("Exception while creating AcroformDictionary");
		D = e.internal.scaleFactor, e.internal.acroformPlugin.acroFormDictionaryRoot = new ht(), e.internal.acroformPlugin.acroFormDictionaryRoot.scope = e, e.internal.acroformPlugin.acroFormDictionaryRoot._eventID = e.internal.events.subscribe("postPutResources", function() {
			(function(t) {
				t.internal.events.unsubscribe(t.internal.acroformPlugin.acroFormDictionaryRoot._eventID), delete t.internal.acroformPlugin.acroFormDictionaryRoot._eventID, t.internal.acroformPlugin.printedOut = !0;
			})(e);
		}), e.internal.events.subscribe("buildDocument", function() {
			(function(t) {
				t.internal.acroformPlugin.acroFormDictionaryRoot.objId = void 0;
				var e = t.internal.acroformPlugin.acroFormDictionaryRoot.Fields;
				for (var r in e) if (e.hasOwnProperty(r)) {
					var n = e[r];
					n.objId = void 0, n.hasAnnotation && at(n, t);
				}
			})(e);
		}), e.internal.events.subscribe("putCatalog", function() {
			(function(t) {
				if (void 0 === t.internal.acroformPlugin.acroFormDictionaryRoot) throw new Error("putCatalogCallback: Root missing.");
				t.internal.write("/AcroForm " + t.internal.acroformPlugin.acroFormDictionaryRoot.objId + " 0 R");
			})(e);
		}), e.internal.events.subscribe("postPutPages", function(r) {
			(function(e, r) {
				var n = !e;
				for (var i in e || (r.internal.newObjectDeferredBegin(r.internal.acroformPlugin.acroFormDictionaryRoot.objId, !0), r.internal.acroformPlugin.acroFormDictionaryRoot.putStream()), e = e || r.internal.acroformPlugin.acroFormDictionaryRoot.Kids) if (e.hasOwnProperty(i)) {
					var a = e[i], o = [], s = a.Rect;
					if (a.Rect && (a.Rect = tt(a.Rect, r)), r.internal.newObjectDeferredBegin(a.objId, !0), a.DA = At.createDefaultAppearanceStream(a), "object" === _typeof(a) && "function" == typeof a.getKeyValueListForStream && (o = a.getKeyValueListForStream()), a.Rect = s, a.hasAppearanceStream && !a.appearanceStreamContent) {
						var u = et(a);
						o.push({
							key: "AP",
							value: "<</N " + u + ">>"
						}), r.internal.acroformPlugin.xForms.push(u);
					}
					if (a.appearanceStreamContent) {
						var c = "";
						for (var l in a.appearanceStreamContent) if (a.appearanceStreamContent.hasOwnProperty(l)) {
							var h = a.appearanceStreamContent[l];
							if (c += "/" + l + " ", c += "<<", Object.keys(h).length >= 1 || Array.isArray(h)) {
								for (var i in h) if (h.hasOwnProperty(i)) {
									var f = h[i];
									"function" == typeof f && (f = f.call(r, a)), c += "/" + i + " " + f + " ", r.internal.acroformPlugin.xForms.indexOf(f) >= 0 || r.internal.acroformPlugin.xForms.push(f);
								}
							} else "function" == typeof (f = h) && (f = f.call(r, a)), c += "/" + i + " " + f, r.internal.acroformPlugin.xForms.indexOf(f) >= 0 || r.internal.acroformPlugin.xForms.push(f);
							c += ">>";
						}
						o.push({
							key: "AP",
							value: "<<\n" + c + ">>"
						});
					}
					r.internal.putStream({
						additionalKeyValues: o,
						objectId: a.objId
					}), r.internal.out("endobj");
				}
				n && function(e, r) {
					for (var n in e) if (e.hasOwnProperty(n)) {
						var i = n, a = e[n];
						r.internal.newObjectDeferredBegin(a.objId, !0), "object" === _typeof(a) && "function" == typeof a.putStream && a.putStream(), delete e[i];
					}
				}(r.internal.acroformPlugin.xForms, r);
			})(r, e);
		}), e.internal.acroformPlugin.isInitialized = !0;
	}
};
var st = R.__acroform__.arrayToPdfArray = function(e, r, n) {
	var i = function(t) {
		return t;
	};
	if (Array.isArray(e)) {
		for (var a = "[", o = 0; o < e.length; o++) switch (0 !== o && (a += " "), _typeof(e[o])) {
			case "boolean":
			case "number":
			case "object":
				a += e[o].toString();
				break;
			case "string": "/" === e[o].substr(0, 1) ? a += "/" + U(e[o].substr(1)) : (void 0 !== r && n && (i = n.internal.getEncryptor(r)), a += "(" + T(i(e[o].toString())) + ")");
		}
		return a + "]";
	}
	throw new Error("Invalid argument passed to jsPDF.__acroform__.arrayToPdfArray");
};
var ut = function(t, e, r) {
	var n = function(t) {
		return t;
	};
	return void 0 !== e && r && (n = r.internal.getEncryptor(e)), (t = t || "").toString(), "(" + T(n(t)) + ")";
};
var ct = function() {
	this._objId = void 0, this._scope = void 0, Object.defineProperty(this, "objId", {
		get: function() {
			if (void 0 === this._objId) {
				if (void 0 === this.scope) return;
				this._objId = this.scope.internal.newObjectDeferred();
			}
			return this._objId;
		},
		set: function(t) {
			this._objId = t;
		}
	}), Object.defineProperty(this, "scope", {
		value: this._scope,
		writable: !0
	});
};
ct.prototype.toString = function() {
	return this.objId + " 0 R";
}, ct.prototype.putStream = function() {
	var t = this.getKeyValueListForStream();
	this.scope.internal.putStream({
		data: this.stream,
		additionalKeyValues: t,
		objectId: this.objId
	}), this.scope.internal.out("endobj");
}, ct.prototype.getKeyValueListForStream = function() {
	var t = [], e = Object.getOwnPropertyNames(this).filter(function(t) {
		return "content" != t && "appearanceStreamContent" != t && "scope" != t && "objId" != t && "_" != t.substring(0, 1);
	});
	for (var r in e) if (!1 === Object.getOwnPropertyDescriptor(this, e[r]).configurable) {
		var n = e[r], i = this[n];
		i && (Array.isArray(i) ? t.push({
			key: n,
			value: st(i, this.objId, this.scope)
		}) : i instanceof ct ? (i.scope = this.scope, t.push({
			key: n,
			value: i.objId + " 0 R"
		})) : "function" != typeof i && t.push({
			key: n,
			value: i
		}));
	}
	return t;
};
var lt = function() {
	ct.call(this), Object.defineProperty(this, "Type", {
		value: "/XObject",
		configurable: !1,
		writable: !0
	}), Object.defineProperty(this, "Subtype", {
		value: "/Form",
		configurable: !1,
		writable: !0
	}), Object.defineProperty(this, "FormType", {
		value: 1,
		configurable: !1,
		writable: !0
	});
	var t, e = [];
	Object.defineProperty(this, "BBox", {
		configurable: !1,
		get: function() {
			return e;
		},
		set: function(t) {
			e = t;
		}
	}), Object.defineProperty(this, "Resources", {
		value: "2 0 R",
		configurable: !1,
		writable: !0
	}), Object.defineProperty(this, "stream", {
		enumerable: !1,
		configurable: !0,
		set: function(e) {
			t = e.trim();
		},
		get: function() {
			return t || null;
		}
	});
};
V(lt, ct);
var ht = function() {
	ct.call(this);
	var t, e = [];
	Object.defineProperty(this, "Kids", {
		enumerable: !1,
		configurable: !0,
		get: function() {
			return e.length > 0 ? e : void 0;
		}
	}), Object.defineProperty(this, "Fields", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			return e;
		}
	}), Object.defineProperty(this, "DA", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			if (t) {
				var e = function(t) {
					return t;
				};
				return this.scope && (e = this.scope.internal.getEncryptor(this.objId)), "(" + T(e(t)) + ")";
			}
		},
		set: function(e) {
			t = e;
		}
	});
};
V(ht, ct);
var ft = function t() {
	ct.call(this);
	var e = 4;
	Object.defineProperty(this, "F", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			return e;
		},
		set: function(t) {
			if (isNaN(t)) throw new Error("Invalid value \"" + t + "\" for attribute F supplied.");
			e = t;
		}
	}), Object.defineProperty(this, "showWhenPrinted", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(e, 3));
		},
		set: function(t) {
			!0 === Boolean(t) ? this.F = $(e, 3) : this.F = Q(e, 3);
		}
	});
	var r = 0;
	Object.defineProperty(this, "Ff", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			return r;
		},
		set: function(t) {
			if (isNaN(t)) throw new Error("Invalid value \"" + t + "\" for attribute Ff supplied.");
			r = t;
		}
	});
	var n = [];
	Object.defineProperty(this, "Rect", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			if (0 !== n.length) return n;
		},
		set: function(t) {
			n = void 0 !== t ? t : [];
		}
	}), Object.defineProperty(this, "x", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !n || isNaN(n[0]) ? 0 : n[0];
		},
		set: function(t) {
			n[0] = t;
		}
	}), Object.defineProperty(this, "y", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !n || isNaN(n[1]) ? 0 : n[1];
		},
		set: function(t) {
			n[1] = t;
		}
	}), Object.defineProperty(this, "width", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !n || isNaN(n[2]) ? 0 : n[2];
		},
		set: function(t) {
			n[2] = t;
		}
	}), Object.defineProperty(this, "height", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return !n || isNaN(n[3]) ? 0 : n[3];
		},
		set: function(t) {
			n[3] = t;
		}
	});
	var i = "";
	Object.defineProperty(this, "FT", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			return i;
		},
		set: function(t) {
			switch (t) {
				case "/Btn":
				case "/Tx":
				case "/Ch":
				case "/Sig":
					i = t;
					break;
				default: throw new Error("Invalid value \"" + t + "\" for attribute FT supplied.");
			}
		}
	});
	var a = null;
	Object.defineProperty(this, "T", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			if (!a || a.length < 1) {
				if (this instanceof wt) return;
				a = "FieldObject" + t.FieldNum++;
			}
			var e = function(t) {
				return t;
			};
			return this.scope && (e = this.scope.internal.getEncryptor(this.objId)), "(" + T(e(a)) + ")";
		},
		set: function(t) {
			a = t.toString();
		}
	}), Object.defineProperty(this, "fieldName", {
		configurable: !0,
		enumerable: !0,
		get: function() {
			return a;
		},
		set: function(t) {
			a = t;
		}
	});
	var o = "helvetica";
	Object.defineProperty(this, "fontName", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return o;
		},
		set: function(t) {
			o = t;
		}
	});
	var s = "normal";
	Object.defineProperty(this, "fontStyle", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return s;
		},
		set: function(t) {
			s = t;
		}
	});
	var u = 0;
	Object.defineProperty(this, "fontSize", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return u;
		},
		set: function(t) {
			u = t;
		}
	});
	var c = void 0;
	Object.defineProperty(this, "maxFontSize", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return void 0 === c ? 50 / D : c;
		},
		set: function(t) {
			c = t;
		}
	});
	var l = "black";
	Object.defineProperty(this, "color", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return l;
		},
		set: function(t) {
			l = t;
		}
	});
	var h = "/F1 0 Tf 0 g";
	Object.defineProperty(this, "DA", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			if (!(!h || this instanceof wt || this instanceof Lt)) return ut(h, this.objId, this.scope);
		},
		set: function(t) {
			t = t.toString(), h = t;
		}
	});
	var f = null;
	Object.defineProperty(this, "DV", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			if (f) return this instanceof vt == 0 ? ut(f, this.objId, this.scope) : f;
		},
		set: function(t) {
			t = t.toString(), f = this instanceof vt == 0 ? "(" === t.substr(0, 1) ? z(t.substr(1, t.length - 2)) : z(t) : t;
		}
	}), Object.defineProperty(this, "defaultValue", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return this instanceof vt == 1 ? z(f.substr(1, f.length - 1)) : f;
		},
		set: function(t) {
			t = t.toString(), f = this instanceof vt == 1 ? "/" + U(t) : t;
		}
	});
	var d = null;
	Object.defineProperty(this, "_V", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			if (d) return d;
		},
		set: function(t) {
			this.V = t;
		}
	}), Object.defineProperty(this, "V", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			if (d) return this instanceof vt == 0 ? ut(d, this.objId, this.scope) : d;
		},
		set: function(t) {
			t = t.toString(), d = this instanceof vt == 0 ? "(" === t.substr(0, 1) ? z(t.substr(1, t.length - 2)) : z(t) : t;
		}
	}), Object.defineProperty(this, "value", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return this instanceof vt == 1 ? z(d.substr(1, d.length - 1)) : d;
		},
		set: function(t) {
			t = t.toString(), d = this instanceof vt == 1 ? "/" + U(t) : t;
		}
	}), Object.defineProperty(this, "hasAnnotation", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return this.Rect;
		}
	}), Object.defineProperty(this, "Type", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			return this.hasAnnotation ? "/Annot" : null;
		}
	}), Object.defineProperty(this, "Subtype", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			return this.hasAnnotation ? "/Widget" : null;
		}
	});
	var p, g = !1;
	Object.defineProperty(this, "hasAppearanceStream", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return g;
		},
		set: function(t) {
			t = Boolean(t), g = t;
		}
	}), Object.defineProperty(this, "page", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			if (p) return p;
		},
		set: function(t) {
			p = t;
		}
	}), Object.defineProperty(this, "readOnly", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 1));
		},
		set: function(t) {
			!0 === Boolean(t) ? this.Ff = $(this.Ff, 1) : this.Ff = Q(this.Ff, 1);
		}
	}), Object.defineProperty(this, "required", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 2));
		},
		set: function(t) {
			!0 === Boolean(t) ? this.Ff = $(this.Ff, 2) : this.Ff = Q(this.Ff, 2);
		}
	}), Object.defineProperty(this, "noExport", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 3));
		},
		set: function(t) {
			!0 === Boolean(t) ? this.Ff = $(this.Ff, 3) : this.Ff = Q(this.Ff, 3);
		}
	});
	var m = null;
	Object.defineProperty(this, "Q", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			if (null !== m) return m;
		},
		set: function(t) {
			if (-1 === [
				0,
				1,
				2
			].indexOf(t)) throw new Error("Invalid value \"" + t + "\" for attribute Q supplied.");
			m = t;
		}
	}), Object.defineProperty(this, "textAlign", {
		get: function() {
			var t;
			switch (m) {
				case 0:
				default:
					t = "left";
					break;
				case 1:
					t = "center";
					break;
				case 2: t = "right";
			}
			return t;
		},
		configurable: !0,
		enumerable: !0,
		set: function(t) {
			switch (t) {
				case "right":
				case 2:
					m = 2;
					break;
				case "center":
				case 1:
					m = 1;
					break;
				default: m = 0;
			}
		}
	});
};
V(ft, ct);
var dt = function() {
	ft.call(this), this.FT = "/Ch", this.V = "()", this.fontName = "zapfdingbats";
	var t = 0;
	Object.defineProperty(this, "TI", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			return t;
		},
		set: function(e) {
			t = e;
		}
	}), Object.defineProperty(this, "topIndex", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return t;
		},
		set: function(e) {
			t = e;
		}
	});
	var e = [];
	Object.defineProperty(this, "Opt", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			return st(e, this.objId, this.scope);
		},
		set: function(t) {
			var r, n = [];
			"string" == typeof (r = t) && (n = function(t, e, r) {
				r || (r = 1);
				for (var n, i = []; n = e.exec(t);) i.push(n[r]);
				return i;
			}(r, /\((.*?)\)/g)), e = n;
		}
	}), this.getOptions = function() {
		return e;
	}, this.setOptions = function(t) {
		e = t, this.sort && e.sort();
	}, this.addOption = function(t) {
		t = (t = t || "").toString(), e.push(t), this.sort && e.sort();
	}, this.removeOption = function(t, r) {
		for (r = r || !1, t = (t = t || "").toString(); -1 !== e.indexOf(t) && (e.splice(e.indexOf(t), 1), !1 !== r););
	}, Object.defineProperty(this, "combo", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 18));
		},
		set: function(t) {
			!0 === Boolean(t) ? this.Ff = $(this.Ff, 18) : this.Ff = Q(this.Ff, 18);
		}
	}), Object.defineProperty(this, "edit", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 19));
		},
		set: function(t) {
			!0 === this.combo && (!0 === Boolean(t) ? this.Ff = $(this.Ff, 19) : this.Ff = Q(this.Ff, 19));
		}
	}), Object.defineProperty(this, "sort", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 20));
		},
		set: function(t) {
			!0 === Boolean(t) ? (this.Ff = $(this.Ff, 20), e.sort()) : this.Ff = Q(this.Ff, 20);
		}
	}), Object.defineProperty(this, "multiSelect", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 22));
		},
		set: function(t) {
			!0 === Boolean(t) ? this.Ff = $(this.Ff, 22) : this.Ff = Q(this.Ff, 22);
		}
	}), Object.defineProperty(this, "doNotSpellCheck", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 23));
		},
		set: function(t) {
			!0 === Boolean(t) ? this.Ff = $(this.Ff, 23) : this.Ff = Q(this.Ff, 23);
		}
	}), Object.defineProperty(this, "commitOnSelChange", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 27));
		},
		set: function(t) {
			!0 === Boolean(t) ? this.Ff = $(this.Ff, 27) : this.Ff = Q(this.Ff, 27);
		}
	}), this.hasAppearanceStream = !1;
};
V(dt, ft);
var pt = function() {
	dt.call(this), this.fontName = "helvetica", this.combo = !1;
};
V(pt, dt);
var gt = function() {
	pt.call(this), this.combo = !0;
};
V(gt, pt);
var mt = function() {
	gt.call(this), this.edit = !0;
};
V(mt, gt);
var vt = function() {
	ft.call(this), this.FT = "/Btn", Object.defineProperty(this, "noToggleToOff", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 15));
		},
		set: function(t) {
			!0 === Boolean(t) ? this.Ff = $(this.Ff, 15) : this.Ff = Q(this.Ff, 15);
		}
	}), Object.defineProperty(this, "radio", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 16));
		},
		set: function(t) {
			!0 === Boolean(t) ? this.Ff = $(this.Ff, 16) : this.Ff = Q(this.Ff, 16);
		}
	}), Object.defineProperty(this, "pushButton", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 17));
		},
		set: function(t) {
			!0 === Boolean(t) ? this.Ff = $(this.Ff, 17) : this.Ff = Q(this.Ff, 17);
		}
	}), Object.defineProperty(this, "radioIsUnison", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 26));
		},
		set: function(t) {
			!0 === Boolean(t) ? this.Ff = $(this.Ff, 26) : this.Ff = Q(this.Ff, 26);
		}
	});
	var e, r = {};
	Object.defineProperty(this, "MK", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			var t = function(t) {
				return t;
			};
			if (this.scope && (t = this.scope.internal.getEncryptor(this.objId)), 0 !== Object.keys(r).length) {
				var e, n = [];
				for (e in n.push("<<"), r) n.push("/" + e + " (" + T(t(r[e])) + ")");
				return n.push(">>"), n.join("\n");
			}
		},
		set: function(e) {
			"object" === _typeof(e) && (r = e);
		}
	}), Object.defineProperty(this, "caption", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return r.CA || "";
		},
		set: function(t) {
			"string" == typeof t && (r.CA = t);
		}
	}), Object.defineProperty(this, "AS", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			return e;
		},
		set: function(t) {
			var r = null == t ? "" : t.toString();
			"/" === r.substr(0, 1) && (r = r.substr(1)), e = "/" + U(r);
		}
	}), Object.defineProperty(this, "appearanceState", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return e.substr(1, e.length - 1);
		},
		set: function(t) {
			e = "/" + U(t);
		}
	});
};
V(vt, ft);
var bt = function() {
	vt.call(this), this.pushButton = !0;
};
V(bt, vt);
var yt = function() {
	vt.call(this), this.radio = !0, this.pushButton = !1;
	var t = [];
	Object.defineProperty(this, "Kids", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			return t;
		},
		set: function(e) {
			t = void 0 !== e ? e : [];
		}
	});
};
V(yt, vt);
var wt = function() {
	var e, r;
	ft.call(this), Object.defineProperty(this, "Parent", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			return e;
		},
		set: function(t) {
			e = t;
		}
	}), Object.defineProperty(this, "optionName", {
		enumerable: !1,
		configurable: !0,
		get: function() {
			return r;
		},
		set: function(t) {
			r = t;
		}
	});
	var n, i = {};
	Object.defineProperty(this, "MK", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			var t = function(t) {
				return t;
			};
			this.scope && (t = this.scope.internal.getEncryptor(this.objId));
			var e, r = [];
			for (e in r.push("<<"), i) r.push("/" + e + " (" + T(t(i[e])) + ")");
			return r.push(">>"), r.join("\n");
		},
		set: function(e) {
			"object" === _typeof(e) && (i = e);
		}
	}), Object.defineProperty(this, "caption", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return i.CA || "";
		},
		set: function(t) {
			"string" == typeof t && (i.CA = t);
		}
	}), Object.defineProperty(this, "AS", {
		enumerable: !1,
		configurable: !1,
		get: function() {
			return n;
		},
		set: function(t) {
			var e = null == t ? "" : t.toString();
			"/" === e.substr(0, 1) && (e = e.substr(1)), n = "/" + U(e);
		}
	}), Object.defineProperty(this, "appearanceState", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return n.substr(1, n.length - 1);
		},
		set: function(t) {
			var e = null == t ? "" : t.toString();
			"/" === e.substr(0, 1) && (e = e.substr(1)), n = "/" + U(e);
		}
	}), this.caption = "l", this.appearanceState = "Off", this._AppearanceType = At.RadioButton.Circle, this.appearanceStreamContent = this._AppearanceType.createAppearanceStream(this.optionName);
};
V(wt, ft), yt.prototype.setAppearance = function(t) {
	if (!("createAppearanceStream" in t) || !("getCA" in t)) throw new Error("Couldn't assign Appearance to RadioButton. Appearance was Invalid!");
	for (var e in this.Kids) if (this.Kids.hasOwnProperty(e)) {
		var r = this.Kids[e];
		r.appearanceStreamContent = t.createAppearanceStream(r.optionName), r.caption = t.getCA();
	}
}, yt.prototype.createOption = function(t) {
	var e = new wt();
	return e.Parent = this, e.optionName = t, this.Kids.push(e), St.call(this.scope, e), e;
};
var Nt = function() {
	vt.call(this), this.fontName = "zapfdingbats", this.caption = "3", this.appearanceState = "On", this.value = "On", this.textAlign = "center", this.appearanceStreamContent = At.CheckBox.createAppearanceStream();
};
V(Nt, vt);
var Lt = function() {
	ft.call(this), this.FT = "/Tx", Object.defineProperty(this, "multiline", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 13));
		},
		set: function(t) {
			!0 === Boolean(t) ? this.Ff = $(this.Ff, 13) : this.Ff = Q(this.Ff, 13);
		}
	}), Object.defineProperty(this, "fileSelect", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 21));
		},
		set: function(t) {
			!0 === Boolean(t) ? this.Ff = $(this.Ff, 21) : this.Ff = Q(this.Ff, 21);
		}
	}), Object.defineProperty(this, "doNotSpellCheck", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 23));
		},
		set: function(t) {
			!0 === Boolean(t) ? this.Ff = $(this.Ff, 23) : this.Ff = Q(this.Ff, 23);
		}
	}), Object.defineProperty(this, "doNotScroll", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 24));
		},
		set: function(t) {
			!0 === Boolean(t) ? this.Ff = $(this.Ff, 24) : this.Ff = Q(this.Ff, 24);
		}
	}), Object.defineProperty(this, "comb", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 25));
		},
		set: function(t) {
			!0 === Boolean(t) ? this.Ff = $(this.Ff, 25) : this.Ff = Q(this.Ff, 25);
		}
	}), Object.defineProperty(this, "richText", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 26));
		},
		set: function(t) {
			!0 === Boolean(t) ? this.Ff = $(this.Ff, 26) : this.Ff = Q(this.Ff, 26);
		}
	});
	var t = null;
	Object.defineProperty(this, "MaxLen", {
		enumerable: !0,
		configurable: !1,
		get: function() {
			return t;
		},
		set: function(e) {
			t = e;
		}
	}), Object.defineProperty(this, "maxLength", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return t;
		},
		set: function(e) {
			Number.isInteger(e) && (t = e);
		}
	}), Object.defineProperty(this, "hasAppearanceStream", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return this.V || this.DV;
		}
	});
};
V(Lt, ft);
var xt = function() {
	Lt.call(this), Object.defineProperty(this, "password", {
		enumerable: !0,
		configurable: !0,
		get: function() {
			return Boolean(Z(this.Ff, 14));
		},
		set: function(t) {
			!0 === Boolean(t) ? this.Ff = $(this.Ff, 14) : this.Ff = Q(this.Ff, 14);
		}
	}), this.password = !0;
};
V(xt, Lt);
var At = {
	CheckBox: {
		createAppearanceStream: function() {
			return {
				N: { On: At.CheckBox.YesNormal },
				D: {
					On: At.CheckBox.YesPushDown,
					Off: At.CheckBox.OffPushDown
				}
			};
		},
		YesPushDown: function(t) {
			var e = Y(t);
			e.scope = t.scope;
			var r = [], n = t.scope.internal.getFont(t.fontName, t.fontStyle).id, i = t.scope.__private__.encodeColorString(t.color), a = rt(t, t.caption);
			return r.push("0.749023 g"), r.push("0 0 " + H(At.internal.getWidth(t)) + " " + H(At.internal.getHeight(t)) + " re"), r.push("f"), r.push("BMC"), r.push("q"), r.push("0 0 1 rg"), r.push("/" + n + " " + H(a.fontSize) + " Tf " + i), r.push("BT"), r.push(a.text), r.push("ET"), r.push("Q"), r.push("EMC"), e.stream = r.join("\n"), e;
		},
		YesNormal: function(t) {
			var e = Y(t);
			e.scope = t.scope;
			var r = t.scope.internal.getFont(t.fontName, t.fontStyle).id, n = t.scope.__private__.encodeColorString(t.color), i = [], a = At.internal.getHeight(t), o = At.internal.getWidth(t), s = rt(t, t.caption);
			return i.push("1 g"), i.push("0 0 " + H(o) + " " + H(a) + " re"), i.push("f"), i.push("q"), i.push("0 0 1 rg"), i.push("0 0 " + H(o - 1) + " " + H(a - 1) + " re"), i.push("W"), i.push("n"), i.push("0 g"), i.push("BT"), i.push("/" + r + " " + H(s.fontSize) + " Tf " + n), i.push(s.text), i.push("ET"), i.push("Q"), e.stream = i.join("\n"), e;
		},
		OffPushDown: function(t) {
			var e = Y(t);
			e.scope = t.scope;
			var r = [];
			return r.push("0.749023 g"), r.push("0 0 " + H(At.internal.getWidth(t)) + " " + H(At.internal.getHeight(t)) + " re"), r.push("f"), e.stream = r.join("\n"), e;
		}
	},
	RadioButton: {
		Circle: {
			createAppearanceStream: function(t) {
				var e = {
					D: { Off: At.RadioButton.Circle.OffPushDown },
					N: {}
				};
				return e.N[t] = At.RadioButton.Circle.YesNormal, e.D[t] = At.RadioButton.Circle.YesPushDown, e;
			},
			getCA: function() {
				return "l";
			},
			YesNormal: function(t) {
				var e = Y(t);
				e.scope = t.scope;
				var r = [], n = At.internal.getWidth(t) <= At.internal.getHeight(t) ? At.internal.getWidth(t) / 4 : At.internal.getHeight(t) / 4;
				n = Number((.9 * n).toFixed(5));
				var i = At.internal.Bezier_C, a = Number((n * i).toFixed(5));
				return r.push("q"), r.push("1 0 0 1 " + W(At.internal.getWidth(t) / 2) + " " + W(At.internal.getHeight(t) / 2) + " cm"), r.push(n + " 0 m"), r.push(n + " " + a + " " + a + " " + n + " 0 " + n + " c"), r.push("-" + a + " " + n + " -" + n + " " + a + " -" + n + " 0 c"), r.push("-" + n + " -" + a + " -" + a + " -" + n + " 0 -" + n + " c"), r.push(a + " -" + n + " " + n + " -" + a + " " + n + " 0 c"), r.push("f"), r.push("Q"), e.stream = r.join("\n"), e;
			},
			YesPushDown: function(t) {
				var e = Y(t);
				e.scope = t.scope;
				var r = [], n = At.internal.getWidth(t) <= At.internal.getHeight(t) ? At.internal.getWidth(t) / 4 : At.internal.getHeight(t) / 4;
				n = Number((.9 * n).toFixed(5));
				var i = Number((2 * n).toFixed(5)), a = Number((i * At.internal.Bezier_C).toFixed(5)), o = Number((n * At.internal.Bezier_C).toFixed(5));
				return r.push("0.749023 g"), r.push("q"), r.push("1 0 0 1 " + W(At.internal.getWidth(t) / 2) + " " + W(At.internal.getHeight(t) / 2) + " cm"), r.push(i + " 0 m"), r.push(i + " " + a + " " + a + " " + i + " 0 " + i + " c"), r.push("-" + a + " " + i + " -" + i + " " + a + " -" + i + " 0 c"), r.push("-" + i + " -" + a + " -" + a + " -" + i + " 0 -" + i + " c"), r.push(a + " -" + i + " " + i + " -" + a + " " + i + " 0 c"), r.push("f"), r.push("Q"), r.push("0 g"), r.push("q"), r.push("1 0 0 1 " + W(At.internal.getWidth(t) / 2) + " " + W(At.internal.getHeight(t) / 2) + " cm"), r.push(n + " 0 m"), r.push(n + " " + o + " " + o + " " + n + " 0 " + n + " c"), r.push("-" + o + " " + n + " -" + n + " " + o + " -" + n + " 0 c"), r.push("-" + n + " -" + o + " -" + o + " -" + n + " 0 -" + n + " c"), r.push(o + " -" + n + " " + n + " -" + o + " " + n + " 0 c"), r.push("f"), r.push("Q"), e.stream = r.join("\n"), e;
			},
			OffPushDown: function(t) {
				var e = Y(t);
				e.scope = t.scope;
				var r = [], n = At.internal.getWidth(t) <= At.internal.getHeight(t) ? At.internal.getWidth(t) / 4 : At.internal.getHeight(t) / 4;
				n = Number((.9 * n).toFixed(5));
				var i = Number((2 * n).toFixed(5)), a = Number((i * At.internal.Bezier_C).toFixed(5));
				return r.push("0.749023 g"), r.push("q"), r.push("1 0 0 1 " + W(At.internal.getWidth(t) / 2) + " " + W(At.internal.getHeight(t) / 2) + " cm"), r.push(i + " 0 m"), r.push(i + " " + a + " " + a + " " + i + " 0 " + i + " c"), r.push("-" + a + " " + i + " -" + i + " " + a + " -" + i + " 0 c"), r.push("-" + i + " -" + a + " -" + a + " -" + i + " 0 -" + i + " c"), r.push(a + " -" + i + " " + i + " -" + a + " " + i + " 0 c"), r.push("f"), r.push("Q"), e.stream = r.join("\n"), e;
			}
		},
		Cross: {
			createAppearanceStream: function(t) {
				var e = {
					D: { Off: At.RadioButton.Cross.OffPushDown },
					N: {}
				};
				return e.N[t] = At.RadioButton.Cross.YesNormal, e.D[t] = At.RadioButton.Cross.YesPushDown, e;
			},
			getCA: function() {
				return "8";
			},
			YesNormal: function(t) {
				var e = Y(t);
				e.scope = t.scope;
				var r = [], n = At.internal.calculateCross(t);
				return r.push("q"), r.push("1 1 " + H(At.internal.getWidth(t) - 2) + " " + H(At.internal.getHeight(t) - 2) + " re"), r.push("W"), r.push("n"), r.push(H(n.x1.x) + " " + H(n.x1.y) + " m"), r.push(H(n.x2.x) + " " + H(n.x2.y) + " l"), r.push(H(n.x4.x) + " " + H(n.x4.y) + " m"), r.push(H(n.x3.x) + " " + H(n.x3.y) + " l"), r.push("s"), r.push("Q"), e.stream = r.join("\n"), e;
			},
			YesPushDown: function(t) {
				var e = Y(t);
				e.scope = t.scope;
				var r = At.internal.calculateCross(t), n = [];
				return n.push("0.749023 g"), n.push("0 0 " + H(At.internal.getWidth(t)) + " " + H(At.internal.getHeight(t)) + " re"), n.push("f"), n.push("q"), n.push("1 1 " + H(At.internal.getWidth(t) - 2) + " " + H(At.internal.getHeight(t) - 2) + " re"), n.push("W"), n.push("n"), n.push(H(r.x1.x) + " " + H(r.x1.y) + " m"), n.push(H(r.x2.x) + " " + H(r.x2.y) + " l"), n.push(H(r.x4.x) + " " + H(r.x4.y) + " m"), n.push(H(r.x3.x) + " " + H(r.x3.y) + " l"), n.push("s"), n.push("Q"), e.stream = n.join("\n"), e;
			},
			OffPushDown: function(t) {
				var e = Y(t);
				e.scope = t.scope;
				var r = [];
				return r.push("0.749023 g"), r.push("0 0 " + H(At.internal.getWidth(t)) + " " + H(At.internal.getHeight(t)) + " re"), r.push("f"), e.stream = r.join("\n"), e;
			}
		}
	},
	createDefaultAppearanceStream: function(t) {
		var e = t.scope.internal.getFont(t.fontName, t.fontStyle).id, r = t.scope.__private__.encodeColorString(t.color);
		return "/" + e + " " + t.fontSize + " Tf " + r;
	}
};
At.internal = {
	Bezier_C: .551915024494,
	calculateCross: function(t) {
		var e = At.internal.getWidth(t), r = At.internal.getHeight(t), n = Math.min(e, r);
		return {
			x1: {
				x: (e - n) / 2,
				y: (r - n) / 2 + n
			},
			x2: {
				x: (e - n) / 2 + n,
				y: (r - n) / 2
			},
			x3: {
				x: (e - n) / 2,
				y: (r - n) / 2
			},
			x4: {
				x: (e - n) / 2 + n,
				y: (r - n) / 2 + n
			}
		};
	}
}, At.internal.getWidth = function(e) {
	var r = 0;
	return "object" === _typeof(e) && (r = G(e.Rect[2])), r;
}, At.internal.getHeight = function(e) {
	var r = 0;
	return "object" === _typeof(e) && (r = G(e.Rect[3])), r;
};
var St = R.addField = function(t) {
	if (ot(this, t), !(t instanceof ft)) throw new Error("Invalid argument passed to jsPDF.addField.");
	var e;
	return (e = t).scope.internal.acroformPlugin.printedOut && (e.scope.internal.acroformPlugin.printedOut = !1, e.scope.internal.acroformPlugin.acroFormDictionaryRoot = null), e.scope.internal.acroformPlugin.acroFormDictionaryRoot.Fields.push(e), t.page = t.scope.internal.getCurrentPageInfo().pageNumber, this;
};
R.AcroFormChoiceField = dt, R.AcroFormListBox = pt, R.AcroFormComboBox = gt, R.AcroFormEditBox = mt, R.AcroFormButton = vt, R.AcroFormPushButton = bt, R.AcroFormRadioButton = yt, R.AcroFormCheckBox = Nt, R.AcroFormTextField = Lt, R.AcroFormPasswordField = xt, R.AcroFormAppearance = At, R.AcroForm = {
	ChoiceField: dt,
	ListBox: pt,
	ComboBox: gt,
	EditBox: mt,
	Button: vt,
	PushButton: bt,
	RadioButton: yt,
	CheckBox: Nt,
	TextField: Lt,
	PasswordField: xt,
	Appearance: At
}, E.AcroForm = {
	ChoiceField: dt,
	ListBox: pt,
	ComboBox: gt,
	EditBox: mt,
	Button: vt,
	PushButton: bt,
	RadioButton: yt,
	CheckBox: Nt,
	TextField: Lt,
	PasswordField: xt,
	Appearance: At
};
E.AcroForm;
function Pt(t) {
	return t.reduce(function(t, e, r) {
		return t[e] = r, t;
	}, {});
}
(function(e) {
	e.__addimage__ = {};
	var n = "UNKNOWN", i = {
		PNG: [[
			137,
			80,
			78,
			71
		]],
		TIFF: [[
			77,
			77,
			0,
			42
		], [
			73,
			73,
			42,
			0
		]],
		JPEG: [
			[
				255,
				216,
				255,
				224,
				void 0,
				void 0,
				74,
				70,
				73,
				70,
				0
			],
			[
				255,
				216,
				255,
				225,
				void 0,
				void 0,
				69,
				120,
				105,
				102,
				0,
				0
			],
			[
				255,
				216,
				255,
				219
			],
			[
				255,
				216,
				255,
				238
			]
		],
		JPEG2000: [[
			0,
			0,
			0,
			12,
			106,
			80,
			32,
			32
		]],
		GIF87a: [[
			71,
			73,
			70,
			56,
			55,
			97
		]],
		GIF89a: [[
			71,
			73,
			70,
			56,
			57,
			97
		]],
		WEBP: [[
			82,
			73,
			70,
			70,
			void 0,
			void 0,
			void 0,
			void 0,
			87,
			69,
			66,
			80
		]],
		BMP: [
			[66, 77],
			[66, 65],
			[67, 73],
			[67, 80],
			[73, 67],
			[80, 84]
		]
	}, a = e.__addimage__.getImageFileTypeByImageData = function(t, e) {
		var r, a, o, s, u, c = n;
		if ("RGBA" === (e = e || n) || void 0 !== t.data && t.data instanceof Uint8ClampedArray && "height" in t && "width" in t) return "RGBA";
		if (A(t)) for (u in i) for (o = i[u], r = 0; r < o.length; r += 1) {
			for (s = !0, a = 0; a < o[r].length; a += 1) if (void 0 !== o[r][a] && o[r][a] !== t[a]) {
				s = !1;
				break;
			}
			if (!0 === s) {
				c = u;
				break;
			}
		}
		else for (u in i) for (o = i[u], r = 0; r < o.length; r += 1) {
			for (s = !0, a = 0; a < o[r].length; a += 1) if (void 0 !== o[r][a] && o[r][a] !== t.charCodeAt(a)) {
				s = !1;
				break;
			}
			if (!0 === s) {
				c = u;
				break;
			}
		}
		return c === n && e !== n && (c = e), c;
	}, o = function t(e) {
		for (var r = this.internal.write, n = this.internal.putStream, i = (0, this.internal.getFilters)(); -1 !== i.indexOf("FlateEncode");) i.splice(i.indexOf("FlateEncode"), 1);
		e.objectId = this.internal.newObject();
		var a = [];
		if (a.push({
			key: "Type",
			value: "/XObject"
		}), a.push({
			key: "Subtype",
			value: "/Image"
		}), a.push({
			key: "Width",
			value: e.width
		}), a.push({
			key: "Height",
			value: e.height
		}), e.colorSpace === y.INDEXED ? a.push({
			key: "ColorSpace",
			value: "[/Indexed /DeviceRGB " + (e.palette.length / 3 - 1) + " " + ("sMask" in e && void 0 !== e.sMask ? e.objectId + 2 : e.objectId + 1) + " 0 R]"
		}) : (a.push({
			key: "ColorSpace",
			value: "/" + e.colorSpace
		}), e.colorSpace === y.DEVICE_CMYK && a.push({
			key: "Decode",
			value: "[1 0 1 0 1 0 1 0]"
		})), a.push({
			key: "BitsPerComponent",
			value: e.bitsPerComponent
		}), "decodeParameters" in e && void 0 !== e.decodeParameters && a.push({
			key: "DecodeParms",
			value: "<<" + e.decodeParameters + ">>"
		}), "transparency" in e && Array.isArray(e.transparency) && e.transparency.length > 0) {
			for (var o = "", s = 0, u = e.transparency.length; s < u; s++) o += e.transparency[s] + " " + e.transparency[s] + " ";
			a.push({
				key: "Mask",
				value: "[" + o + "]"
			});
		}
		void 0 !== e.sMask && a.push({
			key: "SMask",
			value: e.objectId + 1 + " 0 R"
		});
		var c = void 0 !== e.filter ? ["/" + e.filter] : void 0;
		if (n({
			data: e.data,
			additionalKeyValues: a,
			alreadyAppliedFilters: c,
			objectId: e.objectId
		}), r("endobj"), "sMask" in e && void 0 !== e.sMask) {
			var l, h = null !== (l = e.sMaskBitsPerComponent) && void 0 !== l ? l : e.bitsPerComponent, f = {
				width: e.width,
				height: e.height,
				colorSpace: "DeviceGray",
				bitsPerComponent: h,
				data: e.sMask
			};
			"filter" in e && (f.decodeParameters = "/Predictor ".concat(e.predictor, " /Colors 1 /BitsPerComponent ").concat(h, " /Columns ").concat(e.width), f.filter = e.filter), t.call(this, f);
		}
		if (e.colorSpace === y.INDEXED) {
			var d = this.internal.newObject();
			n({
				data: _(new Uint8Array(e.palette)),
				objectId: d
			}), r("endobj");
		}
	}, s = function() {
		var t = this.internal.collections["addImage_images"];
		for (var e in t) o.call(this, t[e]);
	}, u = function() {
		var t, e = this.internal.collections["addImage_images"], n = this.internal.write;
		for (var i in e) n("/I" + (t = e[i]).index, t.objectId, "0", "R");
	}, c = function() {
		this.internal.collections["addImage_images"] || (this.internal.collections["addImage_images"] = {}, this.internal.events.subscribe("putResources", s), this.internal.events.subscribe("putXobjectDict", u));
	}, l = function() {
		var t = this.internal.collections["addImage_images"];
		return c.call(this), t;
	}, h = function() {
		return Object.keys(this.internal.collections["addImage_images"]).length;
	}, d = function(t) {
		return "function" == typeof e["process" + t.toUpperCase()];
	}, p = function(e) {
		return "object" === _typeof(e) && 1 === e.nodeType;
	}, g = function(t, r) {
		if ("IMG" === t.nodeName && t.hasAttribute("src")) {
			var n = "" + t.getAttribute("src");
			if (0 === n.indexOf("data:image/")) return f(unescape(n).split("base64,").pop());
			var i = e.loadFile(n, !0);
			if (void 0 !== i) return i;
		}
		if ("CANVAS" === t.nodeName) {
			if (0 === t.width || 0 === t.height) throw new Error("Given canvas must have data. Canvas width: " + t.width + ", height: " + t.height);
			var a;
			switch (r) {
				case "PNG":
					a = "image/png";
					break;
				case "WEBP":
					a = "image/webp";
					break;
				default: a = "image/jpeg";
			}
			return f(t.toDataURL(a, 1).split("base64,").pop());
		}
	}, m = function(t) {
		var e = this.internal.collections["addImage_images"];
		if (e) {
			for (var n in e) if (t === e[n].alias) return e[n];
		}
	}, v = function(t, e, r) {
		return t || e || (t = -96, e = -96), t < 0 && (t = -1 * r.width * 72 / t / this.internal.scaleFactor), e < 0 && (e = -1 * r.height * 72 / e / this.internal.scaleFactor), 0 === t && (t = e * r.width / r.height), 0 === e && (e = t * r.height / r.width), [t, e];
	}, b = function(t, e, r, n, i, a) {
		var o = v.call(this, r, n, i), s = this.internal.getCoordinateString, u = this.internal.getVerticalCoordinateString, c = l.call(this);
		if (r = o[0], n = o[1], c[i.index] = i, a) {
			a *= Math.PI / 180;
			var h = Math.cos(a), f = Math.sin(a), d = function(t) {
				return t.toFixed(4);
			}, p = [
				d(h),
				d(f),
				d(-1 * f),
				d(h),
				0,
				0,
				"cm"
			];
		}
		this.internal.write("q"), a ? (this.internal.write([
			1,
			"0",
			"0",
			1,
			s(t),
			u(e + n),
			"cm"
		].join(" ")), this.internal.write(p.join(" ")), this.internal.write([
			s(r),
			"0",
			"0",
			s(n),
			"0",
			"0",
			"cm"
		].join(" "))) : this.internal.write([
			s(r),
			"0",
			"0",
			s(n),
			s(t),
			u(e + n),
			"cm"
		].join(" ")), this.isAdvancedAPI() && this.internal.write([
			1,
			0,
			0,
			-1,
			0,
			0,
			"cm"
		].join(" ")), this.internal.write("/I" + i.index + " Do"), this.internal.write("Q");
	}, y = e.color_spaces = {
		DEVICE_RGB: "DeviceRGB",
		DEVICE_GRAY: "DeviceGray",
		DEVICE_CMYK: "DeviceCMYK",
		CAL_GREY: "CalGray",
		CAL_RGB: "CalRGB",
		LAB: "Lab",
		ICC_BASED: "ICCBased",
		INDEXED: "Indexed",
		PATTERN: "Pattern",
		SEPARATION: "Separation",
		DEVICE_N: "DeviceN"
	};
	e.decode = {
		DCT_DECODE: "DCTDecode",
		FLATE_DECODE: "FlateDecode",
		LZW_DECODE: "LZWDecode",
		JPX_DECODE: "JPXDecode",
		JBIG2_DECODE: "JBIG2Decode",
		ASCII85_DECODE: "ASCII85Decode",
		ASCII_HEX_DECODE: "ASCIIHexDecode",
		RUN_LENGTH_DECODE: "RunLengthDecode",
		CCITT_FAX_DECODE: "CCITTFaxDecode"
	};
	var w = e.image_compression = {
		NONE: "NONE",
		FAST: "FAST",
		MEDIUM: "MEDIUM",
		SLOW: "SLOW"
	}, N = e.__addimage__.sHashCode = function(t) {
		var e, r, n = 0;
		if ("string" == typeof t) for (r = t.length, e = 0; e < r; e++) n = (n << 5) - n + t.charCodeAt(e), n |= 0;
		else if (A(t)) for (r = t.byteLength / 2, e = 0; e < r; e++) n = (n << 5) - n + t[e], n |= 0;
		return n;
	}, L = e.__addimage__.validateStringAsBase64 = function(t) {
		(t = t || "").toString().trim();
		var e = !0;
		return 0 === t.length && (e = !1), t.length % 4 != 0 && (e = !1), !1 === /^[A-Za-z0-9+/]+$/.test(t.substr(0, t.length - 2)) && (e = !1), !1 === /^[A-Za-z0-9/][A-Za-z0-9+/]|[A-Za-z0-9+/]=|==$/.test(t.substr(-2)) && (e = !1), e;
	}, x = e.__addimage__.extractImageFromDataUrl = function(t) {
		if (null == t) return null;
		if (!(t = t.trim()).startsWith("data:")) return null;
		var e = t.indexOf(",");
		return e < 0 ? null : t.substring(0, e).trim().endsWith("base64") ? t.substring(e + 1) : null;
	};
	e.__addimage__.isArrayBuffer = function(t) {
		return t instanceof ArrayBuffer;
	};
	var A = e.__addimage__.isArrayBufferView = function(t) {
		return t instanceof Int8Array || t instanceof Uint8Array || t instanceof Uint8ClampedArray || t instanceof Int16Array || t instanceof Uint16Array || t instanceof Int32Array || t instanceof Uint32Array || t instanceof Float32Array || t instanceof Float64Array;
	}, S = e.__addimage__.binaryStringToUint8Array = function(t) {
		for (var e = t.length, r = new Uint8Array(e), n = 0; n < e; n++) r[n] = t.charCodeAt(n);
		return r;
	}, _ = e.__addimage__.arrayBufferToBinaryString = function(t) {
		for (var e = "", r = A(t) ? t : new Uint8Array(t), n = 0; n < r.length; n += 8192) e += String.fromCharCode.apply(null, r.subarray(n, n + 8192));
		return e;
	};
	e.addImage = function() {
		var e, r, i, a, o, s, u, l, h;
		if ("number" == typeof arguments[1] ? (r = n, i = arguments[1], a = arguments[2], o = arguments[3], s = arguments[4], u = arguments[5], l = arguments[6], h = arguments[7]) : (r = arguments[1], i = arguments[2], a = arguments[3], o = arguments[4], s = arguments[5], u = arguments[6], l = arguments[7], h = arguments[8]), "object" === _typeof(e = arguments[0]) && !p(e) && "imageData" in e) {
			var f = e;
			e = f.imageData, r = f.format || r || n, i = f.x || i || 0, a = f.y || a || 0, o = f.w || f.width || o, s = f.h || f.height || s, u = f.alias || u, l = f.compression || l, h = f.rotation || f.angle || h;
		}
		var d = this.internal.getFilters();
		if (void 0 === l && -1 !== d.indexOf("FlateEncode") && (l = "SLOW"), isNaN(i) || isNaN(a)) throw new Error("Invalid coordinates passed to jsPDF.addImage");
		c.call(this);
		var g = P.call(this, e, r, u, l);
		return b.call(this, i, a, o, s, g, h), this;
	};
	var P = function(t, r, i, o) {
		var s, u, c;
		if ("string" == typeof t && a(t) === n) {
			t = unescape(t);
			var l = k(t, !1);
			("" !== l || void 0 !== (l = e.loadFile(t, !0))) && (t = l);
		}
		if (p(t) && (t = g(t, r)), r = a(t, r), !d(r)) throw new Error("addImage does not support files of type '" + r + "', please ensure that a plugin for '" + r + "' support is added.");
		if ((null == (c = i) || 0 === c.length) && (i = function(t) {
			return "string" == typeof t || A(t) ? N(t) : A(t.data) ? N(t.data) : null;
		}(t)), (s = m.call(this, i)) || (t instanceof Uint8Array || "RGBA" === r || (u = t, t = S(t)), s = this["process" + r.toUpperCase()](t, h.call(this), i, function(t) {
			return t && "string" == typeof t && (t = t.toUpperCase()), t in e.image_compression ? t : w.NONE;
		}(o), u)), !s) throw new Error("An unknown error occurred whilst processing the image.");
		return s;
	}, k = e.__addimage__.convertBase64ToBinaryString = function(t, e) {
		e = "boolean" != typeof e || e;
		var r, n = "";
		if ("string" == typeof t) {
			var i;
			r = null !== (i = x(t)) && void 0 !== i ? i : t;
			try {
				n = f(r);
			} catch (a) {
				if (e) throw L(r) ? /* @__PURE__ */ new Error("atob-Error in jsPDF.convertBase64ToBinaryString " + a.message) : /* @__PURE__ */ new Error("Supplied Data is not a valid base64-String jsPDF.convertBase64ToBinaryString ");
			}
		}
		return n;
	};
	e.getImageProperties = function(t) {
		var r, i, o = "";
		if (p(t) && (t = g(t)), "string" == typeof t && a(t) === n && ("" === (o = k(t, !1)) && (o = e.loadFile(t) || ""), t = o), i = a(t), !d(i)) throw new Error("addImage does not support files of type '" + i + "', please ensure that a plugin for '" + i + "' support is added.");
		if (t instanceof Uint8Array || (t = S(t)), !(r = this["process" + i.toUpperCase()](t))) throw new Error("An unknown error occurred whilst processing the image");
		return r.fileType = i, r;
	};
})(E.API), function(t) {
	/**
	* @license
	* Copyright (c) 2014 Steven Spungin (TwelveTone LLC)  steven@twelvetone.tv
	*
	* Licensed under the MIT License.
	* http://opensource.org/licenses/mit-license
	*/
	var e = function(t) {
		if (void 0 !== t && "" != t) return !0;
	};
	E.API.events.push(["addPage", function(t) {
		this.internal.getPageInfo(t.pageNumber).pageContext.annotations = [];
	}]), t.events.push(["putPage", function(t) {
		for (var r, n, i, a = this.internal.getCoordinateString, o = this.internal.getVerticalCoordinateString, s = this.internal.getPageInfoByObjId(t.objId), u = t.pageContext.annotations, c = !1, l = 0; l < u.length && !c; l++) switch ((r = u[l]).type) {
			case "link":
				(e(r.options.url) || e(r.options.pageNumber)) && (c = !0);
				break;
			case "reference":
			case "text":
			case "freetext": c = !0;
		}
		if (0 != c) {
			this.internal.write("/Annots [");
			for (var h = 0; h < u.length; h++) {
				r = u[h];
				var f = this.internal.pdfEscape, d = this.internal.getEncryptor(t.objId);
				switch (r.type) {
					case "reference":
						this.internal.write(" " + r.object.objId + " 0 R ");
						break;
					case "text":
						var p = this.internal.newAdditionalObject(), g = this.internal.newAdditionalObject(), m = this.internal.getEncryptor(p.objId), v = r.title || "Note";
						i = "<</Type /Annot /Subtype /Text " + (n = "/Rect [" + a(r.bounds.x) + " " + o(r.bounds.y + r.bounds.h) + " " + a(r.bounds.x + r.bounds.w) + " " + o(r.bounds.y) + "] ") + "/Contents (" + f(m(r.contents)) + ")", i += " /Popup " + g.objId + " 0 R", i += " /P " + s.objId + " 0 R", i += " /T (" + f(m(v)) + ") >>", p.content = i;
						var b = p.objId + " 0 R";
						i = "<</Type /Annot /Subtype /Popup " + (n = "/Rect [" + a(r.bounds.x + 30) + " " + o(r.bounds.y + r.bounds.h) + " " + a(r.bounds.x + r.bounds.w + 30) + " " + o(r.bounds.y) + "] ") + " /Parent " + b, r.open && (i += " /Open true"), i += " >>", g.content = i, this.internal.write(p.objId, "0 R", g.objId, "0 R");
						break;
					case "freetext":
						n = "/Rect [" + a(r.bounds.x) + " " + o(r.bounds.y) + " " + a(r.bounds.x + r.bounds.w) + " " + o(r.bounds.y + r.bounds.h) + "] ";
						var y = "font: Helvetica,sans-serif 12.0pt; text-align:left; color:#" + (r.color || "#000000");
						i = "<</Type /Annot /Subtype /FreeText " + n + "/Contents (" + f(d(r.contents)) + ")", i += " /DS(" + f(d(y)) + ")", i += " /Border [0 0 0]", i += " >>", this.internal.write(i);
						break;
					case "link":
						if (r.options.name) {
							var w = this.annotations._nameMap[r.options.name];
							r.options.pageNumber = w.page, r.options.top = w.y;
						} else r.options.top || (r.options.top = 0);
						if (n = "/Rect [" + r.finalBounds.x + " " + r.finalBounds.y + " " + r.finalBounds.w + " " + r.finalBounds.h + "] ", i = "", r.options.url) i = "<</Type /Annot /Subtype /Link " + n + "/Border [0 0 0] /A <</S /URI /URI (" + f(d(r.options.url)) + ") >>";
						else if (r.options.pageNumber) switch (i = "<</Type /Annot /Subtype /Link " + n + "/Border [0 0 0] /Dest [" + this.internal.getPageInfo(r.options.pageNumber).objId + " 0 R", r.options.magFactor = r.options.magFactor || "XYZ", r.options.magFactor) {
							case "Fit":
								i += " /Fit]";
								break;
							case "FitH":
								i += " /FitH " + r.options.top + "]";
								break;
							case "FitV":
								r.options.left = r.options.left || 0, i += " /FitV " + r.options.left + "]";
								break;
							default:
								var N = o(r.options.top);
								r.options.left = r.options.left || 0, void 0 === r.options.zoom && (r.options.zoom = 0), i += " /XYZ " + r.options.left + " " + N + " " + r.options.zoom + "]";
						}
						"" != i && (i += " >>", this.internal.write(i));
				}
			}
			this.internal.write("]");
		}
	}]), t.createAnnotation = function(t) {
		var e = this.internal.getCurrentPageInfo();
		switch (t.type) {
			case "link":
				this.link(t.bounds.x, t.bounds.y, t.bounds.w, t.bounds.h, t);
				break;
			case "text":
			case "freetext": e.pageContext.annotations.push(t);
		}
	}, t.link = function(t, e, r, n, i) {
		var a = this.internal.getCurrentPageInfo(), o = this.internal.getCoordinateString, s = this.internal.getVerticalCoordinateString;
		a.pageContext.annotations.push({
			finalBounds: {
				x: o(t),
				y: s(e),
				w: o(t + r),
				h: s(e + n)
			},
			options: i,
			type: "link"
		});
	}, t.textWithLink = function(t, e, r, n) {
		var i, a, o = this.getTextWidth(t), s = this.internal.getLineHeight() / this.internal.scaleFactor;
		if (void 0 !== n.maxWidth) {
			a = n.maxWidth;
			var u = this.splitTextToSize(t, a).length;
			i = Math.ceil(s * u);
		} else a = o, i = s;
		return this.text(t, e, r, n), r += .2 * s, "center" === n.align && (e -= o / 2), "right" === n.align && (e -= o), this.link(e, r - s, a, i, n), o;
	}, t.getTextWidth = function(t) {
		var e = this.internal.getFontSize();
		return this.getStringUnitWidth(t) * e / this.internal.scaleFactor;
	};
}(E.API), function(t) {
	/**
	* @license
	* Copyright (c) 2017 Aras Abbasi
	*
	* Licensed under the MIT License.
	* http://opensource.org/licenses/mit-license
	*/
	var e = {
		1569: [65152],
		1570: [65153, 65154],
		1571: [65155, 65156],
		1572: [65157, 65158],
		1573: [65159, 65160],
		1574: [
			65161,
			65162,
			65163,
			65164
		],
		1575: [65165, 65166],
		1576: [
			65167,
			65168,
			65169,
			65170
		],
		1577: [65171, 65172],
		1578: [
			65173,
			65174,
			65175,
			65176
		],
		1579: [
			65177,
			65178,
			65179,
			65180
		],
		1580: [
			65181,
			65182,
			65183,
			65184
		],
		1581: [
			65185,
			65186,
			65187,
			65188
		],
		1582: [
			65189,
			65190,
			65191,
			65192
		],
		1583: [65193, 65194],
		1584: [65195, 65196],
		1585: [65197, 65198],
		1586: [65199, 65200],
		1587: [
			65201,
			65202,
			65203,
			65204
		],
		1588: [
			65205,
			65206,
			65207,
			65208
		],
		1589: [
			65209,
			65210,
			65211,
			65212
		],
		1590: [
			65213,
			65214,
			65215,
			65216
		],
		1591: [
			65217,
			65218,
			65219,
			65220
		],
		1592: [
			65221,
			65222,
			65223,
			65224
		],
		1593: [
			65225,
			65226,
			65227,
			65228
		],
		1594: [
			65229,
			65230,
			65231,
			65232
		],
		1601: [
			65233,
			65234,
			65235,
			65236
		],
		1602: [
			65237,
			65238,
			65239,
			65240
		],
		1603: [
			65241,
			65242,
			65243,
			65244
		],
		1604: [
			65245,
			65246,
			65247,
			65248
		],
		1605: [
			65249,
			65250,
			65251,
			65252
		],
		1606: [
			65253,
			65254,
			65255,
			65256
		],
		1607: [
			65257,
			65258,
			65259,
			65260
		],
		1608: [65261, 65262],
		1609: [
			65263,
			65264,
			64488,
			64489
		],
		1610: [
			65265,
			65266,
			65267,
			65268
		],
		1649: [64336, 64337],
		1655: [64477],
		1657: [
			64358,
			64359,
			64360,
			64361
		],
		1658: [
			64350,
			64351,
			64352,
			64353
		],
		1659: [
			64338,
			64339,
			64340,
			64341
		],
		1662: [
			64342,
			64343,
			64344,
			64345
		],
		1663: [
			64354,
			64355,
			64356,
			64357
		],
		1664: [
			64346,
			64347,
			64348,
			64349
		],
		1667: [
			64374,
			64375,
			64376,
			64377
		],
		1668: [
			64370,
			64371,
			64372,
			64373
		],
		1670: [
			64378,
			64379,
			64380,
			64381
		],
		1671: [
			64382,
			64383,
			64384,
			64385
		],
		1672: [64392, 64393],
		1676: [64388, 64389],
		1677: [64386, 64387],
		1678: [64390, 64391],
		1681: [64396, 64397],
		1688: [64394, 64395],
		1700: [
			64362,
			64363,
			64364,
			64365
		],
		1702: [
			64366,
			64367,
			64368,
			64369
		],
		1705: [
			64398,
			64399,
			64400,
			64401
		],
		1709: [
			64467,
			64468,
			64469,
			64470
		],
		1711: [
			64402,
			64403,
			64404,
			64405
		],
		1713: [
			64410,
			64411,
			64412,
			64413
		],
		1715: [
			64406,
			64407,
			64408,
			64409
		],
		1722: [64414, 64415],
		1723: [
			64416,
			64417,
			64418,
			64419
		],
		1726: [
			64426,
			64427,
			64428,
			64429
		],
		1728: [64420, 64421],
		1729: [
			64422,
			64423,
			64424,
			64425
		],
		1733: [64480, 64481],
		1734: [64473, 64474],
		1735: [64471, 64472],
		1736: [64475, 64476],
		1737: [64482, 64483],
		1739: [64478, 64479],
		1740: [
			64508,
			64509,
			64510,
			64511
		],
		1744: [
			64484,
			64485,
			64486,
			64487
		],
		1746: [64430, 64431],
		1747: [64432, 64433]
	}, r = {
		65247: {
			65154: 65269,
			65156: 65271,
			65160: 65273,
			65166: 65275
		},
		65248: {
			65154: 65270,
			65156: 65272,
			65160: 65274,
			65166: 65276
		},
		65165: { 65247: { 65248: { 65258: 65010 } } },
		1617: {
			1612: 64606,
			1613: 64607,
			1614: 64608,
			1615: 64609,
			1616: 64610
		}
	}, n = {
		1612: 64606,
		1613: 64607,
		1614: 64608,
		1615: 64609,
		1616: 64610
	}, i = [
		1570,
		1571,
		1573,
		1575
	];
	t.__arabicParser__ = {};
	var a = t.__arabicParser__.isInArabicSubstitutionA = function(t) {
		return void 0 !== e[t.charCodeAt(0)];
	}, o = t.__arabicParser__.isArabicLetter = function(t) {
		return "string" == typeof t && /^[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]+$/.test(t);
	}, s = t.__arabicParser__.isArabicEndLetter = function(t) {
		return o(t) && a(t) && e[t.charCodeAt(0)].length <= 2;
	}, u = t.__arabicParser__.isArabicAlfLetter = function(t) {
		return o(t) && i.indexOf(t.charCodeAt(0)) >= 0;
	};
	t.__arabicParser__.arabicLetterHasIsolatedForm = function(t) {
		return o(t) && a(t) && e[t.charCodeAt(0)].length >= 1;
	};
	var c = t.__arabicParser__.arabicLetterHasFinalForm = function(t) {
		return o(t) && a(t) && e[t.charCodeAt(0)].length >= 2;
	};
	t.__arabicParser__.arabicLetterHasInitialForm = function(t) {
		return o(t) && a(t) && e[t.charCodeAt(0)].length >= 3;
	};
	var l = t.__arabicParser__.arabicLetterHasMedialForm = function(t) {
		return o(t) && a(t) && 4 == e[t.charCodeAt(0)].length;
	}, h = t.__arabicParser__.resolveLigatures = function(t) {
		var e = 0, n = r, i = "", a = 0;
		for (e = 0; e < t.length; e += 1) void 0 !== n[t.charCodeAt(e)] ? (a++, "number" == typeof (n = n[t.charCodeAt(e)]) && (i += String.fromCharCode(n), n = r, a = 0), e === t.length - 1 && (n = r, i += t.charAt(e - (a - 1)), e -= a - 1, a = 0)) : (n = r, i += t.charAt(e - a), e -= a, a = 0);
		return i;
	};
	t.__arabicParser__.isArabicDiacritic = function(t) {
		return void 0 !== t && void 0 !== n[t.charCodeAt(0)];
	};
	var f = t.__arabicParser__.getCorrectForm = function(t, e, r) {
		return o(t) ? !1 === a(t) ? -1 : !c(t) || !o(e) && !o(r) || !o(r) && s(e) || s(t) && !o(e) || s(t) && u(e) || s(t) && s(e) ? 0 : l(t) && o(e) && !s(e) && o(r) && c(r) ? 3 : s(t) || !o(r) ? 1 : 2 : -1;
	}, d = function(t) {
		var r = 0, n = 0, i = 0, a = "", s = "", u = "", c = (t = t || "").split("\\s+"), l = [];
		for (r = 0; r < c.length; r += 1) {
			for (l.push(""), n = 0; n < c[r].length; n += 1) a = c[r][n], s = c[r][n - 1], u = c[r][n + 1], o(a) ? (i = f(a, s, u), l[r] += -1 !== i ? String.fromCharCode(e[a.charCodeAt(0)][i]) : a) : l[r] += a;
			l[r] = h(l[r]);
		}
		return l.join(" ");
	}, p = t.__arabicParser__.processArabic = t.processArabic = function() {
		var t, e = "string" == typeof arguments[0] ? arguments[0] : arguments[0].text, r = [];
		if (Array.isArray(e)) {
			var n = 0;
			for (r = [], n = 0; n < e.length; n += 1) Array.isArray(e[n]) ? r.push([
				d(e[n][0]),
				e[n][1],
				e[n][2]
			]) : r.push([d(e[n])]);
			t = r;
		} else t = d(e);
		return "string" == typeof arguments[0] ? t : (arguments[0].text = t, arguments[0]);
	};
	t.events.push(["preProcessText", p]);
}(E.API), E.API.autoPrint = function(t) {
	var e;
	return (t = t || {}).variant = t.variant || "non-conform", "javascript" === t.variant ? this.addJS("print({});") : (this.internal.events.subscribe("postPutResources", function() {
		e = this.internal.newObject(), this.internal.out("<<"), this.internal.out("/S /Named"), this.internal.out("/Type /Action"), this.internal.out("/N /Print"), this.internal.out(">>"), this.internal.out("endobj");
	}), this.internal.events.subscribe("putCatalog", function() {
		this.internal.out("/OpenAction " + e + " 0 R");
	})), this;
}, function(t) {
	/**
	* @license
	* Copyright (c) 2014 Steven Spungin (TwelveTone LLC)  steven@twelvetone.tv
	*
	* Licensed under the MIT License.
	* http://opensource.org/licenses/mit-license
	*/
	var e = function() {
		var t = void 0;
		Object.defineProperty(this, "pdf", {
			get: function() {
				return t;
			},
			set: function(e) {
				t = e;
			}
		});
		var e = 150;
		Object.defineProperty(this, "width", {
			get: function() {
				return e;
			},
			set: function(t) {
				e = isNaN(t) || !1 === Number.isInteger(t) || t < 0 ? 150 : t, this.getContext("2d").pageWrapXEnabled && (this.getContext("2d").pageWrapX = e + 1);
			}
		});
		var r = 300;
		Object.defineProperty(this, "height", {
			get: function() {
				return r;
			},
			set: function(t) {
				r = isNaN(t) || !1 === Number.isInteger(t) || t < 0 ? 300 : t, this.getContext("2d").pageWrapYEnabled && (this.getContext("2d").pageWrapY = r + 1);
			}
		});
		var n = [];
		Object.defineProperty(this, "childNodes", {
			get: function() {
				return n;
			},
			set: function(t) {
				n = t;
			}
		});
		var i = {};
		Object.defineProperty(this, "style", {
			get: function() {
				return i;
			},
			set: function(t) {
				i = t;
			}
		}), Object.defineProperty(this, "parentNode", {});
	};
	e.prototype.getContext = function(t, e) {
		var r;
		if ("2d" !== (t = t || "2d")) return null;
		for (r in e) this.pdf.context2d.hasOwnProperty(r) && (this.pdf.context2d[r] = e[r]);
		return this.pdf.context2d._canvas = this, this.pdf.context2d;
	}, e.prototype.toDataURL = function() {
		throw new Error("toDataURL is not implemented.");
	}, t.events.push(["initialized", function() {
		this.canvas = new e(), this.canvas.pdf = this;
	}]);
}(E.API), function(e) {
	var r = {
		left: 0,
		top: 0,
		bottom: 0,
		right: 0
	}, n = !1, i = function() {
		void 0 === this.internal.__cell__ && (this.internal.__cell__ = {}, this.internal.__cell__.padding = 3, this.internal.__cell__.headerFunction = void 0, this.internal.__cell__.margins = Object.assign({}, r), this.internal.__cell__.margins.width = this.getPageWidth(), a.call(this));
	}, a = function() {
		this.internal.__cell__.lastCell = new o(), this.internal.__cell__.pages = 1;
	}, o = function() {
		var t = arguments[0];
		Object.defineProperty(this, "x", {
			enumerable: !0,
			get: function() {
				return t;
			},
			set: function(e) {
				t = e;
			}
		});
		var e = arguments[1];
		Object.defineProperty(this, "y", {
			enumerable: !0,
			get: function() {
				return e;
			},
			set: function(t) {
				e = t;
			}
		});
		var r = arguments[2];
		Object.defineProperty(this, "width", {
			enumerable: !0,
			get: function() {
				return r;
			},
			set: function(t) {
				r = t;
			}
		});
		var n = arguments[3];
		Object.defineProperty(this, "height", {
			enumerable: !0,
			get: function() {
				return n;
			},
			set: function(t) {
				n = t;
			}
		});
		var i = arguments[4];
		Object.defineProperty(this, "text", {
			enumerable: !0,
			get: function() {
				return i;
			},
			set: function(t) {
				i = t;
			}
		});
		var a = arguments[5];
		Object.defineProperty(this, "lineNumber", {
			enumerable: !0,
			get: function() {
				return a;
			},
			set: function(t) {
				a = t;
			}
		});
		var o = arguments[6];
		return Object.defineProperty(this, "align", {
			enumerable: !0,
			get: function() {
				return o;
			},
			set: function(t) {
				o = t;
			}
		}), this;
	};
	o.prototype.clone = function() {
		return new o(this.x, this.y, this.width, this.height, this.text, this.lineNumber, this.align);
	}, o.prototype.toArray = function() {
		return [
			this.x,
			this.y,
			this.width,
			this.height,
			this.text,
			this.lineNumber,
			this.align
		];
	}, e.setHeaderFunction = function(t) {
		return i.call(this), this.internal.__cell__.headerFunction = "function" == typeof t ? t : void 0, this;
	}, e.getTextDimensions = function(t, e) {
		i.call(this);
		var r = (e = e || {}).fontSize || this.getFontSize(), n = e.font || this.getFont(), a = e.scaleFactor || this.internal.scaleFactor, o = 0, s = 0, u = 0, c = this;
		if (!Array.isArray(t) && "string" != typeof t) {
			if ("number" != typeof t) throw new Error("getTextDimensions expects text-parameter to be of type String or type Number or an Array of Strings.");
			t = String(t);
		}
		var l = e.maxWidth;
		l > 0 ? "string" == typeof t ? t = this.splitTextToSize(t, l) : "[object Array]" === Object.prototype.toString.call(t) && (t = t.reduce(function(t, e) {
			return t.concat(c.splitTextToSize(e, l));
		}, [])) : t = Array.isArray(t) ? t : [t];
		for (var h = 0; h < t.length; h++) o < (u = this.getStringUnitWidth(t[h], { font: n }) * r) && (o = u);
		return 0 !== o && (s = t.length), {
			w: o /= a,
			h: Math.max((s * r * this.getLineHeightFactor() - r * (this.getLineHeightFactor() - 1)) / a, 0)
		};
	}, e.cellAddPage = function() {
		i.call(this), this.addPage();
		var t = this.internal.__cell__.margins || r;
		return this.internal.__cell__.lastCell = new o(t.left, t.top, void 0, void 0), this.internal.__cell__.pages += 1, this;
	};
	var s = e.cell = function() {
		var t = arguments[0] instanceof o ? arguments[0] : new o(arguments[0], arguments[1], arguments[2], arguments[3], arguments[4], arguments[5], arguments[6]);
		i.call(this);
		var e = this.internal.__cell__.lastCell, a = this.internal.__cell__.padding, s = this.internal.__cell__.margins || r, u = this.internal.__cell__.tableHeaderRow, c = this.internal.__cell__.printHeaders;
		return void 0 !== e.lineNumber && (e.lineNumber === t.lineNumber ? (t.x = (e.x || 0) + (e.width || 0), t.y = e.y || 0) : e.y + e.height + t.height + s.bottom > this.getPageHeight() ? (this.cellAddPage(), t.y = s.top, c && u && (this.printHeaderRow(t.lineNumber, !0), t.y += u[0].height)) : t.y = e.y + e.height || t.y), void 0 !== t.text[0] && (this.rect(t.x, t.y, t.width, t.height, !0 === n ? "FD" : void 0), "right" === t.align ? this.text(t.text, t.x + t.width - a, t.y + a, {
			align: "right",
			baseline: "top"
		}) : "center" === t.align ? this.text(t.text, t.x + t.width / 2, t.y + a, {
			align: "center",
			baseline: "top",
			maxWidth: t.width - a - a
		}) : this.text(t.text, t.x + a, t.y + a, {
			align: "left",
			baseline: "top",
			maxWidth: t.width - a - a
		})), this.internal.__cell__.lastCell = t, this;
	};
	e.table = function(e, n, c, l, h) {
		if (i.call(this), !c) throw new Error("No data for PDF table.");
		var f, d, p, g, m = [], v = [], b = [], y = {}, w = {}, N = [], L = [], x = (h = h || {}).autoSize || !1, A = !1 !== h.printHeaders, S = h.css && void 0 !== h.css["font-size"] ? 16 * h.css["font-size"] : h.fontSize || 12, _ = h.margins || Object.assign({ width: this.getPageWidth() }, r), P = "number" == typeof h.padding ? h.padding : 3, k = h.headerBackgroundColor || "#c8c8c8", F = h.headerTextColor || "#000";
		if (a.call(this), this.internal.__cell__.printHeaders = A, this.internal.__cell__.margins = _, this.internal.__cell__.table_font_size = S, this.internal.__cell__.padding = P, this.internal.__cell__.headerBackgroundColor = k, this.internal.__cell__.headerTextColor = F, this.setFontSize(S), null == l) v = m = Object.keys(c[0]), b = m.map(function() {
			return "left";
		});
		else if (Array.isArray(l) && "object" === _typeof(l[0])) for (m = l.map(function(t) {
			return t.name;
		}), v = l.map(function(t) {
			return t.prompt || t.name || "";
		}), b = l.map(function(t) {
			return t.align || "left";
		}), f = 0; f < l.length; f += 1) w[l[f].name] = .7499990551181103 * l[f].width;
		else Array.isArray(l) && "string" == typeof l[0] && (v = m = l, b = m.map(function() {
			return "left";
		}));
		if (x || Array.isArray(l) && "string" == typeof l[0]) for (f = 0; f < m.length; f += 1) {
			for (y[g = m[f]] = c.map(function(t) {
				return t[g];
			}), this.setFont(void 0, "bold"), N.push(this.getTextDimensions(v[f], {
				fontSize: this.internal.__cell__.table_font_size,
				scaleFactor: this.internal.scaleFactor
			}).w), d = y[g], this.setFont(void 0, "normal"), p = 0; p < d.length; p += 1) N.push(this.getTextDimensions(d[p], {
				fontSize: this.internal.__cell__.table_font_size,
				scaleFactor: this.internal.scaleFactor
			}).w);
			w[g] = Math.max.apply(null, N) + P + P, N = [];
		}
		if (A) {
			var I = {};
			for (f = 0; f < m.length; f += 1) I[m[f]] = {}, I[m[f]].text = v[f], I[m[f]].align = b[f];
			var C = u.call(this, I, w);
			L = m.map(function(t) {
				return new o(e, n, w[t], C, I[t].text, void 0, I[t].align);
			}), this.setTableHeaderRow(L), this.printHeaderRow(1, !1);
		}
		var j = l.reduce(function(t, e) {
			return t[e.name] = e.align, t;
		}, {});
		for (f = 0; f < c.length; f += 1) {
			"rowStart" in h && h.rowStart instanceof Function && h.rowStart({
				row: f,
				data: c[f]
			}, this);
			var O = u.call(this, c[f], w);
			for (p = 0; p < m.length; p += 1) {
				var B = c[f][m[p]];
				"cellStart" in h && h.cellStart instanceof Function && h.cellStart({
					row: f,
					col: p,
					data: B
				}, this), s.call(this, new o(e, n, w[m[p]], O, B, f + 2, j[m[p]]));
			}
		}
		return this.internal.__cell__.table_x = e, this.internal.__cell__.table_y = n, this;
	};
	var u = function(t, e) {
		var r = this.internal.__cell__.padding, n = this.internal.__cell__.table_font_size, i = this.internal.scaleFactor;
		return Object.keys(t).map(function(n) {
			var i = t[n];
			return this.splitTextToSize(i.hasOwnProperty("text") ? i.text : i, e[n] - r - r);
		}, this).map(function(t) {
			return this.getLineHeightFactor() * t.length * n / i + r + r;
		}, this).reduce(function(t, e) {
			return Math.max(t, e);
		}, 0);
	};
	e.setTableHeaderRow = function(t) {
		i.call(this), this.internal.__cell__.tableHeaderRow = t;
	}, e.printHeaderRow = function(t, e) {
		if (i.call(this), !this.internal.__cell__.tableHeaderRow) throw new Error("Property tableHeaderRow does not exist.");
		var r;
		if (n = !0, "function" == typeof this.internal.__cell__.headerFunction) {
			var a = this.internal.__cell__.headerFunction(this, this.internal.__cell__.pages);
			this.internal.__cell__.lastCell = new o(a[0], a[1], a[2], a[3], void 0, -1);
		}
		this.setFont(void 0, "bold");
		for (var u = [], c = 0; c < this.internal.__cell__.tableHeaderRow.length; c += 1) {
			r = this.internal.__cell__.tableHeaderRow[c].clone(), e && (r.y = this.internal.__cell__.margins.top || 0, u.push(r)), r.lineNumber = t;
			var l = this.getTextColor();
			this.setTextColor(this.internal.__cell__.headerTextColor), this.setFillColor(this.internal.__cell__.headerBackgroundColor), s.call(this, r), this.setTextColor(l);
		}
		u.length > 0 && this.setTableHeaderRow(u), this.setFont(void 0, "normal"), n = !1;
	};
}(E.API);
var kt = {
	italic: [
		"italic",
		"oblique",
		"normal"
	],
	oblique: [
		"oblique",
		"italic",
		"normal"
	],
	normal: [
		"normal",
		"oblique",
		"italic"
	]
};
var Ft = [
	"ultra-condensed",
	"extra-condensed",
	"condensed",
	"semi-condensed",
	"normal",
	"semi-expanded",
	"expanded",
	"extra-expanded",
	"ultra-expanded"
];
var It = Pt(Ft);
var Ct = [
	100,
	200,
	300,
	400,
	500,
	600,
	700,
	800,
	900
];
var jt = Pt(Ct);
function Ot(t) {
	var e = t.family.replace(/"|'/g, "").toLowerCase(), r = function(t) {
		return kt[t = t || "normal"] ? t : "normal";
	}(t.style), n = function(t) {
		return t ? "number" == typeof t ? t >= 100 && t <= 900 && t % 100 == 0 ? t : 400 : /^\d00$/.test(t) ? parseInt(t) : "bold" === t ? 700 : 400 : 400;
	}(t.weight), i = function(t) {
		return "number" == typeof It[t = t || "normal"] ? t : "normal";
	}(t.stretch);
	return {
		family: e,
		style: r,
		weight: n,
		stretch: i,
		src: t.src || [],
		ref: t.ref || {
			name: e,
			style: [
				i,
				r,
				n
			].join(" ")
		}
	};
}
function Bt(t, e, r, n) {
	var i;
	for (i = r; i >= 0 && i < e.length; i += n) if (t[e[i]]) return t[e[i]];
	for (i = r; i >= 0 && i < e.length; i -= n) if (t[e[i]]) return t[e[i]];
}
var Mt = {
	"sans-serif": "helvetica",
	fixed: "courier",
	monospace: "courier",
	terminal: "courier",
	cursive: "times",
	fantasy: "times",
	serif: "times"
};
var qt = {
	caption: "times",
	icon: "times",
	menu: "times",
	"message-box": "times",
	"small-caption": "times",
	"status-bar": "times"
};
function Et(t) {
	return [
		t.stretch,
		t.style,
		t.weight,
		t.family
	].join(" ");
}
function Rt(t) {
	return t.trimLeft();
}
function Dt(t, e) {
	for (var r = 0; r < t.length;) {
		if (t.charAt(r) === e) return [t.substring(0, r), t.substring(r + 1)];
		r += 1;
	}
	return null;
}
function Tt(t) {
	var e = t.match(/^(-[a-z_]|[a-z_])[a-z0-9_-]*/i);
	return null === e ? null : [e[0], t.substring(e[0].length)];
}
var zt;
var Ut;
var Ht;
var Wt;
var Vt;
var Gt = ["times"];
function Yt(t, r, n, i, a) {
	var o = 4, s = Kt;
	switch (a) {
		case E.API.image_compression.FAST:
			o = 1, s = Xt;
			break;
		case E.API.image_compression.MEDIUM:
			o = 6, s = Zt;
			break;
		case E.API.image_compression.SLOW: o = 9, s = $t;
	}
	t = function(t, e, r, n) {
		for (var i, a = t.length / e, o = new Uint8Array(t.length + a), s = [
			Jt,
			Xt,
			Kt,
			Zt,
			$t
		], u = 0; u < a; u += 1) {
			var c = u * e, l = t.subarray(c, c + e);
			if (n) o.set(n(l, r, i), c + u);
			else {
				for (var h = s.length, f = [], d = 0; d < h; d += 1) f[d] = s[d](l, r, i);
				var p = te(f.concat());
				o.set(f[p], c + u);
			}
			i = l;
		}
		return o;
	}(t, r, Math.ceil(n * i / 8), s);
	var u = zlibSync(t, { level: o });
	return E.API.__addimage__.arrayBufferToBinaryString(u);
}
function Jt(t) {
	var e = Array.apply([], t);
	return e.unshift(0), e;
}
function Xt(t, e) {
	var r = t.length, n = [];
	n[0] = 1;
	for (var i = 0; i < r; i += 1) {
		var a = t[i - e] || 0;
		n[i + 1] = t[i] - a + 256 & 255;
	}
	return n;
}
function Kt(t, e, r) {
	var n = t.length, i = [];
	i[0] = 2;
	for (var a = 0; a < n; a += 1) {
		var o = r && r[a] || 0;
		i[a + 1] = t[a] - o + 256 & 255;
	}
	return i;
}
function Zt(t, e, r) {
	var n = t.length, i = [];
	i[0] = 3;
	for (var a = 0; a < n; a += 1) {
		var o = t[a - e] || 0, s = r && r[a] || 0;
		i[a + 1] = t[a] + 256 - (o + s >>> 1) & 255;
	}
	return i;
}
function $t(t, e, r) {
	var n = t.length, i = [];
	i[0] = 4;
	for (var a = 0; a < n; a += 1) {
		var o = Qt(t[a - e] || 0, r && r[a] || 0, r && r[a - e] || 0);
		i[a + 1] = t[a] - o + 256 & 255;
	}
	return i;
}
function Qt(t, e, r) {
	if (t === e && e === r) return t;
	var n = Math.abs(e - r), i = Math.abs(t - r), a = Math.abs(t + e - r - r);
	return n <= i && n <= a ? t : i <= a ? e : r;
}
function te(t) {
	var e = t.map(function(t) {
		return t.reduce(function(t, e) {
			return t + Math.abs(e);
		}, 0);
	});
	return e.indexOf(Math.min.apply(null, e));
}
function ee(t, e, r) {
	var n = e * r, i = Math.floor(n / 8), a = 16 - (n - 8 * i + r), o = (1 << r) - 1;
	return ne(t, i) >> a & o;
}
function re(t, e, r, n) {
	var i = r * n, a = Math.floor(i / 8), o = 16 - (i - 8 * a + n), s = (1 << n) - 1, u = (e & s) << o;
	(function(t, e, r) {
		if (e + 1 < t.byteLength) t.setUint16(e, r, !1);
		else {
			var n = r >> 8 & 255;
			t.setUint8(e, n);
		}
	})(t, a, ne(t, a) & ~(s << o) & 65535 | u);
	/**
	* @license
	* (c) Dean McNamee <dean@gmail.com>, 2013.
	*
	* https://github.com/deanm/omggif
	*
	* Permission is hereby granted, free of charge, to any person obtaining a copy
	* of this software and associated documentation files (the "Software"), to
	* deal in the Software without restriction, including without limitation the
	* rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
	* sell copies of the Software, and to permit persons to whom the Software is
	* furnished to do so, subject to the following conditions:
	*
	* The above copyright notice and this permission notice shall be included in
	* all copies or substantial portions of the Software.
	*
	* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
	* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
	* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
	* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
	* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
	* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
	* IN THE SOFTWARE.
	*
	* omggif is a JavaScript implementation of a GIF 89a encoder and decoder,
	* including animation and compression.  It does not rely on any specific
	* underlying system, so should run in the browser, Node, or Plask.
	*/
}
function ne(t, e) {
	return e + 1 < t.byteLength ? t.getUint16(e, !1) : t.getUint8(e) << 8;
}
function ie(t) {
	var e = 0;
	if (71 !== t[e++] || 73 !== t[e++] || 70 !== t[e++] || 56 !== t[e++] || 56 != (t[e++] + 1 & 253) || 97 !== t[e++]) throw new Error("Invalid GIF 87a/89a header.");
	var r = t[e++] | t[e++] << 8, n = t[e++] | t[e++] << 8, i = t[e++], a = i >> 7, o = 1 << 1 + (7 & i);
	t[e++], t[e++];
	var s = null, u = null;
	a && (s = e, u = o, e += 3 * o);
	var c = !0, l = [], h = 0, f = null, d = 0, p = null;
	for (this.width = r, this.height = n; c && e < t.length;) switch (t[e++]) {
		case 33:
			switch (t[e++]) {
				case 255:
					if (11 !== t[e] || 78 == t[e + 1] && 69 == t[e + 2] && 84 == t[e + 3] && 83 == t[e + 4] && 67 == t[e + 5] && 65 == t[e + 6] && 80 == t[e + 7] && 69 == t[e + 8] && 50 == t[e + 9] && 46 == t[e + 10] && 48 == t[e + 11] && 3 == t[e + 12] && 1 == t[e + 13] && 0 == t[e + 16]) e += 14, p = t[e++] | t[e++] << 8, e++;
					else for (e += 12;;) {
						if (!((P = t[e++]) >= 0)) throw Error("Invalid block size");
						if (0 === P) break;
						e += P;
					}
					break;
				case 249:
					if (4 !== t[e++] || 0 !== t[e + 4]) throw new Error("Invalid graphics extension block.");
					var g = t[e++];
					h = t[e++] | t[e++] << 8, f = t[e++], 1 & g || (f = null), d = g >> 2 & 7, e++;
					break;
				case 254:
					for (;;) {
						if (!((P = t[e++]) >= 0)) throw Error("Invalid block size");
						if (0 === P) break;
						e += P;
					}
					break;
				default: throw new Error("Unknown graphic control label: 0x" + t[e - 1].toString(16));
			}
			break;
		case 44:
			var m = t[e++] | t[e++] << 8, v = t[e++] | t[e++] << 8, b = t[e++] | t[e++] << 8, y = t[e++] | t[e++] << 8, w = t[e++], N = w >> 6 & 1, L = 1 << 1 + (7 & w), x = s, A = u, S = !1;
			w >> 7 && (S = !0, x = e, A = L, e += 3 * L);
			var _ = e;
			for (e++;;) {
				var P;
				if (!((P = t[e++]) >= 0)) throw Error("Invalid block size");
				if (0 === P) break;
				e += P;
			}
			l.push({
				x: m,
				y: v,
				width: b,
				height: y,
				has_local_palette: S,
				palette_offset: x,
				palette_size: A,
				data_offset: _,
				data_length: e - _,
				transparent_index: f,
				interlaced: !!N,
				delay: h,
				disposal: d
			});
			break;
		case 59:
			c = !1;
			break;
		default: throw new Error("Unknown gif block: 0x" + t[e - 1].toString(16));
	}
	this.numFrames = function() {
		return l.length;
	}, this.loopCount = function() {
		return p;
	}, this.frameInfo = function(t) {
		if (t < 0 || t >= l.length) throw new Error("Frame index out of range.");
		return l[t];
	}, this.decodeAndBlitFrameBGRA = function(e, n) {
		var i = this.frameInfo(e), a = i.width * i.height;
		if (a > 536870912) throw new Error("Image dimensions exceed 512MB, which is too large.");
		var o = new Uint8Array(a);
		ae(t, i.data_offset, o, a);
		var s = i.palette_offset, u = i.transparent_index;
		null === u && (u = 256);
		var c = i.width, l = r - c, h = c, f = 4 * (i.y * r + i.x), d = 4 * ((i.y + i.height) * r + i.x), p = f, g = 4 * l;
		!0 === i.interlaced && (g += 4 * r * 7);
		for (var m = 8, v = 0, b = o.length; v < b; ++v) {
			var y = o[v];
			if (0 === h && (h = c, (p += g) >= d && (g = 4 * l + 4 * r * (m - 1), p = f + (c + l) * (m << 1), m >>= 1)), y === u) p += 4;
			else {
				var w = t[s + 3 * y], N = t[s + 3 * y + 1], L = t[s + 3 * y + 2];
				n[p++] = L, n[p++] = N, n[p++] = w, n[p++] = 255;
			}
			--h;
		}
	}, this.decodeAndBlitFrameRGBA = function(e, n) {
		var i = this.frameInfo(e), a = i.width * i.height;
		if (a > 536870912) throw new Error("Image dimensions exceed 512MB, which is too large.");
		var o = new Uint8Array(a);
		ae(t, i.data_offset, o, a);
		var s = i.palette_offset, u = i.transparent_index;
		null === u && (u = 256);
		var c = i.width, l = r - c, h = c, f = 4 * (i.y * r + i.x), d = 4 * ((i.y + i.height) * r + i.x), p = f, g = 4 * l;
		!0 === i.interlaced && (g += 4 * r * 7);
		for (var m = 8, v = 0, b = o.length; v < b; ++v) {
			var y = o[v];
			if (0 === h && (h = c, (p += g) >= d && (g = 4 * l + 4 * r * (m - 1), p = f + (c + l) * (m << 1), m >>= 1)), y === u) p += 4;
			else {
				var w = t[s + 3 * y], N = t[s + 3 * y + 1], L = t[s + 3 * y + 2];
				n[p++] = w, n[p++] = N, n[p++] = L, n[p++] = 255;
			}
			--h;
		}
	};
}
function ae(t, e, r, n) {
	for (var i = t[e++], a = 1 << i, s = a + 1, u = s + 1, c = i + 1, l = (1 << c) - 1, h = 0, f = 0, d = 0, p = t[e++], g = /* @__PURE__ */ new Int32Array(4096), m = null;;) {
		for (; h < 16 && 0 !== p;) f |= t[e++] << h, h += 8, 1 === p ? p = t[e++] : --p;
		if (h < c) break;
		var v = f & l;
		if (f >>= c, h -= c, v !== a) {
			if (v === s) break;
			for (var b = v < u ? v : m, y = 0, w = b; w > a;) w = g[w] >> 8, ++y;
			var N = w;
			if (d + y + (b !== v ? 1 : 0) > n) return void o.log("Warning, gif stream longer than expected.");
			r[d++] = N;
			var L = d += y;
			for (b !== v && (r[d++] = N), w = b; y--;) w = g[w], r[--L] = 255 & w, w >>= 8;
			null !== m && u < 4096 && (g[u++] = m << 8 | N, u >= l + 1 && c < 12 && (++c, l = l << 1 | 1)), m = v;
		} else u = s + 1, l = (1 << (c = i + 1)) - 1, m = null;
	}
	return d !== n && o.log("Warning, gif stream shorter than expected."), r;
}
/**
* @license
Copyright (c) 2008, Adobe Systems Incorporated
All rights reserved.

Redistribution and use in source and binary forms, with or without 
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright notice, 
this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the 
documentation and/or other materials provided with the distribution.

* Neither the name of Adobe Systems Incorporated nor the names of its 
contributors may be used to endorse or promote products derived from 
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/ function oe(t) {
	var e, r, n, i, a, o = Math.floor, s = new Array(64), u = new Array(64), c = new Array(64), l = new Array(64), h = new Array(65535), f = new Array(65535), d = new Array(64), p = new Array(64), g = [], m = 0, v = 7, b = new Array(64), y = new Array(64), w = new Array(64), N = new Array(256), L = new Array(2048), x = [
		0,
		1,
		5,
		6,
		14,
		15,
		27,
		28,
		2,
		4,
		7,
		13,
		16,
		26,
		29,
		42,
		3,
		8,
		12,
		17,
		25,
		30,
		41,
		43,
		9,
		11,
		18,
		24,
		31,
		40,
		44,
		53,
		10,
		19,
		23,
		32,
		39,
		45,
		52,
		54,
		20,
		22,
		33,
		38,
		46,
		51,
		55,
		60,
		21,
		34,
		37,
		47,
		50,
		56,
		59,
		61,
		35,
		36,
		48,
		49,
		57,
		58,
		62,
		63
	], A = [
		0,
		0,
		1,
		5,
		1,
		1,
		1,
		1,
		1,
		1,
		0,
		0,
		0,
		0,
		0,
		0,
		0
	], S = [
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9,
		10,
		11
	], _ = [
		0,
		0,
		2,
		1,
		3,
		3,
		2,
		4,
		3,
		5,
		5,
		4,
		4,
		0,
		0,
		1,
		125
	], P = [
		1,
		2,
		3,
		0,
		4,
		17,
		5,
		18,
		33,
		49,
		65,
		6,
		19,
		81,
		97,
		7,
		34,
		113,
		20,
		50,
		129,
		145,
		161,
		8,
		35,
		66,
		177,
		193,
		21,
		82,
		209,
		240,
		36,
		51,
		98,
		114,
		130,
		9,
		10,
		22,
		23,
		24,
		25,
		26,
		37,
		38,
		39,
		40,
		41,
		42,
		52,
		53,
		54,
		55,
		56,
		57,
		58,
		67,
		68,
		69,
		70,
		71,
		72,
		73,
		74,
		83,
		84,
		85,
		86,
		87,
		88,
		89,
		90,
		99,
		100,
		101,
		102,
		103,
		104,
		105,
		106,
		115,
		116,
		117,
		118,
		119,
		120,
		121,
		122,
		131,
		132,
		133,
		134,
		135,
		136,
		137,
		138,
		146,
		147,
		148,
		149,
		150,
		151,
		152,
		153,
		154,
		162,
		163,
		164,
		165,
		166,
		167,
		168,
		169,
		170,
		178,
		179,
		180,
		181,
		182,
		183,
		184,
		185,
		186,
		194,
		195,
		196,
		197,
		198,
		199,
		200,
		201,
		202,
		210,
		211,
		212,
		213,
		214,
		215,
		216,
		217,
		218,
		225,
		226,
		227,
		228,
		229,
		230,
		231,
		232,
		233,
		234,
		241,
		242,
		243,
		244,
		245,
		246,
		247,
		248,
		249,
		250
	], k = [
		0,
		0,
		3,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		0,
		0,
		0,
		0,
		0
	], F = [
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9,
		10,
		11
	], I = [
		0,
		0,
		2,
		1,
		2,
		4,
		4,
		3,
		4,
		7,
		5,
		4,
		4,
		0,
		1,
		2,
		119
	], C = [
		0,
		1,
		2,
		3,
		17,
		4,
		5,
		33,
		49,
		6,
		18,
		65,
		81,
		7,
		97,
		113,
		19,
		34,
		50,
		129,
		8,
		20,
		66,
		145,
		161,
		177,
		193,
		9,
		35,
		51,
		82,
		240,
		21,
		98,
		114,
		209,
		10,
		22,
		36,
		52,
		225,
		37,
		241,
		23,
		24,
		25,
		26,
		38,
		39,
		40,
		41,
		42,
		53,
		54,
		55,
		56,
		57,
		58,
		67,
		68,
		69,
		70,
		71,
		72,
		73,
		74,
		83,
		84,
		85,
		86,
		87,
		88,
		89,
		90,
		99,
		100,
		101,
		102,
		103,
		104,
		105,
		106,
		115,
		116,
		117,
		118,
		119,
		120,
		121,
		122,
		130,
		131,
		132,
		133,
		134,
		135,
		136,
		137,
		138,
		146,
		147,
		148,
		149,
		150,
		151,
		152,
		153,
		154,
		162,
		163,
		164,
		165,
		166,
		167,
		168,
		169,
		170,
		178,
		179,
		180,
		181,
		182,
		183,
		184,
		185,
		186,
		194,
		195,
		196,
		197,
		198,
		199,
		200,
		201,
		202,
		210,
		211,
		212,
		213,
		214,
		215,
		216,
		217,
		218,
		226,
		227,
		228,
		229,
		230,
		231,
		232,
		233,
		234,
		242,
		243,
		244,
		245,
		246,
		247,
		248,
		249,
		250
	];
	function j(t, e) {
		for (var r = 0, n = 0, i = new Array(), a = 1; a <= 16; a++) {
			for (var o = 1; o <= t[a]; o++) i[e[n]] = [], i[e[n]][0] = r, i[e[n]][1] = a, n++, r++;
			r *= 2;
		}
		return i;
	}
	function O(t) {
		for (var e = t[0], r = t[1] - 1; r >= 0;) e & 1 << r && (m |= 1 << v), r--, --v < 0 && (255 == m ? (B(255), B(0)) : B(m), v = 7, m = 0);
	}
	function B(t) {
		g.push(t);
	}
	function M(t) {
		B(t >> 8 & 255), B(255 & t);
	}
	function q(t, e, r, n, i) {
		for (var a, o = i[0], s = i[240], u = function(t, e) {
			var r, n, i, a, o, s, u, c, l, h, f = 0;
			for (l = 0; l < 8; ++l) {
				r = t[f], n = t[f + 1], i = t[f + 2], a = t[f + 3], o = t[f + 4], s = t[f + 5], u = t[f + 6];
				var p = r + (c = t[f + 7]), g = r - c, m = n + u, v = n - u, b = i + s, y = i - s, w = a + o, N = a - o, L = p + w, x = p - w, A = m + b, S = m - b;
				t[f] = L + A, t[f + 4] = L - A;
				var _ = .707106781 * (S + x);
				t[f + 2] = x + _, t[f + 6] = x - _;
				var P = .382683433 * ((L = N + y) - (S = v + g)), k = .5411961 * L + P, F = 1.306562965 * S + P, I = .707106781 * (A = y + v), C = g + I, j = g - I;
				t[f + 5] = j + k, t[f + 3] = j - k, t[f + 1] = C + F, t[f + 7] = C - F, f += 8;
			}
			for (f = 0, l = 0; l < 8; ++l) {
				r = t[f], n = t[f + 8], i = t[f + 16], a = t[f + 24], o = t[f + 32], s = t[f + 40], u = t[f + 48];
				var O = r + (c = t[f + 56]), B = r - c, M = n + u, q = n - u, E = i + s, R = i - s, D = a + o, T = a - o, z = O + D, U = O - D, H = M + E, W = M - E;
				t[f] = z + H, t[f + 32] = z - H;
				var V = .707106781 * (W + U);
				t[f + 16] = U + V, t[f + 48] = U - V;
				var G = .382683433 * ((z = T + R) - (W = q + B)), Y = .5411961 * z + G, J = 1.306562965 * W + G, X = .707106781 * (H = R + q), K = B + X, Z = B - X;
				t[f + 40] = Z + Y, t[f + 24] = Z - Y, t[f + 8] = K + J, t[f + 56] = K - J, f++;
			}
			for (l = 0; l < 64; ++l) h = t[l] * e[l], d[l] = h > 0 ? h + .5 | 0 : h - .5 | 0;
			return d;
		}(t, e), c = 0; c < 64; ++c) p[x[c]] = u[c];
		var l = p[0] - r;
		r = p[0], 0 == l ? O(n[0]) : (O(n[f[a = 32767 + l]]), O(h[a]));
		for (var g = 63; g > 0 && 0 == p[g];) g--;
		if (0 == g) return O(o), r;
		for (var m, v = 1; v <= g;) {
			for (var b = v; 0 == p[v] && v <= g;) ++v;
			var y = v - b;
			if (y >= 16) {
				m = y >> 4;
				for (var w = 1; w <= m; ++w) O(s);
				y &= 15;
			}
			a = 32767 + p[v], O(i[(y << 4) + f[a]]), O(h[a]), v++;
		}
		return 63 != g && O(o), r;
	}
	function E(t) {
		t = Math.min(Math.max(t, 1), 100), a != t && (function(t) {
			for (var e = [
				16,
				11,
				10,
				16,
				24,
				40,
				51,
				61,
				12,
				12,
				14,
				19,
				26,
				58,
				60,
				55,
				14,
				13,
				16,
				24,
				40,
				57,
				69,
				56,
				14,
				17,
				22,
				29,
				51,
				87,
				80,
				62,
				18,
				22,
				37,
				56,
				68,
				109,
				103,
				77,
				24,
				35,
				55,
				64,
				81,
				104,
				113,
				92,
				49,
				64,
				78,
				87,
				103,
				121,
				120,
				101,
				72,
				92,
				95,
				98,
				112,
				100,
				103,
				99
			], r = 0; r < 64; r++) {
				var n = o((e[r] * t + 50) / 100);
				n = Math.min(Math.max(n, 1), 255), s[x[r]] = n;
			}
			for (var i = [
				17,
				18,
				24,
				47,
				99,
				99,
				99,
				99,
				18,
				21,
				26,
				66,
				99,
				99,
				99,
				99,
				24,
				26,
				56,
				99,
				99,
				99,
				99,
				99,
				47,
				66,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99,
				99
			], a = 0; a < 64; a++) {
				var h = o((i[a] * t + 50) / 100);
				h = Math.min(Math.max(h, 1), 255), u[x[a]] = h;
			}
			for (var f = [
				1,
				1.387039845,
				1.306562965,
				1.175875602,
				1,
				.785694958,
				.5411961,
				.275899379
			], d = 0, p = 0; p < 8; p++) for (var g = 0; g < 8; g++) c[d] = 1 / (s[x[d]] * f[p] * f[g] * 8), l[d] = 1 / (u[x[d]] * f[p] * f[g] * 8), d++;
		}(t < 50 ? Math.floor(5e3 / t) : Math.floor(200 - 2 * t)), a = t);
	}
	this.encode = function(t, a) {
		a && E(a), g = new Array(), m = 0, v = 7, M(65496), M(65504), M(16), B(74), B(70), B(73), B(70), B(0), B(1), B(1), B(0), M(1), M(1), B(0), B(0), function() {
			M(65499), M(132), B(0);
			for (var t = 0; t < 64; t++) B(s[t]);
			B(1);
			for (var e = 0; e < 64; e++) B(u[e]);
		}(), function(t, e) {
			M(65472), M(17), B(8), M(e), M(t), B(3), B(1), B(17), B(0), B(2), B(17), B(1), B(3), B(17), B(1);
		}(t.width, t.height), function() {
			M(65476), M(418), B(0);
			for (var t = 0; t < 16; t++) B(A[t + 1]);
			for (var e = 0; e <= 11; e++) B(S[e]);
			B(16);
			for (var r = 0; r < 16; r++) B(_[r + 1]);
			for (var n = 0; n <= 161; n++) B(P[n]);
			B(1);
			for (var i = 0; i < 16; i++) B(k[i + 1]);
			for (var a = 0; a <= 11; a++) B(F[a]);
			B(17);
			for (var o = 0; o < 16; o++) B(I[o + 1]);
			for (var s = 0; s <= 161; s++) B(C[s]);
		}(), M(65498), M(12), B(3), B(1), B(0), B(2), B(17), B(3), B(17), B(0), B(63), B(0);
		var o = 0, h = 0, f = 0;
		m = 0, v = 7, this.encode.displayName = "_encode_";
		for (var d, p, N, x, j, R, D, T, z, U = t.data, H = t.width, W = t.height, V = 4 * H, G = 0; G < W;) {
			for (d = 0; d < V;) {
				for (j = V * G + d, D = -1, T = 0, z = 0; z < 64; z++) R = j + (T = z >> 3) * V + (D = 4 * (7 & z)), G + T >= W && (R -= V * (G + 1 + T - W)), d + D >= V && (R -= d + D - V + 4), p = U[R++], N = U[R++], x = U[R++], b[z] = (L[p] + L[N + 256 | 0] + L[x + 512 | 0] >> 16) - 128, y[z] = (L[p + 768 | 0] + L[N + 1024 | 0] + L[x + 1280 | 0] >> 16) - 128, w[z] = (L[p + 1280 | 0] + L[N + 1536 | 0] + L[x + 1792 | 0] >> 16) - 128;
				o = q(b, c, o, e, n), h = q(y, l, h, r, i), f = q(w, l, f, r, i), d += 32;
			}
			G += 8;
		}
		if (v >= 0) {
			var Y = [];
			Y[1] = v + 1, Y[0] = (1 << v + 1) - 1, O(Y);
		}
		return M(65497), new Uint8Array(g);
	}, t = t || 50, function() {
		for (var t = String.fromCharCode, e = 0; e < 256; e++) N[e] = t(e);
	}(), e = j(A, S), r = j(k, F), n = j(_, P), i = j(I, C), function() {
		for (var t = 1, e = 2, r = 1; r <= 15; r++) {
			for (var n = t; n < e; n++) f[32767 + n] = r, h[32767 + n] = [], h[32767 + n][1] = r, h[32767 + n][0] = n;
			for (var i = -(e - 1); i <= -t; i++) f[32767 + i] = r, h[32767 + i] = [], h[32767 + i][1] = r, h[32767 + i][0] = e - 1 + i;
			t <<= 1, e <<= 1;
		}
	}(), function() {
		for (var t = 0; t < 256; t++) L[t] = 19595 * t, L[t + 256 | 0] = 38470 * t, L[t + 512 | 0] = 7471 * t + 32768, L[t + 768 | 0] = -11059 * t, L[t + 1024 | 0] = -21709 * t, L[t + 1280 | 0] = 32768 * t + 8421375, L[t + 1536 | 0] = -27439 * t, L[t + 1792 | 0] = -5329 * t;
	}(), E(t);
}
/**
* @license
* Copyright (c) 2017 Aras Abbasi
*
* Licensed under the MIT License.
* http://opensource.org/licenses/mit-license
*/ function se(t, e) {
	if (this.pos = 0, this.buffer = t, this.datav = new DataView(t.buffer), this.is_with_alpha = !!e, this.bottom_up = !0, this.flag = String.fromCharCode(this.buffer[0]) + String.fromCharCode(this.buffer[1]), this.pos += 2, -1 === [
		"BM",
		"BA",
		"CI",
		"CP",
		"IC",
		"PT"
	].indexOf(this.flag)) throw new Error("Invalid BMP File");
	this.parseHeader(), this.parseBGR();
}
function ue(t) {
	function e(t) {
		if (!t) throw Error("assert :P");
	}
	function r(t, e, r) {
		for (var n = 0; 4 > n; n++) if (t[e + n] != r.charCodeAt(n)) return !0;
		return !1;
	}
	function n(t, e, r, n, i) {
		for (var a = 0; a < i; a++) t[e + a] = r[n + a];
	}
	function i(t, e, r, n) {
		for (var i = 0; i < n; i++) t[e + i] = r;
	}
	function a(t) {
		return new Int32Array(t);
	}
	function o(t, e) {
		for (var r = [], n = 0; n < t; n++) r.push(new e());
		return r;
	}
	function s(t, e) {
		var r = [];
		return function t(r, n, i) {
			for (var a = i[n], o = 0; o < a && (r.push(i.length > n + 1 ? [] : new e()), !(i.length < n + 1)); o++) t(r[o], n + 1, i);
		}(r, 0, t), r;
	}
	var u = function() {
		var t = this;
		function u(t, e) {
			for (var r = 1 << e - 1 >>> 0; t & r;) r >>>= 1;
			return r ? (t & r - 1) + r : t;
		}
		function c(t, r, n, i, a) {
			e(!(i % n));
			do
				t[r + (i -= n)] = a;
			while (0 < i);
		}
		function l(t, r, n, i, o) {
			if (e(2328 >= o), 512 >= o) var s = a(512);
			else if (null == (s = a(o))) return 0;
			return function(t, r, n, i, o, s) {
				var l, f, d = r, p = 1 << n, g = a(16), m = a(16);
				for (e(0 != o), e(null != i), e(null != t), e(0 < n), f = 0; f < o; ++f) {
					if (15 < i[f]) return 0;
					++g[i[f]];
				}
				if (g[0] == o) return 0;
				for (m[1] = 0, l = 1; 15 > l; ++l) {
					if (g[l] > 1 << l) return 0;
					m[l + 1] = m[l] + g[l];
				}
				for (f = 0; f < o; ++f) l = i[f], 0 < i[f] && (s[m[l]++] = f);
				if (1 == m[15]) return (i = new h()).g = 0, i.value = s[0], c(t, d, 1, p, i), p;
				var v, b = -1, y = p - 1, w = 0, N = 1, L = 1, x = 1 << n;
				for (f = 0, l = 1, o = 2; l <= n; ++l, o <<= 1) {
					if (N += L <<= 1, 0 > (L -= g[l])) return 0;
					for (; 0 < g[l]; --g[l]) (i = new h()).g = l, i.value = s[f++], c(t, d + w, o, x, i), w = u(w, l);
				}
				for (l = n + 1, o = 2; 15 >= l; ++l, o <<= 1) {
					if (N += L <<= 1, 0 > (L -= g[l])) return 0;
					for (; 0 < g[l]; --g[l]) {
						if (i = new h(), (w & y) != b) {
							for (d += x, v = 1 << (b = l) - n; 15 > b && !(0 >= (v -= g[b]));) ++b, v <<= 1;
							p += x = 1 << (v = b - n), t[r + (b = w & y)].g = v + n, t[r + b].value = d - r - b;
						}
						i.g = l - n, i.value = s[f++], c(t, d + (w >> n), o, x, i), w = u(w, l);
					}
				}
				return N != 2 * m[15] - 1 ? 0 : p;
			}(t, r, n, i, o, s);
		}
		function h() {
			this.value = this.g = 0;
		}
		function f() {
			this.value = this.g = 0;
		}
		function d() {
			this.G = o(5, h), this.H = a(5), this.jc = this.Qb = this.qb = this.nd = 0, this.pd = o(Er, f);
		}
		function p(t, r, n, i) {
			e(null != t), e(null != r), e(2147483648 > i), t.Ca = 254, t.I = 0, t.b = -8, t.Ka = 0, t.oa = r, t.pa = n, t.Jd = r, t.Yc = n + i, t.Zc = 4 <= i ? n + i - 4 + 1 : n, _(t);
		}
		function g(t, e) {
			for (var r = 0; 0 < e--;) r |= k(t, 128) << e;
			return r;
		}
		function m(t, e) {
			var r = g(t, e);
			return P(t) ? -r : r;
		}
		function v(t, r, n, i) {
			var a, o = 0;
			for (e(null != t), e(null != r), e(4294967288 > i), t.Sb = i, t.Ra = 0, t.u = 0, t.h = 0, 4 < i && (i = 4), a = 0; a < i; ++a) o += r[n + a] << 8 * a;
			t.Ra = o, t.bb = i, t.oa = r, t.pa = n;
		}
		function b(t) {
			for (; 8 <= t.u && t.bb < t.Sb;) t.Ra >>>= 8, t.Ra += t.oa[t.pa + t.bb] << Tr - 8 >>> 0, ++t.bb, t.u -= 8;
			x(t) && (t.h = 1, t.u = 0);
		}
		function y(t, r) {
			if (e(0 <= r), !t.h && r <= Dr) {
				var n = L(t) & Rr[r];
				return t.u += r, b(t), n;
			}
			return t.h = 1, t.u = 0;
		}
		function w() {
			this.b = this.Ca = this.I = 0, this.oa = [], this.pa = 0, this.Jd = [], this.Yc = 0, this.Zc = [], this.Ka = 0;
		}
		function N() {
			this.Ra = 0, this.oa = [], this.h = this.u = this.bb = this.Sb = this.pa = 0;
		}
		function L(t) {
			return t.Ra >>> (t.u & Tr - 1) >>> 0;
		}
		function x(t) {
			return e(t.bb <= t.Sb), t.h || t.bb == t.Sb && t.u > Tr;
		}
		function A(t, e) {
			t.u = e, t.h = x(t);
		}
		function S(t) {
			t.u >= zr && (e(t.u >= zr), b(t));
		}
		function _(t) {
			e(null != t && null != t.oa), t.pa < t.Zc ? (t.I = (t.oa[t.pa++] | t.I << 8) >>> 0, t.b += 8) : (e(null != t && null != t.oa), t.pa < t.Yc ? (t.b += 8, t.I = t.oa[t.pa++] | t.I << 8) : t.Ka ? t.b = 0 : (t.I <<= 8, t.b += 8, t.Ka = 1));
		}
		function P(t) {
			return g(t, 1);
		}
		function k(t, e) {
			var r = t.Ca;
			0 > t.b && _(t);
			var n = t.b, i = r * e >>> 8, a = (t.I >>> n > i) + 0;
			for (a ? (r -= i, t.I -= i + 1 << n >>> 0) : r = i + 1, n = r, i = 0; 256 <= n;) i += 8, n >>= 8;
			return n = 7 ^ i + Ur[n], t.b -= n, t.Ca = (r << n) - 1, a;
		}
		function F(t, e, r) {
			t[e + 0] = r >> 24 & 255, t[e + 1] = r >> 16 & 255, t[e + 2] = r >> 8 & 255, t[e + 3] = 255 & r;
		}
		function I(t, e) {
			return t[e + 0] | t[e + 1] << 8;
		}
		function C(t, e) {
			return I(t, e) | t[e + 2] << 16;
		}
		function j(t, e) {
			return I(t, e) | I(t, e + 2) << 16;
		}
		function O(t, r) {
			var n = 1 << r;
			return e(null != t), e(0 < r), t.X = a(n), null == t.X ? 0 : (t.Mb = 32 - r, t.Xa = r, 1);
		}
		function B(t, r) {
			e(null != t), e(null != r), e(t.Xa == r.Xa), n(r.X, 0, t.X, 0, 1 << r.Xa);
		}
		function M() {
			this.X = [], this.Xa = this.Mb = 0;
		}
		function q(t, r, n, i) {
			e(null != n), e(null != i);
			var a = n[0], o = i[0];
			return 0 == a && (a = (t * o + r / 2) / r), 0 == o && (o = (r * a + t / 2) / t), 0 >= a || 0 >= o ? 0 : (n[0] = a, i[0] = o, 1);
		}
		function E(t, e) {
			return t + (1 << e) - 1 >>> e;
		}
		function R(t, e) {
			return ((4278255360 & t) + (4278255360 & e) >>> 0 & 4278255360) + ((16711935 & t) + (16711935 & e) >>> 0 & 16711935) >>> 0;
		}
		function D(e, r) {
			t[r] = function(r, n, i, a, o, s, u) {
				var c;
				for (c = 0; c < o; ++c) {
					var l = t[e](s[u + c - 1], i, a + c);
					s[u + c] = R(r[n + c], l);
				}
			};
		}
		function T() {
			this.ud = this.hd = this.jd = 0;
		}
		function z(t, e) {
			return ((4278124286 & (t ^ e)) >>> 1) + (t & e) >>> 0;
		}
		function U(t) {
			return 0 <= t && 256 > t ? t : 0 > t ? 0 : 255 < t ? 255 : void 0;
		}
		function H(t, e) {
			return U(t + (t - e + .5 >> 1));
		}
		function W(t, e, r) {
			return Math.abs(e - r) - Math.abs(t - r);
		}
		function V(t, e, r, n, i, a, o) {
			for (n = a[o - 1], r = 0; r < i; ++r) a[o + r] = n = R(t[e + r], n);
		}
		function G(t, e, r, n, i) {
			var a;
			for (a = 0; a < r; ++a) {
				var o = t[e + a], s = o >> 8 & 255, u = 16711935 & (u = (u = 16711935 & o) + ((s << 16) + s));
				n[i + a] = (4278255360 & o) + u >>> 0;
			}
		}
		function Y(t, e) {
			e.jd = 255 & t, e.hd = t >> 8 & 255, e.ud = t >> 16 & 255;
		}
		function J(t, e, r, n, i, a) {
			var o;
			for (o = 0; o < n; ++o) {
				var s = e[r + o], u = s >>> 8, c = s, l = 255 & (l = (l = s >>> 16) + ((t.jd << 24 >> 24) * (u << 24 >> 24) >>> 5));
				c = 255 & (c = (c += (t.hd << 24 >> 24) * (u << 24 >> 24) >>> 5) + ((t.ud << 24 >> 24) * (l << 24 >> 24) >>> 5)), i[a + o] = (4278255360 & s) + (l << 16) + c;
			}
		}
		function X(e, r, n, i, a) {
			t[r] = function(t, e, r, n, o, s, u, c, l) {
				for (n = u; n < c; ++n) for (u = 0; u < l; ++u) o[s++] = a(r[i(t[e++])]);
			}, t[e] = function(e, r, o, s, u, c, l) {
				var h = 8 >> e.b, f = e.Ea, d = e.K[0], p = e.w;
				if (8 > h) for (e = (1 << e.b) - 1, p = (1 << h) - 1; r < o; ++r) {
					var g, m = 0;
					for (g = 0; g < f; ++g) g & e || (m = i(s[u++])), c[l++] = a(d[m & p]), m >>= h;
				}
				else t["VP8LMapColor" + n](s, u, d, p, c, l, r, o, f);
			};
		}
		function K(t, e, r, n, i) {
			for (r = e + r; e < r;) {
				var a = t[e++];
				n[i++] = a >> 16 & 255, n[i++] = a >> 8 & 255, n[i++] = 255 & a;
			}
		}
		function Z(t, e, r, n, i) {
			for (r = e + r; e < r;) {
				var a = t[e++];
				n[i++] = a >> 16 & 255, n[i++] = a >> 8 & 255, n[i++] = 255 & a, n[i++] = a >> 24 & 255;
			}
		}
		function $(t, e, r, n, i) {
			for (r = e + r; e < r;) {
				var a = (o = t[e++]) >> 16 & 240 | o >> 12 & 15, o = 240 & o | o >> 28 & 15;
				n[i++] = a, n[i++] = o;
			}
		}
		function Q(t, e, r, n, i) {
			for (r = e + r; e < r;) {
				var a = (o = t[e++]) >> 16 & 248 | o >> 13 & 7, o = o >> 5 & 224 | o >> 3 & 31;
				n[i++] = a, n[i++] = o;
			}
		}
		function tt(t, e, r, n, i) {
			for (r = e + r; e < r;) {
				var a = t[e++];
				n[i++] = 255 & a, n[i++] = a >> 8 & 255, n[i++] = a >> 16 & 255;
			}
		}
		function et(t, e, r, i, a, o) {
			if (0 == o) for (r = e + r; e < r;) F(i, ((o = t[e++])[0] >> 24 | o[1] >> 8 & 65280 | o[2] << 8 & 16711680 | o[3] << 24) >>> 0), a += 32;
			else n(i, a, t, e, r);
		}
		function rt(e, r) {
			t[r][0] = t[e + "0"], t[r][1] = t[e + "1"], t[r][2] = t[e + "2"], t[r][3] = t[e + "3"], t[r][4] = t[e + "4"], t[r][5] = t[e + "5"], t[r][6] = t[e + "6"], t[r][7] = t[e + "7"], t[r][8] = t[e + "8"], t[r][9] = t[e + "9"], t[r][10] = t[e + "10"], t[r][11] = t[e + "11"], t[r][12] = t[e + "12"], t[r][13] = t[e + "13"], t[r][14] = t[e + "0"], t[r][15] = t[e + "0"];
		}
		function nt(t) {
			return t == Un || t == Hn || t == Wn || t == Vn;
		}
		function it() {
			this.eb = [], this.size = this.A = this.fb = 0;
		}
		function at() {
			this.y = [], this.f = [], this.ea = [], this.F = [], this.Tc = this.Ed = this.Cd = this.Fd = this.lb = this.Db = this.Ab = this.fa = this.J = this.W = this.N = this.O = 0;
		}
		function ot() {
			this.Rd = this.height = this.width = this.S = 0, this.f = {}, this.f.RGBA = new it(), this.f.kb = new at(), this.sd = null;
		}
		function st() {
			this.width = [0], this.height = [0], this.Pd = [0], this.Qd = [0], this.format = [0];
		}
		function ut() {
			this.Id = this.fd = this.Md = this.hb = this.ib = this.da = this.bd = this.cd = this.j = this.v = this.Da = this.Sd = this.ob = 0;
		}
		function ct(t) {
			return alert("todo:WebPSamplerProcessPlane"), t.T;
		}
		function lt(t, e) {
			var r = t.T, i = e.ba.f.RGBA, a = i.eb, o = i.fb + t.ka * i.A, s = mi[e.ba.S], u = t.y, c = t.O, l = t.f, h = t.N, f = t.ea, d = t.W, p = e.cc, g = e.dc, m = e.Mc, v = e.Nc, b = t.ka, y = t.ka + t.T, w = t.U, N = w + 1 >> 1;
			for (0 == b ? s(u, c, null, null, l, h, f, d, l, h, f, d, a, o, null, null, w) : (s(e.ec, e.fc, u, c, p, g, m, v, l, h, f, d, a, o - i.A, a, o, w), ++r); b + 2 < y; b += 2) p = l, g = h, m = f, v = d, h += t.Rc, d += t.Rc, o += 2 * i.A, s(u, (c += 2 * t.fa) - t.fa, u, c, p, g, m, v, l, h, f, d, a, o - i.A, a, o, w);
			return c += t.fa, t.j + y < t.o ? (n(e.ec, e.fc, u, c, w), n(e.cc, e.dc, l, h, N), n(e.Mc, e.Nc, f, d, N), r--) : 1 & y || s(u, c, null, null, l, h, f, d, l, h, f, d, a, o + i.A, null, null, w), r;
		}
		function ht(t, r, n) {
			var i = t.F, a = [t.J];
			if (null != i) {
				var o = t.U, s = r.ba.S, u = s == Dn || s == Wn;
				r = r.ba.f.RGBA;
				var c = [0], l = t.ka;
				c[0] = t.T, t.Kb && (0 == l ? --c[0] : (--l, a[0] -= t.width), t.j + t.ka + t.T == t.o && (c[0] = t.o - t.j - l));
				var h = r.eb;
				l = r.fb + l * r.A, t = An(i, a[0], t.width, o, c, h, l + (u ? 0 : 3), r.A), e(n == c), t && nt(s) && Ln(h, l, u, o, c, r.A);
			}
			return 0;
		}
		function ft(t) {
			var e = t.ma, r = e.ba.S, n = 11 > r, i = r == qn || r == Rn || r == Dn || r == Tn || 12 == r || nt(r);
			if (e.memory = null, e.Ib = null, e.Jb = null, e.Nd = null, !Br(e.Oa, t, i ? 11 : 12)) return 0;
			if (i && nt(r) && vr(), t.da) alert("todo:use_scaling");
			else {
				if (n) {
					if (e.Ib = ct, t.Kb) {
						if (r = t.U + 1 >> 1, e.memory = a(t.U + 2 * r), null == e.memory) return 0;
						e.ec = e.memory, e.fc = 0, e.cc = e.ec, e.dc = e.fc + t.U, e.Mc = e.cc, e.Nc = e.dc + r, e.Ib = lt, vr();
					}
				} else alert("todo:EmitYUV");
				i && (e.Jb = ht, n && gr());
			}
			if (n && !Ii) {
				for (t = 0; 256 > t; ++t) Ci[t] = 89858 * (t - 128) + Si >> Ai, Bi[t] = -22014 * (t - 128) + Si, Oi[t] = -45773 * (t - 128), ji[t] = 113618 * (t - 128) + Si >> Ai;
				for (t = _i; t < Pi; ++t) e = 76283 * (t - 16) + Si >> Ai, Mi[t - _i] = Vt(e, 255), qi[t - _i] = Vt(e + 8 >> 4, 15);
				Ii = 1;
			}
			return 1;
		}
		function dt(t) {
			var r = t.ma, n = t.U, i = t.T;
			return e(!(1 & t.ka)), 0 >= n || 0 >= i ? 0 : (n = r.Ib(t, r), null != r.Jb && r.Jb(t, r, n), r.Dc += n, 1);
		}
		function pt(t) {
			t.ma.memory = null;
		}
		function gt(t, e, r, n) {
			return 47 != y(t, 8) ? 0 : (e[0] = y(t, 14) + 1, r[0] = y(t, 14) + 1, n[0] = y(t, 1), 0 != y(t, 3) ? 0 : !t.h);
		}
		function mt(t, e) {
			if (4 > t) return t + 1;
			var r = t - 2 >> 1;
			return (2 + (1 & t) << r) + y(e, r) + 1;
		}
		function vt(t, e) {
			return 120 < e ? e - 120 : 1 <= (r = ((r = Zn[e - 1]) >> 4) * t + (8 - (15 & r))) ? r : 1;
			var r;
		}
		function bt(t, e, r) {
			var n = L(r), i = t[e += 255 & n].g - 8;
			return 0 < i && (A(r, r.u + 8), n = L(r), e += t[e].value, e += n & (1 << i) - 1), A(r, r.u + t[e].g), t[e].value;
		}
		function yt(t, r, n) {
			return n.g += t.g, n.value += t.value << r >>> 0, e(8 >= n.g), t.g;
		}
		function wt(t, r, n) {
			var i = t.xc;
			return e((r = 0 == i ? 0 : t.vc[t.md * (n >> i) + (r >> i)]) < t.Wb), t.Ya[r];
		}
		function Nt(t, r, i, a) {
			var o = t.ab, s = t.c * r, u = t.C;
			r = u + r;
			var c = i, l = a;
			for (a = t.Ta, i = t.Ua; 0 < o--;) {
				var h = t.gc[o], f = u, d = r, p = c, g = l, m = (l = a, c = i, h.Ea);
				switch (e(f < d), e(d <= h.nc), h.hc) {
					case 2:
						Vr(p, g, (d - f) * m, l, c);
						break;
					case 0:
						var v = f, b = d, y = l, w = c, N = (_ = h).Ea;
						0 == v && (Hr(p, g, null, null, 1, y, w), V(p, g + 1, 0, 0, N - 1, y, w + 1), g += N, w += N, ++v);
						for (var L = 1 << _.b, x = L - 1, A = E(N, _.b), S = _.K, _ = _.w + (v >> _.b) * A; v < b;) {
							var P = S, k = _, F = 1;
							for (Wr(p, g, y, w - N, 1, y, w); F < N;) {
								var I = (F & ~x) + L;
								I > N && (I = N), (0, Kr[P[k++] >> 8 & 15])(p, g + +F, y, w + F - N, I - F, y, w + F), F = I;
							}
							g += N, w += N, ++v & x || (_ += A);
						}
						d != h.nc && n(l, c - m, l, c + (d - f - 1) * m, m);
						break;
					case 1:
						for (m = p, b = g, N = (p = h.Ea) - (w = p & ~(y = (g = 1 << h.b) - 1)), v = E(p, h.b), L = h.K, h = h.w + (f >> h.b) * v; f < d;) {
							for (x = L, A = h, S = new T(), _ = b + w, P = b + p; b < _;) Y(x[A++], S), Zr(S, m, b, g, l, c), b += g, c += g;
							b < P && (Y(x[A++], S), Zr(S, m, b, N, l, c), b += N, c += N), ++f & y || (h += v);
						}
						break;
					case 3: if (p == l && g == c && 0 < h.b) {
						for (b = l, p = m = c + (d - f) * m - (w = (d - f) * E(h.Ea, h.b)), g = l, y = c, v = [], w = (N = w) - 1; 0 <= w; --w) v[w] = g[y + w];
						for (w = N - 1; 0 <= w; --w) b[p + w] = v[w];
						Gr(h, f, d, l, m, l, c);
					} else Gr(h, f, d, p, g, l, c);
				}
				c = a, l = i;
			}
			l != i && n(a, i, c, l, s);
		}
		function Lt(t, r) {
			var n = t.V, i = t.Ba + t.c * t.C, a = r - t.C;
			if (e(r <= t.l.o), e(16 >= a), 0 < a) {
				var o = t.l, s = t.Ta, u = t.Ua, c = o.width;
				if (Nt(t, a, n, i), a = u = [u], e((n = t.C) < (i = r)), e(o.v < o.va), i > o.o && (i = o.o), n < o.j) {
					var l = o.j - n;
					n = o.j, a[0] += l * c;
				}
				if (n >= i ? n = 0 : (a[0] += 4 * o.v, o.ka = n - o.j, o.U = o.va - o.v, o.T = i - n, n = 1), n) {
					if (u = u[0], 11 > (n = t.ca).S) {
						var h = n.f.RGBA, f = (i = n.S, a = o.U, o = o.T, l = h.eb, h.A), d = o;
						for (h = h.fb + t.Ma * h.A; 0 < d--;) {
							var p = s, g = u, m = a, v = l, b = h;
							switch (i) {
								case Mn:
									$r(p, g, m, v, b);
									break;
								case qn:
									Qr(p, g, m, v, b);
									break;
								case Un:
									Qr(p, g, m, v, b), Ln(v, b, 0, m, 1, 0);
									break;
								case En:
									rn(p, g, m, v, b);
									break;
								case Rn:
									et(p, g, m, v, b, 1);
									break;
								case Hn:
									et(p, g, m, v, b, 1), Ln(v, b, 0, m, 1, 0);
									break;
								case Dn:
									et(p, g, m, v, b, 0);
									break;
								case Wn:
									et(p, g, m, v, b, 0), Ln(v, b, 1, m, 1, 0);
									break;
								case Tn:
									tn(p, g, m, v, b);
									break;
								case Vn:
									tn(p, g, m, v, b), xn(v, b, m, 1, 0);
									break;
								case zn:
									en(p, g, m, v, b);
									break;
								default: e(0);
							}
							u += c, h += f;
						}
						t.Ma += o;
					} else alert("todo:EmitRescaledRowsYUVA");
					e(t.Ma <= n.height);
				}
			}
			t.C = r, e(t.C <= t.i);
		}
		function xt(t) {
			var e;
			if (0 < t.ua) return 0;
			for (e = 0; e < t.Wb; ++e) {
				var r = t.Ya[e].G, n = t.Ya[e].H;
				if (0 < r[1][n[1] + 0].g || 0 < r[2][n[2] + 0].g || 0 < r[3][n[3] + 0].g) return 0;
			}
			return 1;
		}
		function At(t, r, n, i, a, o) {
			if (0 != t.Z) {
				var s = t.qd, u = t.rd;
				for (e(null != gi[t.Z]); r < n; ++r) gi[t.Z](s, u, i, a, i, a, o), s = i, u = a, a += o;
				t.qd = s, t.rd = u;
			}
		}
		function St(t, r) {
			var n = t.l.ma, i = 0 == n.Z || 1 == n.Z ? t.l.j : t.C;
			if (i = t.C < i ? i : t.C, e(r <= t.l.o), r > i) {
				var a = t.l.width, o = n.ca, s = n.tb + a * i, u = t.V, c = t.Ba + t.c * i, l = t.gc;
				e(1 == t.ab), e(3 == l[0].hc), Jr(l[0], i, r, u, c, o, s), At(n, i, r, o, s, a);
			}
			t.C = t.Ma = r;
		}
		function _t(t, r, n, i, a, o, s) {
			var u = t.$ / i, c = t.$ % i, l = t.m, h = t.s, f = n + t.$, d = f;
			a = n + i * a;
			var p = n + i * o, g = 280 + h.ua, m = t.Pb ? u : 16777216, v = 0 < h.ua ? h.Wa : null, b = h.wc, y = f < p ? wt(h, c, u) : null;
			e(t.C < o), e(p <= a);
			var w = !1;
			t: for (;;) {
				for (; w || f < p;) {
					var N = 0;
					if (u >= m) {
						var _ = f - n;
						e((m = t).Pb), m.wd = m.m, m.xd = _, 0 < m.s.ua && B(m.s.Wa, m.s.vb), m = u + Qn;
					}
					if (c & b || (y = wt(h, c, u)), e(null != y), y.Qb && (r[f] = y.qb, w = !0), !w) if (S(l), y.jc) {
						N = l, _ = r;
						var P = f, k = y.pd[L(N) & Er - 1];
						e(y.jc), 256 > k.g ? (A(N, N.u + k.g), _[P] = k.value, N = 0) : (A(N, N.u + k.g - 256), e(256 <= k.value), N = k.value), 0 == N && (w = !0);
					} else N = bt(y.G[0], y.H[0], l);
					if (l.h) break;
					if (w || 256 > N) {
						if (!w) if (y.nd) r[f] = (y.qb | N << 8) >>> 0;
						else {
							if (S(l), w = bt(y.G[1], y.H[1], l), S(l), _ = bt(y.G[2], y.H[2], l), P = bt(y.G[3], y.H[3], l), l.h) break;
							r[f] = (P << 24 | w << 16 | N << 8 | _) >>> 0;
						}
						if (w = !1, ++f, ++c >= i && (c = 0, ++u, null != s && u <= o && !(u % 16) && s(t, u), null != v)) for (; d < f;) N = r[d++], v.X[(506832829 * N & 4294967295) >>> v.Mb] = N;
					} else if (280 > N) {
						if (N = mt(N - 256, l), _ = bt(y.G[4], y.H[4], l), S(l), _ = vt(i, _ = mt(_, l)), l.h) break;
						if (f - n < _ || a - f < N) break t;
						for (P = 0; P < N; ++P) r[f + P] = r[f + P - _];
						for (f += N, c += N; c >= i;) c -= i, ++u, null != s && u <= o && !(u % 16) && s(t, u);
						if (e(f <= a), c & b && (y = wt(h, c, u)), null != v) for (; d < f;) N = r[d++], v.X[(506832829 * N & 4294967295) >>> v.Mb] = N;
					} else {
						if (!(N < g)) break t;
						for (w = N - 280, e(null != v); d < f;) N = r[d++], v.X[(506832829 * N & 4294967295) >>> v.Mb] = N;
						N = f, e(!(w >>> (_ = v).Xa)), r[N] = _.X[w], w = !0;
					}
					w || e(l.h == x(l));
				}
				if (t.Pb && l.h && f < a) e(t.m.h), t.a = 5, t.m = t.wd, t.$ = t.xd, 0 < t.s.ua && B(t.s.vb, t.s.Wa);
				else {
					if (l.h) break t;
					s?.(t, u > o ? o : u), t.a = 0, t.$ = f - n;
				}
				return 1;
			}
			return t.a = 3, 0;
		}
		function Pt(t) {
			e(null != t), t.vc = null, t.yc = null, t.Ya = null;
			var r = t.Wa;
			null != r && (r.X = null), t.vb = null, e(null != t);
		}
		function kt() {
			var e = new ar();
			return null == e ? null : (e.a = 0, e.xb = pi, rt("Predictor", "VP8LPredictors"), rt("Predictor", "VP8LPredictors_C"), rt("PredictorAdd", "VP8LPredictorsAdd"), rt("PredictorAdd", "VP8LPredictorsAdd_C"), Vr = G, Zr = J, $r = K, Qr = Z, tn = $, en = Q, rn = tt, t.VP8LMapColor32b = Yr, t.VP8LMapColor8b = Xr, e);
		}
		function Ft(t, r, n, s, u) {
			var c = 1, f = [t], p = [r], g = s.m, m = s.s, v = null, b = 0;
			t: for (;;) {
				if (n) for (; c && y(g, 1);) {
					var w = f, N = p, x = s, _ = 1, P = x.m, k = x.gc[x.ab], F = y(P, 2);
					if (x.Oc & 1 << F) c = 0;
					else {
						switch (x.Oc |= 1 << F, k.hc = F, k.Ea = w[0], k.nc = N[0], k.K = [null], ++x.ab, e(4 >= x.ab), F) {
							case 0:
							case 1:
								k.b = y(P, 3) + 2, _ = Ft(E(k.Ea, k.b), E(k.nc, k.b), 0, x, k.K), k.K = k.K[0];
								break;
							case 3:
								var I, C = y(P, 8) + 1, j = 16 < C ? 0 : 4 < C ? 1 : 2 < C ? 2 : 3;
								if (w[0] = E(k.Ea, j), k.b = j, I = _ = Ft(C, 1, 0, x, k.K)) {
									var B, M = C, q = k, D = 1 << (8 >> q.b), T = a(D);
									if (null == T) I = 0;
									else {
										var z = q.K[0], U = q.w;
										for (T[0] = q.K[0][0], B = 1; B < 1 * M; ++B) T[B] = R(z[U + B], T[B - 1]);
										for (; B < 4 * D; ++B) T[B] = 0;
										q.K[0] = null, q.K[0] = T, I = 1;
									}
								}
								_ = I;
								break;
							case 2: break;
							default: e(0);
						}
						c = _;
					}
				}
				if (f = f[0], p = p[0], c && y(g, 1) && !(c = 1 <= (b = y(g, 4)) && 11 >= b)) {
					s.a = 3;
					break t;
				}
				var H;
				if (H = c) e: {
					var W, V, G, Y = s, J = f, X = p, K = b, Z = n, $ = Y.m, Q = Y.s, tt = [null], et = 1, rt = 0, nt = $n[K];
					r: for (;;) {
						if (Z && y($, 1)) {
							var it = y($, 3) + 2, at = E(J, it), ot = E(X, it), st = at * ot;
							if (!Ft(at, ot, 0, Y, tt)) break r;
							for (tt = tt[0], Q.xc = it, W = 0; W < st; ++W) {
								var ut = tt[W] >> 8 & 65535;
								tt[W] = ut, ut >= et && (et = ut + 1);
							}
						}
						if ($.h) break r;
						for (V = 0; 5 > V; ++V) {
							var ct = Jn[V];
							!V && 0 < K && (ct += 1 << K), rt < ct && (rt = ct);
						}
						var lt = o(et * nt, h), ht = et, ft = o(ht, d);
						if (null == ft) var dt = null;
						else e(65536 >= ht), dt = ft;
						var pt = a(rt);
						if (null == dt || null == pt || null == lt) {
							Y.a = 1;
							break r;
						}
						var gt = lt;
						for (W = G = 0; W < et; ++W) {
							var mt = dt[W], vt = mt.G, bt = mt.H, wt = 0, Nt = 1, Lt = 0;
							for (V = 0; 5 > V; ++V) {
								ct = Jn[V], vt[V] = gt, bt[V] = G, !V && 0 < K && (ct += 1 << K);
								n: {
									var xt, At = ct, St = Y, kt = pt, It = gt, Ct = G, jt = 0, Ot = St.m, Bt = y(Ot, 1);
									if (i(kt, 0, 0, At), Bt) {
										var Mt = y(Ot, 1) + 1, Et = y(Ot, 0 == y(Ot, 1) ? 1 : 8);
										kt[Et] = 1, 2 == Mt && (kt[Et = y(Ot, 8)] = 1);
										var Rt = 1;
									} else {
										var Dt = a(19), Tt = y(Ot, 4) + 4;
										if (19 < Tt) {
											St.a = 3;
											var zt = 0;
											break n;
										}
										for (xt = 0; xt < Tt; ++xt) Dt[Kn[xt]] = y(Ot, 3);
										var Ut = void 0, Ht = void 0, Wt = St, Vt = Dt, Gt = At, Yt = kt, Jt = 0, Xt = Wt.m, Kt = 8, Zt = o(128, h);
										i: for (; l(Zt, 0, 7, Vt, 19);) {
											if (y(Xt, 1)) {
												if ((Ut = 2 + y(Xt, 2 + 2 * y(Xt, 3))) > Gt) break i;
											} else Ut = Gt;
											for (Ht = 0; Ht < Gt && Ut--;) {
												S(Xt);
												var Qt = Zt[0 + (127 & L(Xt))];
												A(Xt, Xt.u + Qt.g);
												var te = Qt.value;
												if (16 > te) Yt[Ht++] = te, 0 != te && (Kt = te);
												else {
													var ee = 16 == te, re = te - 16, ne = Yn[re], ie = y(Xt, Gn[re]) + ne;
													if (Ht + ie > Gt) break i;
													for (var ae = ee ? Kt : 0; 0 < ie--;) Yt[Ht++] = ae;
												}
											}
											Jt = 1;
											break i;
										}
										Jt || (Wt.a = 3), Rt = Jt;
									}
									(Rt = Rt && !Ot.h) && (jt = l(It, Ct, 8, kt, At)), Rt && 0 != jt ? zt = jt : (St.a = 3, zt = 0);
								}
								if (0 == zt) break r;
								if (Nt && 1 == Xn[V] && (Nt = 0 == gt[G].g), wt += gt[G].g, G += zt, 3 >= V) {
									var oe, se = pt[0];
									for (oe = 1; oe < ct; ++oe) pt[oe] > se && (se = pt[oe]);
									Lt += se;
								}
							}
							if (mt.nd = Nt, mt.Qb = 0, Nt && (mt.qb = (vt[3][bt[3] + 0].value << 24 | vt[1][bt[1] + 0].value << 16 | vt[2][bt[2] + 0].value) >>> 0, 0 == wt && 256 > vt[0][bt[0] + 0].value && (mt.Qb = 1, mt.qb += vt[0][bt[0] + 0].value << 8)), mt.jc = !mt.Qb && 6 > Lt, mt.jc) {
								var ue, ce = mt;
								for (ue = 0; ue < Er; ++ue) {
									var le = ue, he = ce.pd[le], fe = ce.G[0][ce.H[0] + le];
									256 <= fe.value ? (he.g = fe.g + 256, he.value = fe.value) : (he.g = 0, he.value = 0, le >>= yt(fe, 8, he), le >>= yt(ce.G[1][ce.H[1] + le], 16, he), le >>= yt(ce.G[2][ce.H[2] + le], 0, he), yt(ce.G[3][ce.H[3] + le], 24, he));
								}
							}
						}
						Q.vc = tt, Q.Wb = et, Q.Ya = dt, Q.yc = lt, H = 1;
						break e;
					}
					H = 0;
				}
				if (!(c = H)) {
					s.a = 3;
					break t;
				}
				if (0 < b) {
					if (m.ua = 1 << b, !O(m.Wa, b)) {
						s.a = 1, c = 0;
						break t;
					}
				} else m.ua = 0;
				var de = s, pe = f, ge = p, me = de.s, ve = me.xc;
				if (de.c = pe, de.i = ge, me.md = E(pe, ve), me.wc = 0 == ve ? -1 : (1 << ve) - 1, n) {
					s.xb = di;
					break t;
				}
				if (null == (v = a(f * p))) {
					s.a = 1, c = 0;
					break t;
				}
				c = (c = _t(s, v, 0, f, p, p, null)) && !g.h;
				break t;
			}
			return c ? (null != u ? u[0] = v : (e(null == v), e(n)), s.$ = 0, n || Pt(m)) : Pt(m), c;
		}
		function It(t, r) {
			var n = t.c * t.i, i = n + r + 16 * r;
			return e(t.c <= r), t.V = a(i), null == t.V ? (t.Ta = null, t.Ua = 0, t.a = 1, 0) : (t.Ta = t.V, t.Ua = t.Ba + n + r, 1);
		}
		function Ct(t, r) {
			var n = t.C, i = r - n, a = t.V, o = t.Ba + t.c * n;
			for (e(r <= t.l.o); 0 < i;) {
				var s = 16 < i ? 16 : i, u = t.l.ma, c = t.l.width, l = c * s, h = u.ca, f = u.tb + c * n, d = t.Ta, p = t.Ua;
				Nt(t, s, a, o), Sn(d, p, h, f, l), At(u, n, n + s, h, f, c), i -= s, a += s * t.c, n += s;
			}
			e(n == r), t.C = t.Ma = r;
		}
		function jt() {
			this.ub = this.yd = this.td = this.Rb = 0;
		}
		function Ot() {
			this.Kd = this.Ld = this.Ud = this.Td = this.i = this.c = 0;
		}
		function Bt() {
			this.Fb = this.Bb = this.Cb = 0, this.Zb = a(4), this.Lb = a(4);
		}
		function Mt() {
			this.Yb = function() {
				var t = [];
				return function t(e, r, n) {
					for (var i = n[r], a = 0; a < i && (e.push(n.length > r + 1 ? [] : 0), !(n.length < r + 1)); a++) t(e[a], r + 1, n);
				}(t, 0, [3, 11]), t;
			}();
		}
		function qt() {
			this.jb = a(3), this.Wc = s([4, 8], Mt), this.Xc = s([4, 17], Mt);
		}
		function Et() {
			this.Pc = this.wb = this.Tb = this.zd = 0, this.vd = new a(4), this.od = new a(4);
		}
		function Rt() {
			this.ld = this.La = this.dd = this.tc = 0;
		}
		function Dt() {
			this.Na = this.la = 0;
		}
		function Tt() {
			this.Sc = [0, 0], this.Eb = [0, 0], this.Qc = [0, 0], this.ia = this.lc = 0;
		}
		function zt() {
			this.ad = a(384), this.Za = 0, this.Ob = a(16), this.$b = this.Ad = this.ia = this.Gc = this.Hc = this.Dd = 0;
		}
		function Ut() {
			this.uc = this.M = this.Nb = 0, this.wa = Array(new Rt()), this.Y = 0, this.ya = Array(new zt()), this.aa = 0, this.l = new Gt();
		}
		function Ht() {
			this.y = a(16), this.f = a(8), this.ea = a(8);
		}
		function Wt() {
			this.cb = this.a = 0, this.sc = "", this.m = new w(), this.Od = new jt(), this.Kc = new Ot(), this.ed = new Et(), this.Qa = new Bt(), this.Ic = this.$c = this.Aa = 0, this.D = new Ut(), this.Xb = this.Va = this.Hb = this.zb = this.yb = this.Ub = this.za = 0, this.Jc = o(8, w), this.ia = 0, this.pb = o(4, Tt), this.Pa = new qt(), this.Bd = this.kc = 0, this.Ac = [], this.Bc = 0, this.zc = [
				0,
				0,
				0,
				0
			], this.Gd = Array(new Ht()), this.Hd = 0, this.rb = Array(new Dt()), this.sb = 0, this.wa = Array(new Rt()), this.Y = 0, this.oc = [], this.pc = 0, this.sa = [], this.ta = 0, this.qa = [], this.ra = 0, this.Ha = [], this.B = this.R = this.Ia = 0, this.Ec = [], this.M = this.ja = this.Vb = this.Fc = 0, this.ya = Array(new zt()), this.L = this.aa = 0, this.gd = s([4, 2], Rt), this.ga = null, this.Fa = [], this.Cc = this.qc = this.P = 0, this.Gb = [], this.Uc = 0, this.mb = [], this.nb = 0, this.rc = [], this.Ga = this.Vc = 0;
		}
		function Vt(t, e) {
			return 0 > t ? 0 : t > e ? e : t;
		}
		function Gt() {
			this.T = this.U = this.ka = this.height = this.width = 0, this.y = [], this.f = [], this.ea = [], this.Rc = this.fa = this.W = this.N = this.O = 0, this.ma = "void", this.put = "VP8IoPutHook", this.ac = "VP8IoSetupHook", this.bc = "VP8IoTeardownHook", this.ha = this.Kb = 0, this.data = [], this.hb = this.ib = this.da = this.o = this.j = this.va = this.v = this.Da = this.ob = this.w = 0, this.F = [], this.J = 0;
		}
		function Yt() {
			var t = new Wt();
			return null != t && (t.a = 0, t.sc = "OK", t.cb = 0, t.Xb = 0, ri || (ri = Zt)), t;
		}
		function Jt(t, e, r) {
			return 0 == t.a && (t.a = e, t.sc = r, t.cb = 0), 0;
		}
		function Xt(t, e, r) {
			return 3 <= r && 157 == t[e + 0] && 1 == t[e + 1] && 42 == t[e + 2];
		}
		function Kt(t, r) {
			if (null == t) return 0;
			if (t.a = 0, t.sc = "OK", null == r) return Jt(t, 2, "null VP8Io passed to VP8GetHeaders()");
			var n = r.data, a = r.w, o = r.ha;
			if (4 > o) return Jt(t, 7, "Truncated header.");
			var s = n[a + 0] | n[a + 1] << 8 | n[a + 2] << 16, u = t.Od;
			if (u.Rb = !(1 & s), u.td = s >> 1 & 7, u.yd = s >> 4 & 1, u.ub = s >> 5, 3 < u.td) return Jt(t, 3, "Incorrect keyframe parameters.");
			if (!u.yd) return Jt(t, 4, "Frame not displayable.");
			a += 3, o -= 3;
			var c = t.Kc;
			if (u.Rb) {
				if (7 > o) return Jt(t, 7, "cannot parse picture header");
				if (!Xt(n, a, o)) return Jt(t, 3, "Bad code word");
				c.c = 16383 & (n[a + 4] << 8 | n[a + 3]), c.Td = n[a + 4] >> 6, c.i = 16383 & (n[a + 6] << 8 | n[a + 5]), c.Ud = n[a + 6] >> 6, a += 7, o -= 7, t.za = c.c + 15 >> 4, t.Ub = c.i + 15 >> 4, r.width = c.c, r.height = c.i, r.Da = 0, r.j = 0, r.v = 0, r.va = r.width, r.o = r.height, r.da = 0, r.ib = r.width, r.hb = r.height, r.U = r.width, r.T = r.height, i((s = t.Pa).jb, 0, 255, s.jb.length), e(null != (s = t.Qa)), s.Cb = 0, s.Bb = 0, s.Fb = 1, i(s.Zb, 0, 0, s.Zb.length), i(s.Lb, 0, 0, s.Lb);
			}
			if (u.ub > o) return Jt(t, 7, "bad partition length");
			p(s = t.m, n, a, u.ub), a += u.ub, o -= u.ub, u.Rb && (c.Ld = P(s), c.Kd = P(s)), c = t.Qa;
			var l, h = t.Pa;
			if (e(null != s), e(null != c), c.Cb = P(s), c.Cb) {
				if (c.Bb = P(s), P(s)) {
					for (c.Fb = P(s), l = 0; 4 > l; ++l) c.Zb[l] = P(s) ? m(s, 7) : 0;
					for (l = 0; 4 > l; ++l) c.Lb[l] = P(s) ? m(s, 6) : 0;
				}
				if (c.Bb) for (l = 0; 3 > l; ++l) h.jb[l] = P(s) ? g(s, 8) : 255;
			} else c.Bb = 0;
			if (s.Ka) return Jt(t, 3, "cannot parse segment header");
			if ((c = t.ed).zd = P(s), c.Tb = g(s, 6), c.wb = g(s, 3), c.Pc = P(s), c.Pc && P(s)) {
				for (h = 0; 4 > h; ++h) P(s) && (c.vd[h] = m(s, 6));
				for (h = 0; 4 > h; ++h) P(s) && (c.od[h] = m(s, 6));
			}
			if (t.L = 0 == c.Tb ? 0 : c.zd ? 1 : 2, s.Ka) return Jt(t, 3, "cannot parse filter header");
			var f = o;
			if (o = l = a, a = l + f, c = f, t.Xb = (1 << g(t.m, 2)) - 1, f < 3 * (h = t.Xb)) n = 7;
			else {
				for (l += 3 * h, c -= 3 * h, f = 0; f < h; ++f) {
					var d = n[o + 0] | n[o + 1] << 8 | n[o + 2] << 16;
					d > c && (d = c), p(t.Jc[+f], n, l, d), l += d, c -= d, o += 3;
				}
				p(t.Jc[+h], n, l, c), n = l < a ? 0 : 5;
			}
			if (0 != n) return Jt(t, n, "cannot parse partitions");
			for (n = g(l = t.m, 7), o = P(l) ? m(l, 4) : 0, a = P(l) ? m(l, 4) : 0, c = P(l) ? m(l, 4) : 0, h = P(l) ? m(l, 4) : 0, l = P(l) ? m(l, 4) : 0, f = t.Qa, d = 0; 4 > d; ++d) {
				if (f.Cb) {
					var v = f.Zb[d];
					f.Fb || (v += n);
				} else {
					if (0 < d) {
						t.pb[d] = t.pb[0];
						continue;
					}
					v = n;
				}
				var b = t.pb[d];
				b.Sc[0] = ti[Vt(v + o, 127)], b.Sc[1] = ei[Vt(v + 0, 127)], b.Eb[0] = 2 * ti[Vt(v + a, 127)], b.Eb[1] = 101581 * ei[Vt(v + c, 127)] >> 16, 8 > b.Eb[1] && (b.Eb[1] = 8), b.Qc[0] = ti[Vt(v + h, 117)], b.Qc[1] = ei[Vt(v + l, 127)], b.lc = v + l;
			}
			if (!u.Rb) return Jt(t, 4, "Not a key frame.");
			for (P(s), u = t.Pa, n = 0; 4 > n; ++n) {
				for (o = 0; 8 > o; ++o) for (a = 0; 3 > a; ++a) for (c = 0; 11 > c; ++c) h = k(s, ui[n][o][a][c]) ? g(s, 8) : oi[n][o][a][c], u.Wc[n][o].Yb[a][c] = h;
				for (o = 0; 17 > o; ++o) u.Xc[n][o] = u.Wc[n][ci[o]];
			}
			return t.kc = P(s), t.kc && (t.Bd = g(s, 8)), t.cb = 1;
		}
		function Zt(t, e, r, n, i, a, o) {
			var s = e[i].Yb[r];
			for (r = 0; 16 > i; ++i) {
				if (!k(t, s[r + 0])) return i;
				for (; !k(t, s[r + 1]);) if (s = e[++i].Yb[0], r = 0, 16 == i) return 16;
				var u = e[i + 1].Yb;
				if (k(t, s[r + 2])) {
					var c = t, l = 0;
					if (k(c, (f = s)[(h = r) + 3])) if (k(c, f[h + 6])) {
						for (s = 0, h = 2 * (l = k(c, f[h + 8])) + (f = k(c, f[h + 9 + l])), l = 0, f = ni[h]; f[s]; ++s) l += l + k(c, f[s]);
						l += 3 + (8 << h);
					} else k(c, f[h + 7]) ? (l = 7 + 2 * k(c, 165), l += k(c, 145)) : l = 5 + k(c, 159);
					else l = k(c, f[h + 4]) ? 3 + k(c, f[h + 5]) : 2;
					s = u[2];
				} else l = 1, s = u[1];
				u = o + ii[i], 0 > (c = t).b && _(c);
				var h, f = c.b, d = (h = c.Ca >> 1) - (c.I >> f) >> 31;
				--c.b, c.Ca += d, c.Ca |= 1, c.I -= (h + 1 & d) << f, a[u] = ((l ^ d) - d) * n[(0 < i) + 0];
			}
			return 16;
		}
		function $t(t) {
			var e = t.rb[t.sb - 1];
			e.la = 0, e.Na = 0, i(t.zc, 0, 0, t.zc.length), t.ja = 0;
		}
		function Qt(t, e, r, n, i) {
			i = t[e + r + 32 * n] + (i >> 3), t[e + r + 32 * n] = -256 & i ? 0 > i ? 0 : 255 : i;
		}
		function te(t, e, r, n, i, a) {
			Qt(t, e, 0, r, n + i), Qt(t, e, 1, r, n + a), Qt(t, e, 2, r, n - a), Qt(t, e, 3, r, n - i);
		}
		function ee(t) {
			return (20091 * t >> 16) + t;
		}
		function re(t, e, r, n) {
			var i, o = 0, s = a(16);
			for (i = 0; 4 > i; ++i) {
				var u = t[e + 0] + t[e + 8], c = t[e + 0] - t[e + 8], l = (35468 * t[e + 4] >> 16) - ee(t[e + 12]), h = ee(t[e + 4]) + (35468 * t[e + 12] >> 16);
				s[o + 0] = u + h, s[o + 1] = c + l, s[o + 2] = c - l, s[o + 3] = u - h, o += 4, e++;
			}
			for (i = o = 0; 4 > i; ++i) u = (t = s[o + 0] + 4) + s[o + 8], c = t - s[o + 8], l = (35468 * s[o + 4] >> 16) - ee(s[o + 12]), Qt(r, n, 0, 0, u + (h = ee(s[o + 4]) + (35468 * s[o + 12] >> 16))), Qt(r, n, 1, 0, c + l), Qt(r, n, 2, 0, c - l), Qt(r, n, 3, 0, u - h), o++, n += 32;
		}
		function ne(t, e, r, n) {
			var i = t[e + 0] + 4, a = 35468 * t[e + 4] >> 16, o = ee(t[e + 4]), s = 35468 * t[e + 1] >> 16;
			te(r, n, 0, i + o, t = ee(t[e + 1]), s), te(r, n, 1, i + a, t, s), te(r, n, 2, i - a, t, s), te(r, n, 3, i - o, t, s);
		}
		function ie(t, e, r, n, i) {
			re(t, e, r, n), i && re(t, e + 16, r, n + 4);
		}
		function ae(t, e, r, n) {
			an(t, e + 0, r, n, 1), an(t, e + 32, r, n + 128, 1);
		}
		function oe(t, e, r, n) {
			var i;
			for (t = t[e + 0] + 4, i = 0; 4 > i; ++i) for (e = 0; 4 > e; ++e) Qt(r, n, e, i, t);
		}
		function se(t, e, r, n) {
			t[e + 0] && un(t, e + 0, r, n), t[e + 16] && un(t, e + 16, r, n + 4), t[e + 32] && un(t, e + 32, r, n + 128), t[e + 48] && un(t, e + 48, r, n + 128 + 4);
		}
		function ue(t, e, r, n) {
			var i, o = a(16);
			for (i = 0; 4 > i; ++i) {
				var s = t[e + 0 + i] + t[e + 12 + i], u = t[e + 4 + i] + t[e + 8 + i], c = t[e + 4 + i] - t[e + 8 + i], l = t[e + 0 + i] - t[e + 12 + i];
				o[0 + i] = s + u, o[8 + i] = s - u, o[4 + i] = l + c, o[12 + i] = l - c;
			}
			for (i = 0; 4 > i; ++i) s = (t = o[0 + 4 * i] + 3) + o[3 + 4 * i], u = o[1 + 4 * i] + o[2 + 4 * i], c = o[1 + 4 * i] - o[2 + 4 * i], l = t - o[3 + 4 * i], r[n + 0] = s + u >> 3, r[n + 16] = l + c >> 3, r[n + 32] = s - u >> 3, r[n + 48] = l - c >> 3, n += 64;
		}
		function ce(t, e, r) {
			var n, i = e - 32, a = On, o = 255 - t[i - 1];
			for (n = 0; n < r; ++n) {
				var s, u = a, c = o + t[e - 1];
				for (s = 0; s < r; ++s) t[e + s] = u[c + t[i + s]];
				e += 32;
			}
		}
		function le(t, e) {
			ce(t, e, 4);
		}
		function he(t, e) {
			ce(t, e, 8);
		}
		function fe(t, e) {
			ce(t, e, 16);
		}
		function de(t, e) {
			var r;
			for (r = 0; 16 > r; ++r) n(t, e + 32 * r, t, e - 32, 16);
		}
		function pe(t, e) {
			var r;
			for (r = 16; 0 < r; --r) i(t, e, t[e - 1], 16), e += 32;
		}
		function ge(t, e, r) {
			var n;
			for (n = 0; 16 > n; ++n) i(e, r + 32 * n, t, 16);
		}
		function me(t, e) {
			var r, n = 16;
			for (r = 0; 16 > r; ++r) n += t[e - 1 + 32 * r] + t[e + r - 32];
			ge(n >> 5, t, e);
		}
		function ve(t, e) {
			var r, n = 8;
			for (r = 0; 16 > r; ++r) n += t[e - 1 + 32 * r];
			ge(n >> 4, t, e);
		}
		function be(t, e) {
			var r, n = 8;
			for (r = 0; 16 > r; ++r) n += t[e + r - 32];
			ge(n >> 4, t, e);
		}
		function ye(t, e) {
			ge(128, t, e);
		}
		function we(t, e, r) {
			return t + 2 * e + r + 2 >> 2;
		}
		function Ne(t, e) {
			var r, i = e - 32;
			for (i = new Uint8Array([
				we(t[i - 1], t[i + 0], t[i + 1]),
				we(t[i + 0], t[i + 1], t[i + 2]),
				we(t[i + 1], t[i + 2], t[i + 3]),
				we(t[i + 2], t[i + 3], t[i + 4])
			]), r = 0; 4 > r; ++r) n(t, e + 32 * r, i, 0, i.length);
		}
		function Le(t, e) {
			var r = t[e - 1], n = t[e - 1 + 32], i = t[e - 1 + 64], a = t[e - 1 + 96];
			F(t, e + 0, 16843009 * we(t[e - 1 - 32], r, n)), F(t, e + 32, 16843009 * we(r, n, i)), F(t, e + 64, 16843009 * we(n, i, a)), F(t, e + 96, 16843009 * we(i, a, a));
		}
		function xe(t, e) {
			var r, n = 4;
			for (r = 0; 4 > r; ++r) n += t[e + r - 32] + t[e - 1 + 32 * r];
			for (n >>= 3, r = 0; 4 > r; ++r) i(t, e + 32 * r, n, 4);
		}
		function Ae(t, e) {
			var r = t[e - 1 + 0], n = t[e - 1 + 32], i = t[e - 1 + 64], a = t[e - 1 - 32], o = t[e + 0 - 32], s = t[e + 1 - 32], u = t[e + 2 - 32], c = t[e + 3 - 32];
			t[e + 0 + 96] = we(n, i, t[e - 1 + 96]), t[e + 1 + 96] = t[e + 0 + 64] = we(r, n, i), t[e + 2 + 96] = t[e + 1 + 64] = t[e + 0 + 32] = we(a, r, n), t[e + 3 + 96] = t[e + 2 + 64] = t[e + 1 + 32] = t[e + 0 + 0] = we(o, a, r), t[e + 3 + 64] = t[e + 2 + 32] = t[e + 1 + 0] = we(s, o, a), t[e + 3 + 32] = t[e + 2 + 0] = we(u, s, o), t[e + 3 + 0] = we(c, u, s);
		}
		function Se(t, e) {
			var r = t[e + 1 - 32], n = t[e + 2 - 32], i = t[e + 3 - 32], a = t[e + 4 - 32], o = t[e + 5 - 32], s = t[e + 6 - 32], u = t[e + 7 - 32];
			t[e + 0 + 0] = we(t[e + 0 - 32], r, n), t[e + 1 + 0] = t[e + 0 + 32] = we(r, n, i), t[e + 2 + 0] = t[e + 1 + 32] = t[e + 0 + 64] = we(n, i, a), t[e + 3 + 0] = t[e + 2 + 32] = t[e + 1 + 64] = t[e + 0 + 96] = we(i, a, o), t[e + 3 + 32] = t[e + 2 + 64] = t[e + 1 + 96] = we(a, o, s), t[e + 3 + 64] = t[e + 2 + 96] = we(o, s, u), t[e + 3 + 96] = we(s, u, u);
		}
		function _e(t, e) {
			var r = t[e - 1 + 0], n = t[e - 1 + 32], i = t[e - 1 + 64], a = t[e - 1 - 32], o = t[e + 0 - 32], s = t[e + 1 - 32], u = t[e + 2 - 32], c = t[e + 3 - 32];
			t[e + 0 + 0] = t[e + 1 + 64] = a + o + 1 >> 1, t[e + 1 + 0] = t[e + 2 + 64] = o + s + 1 >> 1, t[e + 2 + 0] = t[e + 3 + 64] = s + u + 1 >> 1, t[e + 3 + 0] = u + c + 1 >> 1, t[e + 0 + 96] = we(i, n, r), t[e + 0 + 64] = we(n, r, a), t[e + 0 + 32] = t[e + 1 + 96] = we(r, a, o), t[e + 1 + 32] = t[e + 2 + 96] = we(a, o, s), t[e + 2 + 32] = t[e + 3 + 96] = we(o, s, u), t[e + 3 + 32] = we(s, u, c);
		}
		function Pe(t, e) {
			var r = t[e + 0 - 32], n = t[e + 1 - 32], i = t[e + 2 - 32], a = t[e + 3 - 32], o = t[e + 4 - 32], s = t[e + 5 - 32], u = t[e + 6 - 32], c = t[e + 7 - 32];
			t[e + 0 + 0] = r + n + 1 >> 1, t[e + 1 + 0] = t[e + 0 + 64] = n + i + 1 >> 1, t[e + 2 + 0] = t[e + 1 + 64] = i + a + 1 >> 1, t[e + 3 + 0] = t[e + 2 + 64] = a + o + 1 >> 1, t[e + 0 + 32] = we(r, n, i), t[e + 1 + 32] = t[e + 0 + 96] = we(n, i, a), t[e + 2 + 32] = t[e + 1 + 96] = we(i, a, o), t[e + 3 + 32] = t[e + 2 + 96] = we(a, o, s), t[e + 3 + 64] = we(o, s, u), t[e + 3 + 96] = we(s, u, c);
		}
		function ke(t, e) {
			var r = t[e - 1 + 0], n = t[e - 1 + 32], i = t[e - 1 + 64], a = t[e - 1 + 96];
			t[e + 0 + 0] = r + n + 1 >> 1, t[e + 2 + 0] = t[e + 0 + 32] = n + i + 1 >> 1, t[e + 2 + 32] = t[e + 0 + 64] = i + a + 1 >> 1, t[e + 1 + 0] = we(r, n, i), t[e + 3 + 0] = t[e + 1 + 32] = we(n, i, a), t[e + 3 + 32] = t[e + 1 + 64] = we(i, a, a), t[e + 3 + 64] = t[e + 2 + 64] = t[e + 0 + 96] = t[e + 1 + 96] = t[e + 2 + 96] = t[e + 3 + 96] = a;
		}
		function Fe(t, e) {
			var r = t[e - 1 + 0], n = t[e - 1 + 32], i = t[e - 1 + 64], a = t[e - 1 + 96], o = t[e - 1 - 32], s = t[e + 0 - 32], u = t[e + 1 - 32], c = t[e + 2 - 32];
			t[e + 0 + 0] = t[e + 2 + 32] = r + o + 1 >> 1, t[e + 0 + 32] = t[e + 2 + 64] = n + r + 1 >> 1, t[e + 0 + 64] = t[e + 2 + 96] = i + n + 1 >> 1, t[e + 0 + 96] = a + i + 1 >> 1, t[e + 3 + 0] = we(s, u, c), t[e + 2 + 0] = we(o, s, u), t[e + 1 + 0] = t[e + 3 + 32] = we(r, o, s), t[e + 1 + 32] = t[e + 3 + 64] = we(n, r, o), t[e + 1 + 64] = t[e + 3 + 96] = we(i, n, r), t[e + 1 + 96] = we(a, i, n);
		}
		function Ie(t, e) {
			var r;
			for (r = 0; 8 > r; ++r) n(t, e + 32 * r, t, e - 32, 8);
		}
		function Ce(t, e) {
			var r;
			for (r = 0; 8 > r; ++r) i(t, e, t[e - 1], 8), e += 32;
		}
		function je(t, e, r) {
			var n;
			for (n = 0; 8 > n; ++n) i(e, r + 32 * n, t, 8);
		}
		function Oe(t, e) {
			var r, n = 8;
			for (r = 0; 8 > r; ++r) n += t[e + r - 32] + t[e - 1 + 32 * r];
			je(n >> 4, t, e);
		}
		function Be(t, e) {
			var r, n = 4;
			for (r = 0; 8 > r; ++r) n += t[e + r - 32];
			je(n >> 3, t, e);
		}
		function Me(t, e) {
			var r, n = 4;
			for (r = 0; 8 > r; ++r) n += t[e - 1 + 32 * r];
			je(n >> 3, t, e);
		}
		function qe(t, e) {
			je(128, t, e);
		}
		function Ee(t, e, r) {
			var n = t[e - r], i = t[e + 0], a = 3 * (i - n) + Cn[1020 + t[e - 2 * r] - t[e + r]], o = jn[112 + (a + 4 >> 3)];
			t[e - r] = On[255 + n + jn[112 + (a + 3 >> 3)]], t[e + 0] = On[255 + i - o];
		}
		function Re(t, e, r, n) {
			var i = t[e + 0], a = t[e + r];
			return Bn[255 + t[e - 2 * r] - t[e - r]] > n || Bn[255 + a - i] > n;
		}
		function De(t, e, r, n) {
			return 4 * Bn[255 + t[e - r] - t[e + 0]] + Bn[255 + t[e - 2 * r] - t[e + r]] <= n;
		}
		function Te(t, e, r, n, i) {
			var a = t[e - 3 * r], o = t[e - 2 * r], s = t[e - r], u = t[e + 0], c = t[e + r], l = t[e + 2 * r], h = t[e + 3 * r];
			return 4 * Bn[255 + s - u] + Bn[255 + o - c] > n ? 0 : Bn[255 + t[e - 4 * r] - a] <= i && Bn[255 + a - o] <= i && Bn[255 + o - s] <= i && Bn[255 + h - l] <= i && Bn[255 + l - c] <= i && Bn[255 + c - u] <= i;
		}
		function ze(t, e, r, n) {
			var i = 2 * n + 1;
			for (n = 0; 16 > n; ++n) De(t, e + n, r, i) && Ee(t, e + n, r);
		}
		function Ue(t, e, r, n) {
			var i = 2 * n + 1;
			for (n = 0; 16 > n; ++n) De(t, e + n * r, 1, i) && Ee(t, e + n * r, 1);
		}
		function He(t, e, r, n) {
			var i;
			for (i = 3; 0 < i; --i) ze(t, e += 4 * r, r, n);
		}
		function We(t, e, r, n) {
			var i;
			for (i = 3; 0 < i; --i) Ue(t, e += 4, r, n);
		}
		function Ve(t, e, r, n, i, a, o, s) {
			for (a = 2 * a + 1; 0 < i--;) {
				if (Te(t, e, r, a, o)) if (Re(t, e, r, s)) Ee(t, e, r);
				else {
					var u = t, c = e, l = r, h = u[c - 2 * l], f = u[c - l], d = u[c + 0], p = u[c + l], g = u[c + 2 * l], m = 27 * (b = Cn[1020 + 3 * (d - f) + Cn[1020 + h - p]]) + 63 >> 7, v = 18 * b + 63 >> 7, b = 9 * b + 63 >> 7;
					u[c - 3 * l] = On[255 + u[c - 3 * l] + b], u[c - 2 * l] = On[255 + h + v], u[c - l] = On[255 + f + m], u[c + 0] = On[255 + d - m], u[c + l] = On[255 + p - v], u[c + 2 * l] = On[255 + g - b];
				}
				e += n;
			}
		}
		function Ge(t, e, r, n, i, a, o, s) {
			for (a = 2 * a + 1; 0 < i--;) {
				if (Te(t, e, r, a, o)) if (Re(t, e, r, s)) Ee(t, e, r);
				else {
					var u = t, c = e, l = r, h = u[c - l], f = u[c + 0], d = u[c + l], p = jn[112 + (4 + (g = 3 * (f - h)) >> 3)], g = jn[112 + (g + 3 >> 3)], m = p + 1 >> 1;
					u[c - 2 * l] = On[255 + u[c - 2 * l] + m], u[c - l] = On[255 + h + g], u[c + 0] = On[255 + f - p], u[c + l] = On[255 + d - m];
				}
				e += n;
			}
		}
		function Ye(t, e, r, n, i, a) {
			Ve(t, e, r, 1, 16, n, i, a);
		}
		function Je(t, e, r, n, i, a) {
			Ve(t, e, 1, r, 16, n, i, a);
		}
		function Xe(t, e, r, n, i, a) {
			var o;
			for (o = 3; 0 < o; --o) Ge(t, e += 4 * r, r, 1, 16, n, i, a);
		}
		function Ke(t, e, r, n, i, a) {
			var o;
			for (o = 3; 0 < o; --o) Ge(t, e += 4, 1, r, 16, n, i, a);
		}
		function Ze(t, e, r, n, i, a, o, s) {
			Ve(t, e, i, 1, 8, a, o, s), Ve(r, n, i, 1, 8, a, o, s);
		}
		function $e(t, e, r, n, i, a, o, s) {
			Ve(t, e, 1, i, 8, a, o, s), Ve(r, n, 1, i, 8, a, o, s);
		}
		function Qe(t, e, r, n, i, a, o, s) {
			Ge(t, e + 4 * i, i, 1, 8, a, o, s), Ge(r, n + 4 * i, i, 1, 8, a, o, s);
		}
		function tr(t, e, r, n, i, a, o, s) {
			Ge(t, e + 4, 1, i, 8, a, o, s), Ge(r, n + 4, 1, i, 8, a, o, s);
		}
		function er() {
			this.ba = new ot(), this.ec = [], this.cc = [], this.Mc = [], this.Dc = this.Nc = this.dc = this.fc = 0, this.Oa = new ut(), this.memory = 0, this.Ib = "OutputFunc", this.Jb = "OutputAlphaFunc", this.Nd = "OutputRowFunc";
		}
		function rr() {
			this.data = [], this.offset = this.kd = this.ha = this.w = 0, this.na = [], this.xa = this.gb = this.Ja = this.Sa = this.P = 0;
		}
		function nr() {
			this.nc = this.Ea = this.b = this.hc = 0, this.K = [], this.w = 0;
		}
		function ir() {
			this.ua = 0, this.Wa = new M(), this.vb = new M(), this.md = this.xc = this.wc = 0, this.vc = [], this.Wb = 0, this.Ya = new d(), this.yc = new h();
		}
		function ar() {
			this.xb = this.a = 0, this.l = new Gt(), this.ca = new ot(), this.V = [], this.Ba = 0, this.Ta = [], this.Ua = 0, this.m = new N(), this.Pb = 0, this.wd = new N(), this.Ma = this.$ = this.C = this.i = this.c = this.xd = 0, this.s = new ir(), this.ab = 0, this.gc = o(4, nr), this.Oc = 0;
		}
		function or() {
			this.Lc = this.Z = this.$a = this.i = this.c = 0, this.l = new Gt(), this.ic = 0, this.ca = [], this.tb = 0, this.qd = null, this.rd = 0;
		}
		function sr(t, e, r, n, i, a, o) {
			for (t = null == t ? 0 : t[e + 0], e = 0; e < o; ++e) i[a + e] = t + r[n + e] & 255, t = i[a + e];
		}
		function ur(t, e, r, n, i, a, o) {
			var s;
			if (null == t) sr(null, null, r, n, i, a, o);
			else for (s = 0; s < o; ++s) i[a + s] = t[e + s] + r[n + s] & 255;
		}
		function cr(t, e, r, n, i, a, o) {
			if (null == t) sr(null, null, r, n, i, a, o);
			else {
				var s, u = t[e + 0], c = u, l = u;
				for (s = 0; s < o; ++s) c = l + (u = t[e + s]) - c, l = r[n + s] + (-256 & c ? 0 > c ? 0 : 255 : c) & 255, c = u, i[a + s] = l;
			}
		}
		function lr(t, r, i, o) {
			var s = r.width, u = r.o;
			if (e(null != t && null != r), 0 > i || 0 >= o || i + o > u) return null;
			if (!t.Cc) {
				if (null == t.ga) {
					var c;
					if (t.ga = new or(), (c = null == t.ga) || (c = r.width * r.o, e(0 == t.Gb.length), t.Gb = a(c), t.Uc = 0, null == t.Gb ? c = 0 : (t.mb = t.Gb, t.nb = t.Uc, t.rc = null, c = 1), c = !c), !c) {
						c = t.ga;
						var l = t.Fa, h = t.P, f = t.qc, d = t.mb, p = t.nb, g = h + 1, m = f - 1, b = c.l;
						if (e(null != l && null != d && null != r), gi[0] = null, gi[1] = sr, gi[2] = ur, gi[3] = cr, c.ca = d, c.tb = p, c.c = r.width, c.i = r.height, e(0 < c.c && 0 < c.i), 1 >= f) r = 0;
						else if (c.$a = 3 & l[h + 0], c.Z = l[h + 0] >> 2 & 3, c.Lc = l[h + 0] >> 4 & 3, h = l[h + 0] >> 6 & 3, 0 > c.$a || 1 < c.$a || 4 <= c.Z || 1 < c.Lc || h) r = 0;
						else if (b.put = dt, b.ac = ft, b.bc = pt, b.ma = c, b.width = r.width, b.height = r.height, b.Da = r.Da, b.v = r.v, b.va = r.va, b.j = r.j, b.o = r.o, c.$a) t: {
							e(1 == c.$a), r = kt();
							e: for (;;) {
								if (null == r) {
									r = 0;
									break t;
								}
								if (e(null != c), c.mc = r, r.c = c.c, r.i = c.i, r.l = c.l, r.l.ma = c, r.l.width = c.c, r.l.height = c.i, r.a = 0, v(r.m, l, g, m), !Ft(c.c, c.i, 1, r, null)) break e;
								if (1 == r.ab && 3 == r.gc[0].hc && xt(r.s) ? (c.ic = 1, l = r.c * r.i, r.Ta = null, r.Ua = 0, r.V = a(l), r.Ba = 0, null == r.V ? (r.a = 1, r = 0) : r = 1) : (c.ic = 0, r = It(r, c.c)), !r) break e;
								r = 1;
								break t;
							}
							c.mc = null, r = 0;
						}
						else r = m >= c.c * c.i;
						c = !r;
					}
					if (c) return null;
					1 != t.ga.Lc ? t.Ga = 0 : o = u - i;
				}
				e(null != t.ga), e(i + o <= u);
				t: {
					if (r = (l = t.ga).c, u = l.l.o, 0 == l.$a) {
						if (g = t.rc, m = t.Vc, b = t.Fa, h = t.P + 1 + i * r, f = t.mb, d = t.nb + i * r, e(h <= t.P + t.qc), 0 != l.Z) for (e(null != gi[l.Z]), c = 0; c < o; ++c) gi[l.Z](g, m, b, h, f, d, r), g = f, m = d, d += r, h += r;
						else for (c = 0; c < o; ++c) n(f, d, b, h, r), g = f, m = d, d += r, h += r;
						t.rc = g, t.Vc = m;
					} else {
						if (e(null != l.mc), r = i + o, e(null != (c = l.mc)), e(r <= c.i), c.C >= r) r = 1;
						else if (l.ic || gr(), l.ic) {
							l = c.V, g = c.Ba, m = c.c;
							var y = c.i, w = (b = 1, h = c.$ / m, f = c.$ % m, d = c.m, p = c.s, c.$), N = m * y, L = m * r, A = p.wc, _ = w < L ? wt(p, f, h) : null;
							e(w <= N), e(r <= y), e(xt(p));
							e: for (;;) {
								for (; !d.h && w < L;) {
									if (f & A || (_ = wt(p, f, h)), e(null != _), S(d), 256 > (y = bt(_.G[0], _.H[0], d))) l[g + w] = y, ++w, ++f >= m && (f = 0, ++h <= r && !(h % 16) && St(c, h));
									else {
										if (!(280 > y)) {
											b = 0;
											break e;
										}
										y = mt(y - 256, d);
										var P, k = bt(_.G[4], _.H[4], d);
										if (S(d), !(w >= (k = vt(m, k = mt(k, d))) && N - w >= y)) {
											b = 0;
											break e;
										}
										for (P = 0; P < y; ++P) l[g + w + P] = l[g + w + P - k];
										for (w += y, f += y; f >= m;) f -= m, ++h <= r && !(h % 16) && St(c, h);
										w < L && f & A && (_ = wt(p, f, h));
									}
									e(d.h == x(d));
								}
								St(c, h > r ? r : h);
								break e;
							}
							!b || d.h && w < N ? (b = 0, c.a = d.h ? 5 : 3) : c.$ = w, r = b;
						} else r = _t(c, c.V, c.Ba, c.c, c.i, r, Ct);
						if (!r) {
							o = 0;
							break t;
						}
					}
					i + o >= u && (t.Cc = 1), o = 1;
				}
				if (!o) return null;
				if (t.Cc && (null != (o = t.ga) && (o.mc = null), t.ga = null, 0 < t.Ga)) return alert("todo:WebPDequantizeLevels"), null;
			}
			return t.nb + i * s;
		}
		function hr(t, e, r, n, i, a) {
			for (; 0 < i--;) {
				var o, s = t, u = e + (r ? 1 : 0), c = t, l = e + (r ? 0 : 3);
				for (o = 0; o < n; ++o) {
					var h = c[l + 4 * o];
					255 != h && (h *= 32897, s[u + 4 * o + 0] = s[u + 4 * o + 0] * h >> 23, s[u + 4 * o + 1] = s[u + 4 * o + 1] * h >> 23, s[u + 4 * o + 2] = s[u + 4 * o + 2] * h >> 23);
				}
				e += a;
			}
		}
		function fr(t, e, r, n, i) {
			for (; 0 < n--;) {
				var a;
				for (a = 0; a < r; ++a) {
					var o = t[e + 2 * a + 0], s = 15 & (c = t[e + 2 * a + 1]), u = 4369 * s, c = (240 & c | c >> 4) * u >> 16;
					t[e + 2 * a + 0] = (240 & o | o >> 4) * u >> 16 & 240 | (15 & o | o << 4) * u >> 16 >> 4 & 15, t[e + 2 * a + 1] = 240 & c | s;
				}
				e += i;
			}
		}
		function dr(t, e, r, n, i, a, o, s) {
			var u, c, l = 255;
			for (c = 0; c < i; ++c) {
				for (u = 0; u < n; ++u) {
					var h = t[e + u];
					a[o + 4 * u] = h, l &= h;
				}
				e += r, o += s;
			}
			return 255 != l;
		}
		function pr(t, e, r, n, i) {
			var a;
			for (a = 0; a < i; ++a) r[n + a] = t[e + a] >> 8;
		}
		function gr() {
			Ln = hr, xn = fr, An = dr, Sn = pr;
		}
		function mr(r, n, i) {
			t[r] = function(t, r, a, o, s, u, c, l, h, f, d, p, g, m, v, b, y) {
				var w, N = y - 1 >> 1, L = s[u + 0] | c[l + 0] << 16, x = h[f + 0] | d[p + 0] << 16;
				e(null != t);
				var A = 3 * L + x + 131074 >> 2;
				for (n(t[r + 0], 255 & A, A >> 16, g, m), null != a && (A = 3 * x + L + 131074 >> 2, n(a[o + 0], 255 & A, A >> 16, v, b)), w = 1; w <= N; ++w) {
					var S = s[u + w] | c[l + w] << 16, _ = h[f + w] | d[p + w] << 16, P = L + S + x + _ + 524296, k = P + 2 * (S + x) >> 3;
					A = k + L >> 1, L = (P = P + 2 * (L + _) >> 3) + S >> 1, n(t[r + 2 * w - 1], 255 & A, A >> 16, g, m + (2 * w - 1) * i), n(t[r + 2 * w - 0], 255 & L, L >> 16, g, m + (2 * w - 0) * i), null != a && (A = P + x >> 1, L = k + _ >> 1, n(a[o + 2 * w - 1], 255 & A, A >> 16, v, b + (2 * w - 1) * i), n(a[o + 2 * w + 0], 255 & L, L >> 16, v, b + (2 * w + 0) * i)), L = S, x = _;
				}
				1 & y || (A = 3 * L + x + 131074 >> 2, n(t[r + y - 1], 255 & A, A >> 16, g, m + (y - 1) * i), null != a && (A = 3 * x + L + 131074 >> 2, n(a[o + y - 1], 255 & A, A >> 16, v, b + (y - 1) * i)));
			};
		}
		function vr() {
			mi[Mn] = vi, mi[qn] = yi, mi[En] = bi, mi[Rn] = wi, mi[Dn] = Ni, mi[Tn] = Li, mi[zn] = xi, mi[Un] = yi, mi[Hn] = wi, mi[Wn] = Ni, mi[Vn] = Li;
		}
		function br(t) {
			return t & ~Fi ? 0 > t ? 0 : 255 : t >> ki;
		}
		function yr(t, e) {
			return br((19077 * t >> 8) + (26149 * e >> 8) - 14234);
		}
		function wr(t, e, r) {
			return br((19077 * t >> 8) - (6419 * e >> 8) - (13320 * r >> 8) + 8708);
		}
		function Nr(t, e) {
			return br((19077 * t >> 8) + (33050 * e >> 8) - 17685);
		}
		function Lr(t, e, r, n, i) {
			n[i + 0] = yr(t, r), n[i + 1] = wr(t, e, r), n[i + 2] = Nr(t, e);
		}
		function xr(t, e, r, n, i) {
			n[i + 0] = Nr(t, e), n[i + 1] = wr(t, e, r), n[i + 2] = yr(t, r);
		}
		function Ar(t, e, r, n, i) {
			var a = wr(t, e, r);
			e = a << 3 & 224 | Nr(t, e) >> 3, n[i + 0] = 248 & yr(t, r) | a >> 5, n[i + 1] = e;
		}
		function Sr(t, e, r, n, i) {
			var a = 240 & Nr(t, e) | 15;
			n[i + 0] = 240 & yr(t, r) | wr(t, e, r) >> 4, n[i + 1] = a;
		}
		function _r(t, e, r, n, i) {
			n[i + 0] = 255, Lr(t, e, r, n, i + 1);
		}
		function Pr(t, e, r, n, i) {
			xr(t, e, r, n, i), n[i + 3] = 255;
		}
		function kr(t, e, r, n, i) {
			Lr(t, e, r, n, i), n[i + 3] = 255;
		}
		function Fr(e, r, n) {
			t[e] = function(t, e, i, a, o, s, u, c, l) {
				for (var h = c + (-2 & l) * n; c != h;) r(t[e + 0], i[a + 0], o[s + 0], u, c), r(t[e + 1], i[a + 0], o[s + 0], u, c + n), e += 2, ++a, ++s, c += 2 * n;
				1 & l && r(t[e + 0], i[a + 0], o[s + 0], u, c);
			};
		}
		function Ir(t, e, r) {
			return 0 == r ? 0 == t ? 0 == e ? 6 : 5 : 0 == e ? 4 : 0 : r;
		}
		function Cr(t, e, r, n, i) {
			switch (t >>> 30) {
				case 3:
					an(e, r, n, i, 0);
					break;
				case 2:
					on(e, r, n, i);
					break;
				case 1: un(e, r, n, i);
			}
		}
		function jr(t, e) {
			var r, a, o = e.M, s = e.Nb, u = t.oc, c = t.pc + 40, l = t.oc, h = t.pc + 584, f = t.oc, d = t.pc + 600;
			for (r = 0; 16 > r; ++r) u[c + 32 * r - 1] = 129;
			for (r = 0; 8 > r; ++r) l[h + 32 * r - 1] = 129, f[d + 32 * r - 1] = 129;
			for (0 < o ? u[c - 1 - 32] = l[h - 1 - 32] = f[d - 1 - 32] = 129 : (i(u, c - 32 - 1, 127, 21), i(l, h - 32 - 1, 127, 9), i(f, d - 32 - 1, 127, 9)), a = 0; a < t.za; ++a) {
				var p = e.ya[e.aa + a];
				if (0 < a) {
					for (r = -1; 16 > r; ++r) n(u, c + 32 * r - 4, u, c + 32 * r + 12, 4);
					for (r = -1; 8 > r; ++r) n(l, h + 32 * r - 4, l, h + 32 * r + 4, 4), n(f, d + 32 * r - 4, f, d + 32 * r + 4, 4);
				}
				var g = t.Gd, m = t.Hd + a, v = p.ad, b = p.Hc;
				if (0 < o && (n(u, c - 32, g[m].y, 0, 16), n(l, h - 32, g[m].f, 0, 8), n(f, d - 32, g[m].ea, 0, 8)), p.Za) {
					var y = u, w = c - 32 + 16;
					for (0 < o && (a >= t.za - 1 ? i(y, w, g[m].y[15], 4) : n(y, w, g[m + 1].y, 0, 4)), r = 0; 4 > r; r++) y[w + 128 + r] = y[w + 256 + r] = y[w + 384 + r] = y[w + 0 + r];
					for (r = 0; 16 > r; ++r, b <<= 2) y = u, w = c + Ei[r], hi[p.Ob[r]](y, w), Cr(b, v, 16 * +r, y, w);
				} else if (y = Ir(a, o, p.Ob[0]), li[y](u, c), 0 != b) for (r = 0; 16 > r; ++r, b <<= 2) Cr(b, v, 16 * +r, u, c + Ei[r]);
				for (r = p.Gc, y = Ir(a, o, p.Dd), fi[y](l, h), fi[y](f, d), b = v, y = l, w = h, 255 & (p = 0 | r) && (170 & p ? sn(b, 256, y, w) : cn(b, 256, y, w)), p = f, b = d, 255 & (r >>= 8) && (170 & r ? sn(v, 320, p, b) : cn(v, 320, p, b)), o < t.Ub - 1 && (n(g[m].y, 0, u, c + 480, 16), n(g[m].f, 0, l, h + 224, 8), n(g[m].ea, 0, f, d + 224, 8)), r = 8 * s * t.B, g = t.sa, m = t.ta + 16 * a + 16 * s * t.R, v = t.qa, p = t.ra + 8 * a + r, b = t.Ha, y = t.Ia + 8 * a + r, r = 0; 16 > r; ++r) n(g, m + r * t.R, u, c + 32 * r, 16);
				for (r = 0; 8 > r; ++r) n(v, p + r * t.B, l, h + 32 * r, 8), n(b, y + r * t.B, f, d + 32 * r, 8);
			}
		}
		function Or(t, n, i, a, o, s, u, c, l) {
			var h = [0], f = [0], d = 0, p = null != l ? l.kd : 0, g = null != l ? l : new rr();
			if (null == t || 12 > i) return 7;
			g.data = t, g.w = n, g.ha = i, n = [n], i = [i], g.gb = [g.gb];
			t: {
				var m = n, b = i, y = g.gb;
				if (e(null != t), e(null != b), e(null != y), y[0] = 0, 12 <= b[0] && !r(t, m[0], "RIFF")) {
					if (r(t, m[0] + 8, "WEBP")) {
						y = 3;
						break t;
					}
					var w = j(t, m[0] + 4);
					if (12 > w || 4294967286 < w) {
						y = 3;
						break t;
					}
					if (p && w > b[0] - 8) {
						y = 7;
						break t;
					}
					y[0] = w, m[0] += 12, b[0] -= 12;
				}
				y = 0;
			}
			if (0 != y) return y;
			for (w = 0 < g.gb[0], i = i[0];;) {
				t: {
					var L = t;
					b = n, y = i;
					var x = h, A = f, S = m = [0];
					if ((k = d = [d])[0] = 0, 8 > y[0]) y = 7;
					else {
						if (!r(L, b[0], "VP8X")) {
							if (10 != j(L, b[0] + 4)) {
								y = 3;
								break t;
							}
							if (18 > y[0]) {
								y = 7;
								break t;
							}
							var _ = j(L, b[0] + 8), P = 1 + C(L, b[0] + 12);
							if (2147483648 <= P * (L = 1 + C(L, b[0] + 15))) {
								y = 3;
								break t;
							}
							null != S && (S[0] = _), null != x && (x[0] = P), null != A && (A[0] = L), b[0] += 18, y[0] -= 18, k[0] = 1;
						}
						y = 0;
					}
				}
				if (d = d[0], m = m[0], 0 != y) return y;
				if (b = !!(2 & m), !w && d) return 3;
				if (null != s && (s[0] = !!(16 & m)), null != u && (u[0] = b), null != c && (c[0] = 0), u = h[0], m = f[0], d && b && null == l) {
					y = 0;
					break;
				}
				if (4 > i) {
					y = 7;
					break;
				}
				if (w && d || !w && !d && !r(t, n[0], "ALPH")) {
					i = [i], g.na = [g.na], g.P = [g.P], g.Sa = [g.Sa];
					t: {
						_ = t, y = n, w = i;
						var k = g.gb;
						x = g.na, A = g.P, S = g.Sa, P = 22, e(null != _), e(null != w), L = y[0];
						var F = w[0];
						for (e(null != x), e(null != S), x[0] = null, A[0] = null, S[0] = 0;;) {
							if (y[0] = L, w[0] = F, 8 > F) {
								y = 7;
								break t;
							}
							var I = j(_, L + 4);
							if (4294967286 < I) {
								y = 3;
								break t;
							}
							var O = 8 + I + 1 & -2;
							if (P += O, 0 < k && P > k) {
								y = 3;
								break t;
							}
							if (!r(_, L, "VP8 ") || !r(_, L, "VP8L")) {
								y = 0;
								break t;
							}
							if (F[0] < O) {
								y = 7;
								break t;
							}
							r(_, L, "ALPH") || (x[0] = _, A[0] = L + 8, S[0] = I), L += O, F -= O;
						}
					}
					if (i = i[0], g.na = g.na[0], g.P = g.P[0], g.Sa = g.Sa[0], 0 != y) break;
				}
				i = [i], g.Ja = [g.Ja], g.xa = [g.xa];
				t: if (k = t, y = n, w = i, x = g.gb[0], A = g.Ja, S = g.xa, _ = y[0], L = !r(k, _, "VP8 "), P = !r(k, _, "VP8L"), e(null != k), e(null != w), e(null != A), e(null != S), 8 > w[0]) y = 7;
				else {
					if (L || P) {
						if (k = j(k, _ + 4), 12 <= x && k > x - 12) {
							y = 3;
							break t;
						}
						if (p && k > w[0] - 8) {
							y = 7;
							break t;
						}
						A[0] = k, y[0] += 8, w[0] -= 8, S[0] = P;
					} else S[0] = 5 <= w[0] && 47 == k[_ + 0] && !(k[_ + 4] >> 5), A[0] = w[0];
					y = 0;
				}
				if (i = i[0], g.Ja = g.Ja[0], g.xa = g.xa[0], n = n[0], 0 != y) break;
				if (4294967286 < g.Ja) return 3;
				if (null == c || b || (c[0] = g.xa ? 2 : 1), u = [u], m = [m], g.xa) {
					if (5 > i) {
						y = 7;
						break;
					}
					c = u, p = m, b = s, null == t || 5 > i ? t = 0 : 5 <= i && 47 == t[n + 0] && !(t[n + 4] >> 5) ? (w = [0], k = [0], x = [0], v(A = new N(), t, n, i), gt(A, w, k, x) ? (null != c && (c[0] = w[0]), null != p && (p[0] = k[0]), null != b && (b[0] = x[0]), t = 1) : t = 0) : t = 0;
				} else {
					if (10 > i) {
						y = 7;
						break;
					}
					c = m, null == t || 10 > i || !Xt(t, n + 3, i - 3) ? t = 0 : (p = t[n + 0] | t[n + 1] << 8 | t[n + 2] << 16, b = 16383 & (t[n + 7] << 8 | t[n + 6]), t = 16383 & (t[n + 9] << 8 | t[n + 8]), 1 & p || 3 < (p >> 1 & 7) || !(p >> 4 & 1) || p >> 5 >= g.Ja || !b || !t ? t = 0 : (u && (u[0] = b), c && (c[0] = t), t = 1));
				}
				if (!t) return 3;
				if (u = u[0], m = m[0], d && (h[0] != u || f[0] != m)) return 3;
				null != l && (l[0] = g, l.offset = n - l.w, e(4294967286 > n - l.w), e(l.offset == l.ha - i));
				break;
			}
			return 0 == y || 7 == y && d && null == l ? (null != s && (s[0] |= null != g.na && 0 < g.na.length), null != a && (a[0] = u), null != o && (o[0] = m), 0) : y;
		}
		function Br(t, e, r) {
			var n = e.width, i = e.height, a = 0, o = 0, s = n, u = i;
			if (e.Da = null != t && 0 < t.Da, e.Da && (s = t.cd, u = t.bd, a = t.v, o = t.j, 11 > r || (a &= -2, o &= -2), 0 > a || 0 > o || 0 >= s || 0 >= u || a + s > n || o + u > i)) return 0;
			if (e.v = a, e.j = o, e.va = a + s, e.o = o + u, e.U = s, e.T = u, e.da = null != t && 0 < t.da, e.da) {
				if (!q(s, u, r = [t.ib], a = [t.hb])) return 0;
				e.ib = r[0], e.hb = a[0];
			}
			return e.ob = null != t && t.ob, e.Kb = null == t || !t.Sd, e.da && (e.ob = e.ib < 3 * n / 4 && e.hb < 3 * i / 4, e.Kb = 0), 1;
		}
		function Mr(t) {
			if (null == t) return 2;
			if (11 > t.S) {
				var e = t.f.RGBA;
				e.fb += (t.height - 1) * e.A, e.A = -e.A;
			} else e = t.f.kb, t = t.height, e.O += (t - 1) * e.fa, e.fa = -e.fa, e.N += (t - 1 >> 1) * e.Ab, e.Ab = -e.Ab, e.W += (t - 1 >> 1) * e.Db, e.Db = -e.Db, null != e.F && (e.J += (t - 1) * e.lb, e.lb = -e.lb);
			return 0;
		}
		function qr(t, e, r, n) {
			if (null == n || 0 >= t || 0 >= e) return 2;
			if (null != r) {
				if (r.Da) {
					var i = r.cd, o = r.bd, s = -2 & r.v, u = -2 & r.j;
					if (0 > s || 0 > u || 0 >= i || 0 >= o || s + i > t || u + o > e) return 2;
					t = i, e = o;
				}
				if (r.da) {
					if (!q(t, e, i = [r.ib], o = [r.hb])) return 2;
					t = i[0], e = o[0];
				}
			}
			n.width = t, n.height = e;
			t: {
				var c = n.width, l = n.height;
				if (t = n.S, 0 >= c || 0 >= l || !(t >= Mn && 13 > t)) t = 2;
				else {
					if (0 >= n.Rd && null == n.sd) {
						s = o = i = e = 0;
						var h = (u = c * zi[t]) * l;
						if (11 > t || (o = (l + 1) / 2 * (e = (c + 1) / 2), 12 == t && (s = (i = c) * l)), null == (l = a(h + 2 * o + s))) {
							t = 1;
							break t;
						}
						n.sd = l, 11 > t ? ((c = n.f.RGBA).eb = l, c.fb = 0, c.A = u, c.size = h) : ((c = n.f.kb).y = l, c.O = 0, c.fa = u, c.Fd = h, c.f = l, c.N = 0 + h, c.Ab = e, c.Cd = o, c.ea = l, c.W = 0 + h + o, c.Db = e, c.Ed = o, 12 == t && (c.F = l, c.J = 0 + h + 2 * o), c.Tc = s, c.lb = i);
					}
					if (e = 1, i = n.S, o = n.width, s = n.height, i >= Mn && 13 > i) if (11 > i) t = n.f.RGBA, e &= (u = Math.abs(t.A)) * (s - 1) + o <= t.size, e &= u >= o * zi[i], e &= null != t.eb;
					else {
						t = n.f.kb, u = (o + 1) / 2, h = (s + 1) / 2, c = Math.abs(t.fa), l = Math.abs(t.Ab);
						var f = Math.abs(t.Db), d = Math.abs(t.lb), p = d * (s - 1) + o;
						e &= c * (s - 1) + o <= t.Fd, e &= l * (h - 1) + u <= t.Cd, e = (e &= f * (h - 1) + u <= t.Ed) & c >= o & l >= u & f >= u, e &= null != t.y, e &= null != t.f, e &= null != t.ea, 12 == i && (e &= d >= o, e &= p <= t.Tc, e &= null != t.F);
					}
					else e = 0;
					t = e ? 0 : 2;
				}
			}
			return 0 != t || null != r && r.fd && (t = Mr(n)), t;
		}
		var Er = 64, Rr = [
			0,
			1,
			3,
			7,
			15,
			31,
			63,
			127,
			255,
			511,
			1023,
			2047,
			4095,
			8191,
			16383,
			32767,
			65535,
			131071,
			262143,
			524287,
			1048575,
			2097151,
			4194303,
			8388607,
			16777215
		], Dr = 24, Tr = 32, zr = 8, Ur = [
			0,
			0,
			1,
			1,
			2,
			2,
			2,
			2,
			3,
			3,
			3,
			3,
			3,
			3,
			3,
			3,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			4,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			5,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7,
			7
		];
		D("Predictor0", "PredictorAdd0"), t.Predictor0 = function() {
			return 4278190080;
		}, t.Predictor1 = function(t) {
			return t;
		}, t.Predictor2 = function(t, e, r) {
			return e[r + 0];
		}, t.Predictor3 = function(t, e, r) {
			return e[r + 1];
		}, t.Predictor4 = function(t, e, r) {
			return e[r - 1];
		}, t.Predictor5 = function(t, e, r) {
			return z(z(t, e[r + 1]), e[r + 0]);
		}, t.Predictor6 = function(t, e, r) {
			return z(t, e[r - 1]);
		}, t.Predictor7 = function(t, e, r) {
			return z(t, e[r + 0]);
		}, t.Predictor8 = function(t, e, r) {
			return z(e[r - 1], e[r + 0]);
		}, t.Predictor9 = function(t, e, r) {
			return z(e[r + 0], e[r + 1]);
		}, t.Predictor10 = function(t, e, r) {
			return z(z(t, e[r - 1]), z(e[r + 0], e[r + 1]));
		}, t.Predictor11 = function(t, e, r) {
			var n = e[r + 0];
			return 0 >= W(n >> 24 & 255, t >> 24 & 255, (e = e[r - 1]) >> 24 & 255) + W(n >> 16 & 255, t >> 16 & 255, e >> 16 & 255) + W(n >> 8 & 255, t >> 8 & 255, e >> 8 & 255) + W(255 & n, 255 & t, 255 & e) ? n : t;
		}, t.Predictor12 = function(t, e, r) {
			var n = e[r + 0];
			return (U((t >> 24 & 255) + (n >> 24 & 255) - ((e = e[r - 1]) >> 24 & 255)) << 24 | U((t >> 16 & 255) + (n >> 16 & 255) - (e >> 16 & 255)) << 16 | U((t >> 8 & 255) + (n >> 8 & 255) - (e >> 8 & 255)) << 8 | U((255 & t) + (255 & n) - (255 & e))) >>> 0;
		}, t.Predictor13 = function(t, e, r) {
			var n = e[r - 1];
			return (H((t = z(t, e[r + 0])) >> 24 & 255, n >> 24 & 255) << 24 | H(t >> 16 & 255, n >> 16 & 255) << 16 | H(t >> 8 & 255, n >> 8 & 255) << 8 | H(255 & t, 255 & n)) >>> 0;
		};
		var Hr = t.PredictorAdd0;
		t.PredictorAdd1 = V, D("Predictor2", "PredictorAdd2"), D("Predictor3", "PredictorAdd3"), D("Predictor4", "PredictorAdd4"), D("Predictor5", "PredictorAdd5"), D("Predictor6", "PredictorAdd6"), D("Predictor7", "PredictorAdd7"), D("Predictor8", "PredictorAdd8"), D("Predictor9", "PredictorAdd9"), D("Predictor10", "PredictorAdd10"), D("Predictor11", "PredictorAdd11"), D("Predictor12", "PredictorAdd12"), D("Predictor13", "PredictorAdd13");
		var Wr = t.PredictorAdd2;
		X("ColorIndexInverseTransform", "MapARGB", "32b", function(t) {
			return t >> 8 & 255;
		}, function(t) {
			return t;
		}), X("VP8LColorIndexInverseTransformAlpha", "MapAlpha", "8b", function(t) {
			return t;
		}, function(t) {
			return t >> 8 & 255;
		});
		var Vr, Gr = t.ColorIndexInverseTransform, Yr = t.MapARGB, Jr = t.VP8LColorIndexInverseTransformAlpha, Xr = t.MapAlpha, Kr = t.VP8LPredictorsAdd = [];
		Kr.length = 16, (t.VP8LPredictors = []).length = 16, (t.VP8LPredictorsAdd_C = []).length = 16, (t.VP8LPredictors_C = []).length = 16;
		var Zr, $r, Qr, tn, en, rn, nn, an, on, sn, un, cn, ln, hn, fn, dn, pn, gn, mn, vn, bn, yn, wn, Nn, Ln, xn, An, Sn, _n = a(511), Pn = a(2041), kn = a(225), Fn = a(767), In = 0, Cn = Pn, jn = kn, On = Fn, Bn = _n, Mn = 0, qn = 1, En = 2, Rn = 3, Dn = 4, Tn = 5, zn = 6, Un = 7, Hn = 8, Wn = 9, Vn = 10, Gn = [
			2,
			3,
			7
		], Yn = [
			3,
			3,
			11
		], Jn = [
			280,
			256,
			256,
			256,
			40
		], Xn = [
			0,
			1,
			1,
			1,
			0
		], Kn = [
			17,
			18,
			0,
			1,
			2,
			3,
			4,
			5,
			16,
			6,
			7,
			8,
			9,
			10,
			11,
			12,
			13,
			14,
			15
		], Zn = [
			24,
			7,
			23,
			25,
			40,
			6,
			39,
			41,
			22,
			26,
			38,
			42,
			56,
			5,
			55,
			57,
			21,
			27,
			54,
			58,
			37,
			43,
			72,
			4,
			71,
			73,
			20,
			28,
			53,
			59,
			70,
			74,
			36,
			44,
			88,
			69,
			75,
			52,
			60,
			3,
			87,
			89,
			19,
			29,
			86,
			90,
			35,
			45,
			68,
			76,
			85,
			91,
			51,
			61,
			104,
			2,
			103,
			105,
			18,
			30,
			102,
			106,
			34,
			46,
			84,
			92,
			67,
			77,
			101,
			107,
			50,
			62,
			120,
			1,
			119,
			121,
			83,
			93,
			17,
			31,
			100,
			108,
			66,
			78,
			118,
			122,
			33,
			47,
			117,
			123,
			49,
			63,
			99,
			109,
			82,
			94,
			0,
			116,
			124,
			65,
			79,
			16,
			32,
			98,
			110,
			48,
			115,
			125,
			81,
			95,
			64,
			114,
			126,
			97,
			111,
			80,
			113,
			127,
			96,
			112
		], $n = [
			2954,
			2956,
			2958,
			2962,
			2970,
			2986,
			3018,
			3082,
			3212,
			3468,
			3980,
			5004
		], Qn = 8, ti = [
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			10,
			11,
			12,
			13,
			14,
			15,
			16,
			17,
			17,
			18,
			19,
			20,
			20,
			21,
			21,
			22,
			22,
			23,
			23,
			24,
			25,
			25,
			26,
			27,
			28,
			29,
			30,
			31,
			32,
			33,
			34,
			35,
			36,
			37,
			37,
			38,
			39,
			40,
			41,
			42,
			43,
			44,
			45,
			46,
			46,
			47,
			48,
			49,
			50,
			51,
			52,
			53,
			54,
			55,
			56,
			57,
			58,
			59,
			60,
			61,
			62,
			63,
			64,
			65,
			66,
			67,
			68,
			69,
			70,
			71,
			72,
			73,
			74,
			75,
			76,
			76,
			77,
			78,
			79,
			80,
			81,
			82,
			83,
			84,
			85,
			86,
			87,
			88,
			89,
			91,
			93,
			95,
			96,
			98,
			100,
			101,
			102,
			104,
			106,
			108,
			110,
			112,
			114,
			116,
			118,
			122,
			124,
			126,
			128,
			130,
			132,
			134,
			136,
			138,
			140,
			143,
			145,
			148,
			151,
			154,
			157
		], ei = [
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			11,
			12,
			13,
			14,
			15,
			16,
			17,
			18,
			19,
			20,
			21,
			22,
			23,
			24,
			25,
			26,
			27,
			28,
			29,
			30,
			31,
			32,
			33,
			34,
			35,
			36,
			37,
			38,
			39,
			40,
			41,
			42,
			43,
			44,
			45,
			46,
			47,
			48,
			49,
			50,
			51,
			52,
			53,
			54,
			55,
			56,
			57,
			58,
			60,
			62,
			64,
			66,
			68,
			70,
			72,
			74,
			76,
			78,
			80,
			82,
			84,
			86,
			88,
			90,
			92,
			94,
			96,
			98,
			100,
			102,
			104,
			106,
			108,
			110,
			112,
			114,
			116,
			119,
			122,
			125,
			128,
			131,
			134,
			137,
			140,
			143,
			146,
			149,
			152,
			155,
			158,
			161,
			164,
			167,
			170,
			173,
			177,
			181,
			185,
			189,
			193,
			197,
			201,
			205,
			209,
			213,
			217,
			221,
			225,
			229,
			234,
			239,
			245,
			249,
			254,
			259,
			264,
			269,
			274,
			279,
			284
		], ri = null, ni = [
			[
				173,
				148,
				140,
				0
			],
			[
				176,
				155,
				140,
				135,
				0
			],
			[
				180,
				157,
				141,
				134,
				130,
				0
			],
			[
				254,
				254,
				243,
				230,
				196,
				177,
				153,
				140,
				133,
				130,
				129,
				0
			]
		], ii = [
			0,
			1,
			4,
			8,
			5,
			2,
			3,
			6,
			9,
			12,
			13,
			10,
			7,
			11,
			14,
			15
		], ai = [
			-0,
			1,
			-1,
			2,
			-2,
			3,
			4,
			6,
			-3,
			5,
			-4,
			-5,
			-6,
			7,
			-7,
			8,
			-8,
			-9
		], oi = [
			[
				[
					[
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					]
				],
				[
					[
						253,
						136,
						254,
						255,
						228,
						219,
						128,
						128,
						128,
						128,
						128
					],
					[
						189,
						129,
						242,
						255,
						227,
						213,
						255,
						219,
						128,
						128,
						128
					],
					[
						106,
						126,
						227,
						252,
						214,
						209,
						255,
						255,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						98,
						248,
						255,
						236,
						226,
						255,
						255,
						128,
						128,
						128
					],
					[
						181,
						133,
						238,
						254,
						221,
						234,
						255,
						154,
						128,
						128,
						128
					],
					[
						78,
						134,
						202,
						247,
						198,
						180,
						255,
						219,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						185,
						249,
						255,
						243,
						255,
						128,
						128,
						128,
						128,
						128
					],
					[
						184,
						150,
						247,
						255,
						236,
						224,
						128,
						128,
						128,
						128,
						128
					],
					[
						77,
						110,
						216,
						255,
						236,
						230,
						128,
						128,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						101,
						251,
						255,
						241,
						255,
						128,
						128,
						128,
						128,
						128
					],
					[
						170,
						139,
						241,
						252,
						236,
						209,
						255,
						255,
						128,
						128,
						128
					],
					[
						37,
						116,
						196,
						243,
						228,
						255,
						255,
						255,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						204,
						254,
						255,
						245,
						255,
						128,
						128,
						128,
						128,
						128
					],
					[
						207,
						160,
						250,
						255,
						238,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						102,
						103,
						231,
						255,
						211,
						171,
						128,
						128,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						152,
						252,
						255,
						240,
						255,
						128,
						128,
						128,
						128,
						128
					],
					[
						177,
						135,
						243,
						255,
						234,
						225,
						128,
						128,
						128,
						128,
						128
					],
					[
						80,
						129,
						211,
						255,
						194,
						224,
						128,
						128,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						1,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						246,
						1,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					]
				]
			],
			[
				[
					[
						198,
						35,
						237,
						223,
						193,
						187,
						162,
						160,
						145,
						155,
						62
					],
					[
						131,
						45,
						198,
						221,
						172,
						176,
						220,
						157,
						252,
						221,
						1
					],
					[
						68,
						47,
						146,
						208,
						149,
						167,
						221,
						162,
						255,
						223,
						128
					]
				],
				[
					[
						1,
						149,
						241,
						255,
						221,
						224,
						255,
						255,
						128,
						128,
						128
					],
					[
						184,
						141,
						234,
						253,
						222,
						220,
						255,
						199,
						128,
						128,
						128
					],
					[
						81,
						99,
						181,
						242,
						176,
						190,
						249,
						202,
						255,
						255,
						128
					]
				],
				[
					[
						1,
						129,
						232,
						253,
						214,
						197,
						242,
						196,
						255,
						255,
						128
					],
					[
						99,
						121,
						210,
						250,
						201,
						198,
						255,
						202,
						128,
						128,
						128
					],
					[
						23,
						91,
						163,
						242,
						170,
						187,
						247,
						210,
						255,
						255,
						128
					]
				],
				[
					[
						1,
						200,
						246,
						255,
						234,
						255,
						128,
						128,
						128,
						128,
						128
					],
					[
						109,
						178,
						241,
						255,
						231,
						245,
						255,
						255,
						128,
						128,
						128
					],
					[
						44,
						130,
						201,
						253,
						205,
						192,
						255,
						255,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						132,
						239,
						251,
						219,
						209,
						255,
						165,
						128,
						128,
						128
					],
					[
						94,
						136,
						225,
						251,
						218,
						190,
						255,
						255,
						128,
						128,
						128
					],
					[
						22,
						100,
						174,
						245,
						186,
						161,
						255,
						199,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						182,
						249,
						255,
						232,
						235,
						128,
						128,
						128,
						128,
						128
					],
					[
						124,
						143,
						241,
						255,
						227,
						234,
						128,
						128,
						128,
						128,
						128
					],
					[
						35,
						77,
						181,
						251,
						193,
						211,
						255,
						205,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						157,
						247,
						255,
						236,
						231,
						255,
						255,
						128,
						128,
						128
					],
					[
						121,
						141,
						235,
						255,
						225,
						227,
						255,
						255,
						128,
						128,
						128
					],
					[
						45,
						99,
						188,
						251,
						195,
						217,
						255,
						224,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						1,
						251,
						255,
						213,
						255,
						128,
						128,
						128,
						128,
						128
					],
					[
						203,
						1,
						248,
						255,
						255,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						137,
						1,
						177,
						255,
						224,
						255,
						128,
						128,
						128,
						128,
						128
					]
				]
			],
			[
				[
					[
						253,
						9,
						248,
						251,
						207,
						208,
						255,
						192,
						128,
						128,
						128
					],
					[
						175,
						13,
						224,
						243,
						193,
						185,
						249,
						198,
						255,
						255,
						128
					],
					[
						73,
						17,
						171,
						221,
						161,
						179,
						236,
						167,
						255,
						234,
						128
					]
				],
				[
					[
						1,
						95,
						247,
						253,
						212,
						183,
						255,
						255,
						128,
						128,
						128
					],
					[
						239,
						90,
						244,
						250,
						211,
						209,
						255,
						255,
						128,
						128,
						128
					],
					[
						155,
						77,
						195,
						248,
						188,
						195,
						255,
						255,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						24,
						239,
						251,
						218,
						219,
						255,
						205,
						128,
						128,
						128
					],
					[
						201,
						51,
						219,
						255,
						196,
						186,
						128,
						128,
						128,
						128,
						128
					],
					[
						69,
						46,
						190,
						239,
						201,
						218,
						255,
						228,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						191,
						251,
						255,
						255,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						223,
						165,
						249,
						255,
						213,
						255,
						128,
						128,
						128,
						128,
						128
					],
					[
						141,
						124,
						248,
						255,
						255,
						128,
						128,
						128,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						16,
						248,
						255,
						255,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						190,
						36,
						230,
						255,
						236,
						255,
						128,
						128,
						128,
						128,
						128
					],
					[
						149,
						1,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						226,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						247,
						192,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						240,
						128,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						134,
						252,
						255,
						255,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						213,
						62,
						250,
						255,
						255,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						55,
						93,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					]
				],
				[
					[
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					]
				]
			],
			[
				[
					[
						202,
						24,
						213,
						235,
						186,
						191,
						220,
						160,
						240,
						175,
						255
					],
					[
						126,
						38,
						182,
						232,
						169,
						184,
						228,
						174,
						255,
						187,
						128
					],
					[
						61,
						46,
						138,
						219,
						151,
						178,
						240,
						170,
						255,
						216,
						128
					]
				],
				[
					[
						1,
						112,
						230,
						250,
						199,
						191,
						247,
						159,
						255,
						255,
						128
					],
					[
						166,
						109,
						228,
						252,
						211,
						215,
						255,
						174,
						128,
						128,
						128
					],
					[
						39,
						77,
						162,
						232,
						172,
						180,
						245,
						178,
						255,
						255,
						128
					]
				],
				[
					[
						1,
						52,
						220,
						246,
						198,
						199,
						249,
						220,
						255,
						255,
						128
					],
					[
						124,
						74,
						191,
						243,
						183,
						193,
						250,
						221,
						255,
						255,
						128
					],
					[
						24,
						71,
						130,
						219,
						154,
						170,
						243,
						182,
						255,
						255,
						128
					]
				],
				[
					[
						1,
						182,
						225,
						249,
						219,
						240,
						255,
						224,
						128,
						128,
						128
					],
					[
						149,
						150,
						226,
						252,
						216,
						205,
						255,
						171,
						128,
						128,
						128
					],
					[
						28,
						108,
						170,
						242,
						183,
						194,
						254,
						223,
						255,
						255,
						128
					]
				],
				[
					[
						1,
						81,
						230,
						252,
						204,
						203,
						255,
						192,
						128,
						128,
						128
					],
					[
						123,
						102,
						209,
						247,
						188,
						196,
						255,
						233,
						128,
						128,
						128
					],
					[
						20,
						95,
						153,
						243,
						164,
						173,
						255,
						203,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						222,
						248,
						255,
						216,
						213,
						128,
						128,
						128,
						128,
						128
					],
					[
						168,
						175,
						246,
						252,
						235,
						205,
						255,
						255,
						128,
						128,
						128
					],
					[
						47,
						116,
						215,
						255,
						211,
						212,
						255,
						255,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						121,
						236,
						253,
						212,
						214,
						255,
						255,
						128,
						128,
						128
					],
					[
						141,
						84,
						213,
						252,
						201,
						202,
						255,
						219,
						128,
						128,
						128
					],
					[
						42,
						80,
						160,
						240,
						162,
						185,
						255,
						205,
						128,
						128,
						128
					]
				],
				[
					[
						1,
						1,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						244,
						1,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					],
					[
						238,
						1,
						255,
						128,
						128,
						128,
						128,
						128,
						128,
						128,
						128
					]
				]
			]
		], si = [
			[
				[
					231,
					120,
					48,
					89,
					115,
					113,
					120,
					152,
					112
				],
				[
					152,
					179,
					64,
					126,
					170,
					118,
					46,
					70,
					95
				],
				[
					175,
					69,
					143,
					80,
					85,
					82,
					72,
					155,
					103
				],
				[
					56,
					58,
					10,
					171,
					218,
					189,
					17,
					13,
					152
				],
				[
					114,
					26,
					17,
					163,
					44,
					195,
					21,
					10,
					173
				],
				[
					121,
					24,
					80,
					195,
					26,
					62,
					44,
					64,
					85
				],
				[
					144,
					71,
					10,
					38,
					171,
					213,
					144,
					34,
					26
				],
				[
					170,
					46,
					55,
					19,
					136,
					160,
					33,
					206,
					71
				],
				[
					63,
					20,
					8,
					114,
					114,
					208,
					12,
					9,
					226
				],
				[
					81,
					40,
					11,
					96,
					182,
					84,
					29,
					16,
					36
				]
			],
			[
				[
					134,
					183,
					89,
					137,
					98,
					101,
					106,
					165,
					148
				],
				[
					72,
					187,
					100,
					130,
					157,
					111,
					32,
					75,
					80
				],
				[
					66,
					102,
					167,
					99,
					74,
					62,
					40,
					234,
					128
				],
				[
					41,
					53,
					9,
					178,
					241,
					141,
					26,
					8,
					107
				],
				[
					74,
					43,
					26,
					146,
					73,
					166,
					49,
					23,
					157
				],
				[
					65,
					38,
					105,
					160,
					51,
					52,
					31,
					115,
					128
				],
				[
					104,
					79,
					12,
					27,
					217,
					255,
					87,
					17,
					7
				],
				[
					87,
					68,
					71,
					44,
					114,
					51,
					15,
					186,
					23
				],
				[
					47,
					41,
					14,
					110,
					182,
					183,
					21,
					17,
					194
				],
				[
					66,
					45,
					25,
					102,
					197,
					189,
					23,
					18,
					22
				]
			],
			[
				[
					88,
					88,
					147,
					150,
					42,
					46,
					45,
					196,
					205
				],
				[
					43,
					97,
					183,
					117,
					85,
					38,
					35,
					179,
					61
				],
				[
					39,
					53,
					200,
					87,
					26,
					21,
					43,
					232,
					171
				],
				[
					56,
					34,
					51,
					104,
					114,
					102,
					29,
					93,
					77
				],
				[
					39,
					28,
					85,
					171,
					58,
					165,
					90,
					98,
					64
				],
				[
					34,
					22,
					116,
					206,
					23,
					34,
					43,
					166,
					73
				],
				[
					107,
					54,
					32,
					26,
					51,
					1,
					81,
					43,
					31
				],
				[
					68,
					25,
					106,
					22,
					64,
					171,
					36,
					225,
					114
				],
				[
					34,
					19,
					21,
					102,
					132,
					188,
					16,
					76,
					124
				],
				[
					62,
					18,
					78,
					95,
					85,
					57,
					50,
					48,
					51
				]
			],
			[
				[
					193,
					101,
					35,
					159,
					215,
					111,
					89,
					46,
					111
				],
				[
					60,
					148,
					31,
					172,
					219,
					228,
					21,
					18,
					111
				],
				[
					112,
					113,
					77,
					85,
					179,
					255,
					38,
					120,
					114
				],
				[
					40,
					42,
					1,
					196,
					245,
					209,
					10,
					25,
					109
				],
				[
					88,
					43,
					29,
					140,
					166,
					213,
					37,
					43,
					154
				],
				[
					61,
					63,
					30,
					155,
					67,
					45,
					68,
					1,
					209
				],
				[
					100,
					80,
					8,
					43,
					154,
					1,
					51,
					26,
					71
				],
				[
					142,
					78,
					78,
					16,
					255,
					128,
					34,
					197,
					171
				],
				[
					41,
					40,
					5,
					102,
					211,
					183,
					4,
					1,
					221
				],
				[
					51,
					50,
					17,
					168,
					209,
					192,
					23,
					25,
					82
				]
			],
			[
				[
					138,
					31,
					36,
					171,
					27,
					166,
					38,
					44,
					229
				],
				[
					67,
					87,
					58,
					169,
					82,
					115,
					26,
					59,
					179
				],
				[
					63,
					59,
					90,
					180,
					59,
					166,
					93,
					73,
					154
				],
				[
					40,
					40,
					21,
					116,
					143,
					209,
					34,
					39,
					175
				],
				[
					47,
					15,
					16,
					183,
					34,
					223,
					49,
					45,
					183
				],
				[
					46,
					17,
					33,
					183,
					6,
					98,
					15,
					32,
					183
				],
				[
					57,
					46,
					22,
					24,
					128,
					1,
					54,
					17,
					37
				],
				[
					65,
					32,
					73,
					115,
					28,
					128,
					23,
					128,
					205
				],
				[
					40,
					3,
					9,
					115,
					51,
					192,
					18,
					6,
					223
				],
				[
					87,
					37,
					9,
					115,
					59,
					77,
					64,
					21,
					47
				]
			],
			[
				[
					104,
					55,
					44,
					218,
					9,
					54,
					53,
					130,
					226
				],
				[
					64,
					90,
					70,
					205,
					40,
					41,
					23,
					26,
					57
				],
				[
					54,
					57,
					112,
					184,
					5,
					41,
					38,
					166,
					213
				],
				[
					30,
					34,
					26,
					133,
					152,
					116,
					10,
					32,
					134
				],
				[
					39,
					19,
					53,
					221,
					26,
					114,
					32,
					73,
					255
				],
				[
					31,
					9,
					65,
					234,
					2,
					15,
					1,
					118,
					73
				],
				[
					75,
					32,
					12,
					51,
					192,
					255,
					160,
					43,
					51
				],
				[
					88,
					31,
					35,
					67,
					102,
					85,
					55,
					186,
					85
				],
				[
					56,
					21,
					23,
					111,
					59,
					205,
					45,
					37,
					192
				],
				[
					55,
					38,
					70,
					124,
					73,
					102,
					1,
					34,
					98
				]
			],
			[
				[
					125,
					98,
					42,
					88,
					104,
					85,
					117,
					175,
					82
				],
				[
					95,
					84,
					53,
					89,
					128,
					100,
					113,
					101,
					45
				],
				[
					75,
					79,
					123,
					47,
					51,
					128,
					81,
					171,
					1
				],
				[
					57,
					17,
					5,
					71,
					102,
					57,
					53,
					41,
					49
				],
				[
					38,
					33,
					13,
					121,
					57,
					73,
					26,
					1,
					85
				],
				[
					41,
					10,
					67,
					138,
					77,
					110,
					90,
					47,
					114
				],
				[
					115,
					21,
					2,
					10,
					102,
					255,
					166,
					23,
					6
				],
				[
					101,
					29,
					16,
					10,
					85,
					128,
					101,
					196,
					26
				],
				[
					57,
					18,
					10,
					102,
					102,
					213,
					34,
					20,
					43
				],
				[
					117,
					20,
					15,
					36,
					163,
					128,
					68,
					1,
					26
				]
			],
			[
				[
					102,
					61,
					71,
					37,
					34,
					53,
					31,
					243,
					192
				],
				[
					69,
					60,
					71,
					38,
					73,
					119,
					28,
					222,
					37
				],
				[
					68,
					45,
					128,
					34,
					1,
					47,
					11,
					245,
					171
				],
				[
					62,
					17,
					19,
					70,
					146,
					85,
					55,
					62,
					70
				],
				[
					37,
					43,
					37,
					154,
					100,
					163,
					85,
					160,
					1
				],
				[
					63,
					9,
					92,
					136,
					28,
					64,
					32,
					201,
					85
				],
				[
					75,
					15,
					9,
					9,
					64,
					255,
					184,
					119,
					16
				],
				[
					86,
					6,
					28,
					5,
					64,
					255,
					25,
					248,
					1
				],
				[
					56,
					8,
					17,
					132,
					137,
					255,
					55,
					116,
					128
				],
				[
					58,
					15,
					20,
					82,
					135,
					57,
					26,
					121,
					40
				]
			],
			[
				[
					164,
					50,
					31,
					137,
					154,
					133,
					25,
					35,
					218
				],
				[
					51,
					103,
					44,
					131,
					131,
					123,
					31,
					6,
					158
				],
				[
					86,
					40,
					64,
					135,
					148,
					224,
					45,
					183,
					128
				],
				[
					22,
					26,
					17,
					131,
					240,
					154,
					14,
					1,
					209
				],
				[
					45,
					16,
					21,
					91,
					64,
					222,
					7,
					1,
					197
				],
				[
					56,
					21,
					39,
					155,
					60,
					138,
					23,
					102,
					213
				],
				[
					83,
					12,
					13,
					54,
					192,
					255,
					68,
					47,
					28
				],
				[
					85,
					26,
					85,
					85,
					128,
					128,
					32,
					146,
					171
				],
				[
					18,
					11,
					7,
					63,
					144,
					171,
					4,
					4,
					246
				],
				[
					35,
					27,
					10,
					146,
					174,
					171,
					12,
					26,
					128
				]
			],
			[
				[
					190,
					80,
					35,
					99,
					180,
					80,
					126,
					54,
					45
				],
				[
					85,
					126,
					47,
					87,
					176,
					51,
					41,
					20,
					32
				],
				[
					101,
					75,
					128,
					139,
					118,
					146,
					116,
					128,
					85
				],
				[
					56,
					41,
					15,
					176,
					236,
					85,
					37,
					9,
					62
				],
				[
					71,
					30,
					17,
					119,
					118,
					255,
					17,
					18,
					138
				],
				[
					101,
					38,
					60,
					138,
					55,
					70,
					43,
					26,
					142
				],
				[
					146,
					36,
					19,
					30,
					171,
					255,
					97,
					27,
					20
				],
				[
					138,
					45,
					61,
					62,
					219,
					1,
					81,
					188,
					64
				],
				[
					32,
					41,
					20,
					117,
					151,
					142,
					20,
					21,
					163
				],
				[
					112,
					19,
					12,
					61,
					195,
					128,
					48,
					4,
					24
				]
			]
		], ui = [
			[
				[
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						176,
						246,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						223,
						241,
						252,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						249,
						253,
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						244,
						252,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						234,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						246,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						239,
						253,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						254,
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						248,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						251,
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						253,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						251,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						254,
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						254,
						253,
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						250,
						255,
						254,
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				]
			],
			[
				[
					[
						217,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						225,
						252,
						241,
						253,
						255,
						255,
						254,
						255,
						255,
						255,
						255
					],
					[
						234,
						250,
						241,
						250,
						253,
						255,
						253,
						254,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						223,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						238,
						253,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						248,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						249,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						247,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						253,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						252,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						254,
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						250,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				]
			],
			[
				[
					[
						186,
						251,
						250,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						234,
						251,
						244,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						251,
						251,
						243,
						253,
						254,
						255,
						254,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						253,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						236,
						253,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						251,
						253,
						253,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						254,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				]
			],
			[
				[
					[
						248,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						250,
						254,
						252,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						248,
						254,
						249,
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						253,
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						246,
						253,
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						252,
						254,
						251,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						254,
						252,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						248,
						254,
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						253,
						255,
						254,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						251,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						245,
						251,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						253,
						253,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						251,
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						252,
						253,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						252,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						249,
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						255,
						253,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						250,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				],
				[
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						254,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					],
					[
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255,
						255
					]
				]
			]
		], ci = [
			0,
			1,
			2,
			3,
			6,
			4,
			5,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			6,
			7,
			0
		], li = [], hi = [], fi = [], di = 1, pi = 2, gi = [], mi = [];
		mr("UpsampleRgbLinePair", Lr, 3), mr("UpsampleBgrLinePair", xr, 3), mr("UpsampleRgbaLinePair", kr, 4), mr("UpsampleBgraLinePair", Pr, 4), mr("UpsampleArgbLinePair", _r, 4), mr("UpsampleRgba4444LinePair", Sr, 2), mr("UpsampleRgb565LinePair", Ar, 2);
		var vi = t.UpsampleRgbLinePair, bi = t.UpsampleBgrLinePair, yi = t.UpsampleRgbaLinePair, wi = t.UpsampleBgraLinePair, Ni = t.UpsampleArgbLinePair, Li = t.UpsampleRgba4444LinePair, xi = t.UpsampleRgb565LinePair, Ai = 16, Si = 1 << Ai - 1, _i = -227, Pi = 482, ki = 6, Fi = (256 << ki) - 1, Ii = 0, Ci = a(256), ji = a(256), Oi = a(256), Bi = a(256), Mi = a(Pi - _i), qi = a(Pi - _i);
		Fr("YuvToRgbRow", Lr, 3), Fr("YuvToBgrRow", xr, 3), Fr("YuvToRgbaRow", kr, 4), Fr("YuvToBgraRow", Pr, 4), Fr("YuvToArgbRow", _r, 4), Fr("YuvToRgba4444Row", Sr, 2), Fr("YuvToRgb565Row", Ar, 2);
		var Ei = [
			0,
			4,
			8,
			12,
			128,
			132,
			136,
			140,
			256,
			260,
			264,
			268,
			384,
			388,
			392,
			396
		], Ri = [
			0,
			2,
			8
		], Di = [
			8,
			7,
			6,
			4,
			4,
			2,
			2,
			2,
			1,
			1,
			1,
			1
		], Ti = 1;
		this.WebPDecodeRGBA = function(t, r, s, u, c) {
			var l = qn, h = new er(), f = new ot();
			h.ba = f, f.S = l, f.width = [f.width], f.height = [f.height];
			var d = f.width, p = f.height, g = new st();
			if (null == g || null == t) var m = 2;
			else e(null != g), m = Or(t, r, s, g.width, g.height, g.Pd, g.Qd, g.format, null);
			if (0 != m ? d = 0 : (null != d && (d[0] = g.width[0]), null != p && (p[0] = g.height[0]), d = 1), d) {
				f.width = f.width[0], f.height = f.height[0], null != u && (u[0] = f.width), null != c && (c[0] = f.height);
				t: {
					if (u = new Gt(), (c = new rr()).data = t, c.w = r, c.ha = s, c.kd = 1, r = [0], e(null != c), (0 == (t = Or(c.data, c.w, c.ha, null, null, null, r, null, c)) || 7 == t) && r[0] && (t = 4), 0 == (r = t)) {
						if (e(null != h), u.data = c.data, u.w = c.w + c.offset, u.ha = c.ha - c.offset, u.put = dt, u.ac = ft, u.bc = pt, u.ma = h, c.xa) {
							if (null == (t = kt())) {
								h = 1;
								break t;
							}
							if (function(t, r) {
								var n = [0], i = [0], a = [0];
								e: for (;;) {
									if (null == t) return 0;
									if (null == r) return t.a = 2, 0;
									if (t.l = r, t.a = 0, v(t.m, r.data, r.w, r.ha), !gt(t.m, n, i, a)) {
										t.a = 3;
										break e;
									}
									if (t.xb = pi, r.width = n[0], r.height = i[0], !Ft(n[0], i[0], 1, t, null)) break e;
									return 1;
								}
								return e(0 != t.a), 0;
							}(t, u)) {
								if (u = 0 == (r = qr(u.width, u.height, h.Oa, h.ba))) {
									e: {
										u = t;
										r: for (;;) {
											if (null == u) {
												u = 0;
												break e;
											}
											if (e(null != u.s.yc), e(null != u.s.Ya), e(0 < u.s.Wb), e(null != (s = u.l)), e(null != (c = s.ma)), 0 != u.xb) {
												if (u.ca = c.ba, u.tb = c.tb, e(null != u.ca), !Br(c.Oa, s, Rn)) {
													u.a = 2;
													break r;
												}
												if (!It(u, s.width)) break r;
												if (s.da) break r;
												if ((s.da || nt(u.ca.S)) && gr(), 11 > u.ca.S || (alert("todo:WebPInitConvertARGBToYUV"), null != u.ca.f.kb.F && gr()), u.Pb && 0 < u.s.ua && null == u.s.vb.X && !O(u.s.vb, u.s.Wa.Xa)) {
													u.a = 1;
													break r;
												}
												u.xb = 0;
											}
											if (!_t(u, u.V, u.Ba, u.c, u.i, s.o, Lt)) break r;
											c.Dc = u.Ma, u = 1;
											break e;
										}
										e(0 != u.a), u = 0;
									}
									u = !u;
								}
								u && (r = t.a);
							} else r = t.a;
						} else {
							if (null == (t = new Yt())) {
								h = 1;
								break t;
							}
							if (t.Fa = c.na, t.P = c.P, t.qc = c.Sa, Kt(t, u)) {
								if (0 == (r = qr(u.width, u.height, h.Oa, h.ba))) {
									if (t.Aa = 0, s = h.Oa, e(null != (c = t)), null != s) {
										if (0 < (d = 0 > (d = s.Md) ? 0 : 100 < d ? 255 : 255 * d / 100)) {
											for (p = g = 0; 4 > p; ++p) 12 > (m = c.pb[p]).lc && (m.ia = d * Di[0 > m.lc ? 0 : m.lc] >> 3), g |= m.ia;
											g && (alert("todo:VP8InitRandom"), c.ia = 1);
										}
										c.Ga = s.Id, 100 < c.Ga ? c.Ga = 100 : 0 > c.Ga && (c.Ga = 0);
									}
									(function(t, r) {
										if (null == t) return 0;
										if (null == r) return Jt(t, 2, "NULL VP8Io parameter in VP8Decode().");
										if (!t.cb && !Kt(t, r)) return 0;
										if (e(t.cb), null == r.ac || r.ac(r)) {
											r.ob && (t.L = 0);
											var s = Ri[t.L];
											if (2 == t.L ? (t.yb = 0, t.zb = 0) : (t.yb = r.v - s >> 4, t.zb = r.j - s >> 4, 0 > t.yb && (t.yb = 0), 0 > t.zb && (t.zb = 0)), t.Va = r.o + 15 + s >> 4, t.Hb = r.va + 15 + s >> 4, t.Hb > t.za && (t.Hb = t.za), t.Va > t.Ub && (t.Va = t.Ub), 0 < t.L) {
												var u = t.ed;
												for (s = 0; 4 > s; ++s) {
													var c;
													if (t.Qa.Cb) {
														var l = t.Qa.Lb[s];
														t.Qa.Fb || (l += u.Tb);
													} else l = u.Tb;
													for (c = 0; 1 >= c; ++c) {
														var h = t.gd[s][c], f = l;
														if (u.Pc && (f += u.vd[0], c && (f += u.od[0])), 0 < (f = 0 > f ? 0 : 63 < f ? 63 : f)) {
															var d = f;
															0 < u.wb && (d = 4 < u.wb ? d >> 2 : d >> 1) > 9 - u.wb && (d = 9 - u.wb), 1 > d && (d = 1), h.dd = d, h.tc = 2 * f + d, h.ld = 40 <= f ? 2 : 15 <= f ? 1 : 0;
														} else h.tc = 0;
														h.La = c;
													}
												}
											}
											s = 0;
										} else Jt(t, 6, "Frame setup failed"), s = t.a;
										if (s = 0 == s) {
											if (s) {
												t.$c = 0, 0 < t.Aa || (t.Ic = Ti);
												e: {
													s = t.Ic, u = 4 * (d = t.za);
													var p = 32 * d, g = d + 1, m = 0 < t.L ? d * (0 < t.Aa ? 2 : 1) : 0, v = (2 == t.Aa ? 2 : 1) * d;
													if ((h = u + 832 + (c = 3 * (16 * s + Ri[t.L]) / 2 * p) + (l = null != t.Fa && 0 < t.Fa.length ? t.Kc.c * t.Kc.i : 0)) != h) s = 0;
													else {
														if (h > t.Vb) {
															if (t.Vb = 0, t.Ec = a(h), t.Fc = 0, null == t.Ec) {
																s = Jt(t, 1, "no memory during frame initialization.");
																break e;
															}
															t.Vb = h;
														}
														h = t.Ec, f = t.Fc, t.Ac = h, t.Bc = f, f += u, t.Gd = o(p, Ht), t.Hd = 0, t.rb = o(g + 1, Dt), t.sb = 1, t.wa = m ? o(m, Rt) : null, t.Y = 0, t.D.Nb = 0, t.D.wa = t.wa, t.D.Y = t.Y, 0 < t.Aa && (t.D.Y += d), e(!0), t.oc = h, t.pc = f, f += 832, t.ya = o(v, zt), t.aa = 0, t.D.ya = t.ya, t.D.aa = t.aa, 2 == t.Aa && (t.D.aa += d), t.R = 16 * d, t.B = 8 * d, d = (p = Ri[t.L]) * t.R, p = p / 2 * t.B, t.sa = h, t.ta = f + d, t.qa = t.sa, t.ra = t.ta + 16 * s * t.R + p, t.Ha = t.qa, t.Ia = t.ra + 8 * s * t.B + p, t.$c = 0, f += c, t.mb = l ? h : null, t.nb = l ? f : null, e(f + l <= t.Fc + t.Vb), $t(t), i(t.Ac, t.Bc, 0, u), s = 1;
													}
												}
												if (s) {
													if (r.ka = 0, r.y = t.sa, r.O = t.ta, r.f = t.qa, r.N = t.ra, r.ea = t.Ha, r.Vd = t.Ia, r.fa = t.R, r.Rc = t.B, r.F = null, r.J = 0, !In) {
														for (s = -255; 255 >= s; ++s) _n[255 + s] = 0 > s ? -s : s;
														for (s = -1020; 1020 >= s; ++s) Pn[1020 + s] = -128 > s ? -128 : 127 < s ? 127 : s;
														for (s = -112; 112 >= s; ++s) kn[112 + s] = -16 > s ? -16 : 15 < s ? 15 : s;
														for (s = -255; 510 >= s; ++s) Fn[255 + s] = 0 > s ? 0 : 255 < s ? 255 : s;
														In = 1;
													}
													nn = ue, an = ie, sn = ae, un = oe, cn = se, on = ne, ln = Ye, hn = Je, fn = Ze, dn = $e, pn = Xe, gn = Ke, mn = Qe, vn = tr, bn = ze, yn = Ue, wn = He, Nn = We, hi[0] = xe, hi[1] = le, hi[2] = Ne, hi[3] = Le, hi[4] = Ae, hi[5] = _e, hi[6] = Se, hi[7] = Pe, hi[8] = Fe, hi[9] = ke, li[0] = me, li[1] = fe, li[2] = de, li[3] = pe, li[4] = ve, li[5] = be, li[6] = ye, fi[0] = Oe, fi[1] = he, fi[2] = Ie, fi[3] = Ce, fi[4] = Me, fi[5] = Be, fi[6] = qe, s = 1;
												} else s = 0;
											}
											s && (s = function(t, r) {
												for (t.M = 0; t.M < t.Va; ++t.M) {
													var o, s = t.Jc[t.M & t.Xb], u = t.m, c = t;
													for (o = 0; o < c.za; ++o) {
														var l = u, h = c, f = h.Ac, d = h.Bc + 4 * o, p = h.zc, g = h.ya[h.aa + o];
														if (h.Qa.Bb ? g.$b = k(l, h.Pa.jb[0]) ? 2 + k(l, h.Pa.jb[2]) : k(l, h.Pa.jb[1]) : g.$b = 0, h.kc && (g.Ad = k(l, h.Bd)), g.Za = !k(l, 145) + 0, g.Za) {
															var m = g.Ob, v = 0;
															for (h = 0; 4 > h; ++h) {
																var b, y = p[0 + h];
																for (b = 0; 4 > b; ++b) {
																	y = si[f[d + b]][y];
																	for (var w = ai[k(l, y[0])]; 0 < w;) w = ai[2 * w + k(l, y[w])];
																	y = -w, f[d + b] = y;
																}
																n(m, v, f, d, 4), v += 4, p[0 + h] = y;
															}
														} else y = k(l, 156) ? k(l, 128) ? 1 : 3 : k(l, 163) ? 2 : 0, g.Ob[0] = y, i(f, d, y, 4), i(p, 0, y, 4);
														g.Dd = k(l, 142) ? k(l, 114) ? k(l, 183) ? 1 : 3 : 2 : 0;
													}
													if (c.m.Ka) return Jt(t, 7, "Premature end-of-partition0 encountered.");
													for (; t.ja < t.za; ++t.ja) {
														if (c = s, l = (u = t).rb[u.sb - 1], f = u.rb[u.sb + u.ja], o = u.ya[u.aa + u.ja], d = u.kc ? o.Ad : 0) l.la = f.la = 0, o.Za || (l.Na = f.Na = 0), o.Hc = 0, o.Gc = 0, o.ia = 0;
														else {
															var N, L;
															if (l = f, f = c, d = u.Pa.Xc, p = u.ya[u.aa + u.ja], g = u.pb[p.$b], h = p.ad, m = 0, v = u.rb[u.sb - 1], y = b = 0, i(h, m, 0, 384), p.Za) var x = 0, A = d[3];
															else {
																w = a(16);
																var S = l.Na + v.Na;
																if (S = ri(f, d[1], S, g.Eb, 0, w, 0), l.Na = v.Na = (0 < S) + 0, 1 < S) nn(w, 0, h, m);
																else {
																	var _ = w[0] + 3 >> 3;
																	for (w = 0; 256 > w; w += 16) h[m + w] = _;
																}
																x = 1, A = d[0];
															}
															var P = 15 & l.la, F = 15 & v.la;
															for (w = 0; 4 > w; ++w) {
																var I = 1 & F;
																for (_ = L = 0; 4 > _; ++_) P = P >> 1 | (I = (S = ri(f, A, S = I + (1 & P), g.Sc, x, h, m)) > x) << 7, L = L << 2 | (3 < S ? 3 : 1 < S ? 2 : 0 != h[m + 0]), m += 16;
																P >>= 4, F = F >> 1 | I << 7, b = (b << 8 | L) >>> 0;
															}
															for (A = P, x = F >> 4, N = 0; 4 > N; N += 2) {
																for (L = 0, P = l.la >> 4 + N, F = v.la >> 4 + N, w = 0; 2 > w; ++w) {
																	for (I = 1 & F, _ = 0; 2 > _; ++_) S = I + (1 & P), P = P >> 1 | (I = 0 < (S = ri(f, d[2], S, g.Qc, 0, h, m))) << 3, L = L << 2 | (3 < S ? 3 : 1 < S ? 2 : 0 != h[m + 0]), m += 16;
																	P >>= 2, F = F >> 1 | I << 5;
																}
																y |= L << 4 * N, A |= P << 4 << N, x |= (240 & F) << N;
															}
															l.la = A, v.la = x, p.Hc = b, p.Gc = y, p.ia = 43690 & y ? 0 : g.ia, d = !(b | y);
														}
														if (0 < u.L && (u.wa[u.Y + u.ja] = u.gd[o.$b][o.Za], u.wa[u.Y + u.ja].La |= !d), c.Ka) return Jt(t, 7, "Premature end-of-file encountered.");
													}
													if ($t(t), u = r, c = 1, o = (s = t).D, l = 0 < s.L && s.M >= s.zb && s.M <= s.Va, 0 == s.Aa) e: {
														if (o.M = s.M, o.uc = l, jr(s, o), c = 1, o = (L = s.D).Nb, l = (y = Ri[s.L]) * s.R, f = y / 2 * s.B, w = 16 * o * s.R, _ = 8 * o * s.B, d = s.sa, p = s.ta - l + w, g = s.qa, h = s.ra - f + _, m = s.Ha, v = s.Ia - f + _, F = 0 == (P = L.M), b = P >= s.Va - 1, 2 == s.Aa && jr(s, L), L.uc) for (I = (S = s).D.M, e(S.D.uc), L = S.yb; L < S.Hb; ++L) {
															x = L, A = I;
															var C = (j = (z = S).D).Nb;
															N = z.R;
															var j = j.wa[j.Y + x], O = z.sa, B = z.ta + 16 * C * N + 16 * x, M = j.dd, q = j.tc;
															if (0 != q) if (e(3 <= q), 1 == z.L) 0 < x && yn(O, B, N, q + 4), j.La && Nn(O, B, N, q), 0 < A && bn(O, B, N, q + 4), j.La && wn(O, B, N, q);
															else {
																var E = z.B, R = z.qa, D = z.ra + 8 * C * E + 8 * x, T = z.Ha, z = z.Ia + 8 * C * E + 8 * x;
																C = j.ld, 0 < x && (hn(O, B, N, q + 4, M, C), dn(R, D, T, z, E, q + 4, M, C)), j.La && (gn(O, B, N, q, M, C), vn(R, D, T, z, E, q, M, C)), 0 < A && (ln(O, B, N, q + 4, M, C), fn(R, D, T, z, E, q + 4, M, C)), j.La && (pn(O, B, N, q, M, C), mn(R, D, T, z, E, q, M, C));
															}
														}
														if (s.ia && alert("todo:DitherRow"), null != u.put) {
															if (L = 16 * P, P = 16 * (P + 1), F ? (u.y = s.sa, u.O = s.ta + w, u.f = s.qa, u.N = s.ra + _, u.ea = s.Ha, u.W = s.Ia + _) : (L -= y, u.y = d, u.O = p, u.f = g, u.N = h, u.ea = m, u.W = v), b || (P -= y), P > u.o && (P = u.o), u.F = null, u.J = null, null != s.Fa && 0 < s.Fa.length && L < P && (u.J = lr(s, u, L, P - L), u.F = s.mb, null == u.F && 0 == u.F.length)) {
																c = Jt(s, 3, "Could not decode alpha data.");
																break e;
															}
															L < u.j && (y = u.j - L, L = u.j, e(!(1 & y)), u.O += s.R * y, u.N += s.B * (y >> 1), u.W += s.B * (y >> 1), null != u.F && (u.J += u.width * y)), L < P && (u.O += u.v, u.N += u.v >> 1, u.W += u.v >> 1, null != u.F && (u.J += u.v), u.ka = L - u.j, u.U = u.va - u.v, u.T = P - L, c = u.put(u));
														}
														o + 1 != s.Ic || b || (n(s.sa, s.ta - l, d, p + 16 * s.R, l), n(s.qa, s.ra - f, g, h + 8 * s.B, f), n(s.Ha, s.Ia - f, m, v + 8 * s.B, f));
													}
													if (!c) return Jt(t, 6, "Output aborted.");
												}
												return 1;
											}(t, r)), null != r.bc && r.bc(r), s &= 1;
										}
										return s ? (t.cb = 0, s) : 0;
									})(t, u) || (r = t.a);
								}
							} else r = t.a;
						}
						0 == r && null != h.Oa && h.Oa.fd && (r = Mr(h.ba));
					}
					h = r;
				}
				l = 0 != h ? null : 11 > l ? f.f.RGBA.eb : f.f.kb.y;
			} else l = null;
			return l;
		};
		var zi = [
			3,
			4,
			3,
			4,
			4,
			2,
			2,
			4,
			4,
			4,
			2,
			1,
			1
		];
	};
	function c(t, e) {
		for (var r = "", n = 0; n < 4; n++) r += String.fromCharCode(t[e++]);
		return r;
	}
	function l(t, e) {
		return t[e + 0] | t[e + 1] << 8;
	}
	function h(t, e) {
		return (t[e + 0] | t[e + 1] << 8 | t[e + 2] << 16) >>> 0;
	}
	function f(t, e) {
		return (t[e + 0] | t[e + 1] << 8 | t[e + 2] << 16 | t[e + 3] << 24) >>> 0;
	}
	new u();
	var d = [0], p = [0], g = [], m = new u(), v = t, b = function(t, e) {
		var r = {}, n = 0, i = !1, a = 0, o = 0;
		if (r.frames = [], !function(t, e) {
			/** @license
			* Copyright (c) 2017 Dominik Homberger
			Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
			The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
			THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
			https://webpjs.appspot.com
			WebPRiffParser dominikhlbg@gmail.com
			*/
			for (var r = 0; r < 4; r++) if (t[e + r] != "RIFF".charCodeAt(r)) return !0;
			return !1;
		}(t, e)) {
			for (f(t, e += 4), e += 8; e < t.length;) {
				var s = c(t, e), u = f(t, e += 4);
				e += 4;
				var d = u + (1 & u);
				switch (s) {
					case "VP8 ":
					case "VP8L":
						void 0 === r.frames[n] && (r.frames[n] = {}), (m = r.frames[n]).src_off = i ? o : e - 8, m.src_size = a + u + 8, n++, i && (i = !1, a = 0, o = 0);
						break;
					case "VP8X":
						(m = r.header = {}).feature_flags = t[e];
						var p = e + 4;
						m.canvas_width = 1 + h(t, p), p += 3, m.canvas_height = 1 + h(t, p), p += 3;
						break;
					case "ALPH":
						i = !0, a = d + 8, o = e - 8;
						break;
					case "ANIM":
						(m = r.header).bgcolor = f(t, e), p = e + 4, m.loop_count = l(t, p), p += 2;
						break;
					case "ANMF":
						var g, m;
						(m = r.frames[n] = {}).offset_x = 2 * h(t, e), e += 3, m.offset_y = 2 * h(t, e), e += 3, m.width = 1 + h(t, e), e += 3, m.height = 1 + h(t, e), e += 3, m.duration = h(t, e), e += 3, g = t[e++], m.dispose = 1 & g, m.blend = g >> 1 & 1;
				}
				"ANMF" != s && (e += d);
			}
			return r;
		}
	}(v, 0);
	b.response = v, b.rgbaoutput = !0, b.dataurl = !1;
	var y = b.header ? b.header : null, w = b.frames ? b.frames : null;
	if (y) {
		y.loop_counter = y.loop_count, d = [y.canvas_height], p = [y.canvas_width];
		for (var N = 0; N < w.length && 0 != w[N].blend; N++);
	}
	var L = w[0], x = m.WebPDecodeRGBA(v, L.src_off, L.src_size, p, d);
	L.rgba = x, L.imgwidth = p[0], L.imgheight = d[0];
	for (var A = 0; A < p[0] * d[0] * 4; A++) g[A] = x[A];
	return this.width = p, this.height = d, this.data = g, this;
}
/** ====================================================================
* @license
* jsPDF XMP metadata plugin
* Copyright (c) 2016 Jussi Utunen, u-jussi@suomi24.fi
*
* Permission is hereby granted, free of charge, to any person obtaining
* a copy of this software and associated documentation files (the
* "Software"), to deal in the Software without restriction, including
* without limitation the rights to use, copy, modify, merge, publish,
* distribute, sublicense, and/or sell copies of the Software, and to
* permit persons to whom the Software is furnished to do so, subject to
* the following conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
* LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
* OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
* WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
* ====================================================================
*/
function ce() {
	var t, e = this.internal.__metadata__.metadata, r = unescape(encodeURIComponent(e));
	t = this.internal.__metadata__.rawXml ? r : "<x:xmpmeta xmlns:x=\"adobe:ns:meta/\"><rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"><rdf:Description rdf:about=\"\" xmlns:jspdf=\"" + this.internal.__metadata__.namespaceUri + "\"><jspdf:metadata>" + r.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;") + "</jspdf:metadata></rdf:Description></rdf:RDF></x:xmpmeta>", this.internal.__metadata__.metadataObjectNumber = this.internal.newObject(), this.internal.write("<< /Type /Metadata /Subtype /XML /Length " + t.length + " >>"), this.internal.write("stream"), this.internal.write(t), this.internal.write("endstream"), this.internal.write("endobj");
}
function le() {
	this.internal.__metadata__.metadataObjectNumber && this.internal.write("/Metadata " + this.internal.__metadata__.metadataObjectNumber + " 0 R");
}
(function(e) {
	var r, n, i, a, s, u, c, l, f, d = function(t) {
		return t = t || {}, this.isStrokeTransparent = t.isStrokeTransparent || !1, this.strokeOpacity = t.strokeOpacity || 1, this.strokeStyle = t.strokeStyle || "#000000", this.fillStyle = t.fillStyle || "#000000", this.isFillTransparent = t.isFillTransparent || !1, this.fillOpacity = t.fillOpacity || 1, this.font = t.font || "10px sans-serif", this.textBaseline = t.textBaseline || "alphabetic", this.textAlign = t.textAlign || "left", this.lineWidth = t.lineWidth || 1, this.lineJoin = t.lineJoin || "miter", this.lineCap = t.lineCap || "butt", this.path = t.path || [], this.transform = void 0 !== t.transform ? t.transform.clone() : new l(), this.globalCompositeOperation = t.globalCompositeOperation || "normal", this.globalAlpha = t.globalAlpha || 1, this.clip_path = t.clip_path || [], this.currentPoint = t.currentPoint || new u(), this.miterLimit = t.miterLimit || 10, this.lastPoint = t.lastPoint || new u(), this.lineDashOffset = t.lineDashOffset || 0, this.lineDash = t.lineDash || [], this.margin = t.margin || [
			0,
			0,
			0,
			0
		], this.prevPageLastElemOffset = t.prevPageLastElemOffset || 0, this.ignoreClearRect = "boolean" != typeof t.ignoreClearRect || t.ignoreClearRect, this;
	};
	e.events.push(["initialized", function() {
		this.context2d = new p(this), r = this.internal.f2, n = this.internal.getCoordinateString, i = this.internal.getVerticalCoordinateString, a = this.internal.getHorizontalCoordinate, s = this.internal.getVerticalCoordinate, u = this.internal.Point, c = this.internal.Rectangle, l = this.internal.Matrix, f = new d();
	}]);
	var p = function(t) {
		Object.defineProperty(this, "canvas", { get: function() {
			return {
				parentNode: !1,
				style: !1
			};
		} });
		var e = t;
		Object.defineProperty(this, "pdf", { get: function() {
			return e;
		} });
		var r = !1;
		Object.defineProperty(this, "pageWrapXEnabled", {
			get: function() {
				return r;
			},
			set: function(t) {
				r = Boolean(t);
			}
		});
		var n = !1;
		Object.defineProperty(this, "pageWrapYEnabled", {
			get: function() {
				return n;
			},
			set: function(t) {
				n = Boolean(t);
			}
		});
		var i = 0;
		Object.defineProperty(this, "posX", {
			get: function() {
				return i;
			},
			set: function(t) {
				isNaN(t) || (i = t);
			}
		});
		var a = 0;
		Object.defineProperty(this, "posY", {
			get: function() {
				return a;
			},
			set: function(t) {
				isNaN(t) || (a = t);
			}
		}), Object.defineProperty(this, "margin", {
			get: function() {
				return f.margin;
			},
			set: function(t) {
				var e;
				"number" == typeof t ? e = [
					t,
					t,
					t,
					t
				] : ((e = new Array(4))[0] = t[0], e[1] = t.length >= 2 ? t[1] : e[0], e[2] = t.length >= 3 ? t[2] : e[0], e[3] = t.length >= 4 ? t[3] : e[1]), f.margin = e;
			}
		});
		var o = !1;
		Object.defineProperty(this, "autoPaging", {
			get: function() {
				return o;
			},
			set: function(t) {
				o = t;
			}
		});
		var s = 0;
		Object.defineProperty(this, "lastBreak", {
			get: function() {
				return s;
			},
			set: function(t) {
				s = t;
			}
		});
		var u = [];
		Object.defineProperty(this, "pageBreaks", {
			get: function() {
				return u;
			},
			set: function(t) {
				u = t;
			}
		}), Object.defineProperty(this, "ctx", {
			get: function() {
				return f;
			},
			set: function(t) {
				t instanceof d && (f = t);
			}
		}), Object.defineProperty(this, "path", {
			get: function() {
				return f.path;
			},
			set: function(t) {
				f.path = t;
			}
		});
		var c = [];
		Object.defineProperty(this, "ctxStack", {
			get: function() {
				return c;
			},
			set: function(t) {
				c = t;
			}
		}), Object.defineProperty(this, "fillStyle", {
			get: function() {
				return this.ctx.fillStyle;
			},
			set: function(t) {
				var e = g(t);
				this.ctx.fillStyle = e.style, this.ctx.isFillTransparent = 0 === e.a, this.ctx.fillOpacity = e.a, this.pdf.setFillColor(e.r, e.g, e.b, { a: e.a }), this.pdf.setTextColor(e.r, e.g, e.b, { a: e.a });
			}
		}), Object.defineProperty(this, "strokeStyle", {
			get: function() {
				return this.ctx.strokeStyle;
			},
			set: function(t) {
				var e = g(t);
				this.ctx.strokeStyle = e.style, this.ctx.isStrokeTransparent = 0 === e.a, this.ctx.strokeOpacity = e.a, 0 === e.a ? this.pdf.setDrawColor(255, 255, 255) : (e.a, this.pdf.setDrawColor(e.r, e.g, e.b));
			}
		}), Object.defineProperty(this, "lineCap", {
			get: function() {
				return this.ctx.lineCap;
			},
			set: function(t) {
				-1 !== [
					"butt",
					"round",
					"square"
				].indexOf(t) && (this.ctx.lineCap = t, this.pdf.setLineCap(t));
			}
		}), Object.defineProperty(this, "lineWidth", {
			get: function() {
				return this.ctx.lineWidth;
			},
			set: function(t) {
				isNaN(t) || (this.ctx.lineWidth = t, this.pdf.setLineWidth(t));
			}
		}), Object.defineProperty(this, "lineJoin", {
			get: function() {
				return this.ctx.lineJoin;
			},
			set: function(t) {
				-1 !== [
					"bevel",
					"round",
					"miter"
				].indexOf(t) && (this.ctx.lineJoin = t, this.pdf.setLineJoin(t));
			}
		}), Object.defineProperty(this, "miterLimit", {
			get: function() {
				return this.ctx.miterLimit;
			},
			set: function(t) {
				isNaN(t) || (this.ctx.miterLimit = t, this.pdf.setMiterLimit(t));
			}
		}), Object.defineProperty(this, "textBaseline", {
			get: function() {
				return this.ctx.textBaseline;
			},
			set: function(t) {
				this.ctx.textBaseline = t;
			}
		}), Object.defineProperty(this, "textAlign", {
			get: function() {
				return this.ctx.textAlign;
			},
			set: function(t) {
				-1 !== [
					"right",
					"end",
					"center",
					"left",
					"start"
				].indexOf(t) && (this.ctx.textAlign = t);
			}
		});
		var l = null, h = null;
		var p = null;
		Object.defineProperty(this, "fontFaces", {
			get: function() {
				return p;
			},
			set: function(t) {
				l = null, h = null, p = t;
			}
		}), Object.defineProperty(this, "font", {
			get: function() {
				return this.ctx.font;
			},
			set: function(t) {
				var e;
				if (this.ctx.font = t, null !== (e = /^\s*(?=(?:(?:[-a-z]+\s*){0,2}(italic|oblique))?)(?=(?:(?:[-a-z]+\s*){0,2}(small-caps))?)(?=(?:(?:[-a-z]+\s*){0,2}(bold(?:er)?|lighter|[1-9]00))?)(?:(?:normal|\1|\2|\3)\s*){0,3}((?:xx?-)?(?:small|large)|medium|smaller|larger|[.\d]+(?:\%|in|[cem]m|ex|p[ctx]))(?:\s*\/\s*(normal|[.\d]+(?:\%|in|[cem]m|ex|p[ctx])))?\s*([-_,\"\'\sa-z0-9]+?)\s*$/i.exec(t))) {
					var r = e[1];
					e[2];
					var n = e[3], i = e[4];
					e[5];
					var a = e[6], o = /^([.\d]+)((?:%|in|[cem]m|ex|p[ctx]))$/i.exec(i)[2];
					i = "px" === o ? Math.floor(parseFloat(i) * this.pdf.internal.scaleFactor) : "em" === o ? Math.floor(parseFloat(i) * this.pdf.getFontSize()) : Math.floor(parseFloat(i) * this.pdf.internal.scaleFactor), this.pdf.setFontSize(i);
					var s = function(t) {
						var e, r, n = [], i = t.trim();
						if ("" === i) return Gt;
						if (i in qt) return [qt[i]];
						for (; "" !== i;) {
							switch (r = null, e = (i = Rt(i)).charAt(0)) {
								case "\"":
								case "'":
									r = Dt(i.substring(1), e);
									break;
								default: r = Tt(i);
							}
							if (null === r) return Gt;
							if (n.push(r[0]), "" !== (i = Rt(r[1])) && "," !== i.charAt(0)) return Gt;
							i = i.replace(/^,/, "");
						}
						return n;
					}(a);
					if (this.fontFaces) {
						var f = function(t, e, r) {
							for (var n = (r = r || {}).defaultFontFamily || "times", i = Object.assign({}, Mt, r.genericFontFamilies || {}), a = null, o = null, s = 0; s < e.length; ++s) if (i[(a = Ot(e[s])).family] && (a.family = i[a.family]), t.hasOwnProperty(a.family)) {
								o = t[a.family];
								break;
							}
							if (!(o = o || t[n])) throw new Error("Could not find a font-family for the rule '" + Et(a) + "' and default family '" + n + "'.");
							if (o = function(t, e) {
								if (e[t]) return e[t];
								var r = It[t], i = Bt(e, Ft, r, r <= It.normal ? -1 : 1);
								if (!i) throw new Error("Could not find a matching font-stretch value for " + t);
								return i;
							}(a.stretch, o), o = function(t, e) {
								if (e[t]) return e[t];
								for (var r = kt[t], n = 0; n < r.length; ++n) if (e[r[n]]) return e[r[n]];
								throw new Error("Could not find a matching font-style for " + t);
							}(a.style, o), !(o = function(t, e) {
								if (e[t]) return e[t];
								if (400 === t && e[500]) return e[500];
								if (500 === t && e[400]) return e[400];
								var r = jt[t], n = Bt(e, Ct, r, t < 400 ? -1 : 1);
								if (!n) throw new Error("Could not find a matching font-weight for value " + t);
								return n;
							}(a.weight, o))) throw new Error("Failed to resolve a font for the rule '" + Et(a) + "'.");
							return o;
						}(function(t, e) {
							var r = t.getFontList(), n = JSON.stringify(r);
							if (null === l || h !== n) l = function(t) {
								for (var e = {}, r = 0; r < t.length; ++r) {
									var n = Ot(t[r]), i = n.family, a = n.stretch, o = n.style, s = n.weight;
									e[i] = e[i] || {}, e[i][a] = e[i][a] || {}, e[i][a][o] = e[i][a][o] || {}, e[i][a][o][s] = n;
								}
								return e;
							}(function(t) {
								var e = [];
								return Object.keys(t).forEach(function(r) {
									t[r].forEach(function(t) {
										var n = null;
										switch (t) {
											case "bold":
												n = {
													family: r,
													weight: "bold"
												};
												break;
											case "italic":
												n = {
													family: r,
													style: "italic"
												};
												break;
											case "bolditalic":
												n = {
													family: r,
													weight: "bold",
													style: "italic"
												};
												break;
											case "":
											case "normal": n = { family: r };
										}
										null !== n && (n.ref = {
											name: r,
											style: t
										}, e.push(n));
									});
								}), e;
							}(r).concat(e)), h = n;
							return l;
						}(this.pdf, this.fontFaces), s.map(function(t) {
							return {
								family: t,
								stretch: "normal",
								weight: n,
								style: r
							};
						}));
						this.pdf.setFont(f.ref.name, f.ref.style);
					} else {
						var d = "";
						("bold" === n || parseInt(n, 10) >= 700 || "bold" === r) && (d = "bold"), "italic" === r && (d += "italic"), 0 === d.length && (d = "normal");
						for (var p = "", g = {
							arial: "Helvetica",
							Arial: "Helvetica",
							verdana: "Helvetica",
							Verdana: "Helvetica",
							helvetica: "Helvetica",
							Helvetica: "Helvetica",
							"sans-serif": "Helvetica",
							fixed: "Courier",
							monospace: "Courier",
							terminal: "Courier",
							cursive: "Times",
							fantasy: "Times",
							serif: "Times"
						}, m = 0; m < s.length; m++) {
							if (void 0 !== this.pdf.internal.getFont(s[m], d, {
								noFallback: !0,
								disableWarning: !0
							})) {
								p = s[m];
								break;
							}
							if ("bolditalic" === d && void 0 !== this.pdf.internal.getFont(s[m], "bold", {
								noFallback: !0,
								disableWarning: !0
							})) p = s[m], d = "bold";
							else if (void 0 !== this.pdf.internal.getFont(s[m], "normal", {
								noFallback: !0,
								disableWarning: !0
							})) {
								p = s[m], d = "normal";
								break;
							}
						}
						if ("" === p) {
							for (var v = 0; v < s.length; v++) if (g[s[v]]) {
								p = g[s[v]];
								break;
							}
						}
						p = "" === p ? "Times" : p, this.pdf.setFont(p, d);
					}
				}
			}
		}), Object.defineProperty(this, "globalCompositeOperation", {
			get: function() {
				return this.ctx.globalCompositeOperation;
			},
			set: function(t) {
				this.ctx.globalCompositeOperation = t;
			}
		}), Object.defineProperty(this, "globalAlpha", {
			get: function() {
				return this.ctx.globalAlpha;
			},
			set: function(t) {
				this.ctx.globalAlpha = t;
			}
		}), Object.defineProperty(this, "lineDashOffset", {
			get: function() {
				return this.ctx.lineDashOffset;
			},
			set: function(t) {
				this.ctx.lineDashOffset = t, T.call(this);
			}
		}), Object.defineProperty(this, "lineDash", {
			get: function() {
				return this.ctx.lineDash;
			},
			set: function(t) {
				this.ctx.lineDash = t, T.call(this);
			}
		}), Object.defineProperty(this, "ignoreClearRect", {
			get: function() {
				return this.ctx.ignoreClearRect;
			},
			set: function(t) {
				this.ctx.ignoreClearRect = Boolean(t);
			}
		});
	};
	p.prototype.setLineDash = function(t) {
		this.lineDash = t;
	}, p.prototype.getLineDash = function() {
		return this.lineDash.length % 2 ? this.lineDash.concat(this.lineDash) : this.lineDash.slice();
	}, p.prototype.fill = function() {
		x.call(this, "fill", !1);
	}, p.prototype.stroke = function() {
		x.call(this, "stroke", !1);
	}, p.prototype.beginPath = function() {
		this.path = [{ type: "begin" }];
	}, p.prototype.moveTo = function(t, e) {
		if (isNaN(t) || isNaN(e)) throw o.error("jsPDF.context2d.moveTo: Invalid arguments", arguments), /* @__PURE__ */ new Error("Invalid arguments passed to jsPDF.context2d.moveTo");
		var r = this.ctx.transform.applyToPoint(new u(t, e));
		this.path.push({
			type: "mt",
			x: r.x,
			y: r.y
		}), this.ctx.lastPoint = new u(t, e);
	}, p.prototype.closePath = function() {
		var e = new u(0, 0), r = 0;
		for (r = this.path.length - 1; -1 !== r; r--) if ("begin" === this.path[r].type && "object" === _typeof(this.path[r + 1]) && "number" == typeof this.path[r + 1].x) {
			e = new u(this.path[r + 1].x, this.path[r + 1].y);
			break;
		}
		this.path.push({ type: "close" }), this.ctx.lastPoint = new u(e.x, e.y);
	}, p.prototype.lineTo = function(t, e) {
		if (isNaN(t) || isNaN(e)) throw o.error("jsPDF.context2d.lineTo: Invalid arguments", arguments), /* @__PURE__ */ new Error("Invalid arguments passed to jsPDF.context2d.lineTo");
		var r = this.ctx.transform.applyToPoint(new u(t, e));
		this.path.push({
			type: "lt",
			x: r.x,
			y: r.y
		}), this.ctx.lastPoint = new u(r.x, r.y);
	}, p.prototype.clip = function() {
		this.ctx.clip_path = JSON.parse(JSON.stringify(this.path)), x.call(this, null, !0);
	}, p.prototype.quadraticCurveTo = function(t, e, r, n) {
		if (isNaN(r) || isNaN(n) || isNaN(t) || isNaN(e)) throw o.error("jsPDF.context2d.quadraticCurveTo: Invalid arguments", arguments), /* @__PURE__ */ new Error("Invalid arguments passed to jsPDF.context2d.quadraticCurveTo");
		var i = this.ctx.transform.applyToPoint(new u(r, n)), a = this.ctx.transform.applyToPoint(new u(t, e));
		this.path.push({
			type: "qct",
			x1: a.x,
			y1: a.y,
			x: i.x,
			y: i.y
		}), this.ctx.lastPoint = new u(i.x, i.y);
	}, p.prototype.bezierCurveTo = function(t, e, r, n, i, a) {
		if (isNaN(i) || isNaN(a) || isNaN(t) || isNaN(e) || isNaN(r) || isNaN(n)) throw o.error("jsPDF.context2d.bezierCurveTo: Invalid arguments", arguments), /* @__PURE__ */ new Error("Invalid arguments passed to jsPDF.context2d.bezierCurveTo");
		var s = this.ctx.transform.applyToPoint(new u(i, a)), c = this.ctx.transform.applyToPoint(new u(t, e)), l = this.ctx.transform.applyToPoint(new u(r, n));
		this.path.push({
			type: "bct",
			x1: c.x,
			y1: c.y,
			x2: l.x,
			y2: l.y,
			x: s.x,
			y: s.y
		}), this.ctx.lastPoint = new u(s.x, s.y);
	}, p.prototype.arc = function(t, e, r, n, i, a) {
		if (isNaN(t) || isNaN(e) || isNaN(r) || isNaN(n) || isNaN(i)) throw o.error("jsPDF.context2d.arc: Invalid arguments", arguments), /* @__PURE__ */ new Error("Invalid arguments passed to jsPDF.context2d.arc");
		if (a = Boolean(a), !this.ctx.transform.isIdentity) {
			var s = this.ctx.transform.applyToPoint(new u(t, e));
			t = s.x, e = s.y;
			var c = this.ctx.transform.applyToPoint(new u(0, r)), l = this.ctx.transform.applyToPoint(new u(0, 0));
			r = Math.sqrt(Math.pow(c.x - l.x, 2) + Math.pow(c.y - l.y, 2));
		}
		Math.abs(i - n) >= 2 * Math.PI && (n = 0, i = 2 * Math.PI), this.path.push({
			type: "arc",
			x: t,
			y: e,
			radius: r,
			startAngle: n,
			endAngle: i,
			counterclockwise: a
		});
	}, p.prototype.arcTo = function(t, e, r, n, i) {
		throw new Error("arcTo not implemented.");
	}, p.prototype.rect = function(t, e, r, n) {
		if (isNaN(t) || isNaN(e) || isNaN(r) || isNaN(n)) throw o.error("jsPDF.context2d.rect: Invalid arguments", arguments), /* @__PURE__ */ new Error("Invalid arguments passed to jsPDF.context2d.rect");
		this.moveTo(t, e), this.lineTo(t + r, e), this.lineTo(t + r, e + n), this.lineTo(t, e + n), this.lineTo(t, e), this.lineTo(t + r, e), this.lineTo(t, e);
	}, p.prototype.fillRect = function(t, e, r, n) {
		if (isNaN(t) || isNaN(e) || isNaN(r) || isNaN(n)) throw o.error("jsPDF.context2d.fillRect: Invalid arguments", arguments), /* @__PURE__ */ new Error("Invalid arguments passed to jsPDF.context2d.fillRect");
		if (!m.call(this)) {
			var i = {};
			"butt" !== this.lineCap && (i.lineCap = this.lineCap, this.lineCap = "butt"), "miter" !== this.lineJoin && (i.lineJoin = this.lineJoin, this.lineJoin = "miter"), this.beginPath(), this.rect(t, e, r, n), this.fill(), i.hasOwnProperty("lineCap") && (this.lineCap = i.lineCap), i.hasOwnProperty("lineJoin") && (this.lineJoin = i.lineJoin);
		}
	}, p.prototype.strokeRect = function(t, e, r, n) {
		if (isNaN(t) || isNaN(e) || isNaN(r) || isNaN(n)) throw o.error("jsPDF.context2d.strokeRect: Invalid arguments", arguments), /* @__PURE__ */ new Error("Invalid arguments passed to jsPDF.context2d.strokeRect");
		v.call(this) || (this.beginPath(), this.rect(t, e, r, n), this.stroke());
	}, p.prototype.clearRect = function(t, e, r, n) {
		if (isNaN(t) || isNaN(e) || isNaN(r) || isNaN(n)) throw o.error("jsPDF.context2d.clearRect: Invalid arguments", arguments), /* @__PURE__ */ new Error("Invalid arguments passed to jsPDF.context2d.clearRect");
		this.ignoreClearRect || (this.fillStyle = "#ffffff", this.fillRect(t, e, r, n));
	}, p.prototype.save = function(t) {
		t = "boolean" != typeof t || t;
		for (var e = this.pdf.internal.getCurrentPageInfo().pageNumber, r = 0; r < this.pdf.internal.getNumberOfPages(); r++) this.pdf.setPage(r + 1), this.pdf.internal.out("q");
		if (this.pdf.setPage(e), t) {
			this.ctx.fontSize = this.pdf.internal.getFontSize();
			var n = new d(this.ctx);
			this.ctxStack.push(this.ctx), this.ctx = n;
		}
	}, p.prototype.restore = function(t) {
		t = "boolean" != typeof t || t;
		for (var e = this.pdf.internal.getCurrentPageInfo().pageNumber, r = 0; r < this.pdf.internal.getNumberOfPages(); r++) this.pdf.setPage(r + 1), this.pdf.internal.out("Q");
		this.pdf.setPage(e), t && 0 !== this.ctxStack.length && (this.ctx = this.ctxStack.pop(), this.fillStyle = this.ctx.fillStyle, this.strokeStyle = this.ctx.strokeStyle, this.font = this.ctx.font, this.lineCap = this.ctx.lineCap, this.lineWidth = this.ctx.lineWidth, this.lineJoin = this.ctx.lineJoin, this.lineDash = this.ctx.lineDash, this.lineDashOffset = this.ctx.lineDashOffset);
	}, p.prototype.toDataURL = function() {
		throw new Error("toDataUrl not implemented.");
	};
	var g = function(t) {
		var e, r, n, i;
		if (!0 === t.isCanvasGradient && (t = t.getColor()), !t) return {
			r: 0,
			g: 0,
			b: 0,
			a: 0,
			style: t
		};
		if (/transparent|rgba\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*0+\s*\)/.test(t)) e = 0, r = 0, n = 0, i = 0;
		else {
			var a = /rgb\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/.exec(t);
			if (null !== a) e = parseInt(a[1]), r = parseInt(a[2]), n = parseInt(a[3]), i = 1;
			else if (null !== (a = /rgba\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([\d.]+)\s*\)/.exec(t))) e = parseInt(a[1]), r = parseInt(a[2]), n = parseInt(a[3]), i = parseFloat(a[4]);
			else {
				if (i = 1, "string" == typeof t && "#" !== t.charAt(0)) {
					var o = new h(t);
					t = o.ok ? o.toHex() : "#000000";
				}
				4 === t.length ? (e = t.substring(1, 2), e += e, r = t.substring(2, 3), r += r, n = t.substring(3, 4), n += n) : (e = t.substring(1, 3), r = t.substring(3, 5), n = t.substring(5, 7)), e = parseInt(e, 16), r = parseInt(r, 16), n = parseInt(n, 16);
			}
		}
		return {
			r: e,
			g: r,
			b: n,
			a: i,
			style: t
		};
	}, m = function() {
		return this.ctx.isFillTransparent || 0 == this.globalAlpha;
	}, v = function() {
		return Boolean(this.ctx.isStrokeTransparent || 0 == this.globalAlpha);
	};
	p.prototype.fillText = function(t, e, r, n) {
		if (isNaN(e) || isNaN(r) || "string" != typeof t) throw o.error("jsPDF.context2d.fillText: Invalid arguments", arguments), /* @__PURE__ */ new Error("Invalid arguments passed to jsPDF.context2d.fillText");
		if (n = isNaN(n) ? void 0 : n, !m.call(this)) {
			var i = E(this.ctx.transform.rotation), a = this.ctx.transform.scaleX;
			C.call(this, {
				text: t,
				x: e,
				y: r,
				scale: a,
				angle: i,
				align: this.textAlign,
				maxWidth: n
			});
		}
	}, p.prototype.strokeText = function(t, e, r, n) {
		if (isNaN(e) || isNaN(r) || "string" != typeof t) throw o.error("jsPDF.context2d.strokeText: Invalid arguments", arguments), /* @__PURE__ */ new Error("Invalid arguments passed to jsPDF.context2d.strokeText");
		if (!v.call(this)) {
			n = isNaN(n) ? void 0 : n;
			var i = E(this.ctx.transform.rotation), a = this.ctx.transform.scaleX;
			C.call(this, {
				text: t,
				x: e,
				y: r,
				scale: a,
				renderingMode: "stroke",
				angle: i,
				align: this.textAlign,
				maxWidth: n
			});
		}
	}, p.prototype.measureText = function(t) {
		if ("string" != typeof t) throw o.error("jsPDF.context2d.measureText: Invalid arguments", arguments), /* @__PURE__ */ new Error("Invalid arguments passed to jsPDF.context2d.measureText");
		var e = this.pdf, r = this.pdf.internal.scaleFactor, n = e.internal.getFontSize(), i = e.getStringUnitWidth(t) * n / e.internal.scaleFactor;
		return new function(t) {
			var e = (t = t || {}).width || 0;
			return Object.defineProperty(this, "width", { get: function() {
				return e;
			} }), this;
		}({ width: i *= Math.round(96 * r / 72 * 1e4) / 1e4 });
	}, p.prototype.scale = function(t, e) {
		if (isNaN(t) || isNaN(e)) throw o.error("jsPDF.context2d.scale: Invalid arguments", arguments), /* @__PURE__ */ new Error("Invalid arguments passed to jsPDF.context2d.scale");
		var r = new l(t, 0, 0, e, 0, 0);
		this.ctx.transform = this.ctx.transform.multiply(r);
	}, p.prototype.rotate = function(t) {
		if (isNaN(t)) throw o.error("jsPDF.context2d.rotate: Invalid arguments", arguments), /* @__PURE__ */ new Error("Invalid arguments passed to jsPDF.context2d.rotate");
		var e = new l(Math.cos(t), Math.sin(t), -Math.sin(t), Math.cos(t), 0, 0);
		this.ctx.transform = this.ctx.transform.multiply(e);
	}, p.prototype.translate = function(t, e) {
		if (isNaN(t) || isNaN(e)) throw o.error("jsPDF.context2d.translate: Invalid arguments", arguments), /* @__PURE__ */ new Error("Invalid arguments passed to jsPDF.context2d.translate");
		var r = new l(1, 0, 0, 1, t, e);
		this.ctx.transform = this.ctx.transform.multiply(r);
	}, p.prototype.transform = function(t, e, r, n, i, a) {
		if (isNaN(t) || isNaN(e) || isNaN(r) || isNaN(n) || isNaN(i) || isNaN(a)) throw o.error("jsPDF.context2d.transform: Invalid arguments", arguments), /* @__PURE__ */ new Error("Invalid arguments passed to jsPDF.context2d.transform");
		var s = new l(t, e, r, n, i, a);
		this.ctx.transform = this.ctx.transform.multiply(s);
	}, p.prototype.setTransform = function(t, e, r, n, i, a) {
		t = isNaN(t) ? 1 : t, e = isNaN(e) ? 0 : e, r = isNaN(r) ? 0 : r, n = isNaN(n) ? 1 : n, i = isNaN(i) ? 0 : i, a = isNaN(a) ? 0 : a, this.ctx.transform = new l(t, e, r, n, i, a);
	};
	var b = function() {
		return this.margin[0] > 0 || this.margin[1] > 0 || this.margin[2] > 0 || this.margin[3] > 0;
	};
	p.prototype.drawImage = function(t, e, r, n, i, a, o, s, u) {
		var h = this.pdf.getImageProperties(t), f = 1, d = 1, p = 1, g = 1;
		void 0 !== n && void 0 !== s && (p = s / n, g = u / i, f = h.width / n * s / n, d = h.height / i * u / i), void 0 === a && (a = e, o = r, e = 0, r = 0), void 0 !== n && void 0 === s && (s = n, u = i), void 0 === n && void 0 === s && (s = h.width, u = h.height);
		var m = this.ctx.transform.decompose(), v = E(m.rotate.shx), w = new l(), x = (w = (w = (w = w.multiply(m.translate)).multiply(m.skew)).multiply(m.scale)).applyToRectangle(new c(a - e * p, o - r * g, n * f, i * d));
		if (this.autoPaging) {
			for (var S, _ = y.call(this, x), P = [], k = 0; k < _.length; k += 1) -1 === P.indexOf(_[k]) && P.push(_[k]);
			L(P);
			for (var F = P[0], I = P[P.length - 1], C = F; C < I + 1; C++) {
				this.pdf.setPage(C);
				var j = this.pdf.internal.pageSize.width - this.margin[3] - this.margin[1], O = 1 === C ? this.posY + this.margin[0] : this.margin[0], B = this.pdf.internal.pageSize.height - this.posY - this.margin[0] - this.margin[2], M = this.pdf.internal.pageSize.height - this.margin[0] - this.margin[2], q = 1 === C ? 0 : B + (C - 2) * M;
				if (0 !== this.ctx.clip_path.length) {
					var R = this.path;
					S = JSON.parse(JSON.stringify(this.ctx.clip_path)), this.path = N(S, this.posX + this.margin[3], -q + O + this.ctx.prevPageLastElemOffset), A.call(this, "fill", !0), this.path = R;
				}
				var D = JSON.parse(JSON.stringify(x));
				D = N([D], this.posX + this.margin[3], -q + O + this.ctx.prevPageLastElemOffset)[0];
				var T = (C > F || C < I) && b.call(this);
				T && (this.pdf.saveGraphicsState(), this.pdf.rect(this.margin[3], this.margin[0], j, M, null).clip().discardPath()), this.pdf.addImage(t, "JPEG", D.x, D.y, D.w, D.h, null, null, v), T && this.pdf.restoreGraphicsState();
			}
		} else this.pdf.addImage(t, "JPEG", x.x, x.y, x.w, x.h, null, null, v);
	};
	var y = function(t, e, r) {
		var n = [];
		e = e || this.pdf.internal.pageSize.width, r = r || this.pdf.internal.pageSize.height - this.margin[0] - this.margin[2];
		var i = this.posY + this.ctx.prevPageLastElemOffset;
		switch (t.type) {
			default:
			case "mt":
			case "lt":
				n.push(Math.floor((t.y + i) / r) + 1);
				break;
			case "arc":
				n.push(Math.floor((t.y + i - t.radius) / r) + 1), n.push(Math.floor((t.y + i + t.radius) / r) + 1);
				break;
			case "qct":
				var a = R(this.ctx.lastPoint.x, this.ctx.lastPoint.y, t.x1, t.y1, t.x, t.y);
				n.push(Math.floor((a.y + i) / r) + 1), n.push(Math.floor((a.y + a.h + i) / r) + 1);
				break;
			case "bct":
				var o = D(this.ctx.lastPoint.x, this.ctx.lastPoint.y, t.x1, t.y1, t.x2, t.y2, t.x, t.y);
				n.push(Math.floor((o.y + i) / r) + 1), n.push(Math.floor((o.y + o.h + i) / r) + 1);
				break;
			case "rect": n.push(Math.floor((t.y + i) / r) + 1), n.push(Math.floor((t.y + t.h + i) / r) + 1);
		}
		for (var s = 0; s < n.length; s += 1) for (; this.pdf.internal.getNumberOfPages() < n[s];) w.call(this);
		return n;
	}, w = function() {
		var t = this.fillStyle, e = this.strokeStyle, r = this.font, n = this.lineCap, i = this.lineWidth, a = this.lineJoin;
		this.pdf.addPage(), this.fillStyle = t, this.strokeStyle = e, this.font = r, this.lineCap = n, this.lineWidth = i, this.lineJoin = a;
	}, N = function(t, e, r) {
		for (var n = 0; n < t.length; n++) switch (t[n].type) {
			case "bct": t[n].x2 += e, t[n].y2 += r;
			case "qct": t[n].x1 += e, t[n].y1 += r;
			default: t[n].x += e, t[n].y += r;
		}
		return t;
	}, L = function(t) {
		return t.sort(function(t, e) {
			return t - e;
		});
	}, x = function(t, e) {
		var r = this.fillStyle, n = this.strokeStyle, i = this.lineCap, a = this.lineWidth, o = Math.abs(a * this.ctx.transform.scaleX), s = this.lineJoin;
		if (this.autoPaging) {
			for (var u, c, l = JSON.parse(JSON.stringify(this.path)), h = JSON.parse(JSON.stringify(this.path)), f = [], d = 0; d < h.length; d++) if (void 0 !== h[d].x) for (var p = y.call(this, h[d]), g = 0; g < p.length; g += 1) -1 === f.indexOf(p[g]) && f.push(p[g]);
			for (var m = 0; m < f.length; m++) for (; this.pdf.internal.getNumberOfPages() < f[m];) w.call(this);
			L(f);
			for (var v = f[0], x = f[f.length - 1], S = v; S < x + 1; S++) {
				this.pdf.setPage(S), this.fillStyle = r, this.strokeStyle = n, this.lineCap = i, this.lineWidth = o, this.lineJoin = s;
				var _ = this.pdf.internal.pageSize.width - this.margin[3] - this.margin[1], P = 1 === S ? this.posY + this.margin[0] : this.margin[0], k = this.pdf.internal.pageSize.height - this.posY - this.margin[0] - this.margin[2], F = this.pdf.internal.pageSize.height - this.margin[0] - this.margin[2], I = 1 === S ? 0 : k + (S - 2) * F;
				if (0 !== this.ctx.clip_path.length) {
					var C = this.path;
					u = JSON.parse(JSON.stringify(this.ctx.clip_path)), this.path = N(u, this.posX + this.margin[3], -I + P + this.ctx.prevPageLastElemOffset), A.call(this, t, !0), this.path = C;
				}
				if (c = JSON.parse(JSON.stringify(l)), this.path = N(c, this.posX + this.margin[3], -I + P + this.ctx.prevPageLastElemOffset), !1 === e || 0 === S) {
					var j = (S > v || S < x) && b.call(this);
					j && (this.pdf.saveGraphicsState(), this.pdf.rect(this.margin[3], this.margin[0], _, F, null).clip().discardPath()), A.call(this, t, e), j && this.pdf.restoreGraphicsState();
				}
				this.lineWidth = a;
			}
			this.path = l;
		} else this.lineWidth = o, A.call(this, t, e), this.lineWidth = a;
	}, A = function(t, e) {
		if (("stroke" !== t || e || !v.call(this)) && ("stroke" === t || e || !m.call(this))) {
			for (var r, n, i = [], a = this.path, o = 0; o < a.length; o++) {
				var s = a[o];
				switch (s.type) {
					case "begin":
						i.push({ begin: !0 });
						break;
					case "close":
						i.push({ close: !0 });
						break;
					case "mt":
						i.push({
							start: s,
							deltas: [],
							abs: []
						});
						break;
					case "lt":
						var u = i.length;
						if (a[o - 1] && !isNaN(a[o - 1].x) && (r = [s.x - a[o - 1].x, s.y - a[o - 1].y], u > 0)) {
							for (; u >= 0; u--) if (!0 !== i[u - 1].close && !0 !== i[u - 1].begin) {
								i[u - 1].deltas.push(r), i[u - 1].abs.push(s);
								break;
							}
						}
						break;
					case "bct":
						r = [
							s.x1 - a[o - 1].x,
							s.y1 - a[o - 1].y,
							s.x2 - a[o - 1].x,
							s.y2 - a[o - 1].y,
							s.x - a[o - 1].x,
							s.y - a[o - 1].y
						], i[i.length - 1].deltas.push(r);
						break;
					case "qct":
						var c = a[o - 1].x + 2 / 3 * (s.x1 - a[o - 1].x), l = a[o - 1].y + 2 / 3 * (s.y1 - a[o - 1].y), h = s.x + 2 / 3 * (s.x1 - s.x), f = s.y + 2 / 3 * (s.y1 - s.y), d = s.x, p = s.y;
						r = [
							c - a[o - 1].x,
							l - a[o - 1].y,
							h - a[o - 1].x,
							f - a[o - 1].y,
							d - a[o - 1].x,
							p - a[o - 1].y
						], i[i.length - 1].deltas.push(r);
						break;
					case "arc": i.push({
						deltas: [],
						abs: [],
						arc: !0
					}), Array.isArray(i[i.length - 1].abs) && i[i.length - 1].abs.push(s);
				}
			}
			n = e ? null : "stroke" === t ? "stroke" : "fill";
			for (var g = !1, b = 0; b < i.length; b++) if (i[b].arc) for (var y = i[b].abs, w = 0; w < y.length; w++) {
				var N = y[w];
				"arc" === N.type ? P.call(this, N.x, N.y, N.radius, N.startAngle, N.endAngle, N.counterclockwise, void 0, e, !g) : j.call(this, N.x, N.y), g = !0;
			}
			else if (!0 === i[b].close) this.pdf.internal.out("h"), g = !1;
			else if (!0 !== i[b].begin) {
				var L = i[b].start.x, x = i[b].start.y;
				O.call(this, i[b].deltas, L, x), g = !0;
			}
			n && k.call(this, n), e && F.call(this);
		}
	}, S = function(t) {
		var e = this.pdf.internal.getFontSize() / this.pdf.internal.scaleFactor, r = e * (this.pdf.internal.getLineHeightFactor() - 1);
		switch (this.ctx.textBaseline) {
			case "bottom": return t - r;
			case "top": return t + e - r;
			case "hanging": return t + e - 2 * r;
			case "middle": return t + e / 2 - r;
			default: return t;
		}
	}, _ = function(t) {
		return t + this.pdf.internal.getFontSize() / this.pdf.internal.scaleFactor * (this.pdf.internal.getLineHeightFactor() - 1);
	};
	p.prototype.createLinearGradient = function() {
		var t = function() {};
		return t.colorStops = [], t.addColorStop = function(t, e) {
			this.colorStops.push([t, e]);
		}, t.getColor = function() {
			return 0 === this.colorStops.length ? "#000000" : this.colorStops[0][1];
		}, t.isCanvasGradient = !0, t;
	}, p.prototype.createPattern = function() {
		return this.createLinearGradient();
	}, p.prototype.createRadialGradient = function() {
		return this.createLinearGradient();
	};
	var P = function(t, e, r, n, i, a, o, s, u) {
		for (var c = M.call(this, r, n, i, a), l = 0; l < c.length; l++) {
			var h = c[l];
			0 === l && (u ? I.call(this, h.x1 + t, h.y1 + e) : j.call(this, h.x1 + t, h.y1 + e)), B.call(this, t, e, h.x2, h.y2, h.x3, h.y3, h.x4, h.y4);
		}
		s ? F.call(this) : k.call(this, o);
	}, k = function(t) {
		switch (t) {
			case "stroke":
				this.pdf.internal.out("S");
				break;
			case "fill": this.pdf.internal.out("f");
		}
	}, F = function() {
		this.pdf.clip(), this.pdf.discardPath();
	}, I = function(t, e) {
		this.pdf.internal.out(n(t) + " " + i(e) + " m");
	}, C = function(t) {
		var e;
		switch (t.align) {
			case "right":
			case "end":
				e = "right";
				break;
			case "center":
				e = "center";
				break;
			default: e = "left";
		}
		var r, n, i, a = this.pdf.getTextDimensions(t.text), o = S.call(this, t.y), s = _.call(this, o) - a.h, h = this.ctx.transform.applyToPoint(new u(t.x, o));
		if (this.autoPaging) {
			var f = this.ctx.transform.decompose(), d = new l();
			d = (d = (d = d.multiply(f.translate)).multiply(f.skew)).multiply(f.scale);
			for (var p = this.ctx.transform.applyToRectangle(new c(t.x, o, a.w, a.h)), g = d.applyToRectangle(new c(t.x, s, a.w, a.h)), m = y.call(this, g), v = [], w = 0; w < m.length; w += 1) -1 === v.indexOf(m[w]) && v.push(m[w]);
			L(v);
			for (var x = v[0], P = v[v.length - 1], k = x; k < P + 1; k++) {
				this.pdf.setPage(k);
				var F = 1 === k ? this.posY + this.margin[0] : this.margin[0], I = this.pdf.internal.pageSize.height - this.posY - this.margin[0] - this.margin[2], C = this.pdf.internal.pageSize.height - this.margin[2], j = C - this.margin[0], O = this.pdf.internal.pageSize.width - this.margin[1], B = O - this.margin[3], M = 1 === k ? 0 : I + (k - 2) * j;
				if (0 !== this.ctx.clip_path.length) {
					var q = this.path;
					r = JSON.parse(JSON.stringify(this.ctx.clip_path)), this.path = N(r, this.posX + this.margin[3], -1 * M + F), A.call(this, "fill", !0), this.path = q;
				}
				var E = N([JSON.parse(JSON.stringify(g))], this.posX + this.margin[3], -M + F + this.ctx.prevPageLastElemOffset)[0];
				t.scale >= .01 && (n = this.pdf.internal.getFontSize(), this.pdf.setFontSize(n * t.scale), i = this.lineWidth, this.lineWidth = i * t.scale);
				var R = "text" !== this.autoPaging;
				if (R || E.y + E.h <= C) {
					if (R || E.y >= F && E.x <= O) {
						var D = R ? t.text : this.pdf.splitTextToSize(t.text, t.maxWidth || O - E.x)[0], T = N([JSON.parse(JSON.stringify(p))], this.posX + this.margin[3], -M + F + this.ctx.prevPageLastElemOffset)[0], z = R && (k > x || k < P) && b.call(this);
						z && (this.pdf.saveGraphicsState(), this.pdf.rect(this.margin[3], this.margin[0], B, j, null).clip().discardPath()), this.pdf.text(D, T.x, T.y, {
							angle: t.angle,
							align: e,
							renderingMode: t.renderingMode
						}), z && this.pdf.restoreGraphicsState();
					}
				} else E.y < C && (this.ctx.prevPageLastElemOffset += C - E.y);
				t.scale >= .01 && (this.pdf.setFontSize(n), this.lineWidth = i);
			}
		} else t.scale >= .01 && (n = this.pdf.internal.getFontSize(), this.pdf.setFontSize(n * t.scale), i = this.lineWidth, this.lineWidth = i * t.scale), this.pdf.text(t.text, h.x + this.posX, h.y + this.posY, {
			angle: t.angle,
			align: e,
			renderingMode: t.renderingMode,
			maxWidth: t.maxWidth
		}), t.scale >= .01 && (this.pdf.setFontSize(n), this.lineWidth = i);
	}, j = function(t, e, r, a) {
		r = r || 0, a = a || 0, this.pdf.internal.out(n(t + r) + " " + i(e + a) + " l");
	}, O = function(t, e, r) {
		return this.pdf.lines(t, e, r, null, null);
	}, B = function(t, e, n, i, o, u, c, l) {
		this.pdf.internal.out([
			r(a(n + t)),
			r(s(i + e)),
			r(a(o + t)),
			r(s(u + e)),
			r(a(c + t)),
			r(s(l + e)),
			"c"
		].join(" "));
	}, M = function(t, e, r, n) {
		for (var i = 2 * Math.PI, a = Math.PI / 2; e > r;) e -= i;
		var o = Math.abs(r - e);
		o < i && n && (o = i - o);
		for (var s = [], u = n ? -1 : 1, c = e; o > 1e-5;) {
			var l = c + u * Math.min(o, a);
			s.push(q.call(this, t, c, l)), o -= Math.abs(l - c), c = l;
		}
		return s;
	}, q = function(t, e, r) {
		var n = (r - e) / 2, i = t * Math.cos(n), a = t * Math.sin(n), o = i, s = -a, u = o * o + s * s, c = u + o * i + s * a, l = 4 / 3 * (Math.sqrt(2 * u * c) - c) / (o * a - s * i), h = o - l * s, f = s + l * o, d = h, p = -f, g = n + e, m = Math.cos(g), v = Math.sin(g);
		return {
			x1: t * Math.cos(e),
			y1: t * Math.sin(e),
			x2: h * m - f * v,
			y2: h * v + f * m,
			x3: d * m - p * v,
			y3: d * v + p * m,
			x4: t * Math.cos(r),
			y4: t * Math.sin(r)
		};
	}, E = function(t) {
		return 180 * t / Math.PI;
	}, R = function(t, e, r, n, i, a) {
		var o = t + .5 * (r - t), s = e + .5 * (n - e), u = i + .5 * (r - i), l = a + .5 * (n - a), h = Math.min(t, i, o, u), f = Math.max(t, i, o, u), d = Math.min(e, a, s, l), p = Math.max(e, a, s, l);
		return new c(h, d, f - h, p - d);
	}, D = function(t, e, r, n, i, a, o, s) {
		var u, l, h, f, d, p, g, m, v, b, y, w, N, L, x = r - t, A = n - e, S = i - r, _ = a - n, P = o - i, k = s - a;
		for (l = 0; l < 41; l++) v = (g = (h = t + (u = l / 40) * x) + u * ((d = r + u * S) - h)) + u * (d + u * (i + u * P - d) - g), b = (m = (f = e + u * A) + u * ((p = n + u * _) - f)) + u * (p + u * (a + u * k - p) - m), 0 == l ? (y = v, w = b, N = v, L = b) : (y = Math.min(y, v), w = Math.min(w, b), N = Math.max(N, v), L = Math.max(L, b));
		return new c(Math.round(y), Math.round(w), Math.round(N - y), Math.round(L - w));
	}, T = function() {
		if (this.prevLineDash || this.ctx.lineDash.length || this.ctx.lineDashOffset) {
			var t, e, r = (t = this.ctx.lineDash, e = this.ctx.lineDashOffset, JSON.stringify({
				lineDash: t,
				lineDashOffset: e
			}));
			this.prevLineDash !== r && (this.pdf.setLineDash(this.ctx.lineDash, this.ctx.lineDashOffset), this.prevLineDash = r);
		}
	};
})(E.API), function(t) {
	/**
	* @license
	* jsPDF filters PlugIn
	* Copyright (c) 2014 Aras Abbasi
	*
	* Licensed under the MIT License.
	* http://opensource.org/licenses/mit-license
	*/
	var r = function(t) {
		var e, r, n, i, a, o, s, u, c, l;
		for (/[^\x00-\xFF]/.test(t), r = [], n = 0, i = (t += e = "\0\0\0\0".slice(t.length % 4 || 4)).length; i > n; n += 4) 0 !== (a = (t.charCodeAt(n) << 24) + (t.charCodeAt(n + 1) << 16) + (t.charCodeAt(n + 2) << 8) + t.charCodeAt(n + 3)) ? (o = (a = ((a = ((a = ((a = (a - (l = a % 85)) / 85) - (c = a % 85)) / 85) - (u = a % 85)) / 85) - (s = a % 85)) / 85) % 85, r.push(o + 33, s + 33, u + 33, c + 33, l + 33)) : r.push(122);
		return function(t, e) {
			for (var r = e; r > 0; r--) t.pop();
		}(r, e.length), String.fromCharCode.apply(String, r) + "~>";
	}, n = function(t) {
		var e, r, n, i, a, o = String, s = "length", u = 255, c = "charCodeAt", l = "slice", h = "replace";
		for (t[l](-2), t = t[l](0, -2)[h](/\s/g, "")[h]("z", "!!!!!"), n = [], i = 0, a = (t += e = "uuuuu"[l](t[s] % 5 || 5))[s]; a > i; i += 5) r = 52200625 * (t[c](i) - 33) + 614125 * (t[c](i + 1) - 33) + 7225 * (t[c](i + 2) - 33) + 85 * (t[c](i + 3) - 33) + (t[c](i + 4) - 33), n.push(u & r >> 24, u & r >> 16, u & r >> 8, u & r);
		return function(t, e) {
			for (var r = e; r > 0; r--) t.pop();
		}(n, e[s]), o.fromCharCode.apply(o, n);
	}, i = function(t) {
		return t.split("").map(function(t) {
			return ("0" + t.charCodeAt().toString(16)).slice(-2);
		}).join("") + ">";
	}, a = function(t) {
		var e = /* @__PURE__ */ new RegExp(/^([0-9A-Fa-f]{2})+$/);
		if (-1 !== (t = t.replace(/\s/g, "")).indexOf(">") && (t = t.substr(0, t.indexOf(">"))), t.length % 2 && (t += "0"), !1 === e.test(t)) return "";
		for (var r = "", n = 0; n < t.length; n += 2) r += String.fromCharCode("0x" + (t[n] + t[n + 1]));
		return r;
	}, o = function(t) {
		for (var r = new Uint8Array(t.length), n = t.length; n--;) r[n] = t.charCodeAt(n);
		return (r = zlibSync(r)).reduce(function(t, e) {
			return t + String.fromCharCode(e);
		}, "");
	};
	t.processDataByFilters = function(t, e) {
		var s = 0, u = t || "", c = [];
		for ("string" == typeof (e = e || []) && (e = [e]), s = 0; s < e.length; s += 1) switch (e[s]) {
			case "ASCII85Decode":
			case "/ASCII85Decode":
				u = n(u), c.push("/ASCII85Encode");
				break;
			case "ASCII85Encode":
			case "/ASCII85Encode":
				u = r(u), c.push("/ASCII85Decode");
				break;
			case "ASCIIHexDecode":
			case "/ASCIIHexDecode":
				u = a(u), c.push("/ASCIIHexEncode");
				break;
			case "ASCIIHexEncode":
			case "/ASCIIHexEncode":
				u = i(u), c.push("/ASCIIHexDecode");
				break;
			case "FlateEncode":
			case "/FlateEncode":
				u = o(u), c.push("/FlateDecode");
				break;
			default: throw new Error("The filter: \"" + e[s] + "\" is not implemented");
		}
		return {
			data: u,
			reverseChain: c.reverse().join(" ")
		};
	};
}(E.API), function(t) {
	/**
	* @license
	* jsPDF fileloading PlugIn
	* Copyright (c) 2018 Aras Abbasi (aras.abbasi@gmail.com)
	*
	* Licensed under the MIT License.
	* http://opensource.org/licenses/mit-license
	*/
	t.loadFile = function(t, e, r) {
		return function(t, e, r) {
			e = !1 !== e, r = "function" == typeof r ? r : function() {};
			var n = void 0;
			try {
				n = function(t, e, r) {
					var n = new XMLHttpRequest(), i = 0, a = function(t) {
						var e = t.length, r = [], n = String.fromCharCode;
						for (i = 0; i < e; i += 1) r.push(n(255 & t.charCodeAt(i)));
						return r.join("");
					};
					if (n.open("GET", t, !e), n.overrideMimeType("text/plain; charset=x-user-defined"), !1 === e && (n.onload = function() {
						200 === n.status ? r(a(this.responseText)) : r(void 0);
					}), n.send(null), e && 200 === n.status) return a(n.responseText);
				}(t, e, r);
			} catch (i) {}
			return n;
		}(t, e, r);
	}, t.allowFsRead = void 0, t.loadImageFile = t.loadFile;
}(E.API), function(e) {
	function r() {
		return (i.html2canvas ? Promise.resolve(i.html2canvas) : __vitePreload(() => import("./html2canvas-DxQrDcbn.js").then((m) => /* @__PURE__ */ __toESM(m.default)), __vite__mapDeps([0,1]))).catch(function(t) {
			return Promise.reject(/* @__PURE__ */ new Error("Could not load html2canvas: " + t));
		}).then(function(t) {
			return t.default ? t.default : t;
		});
	}
	function n() {
		return (i.DOMPurify ? Promise.resolve(i.DOMPurify) : __vitePreload(() => import("./purify.es-WuMdzNhA.js"), [])).catch(function(t) {
			return Promise.reject(/* @__PURE__ */ new Error("Could not load dompurify: " + t));
		}).then(function(t) {
			return t.default ? t.default : t;
		});
	}
	var a = function(e) {
		var r = _typeof(e);
		return "undefined" === r ? "undefined" : "string" === r || e instanceof String ? "string" : "number" === r || e instanceof Number ? "number" : "function" === r || e instanceof Function ? "function" : e && e.constructor === Array ? "array" : e && 1 === e.nodeType ? "element" : "object" === r ? "object" : "unknown";
	}, o = function(t, e) {
		var r = document.createElement(t);
		for (var n in e.className && (r.className = e.className), e.innerHTML && e.dompurify && (r.innerHTML = e.dompurify.sanitize(e.innerHTML)), e.style) r.style[n] = e.style[n];
		return r;
	}, s = function t(e, r) {
		for (var n = 3 === e.nodeType ? document.createTextNode(e.nodeValue) : e.cloneNode(!1), i = e.firstChild; i; i = i.nextSibling) !0 !== r && 1 === i.nodeType && "SCRIPT" === i.nodeName || n.appendChild(t(i, r));
		return 1 === e.nodeType && ("CANVAS" === e.nodeName ? (n.width = e.width, n.height = e.height, n.getContext("2d").drawImage(e, 0, 0)) : "TEXTAREA" !== e.nodeName && "SELECT" !== e.nodeName || (n.value = e.value), n.addEventListener("load", function() {
			n.scrollTop = e.scrollTop, n.scrollLeft = e.scrollLeft;
		}, !0)), n;
	}, u = function t(e) {
		var r = Object.assign(t.convert(Promise.resolve()), JSON.parse(JSON.stringify(t.template))), n = t.convert(Promise.resolve(), r);
		return (n = n.setProgress(1, t, 1, [t])).set(e);
	};
	(u.prototype = Object.create(Promise.prototype)).constructor = u, u.convert = function(t, e) {
		return t.__proto__ = e || u.prototype, t;
	}, u.template = {
		prop: {
			src: null,
			container: null,
			overlay: null,
			canvas: null,
			img: null,
			pdf: null,
			pageSize: null,
			callback: function() {}
		},
		progress: {
			val: 0,
			state: null,
			n: 0,
			stack: []
		},
		opt: {
			filename: "file.pdf",
			margin: [
				0,
				0,
				0,
				0
			],
			enableLinks: !0,
			x: 0,
			y: 0,
			html2canvas: {},
			jsPDF: {},
			backgroundColor: "transparent"
		}
	}, u.prototype.from = function(t, e) {
		return this.then(function() {
			switch (e = e || function(t) {
				switch (a(t)) {
					case "string": return "string";
					case "element": return "canvas" === t.nodeName.toLowerCase() ? "canvas" : "element";
					default: return "unknown";
				}
			}(t), e) {
				case "string": return this.then(n).then(function(e) {
					return this.set({ src: o("div", {
						innerHTML: t,
						dompurify: e
					}) });
				});
				case "element": return this.set({ src: t });
				case "canvas": return this.set({ canvas: t });
				case "img": return this.set({ img: t });
				default: return this.error("Unknown source type.");
			}
		});
	}, u.prototype.to = function(t) {
		switch (t) {
			case "container": return this.toContainer();
			case "canvas": return this.toCanvas();
			case "img": return this.toImg();
			case "pdf": return this.toPdf();
			default: return this.error("Invalid target.");
		}
	}, u.prototype.toContainer = function() {
		return this.thenList([function() {
			return this.prop.src || this.error("Cannot duplicate - no source HTML.");
		}, function() {
			return this.prop.pageSize || this.setPageSize();
		}]).then(function() {
			var t = {
				position: "relative",
				display: "inline-block",
				width: ("number" != typeof this.opt.width || isNaN(this.opt.width) || "number" != typeof this.opt.windowWidth || isNaN(this.opt.windowWidth) ? Math.max(this.prop.src.clientWidth, this.prop.src.scrollWidth, this.prop.src.offsetWidth) : this.opt.windowWidth) + "px",
				left: 0,
				right: 0,
				top: 0,
				margin: "auto",
				backgroundColor: this.opt.backgroundColor
			}, e = s(this.prop.src, this.opt.html2canvas.javascriptEnabled);
			"BODY" === e.tagName && (t.height = Math.max(document.body.scrollHeight, document.body.offsetHeight, document.documentElement.clientHeight, document.documentElement.scrollHeight, document.documentElement.offsetHeight) + "px"), this.prop.overlay = o("div", {
				className: "html2pdf__overlay",
				style: {
					position: "fixed",
					overflow: "hidden",
					zIndex: 1e3,
					left: "-100000px",
					right: 0,
					bottom: 0,
					top: 0
				}
			}), this.prop.container = o("div", {
				className: "html2pdf__container",
				style: t
			}), this.prop.container.appendChild(e), this.prop.container.firstChild.appendChild(o("div", { style: {
				clear: "both",
				border: "0 none transparent",
				margin: 0,
				padding: 0,
				height: 0
			} })), this.prop.container.style.float = "none", this.prop.overlay.appendChild(this.prop.container), document.body.appendChild(this.prop.overlay), this.prop.container.firstChild.style.position = "relative", this.prop.container.height = Math.max(this.prop.container.firstChild.clientHeight, this.prop.container.firstChild.scrollHeight, this.prop.container.firstChild.offsetHeight) + "px";
		});
	}, u.prototype.toCanvas = function() {
		return this.thenList([function() {
			return document.body.contains(this.prop.container) || this.toContainer();
		}]).then(r).then(function(t) {
			var e = Object.assign({}, this.opt.html2canvas);
			return delete e.onrendered, t(this.prop.container, e);
		}).then(function(t) {
			(this.opt.html2canvas.onrendered || function() {})(t), this.prop.canvas = t, document.body.removeChild(this.prop.overlay);
		});
	}, u.prototype.toContext2d = function() {
		return this.thenList([function() {
			return document.body.contains(this.prop.container) || this.toContainer();
		}]).then(r).then(function(t) {
			var e = this.opt.jsPDF, r = this.opt.fontFaces, n = "number" != typeof this.opt.width || isNaN(this.opt.width) || "number" != typeof this.opt.windowWidth || isNaN(this.opt.windowWidth) ? 1 : this.opt.width / this.opt.windowWidth, i = Object.assign({
				async: !0,
				allowTaint: !0,
				scale: n,
				scrollX: this.opt.scrollX || 0,
				scrollY: this.opt.scrollY || 0,
				backgroundColor: "#ffffff",
				imageTimeout: 15e3,
				logging: !0,
				proxy: null,
				removeContainer: !0,
				foreignObjectRendering: !1,
				useCORS: !1
			}, this.opt.html2canvas);
			if (delete i.onrendered, e.context2d.autoPaging = void 0 === this.opt.autoPaging || this.opt.autoPaging, e.context2d.posX = this.opt.x, e.context2d.posY = this.opt.y, e.context2d.margin = this.opt.margin, e.context2d.fontFaces = r, r) for (var a = 0; a < r.length; ++a) {
				var o = r[a], s = o.src.find(function(t) {
					return "truetype" === t.format;
				});
				s && e.addFont(s.url, o.ref.name, o.ref.style);
			}
			return i.windowHeight = i.windowHeight || 0, i.windowHeight = 0 == i.windowHeight ? Math.max(this.prop.container.clientHeight, this.prop.container.scrollHeight, this.prop.container.offsetHeight) : i.windowHeight, e.context2d.save(!0), t(this.prop.container, i);
		}).then(function(t) {
			this.opt.jsPDF.context2d.restore(!0), (this.opt.html2canvas.onrendered || function() {})(t), this.prop.canvas = t, document.body.removeChild(this.prop.overlay);
		});
	}, u.prototype.toImg = function() {
		return this.thenList([function() {
			return this.prop.canvas || this.toCanvas();
		}]).then(function() {
			var t = this.prop.canvas.toDataURL("image/" + this.opt.image.type, this.opt.image.quality);
			this.prop.img = document.createElement("img"), this.prop.img.src = t;
		});
	}, u.prototype.toPdf = function() {
		return this.thenList([function() {
			return this.toContext2d();
		}]).then(function() {
			this.prop.pdf = this.prop.pdf || this.opt.jsPDF;
		});
	}, u.prototype.output = function(t, e, r) {
		return "img" === (r = r || "pdf").toLowerCase() || "image" === r.toLowerCase() ? this.outputImg(t, e) : this.outputPdf(t, e);
	}, u.prototype.outputPdf = function(t, e) {
		return this.thenList([function() {
			return this.prop.pdf || this.toPdf();
		}]).then(function() {
			return this.prop.pdf.output(t, e);
		});
	}, u.prototype.outputImg = function(t) {
		return this.thenList([function() {
			return this.prop.img || this.toImg();
		}]).then(function() {
			switch (t) {
				case void 0:
				case "img": return this.prop.img;
				case "datauristring":
				case "dataurlstring": return this.prop.img.src;
				case "datauri":
				case "dataurl": return document.location.href = this.prop.img.src;
				default: throw "Image output type \"" + t + "\" is not supported.";
			}
		});
	}, u.prototype.save = function(t) {
		return this.thenList([function() {
			return this.prop.pdf || this.toPdf();
		}]).set(t ? { filename: t } : null).then(function() {
			this.prop.pdf.save(this.opt.filename);
		});
	}, u.prototype.doCallback = function() {
		return this.thenList([function() {
			return this.prop.pdf || this.toPdf();
		}]).then(function() {
			this.prop.callback(this.prop.pdf);
		});
	}, u.prototype.set = function(t) {
		if ("object" !== a(t)) return this;
		var e = Object.keys(t || {}).map(function(e) {
			if (e in u.template.prop) return function() {
				this.prop[e] = t[e];
			};
			switch (e) {
				case "margin": return this.setMargin.bind(this, t.margin);
				case "jsPDF": return function() {
					return this.opt.jsPDF = t.jsPDF, this.setPageSize();
				};
				case "pageSize": return this.setPageSize.bind(this, t.pageSize);
				default: return function() {
					this.opt[e] = t[e];
				};
			}
		}, this);
		return this.then(function() {
			return this.thenList(e);
		});
	}, u.prototype.get = function(t, e) {
		return this.then(function() {
			var r = t in u.template.prop ? this.prop[t] : this.opt[t];
			return e ? e(r) : r;
		});
	}, u.prototype.setMargin = function(t) {
		return this.then(function() {
			switch (a(t)) {
				case "number": t = [
					t,
					t,
					t,
					t
				];
				case "array": if (2 === t.length && (t = [
					t[0],
					t[1],
					t[0],
					t[1]
				]), 4 === t.length) break;
				default: return this.error("Invalid margin array.");
			}
			this.opt.margin = t;
		}).then(this.setPageSize);
	}, u.prototype.setPageSize = function(t) {
		function e(t, e) {
			return Math.floor(t * e / 72 * 96);
		}
		return this.then(function() {
			(t = t || E.getPageSize(this.opt.jsPDF)).hasOwnProperty("inner") || (t.inner = {
				width: t.width - this.opt.margin[1] - this.opt.margin[3],
				height: t.height - this.opt.margin[0] - this.opt.margin[2]
			}, t.inner.px = {
				width: e(t.inner.width, t.k),
				height: e(t.inner.height, t.k)
			}, t.inner.ratio = t.inner.height / t.inner.width), this.prop.pageSize = t;
		});
	}, u.prototype.setProgress = function(t, e, r, n) {
		return null != t && (this.progress.val = t), null != e && (this.progress.state = e), null != r && (this.progress.n = r), null != n && (this.progress.stack = n), this.progress.ratio = this.progress.val / this.progress.state, this;
	}, u.prototype.updateProgress = function(t, e, r, n) {
		return this.setProgress(t ? this.progress.val + t : null, e || null, r ? this.progress.n + r : null, n ? this.progress.stack.concat(n) : null);
	}, u.prototype.then = function(t, e) {
		var r = this;
		return this.thenCore(t, e, function(t, e) {
			return r.updateProgress(null, null, 1, [t]), Promise.prototype.then.call(this, function(e) {
				return r.updateProgress(null, t), e;
			}).then(t, e).then(function(t) {
				return r.updateProgress(1), t;
			});
		});
	}, u.prototype.thenCore = function(t, e, r) {
		r = r || Promise.prototype.then;
		var n = this;
		t && (t = t.bind(n)), e && (e = e.bind(n));
		var i = -1 !== Promise.toString().indexOf("[native code]") && "Promise" === Promise.name ? n : u.convert(Object.assign({}, n), Promise.prototype), a = r.call(i, t, e);
		return u.convert(a, n.__proto__);
	}, u.prototype.thenExternal = function(t, e) {
		return Promise.prototype.then.call(this, t, e);
	}, u.prototype.thenList = function(t) {
		var e = this;
		return t.forEach(function(t) {
			e = e.thenCore(t);
		}), e;
	}, u.prototype.catch = function(t) {
		t && (t = t.bind(this));
		var e = Promise.prototype.catch.call(this, t);
		return u.convert(e, this);
	}, u.prototype.catchExternal = function(t) {
		return Promise.prototype.catch.call(this, t);
	}, u.prototype.error = function(t) {
		return this.then(function() {
			throw new Error(t);
		});
	}, u.prototype.using = u.prototype.set, u.prototype.saveAs = u.prototype.save, u.prototype.export = u.prototype.output, u.prototype.run = u.prototype.then, E.getPageSize = function(e, r, n) {
		if ("object" === _typeof(e)) {
			var i = e;
			e = i.orientation, r = i.unit || r, n = i.format || n;
		}
		r = r || "mm", n = n || "a4", e = ("" + (e || "P")).toLowerCase();
		var a, o = ("" + n).toLowerCase(), s = {
			a0: [2383.94, 3370.39],
			a1: [1683.78, 2383.94],
			a2: [1190.55, 1683.78],
			a3: [841.89, 1190.55],
			a4: [595.28, 841.89],
			a5: [419.53, 595.28],
			a6: [297.64, 419.53],
			a7: [209.76, 297.64],
			a8: [147.4, 209.76],
			a9: [104.88, 147.4],
			a10: [73.7, 104.88],
			b0: [2834.65, 4008.19],
			b1: [2004.09, 2834.65],
			b2: [1417.32, 2004.09],
			b3: [1000.63, 1417.32],
			b4: [708.66, 1000.63],
			b5: [498.9, 708.66],
			b6: [354.33, 498.9],
			b7: [249.45, 354.33],
			b8: [175.75, 249.45],
			b9: [124.72, 175.75],
			b10: [87.87, 124.72],
			c0: [2599.37, 3676.54],
			c1: [1836.85, 2599.37],
			c2: [1298.27, 1836.85],
			c3: [918.43, 1298.27],
			c4: [649.13, 918.43],
			c5: [459.21, 649.13],
			c6: [323.15, 459.21],
			c7: [229.61, 323.15],
			c8: [161.57, 229.61],
			c9: [113.39, 161.57],
			c10: [79.37, 113.39],
			dl: [311.81, 623.62],
			letter: [612, 792],
			"government-letter": [576, 756],
			legal: [612, 1008],
			"junior-legal": [576, 360],
			ledger: [1224, 792],
			tabloid: [792, 1224],
			"credit-card": [153, 243]
		};
		switch (r) {
			case "pt":
				a = 1;
				break;
			case "mm":
				a = 72 / 25.4;
				break;
			case "cm":
				a = 72 / 2.54;
				break;
			case "in":
				a = 72;
				break;
			case "px":
				a = .75;
				break;
			case "pc":
			case "em":
				a = 12;
				break;
			case "ex":
				a = 6;
				break;
			default: throw "Invalid unit: " + r;
		}
		var u, c = 0, l = 0;
		if (s.hasOwnProperty(o)) c = s[o][1] / a, l = s[o][0] / a;
		else try {
			c = n[1], l = n[0];
		} catch (h) {
			throw new Error("Invalid format: " + n);
		}
		if ("p" === e || "portrait" === e) e = "p", l > c && (u = l, l = c, c = u);
		else {
			if ("l" !== e && "landscape" !== e) throw "Invalid orientation: " + e;
			e = "l", c > l && (u = l, l = c, c = u);
		}
		return {
			width: l,
			height: c,
			unit: r,
			k: a,
			orientation: e
		};
	}, e.html = function(t, e) {
		(e = e || {}).callback = e.callback || function() {}, e.html2canvas = e.html2canvas || {}, e.html2canvas.canvas = e.html2canvas.canvas || this.canvas, e.jsPDF = e.jsPDF || this, e.fontFaces = e.fontFaces ? e.fontFaces.map(Ot) : null;
		var r = new u(e);
		return e.worker ? r : r.from(t).doCallback();
	};
}(E.API), E.API.addJS = function(t) {
	var e, r, n = function(t) {
		for (var e = "", r = 0; r < t.length; r++) {
			var n = t[r];
			if ("(" === n || ")" === n) {
				for (var i = 0, a = r - 1; a >= 0 && "\\" === t[a]; a--) i++;
				e += i % 2 == 0 ? "\\" + n : n;
			} else e += n;
		}
		return e;
	}(t);
	return this.internal.events.subscribe("postPutResources", function() {
		e = this.internal.newObject(), this.internal.out("<<"), this.internal.out("/Names [(EmbeddedJS) " + (e + 1) + " 0 R]"), this.internal.out(">>"), this.internal.out("endobj"), r = this.internal.newObject(), this.internal.out("<<"), this.internal.out("/S /JavaScript"), this.internal.out("/JS (" + n + ")"), this.internal.out(">>"), this.internal.out("endobj");
	}), this.internal.events.subscribe("putCatalog", function() {
		void 0 !== e && void 0 !== r && this.internal.out("/Names <</JavaScript " + e + " 0 R>>");
	}), this;
}, function(t) {
	/**
	* @license
	* Copyright (c) 2014 Steven Spungin (TwelveTone LLC)  steven@twelvetone.tv
	*
	* Licensed under the MIT License.
	* http://opensource.org/licenses/mit-license
	*/
	var e;
	t.events.push(["postPutResources", function() {
		var t = this, r = /^(\d+) 0 obj$/;
		if (this.outline.root.children.length > 0) for (var n = t.outline.render().split(/\r\n/), i = 0; i < n.length; i++) {
			var a = n[i], o = r.exec(a);
			if (null != o) {
				var s = o[1];
				t.internal.newObjectDeferredBegin(s, !1);
			}
			t.internal.write(a);
		}
		if (this.outline.createNamedDestinations) {
			var u = this.internal.pages.length, c = [];
			for (i = 0; i < u; i++) {
				var l = t.internal.newObject();
				c.push(l);
				var h = t.internal.getPageInfo(i + 1);
				t.internal.write("<< /D[" + h.objId + " 0 R /XYZ null null null]>> endobj");
			}
			var f = t.internal.newObject();
			for (t.internal.write("<< /Names [ "), i = 0; i < c.length; i++) t.internal.write("(page_" + (i + 1) + ")" + c[i] + " 0 R");
			t.internal.write(" ] >>", "endobj"), e = t.internal.newObject(), t.internal.write("<< /Dests " + f + " 0 R"), t.internal.write(">>", "endobj");
		}
	}]), t.events.push(["putCatalog", function() {
		var t = this;
		t.outline.root.children.length > 0 && (t.internal.write("/Outlines", this.outline.makeRef(this.outline.root)), this.outline.createNamedDestinations && t.internal.write("/Names " + e + " 0 R"));
	}]), t.events.push(["initialized", function() {
		var t = this;
		t.outline = {
			createNamedDestinations: !1,
			root: { children: [] }
		}, t.outline.add = function(t, e, r) {
			var n = {
				title: e,
				options: r,
				children: []
			};
			return t ??= this.root, t.children.push(n), n;
		}, t.outline.render = function() {
			return this.ctx = {}, this.ctx.val = "", this.ctx.pdf = t, this.genIds_r(this.root), this.renderRoot(this.root), this.renderItems(this.root), this.ctx.val;
		}, t.outline.genIds_r = function(e) {
			e.id = t.internal.newObjectDeferred();
			for (var r = 0; r < e.children.length; r++) this.genIds_r(e.children[r]);
		}, t.outline.renderRoot = function(t) {
			this.objStart(t), this.line("/Type /Outlines"), t.children.length > 0 && (this.line("/First " + this.makeRef(t.children[0])), this.line("/Last " + this.makeRef(t.children[t.children.length - 1]))), this.line("/Count " + this.count_r({ count: 0 }, t)), this.objEnd();
		}, t.outline.renderItems = function(e) {
			for (var r = this.ctx.pdf.internal.getVerticalCoordinateString, n = 0; n < e.children.length; n++) {
				var i = e.children[n];
				this.objStart(i), this.line("/Title " + this.makeString(i.title)), this.line("/Parent " + this.makeRef(e)), n > 0 && this.line("/Prev " + this.makeRef(e.children[n - 1])), n < e.children.length - 1 && this.line("/Next " + this.makeRef(e.children[n + 1])), i.children.length > 0 && (this.line("/First " + this.makeRef(i.children[0])), this.line("/Last " + this.makeRef(i.children[i.children.length - 1])));
				var a = this.count = this.count_r({ count: 0 }, i);
				if (a > 0 && this.line("/Count " + a), i.options && i.options.pageNumber) {
					var o = t.internal.getPageInfo(i.options.pageNumber);
					this.line("/Dest [" + o.objId + " 0 R /XYZ 0 " + r(0) + " 0]");
				}
				this.objEnd();
			}
			for (var s = 0; s < e.children.length; s++) this.renderItems(e.children[s]);
		}, t.outline.line = function(t) {
			this.ctx.val += t + "\r\n";
		}, t.outline.makeRef = function(t) {
			return t.id + " 0 R";
		}, t.outline.makeString = function(e) {
			return "(" + t.internal.pdfEscape(e) + ")";
		}, t.outline.objStart = function(t) {
			this.ctx.val += "\r\n" + t.id + " 0 obj\r\n<<\r\n";
		}, t.outline.objEnd = function() {
			this.ctx.val += ">> \r\nendobj\r\n";
		}, t.outline.count_r = function(t, e) {
			for (var r = 0; r < e.children.length; r++) t.count++, this.count_r(t, e.children[r]);
			return t.count;
		};
	}]);
}(E.API), function(t) {
	/**
	* @license
	*
	* Licensed under the MIT License.
	* http://opensource.org/licenses/mit-license
	*/
	var e = [
		192,
		193,
		194,
		195,
		196,
		197,
		198,
		199
	];
	t.processJPEG = function(t, r, n, i, a, o) {
		var s, u = this.decode.DCT_DECODE, c = null;
		if ("string" == typeof t || this.__addimage__.isArrayBuffer(t) || this.__addimage__.isArrayBufferView(t)) {
			switch (t = a || t, t = this.__addimage__.isArrayBuffer(t) ? new Uint8Array(t) : t, s = function(t) {
				for (var r, n = 256 * t.charCodeAt(4) + t.charCodeAt(5), i = t.length, a = {
					width: 0,
					height: 0,
					numcomponents: 1
				}, o = 4; o < i; o += 2) {
					if (o += n, -1 !== e.indexOf(t.charCodeAt(o + 1))) {
						r = 256 * t.charCodeAt(o + 5) + t.charCodeAt(o + 6), a = {
							width: 256 * t.charCodeAt(o + 7) + t.charCodeAt(o + 8),
							height: r,
							numcomponents: t.charCodeAt(o + 9)
						};
						break;
					}
					n = 256 * t.charCodeAt(o + 2) + t.charCodeAt(o + 3);
				}
				return a;
			}(t = this.__addimage__.isArrayBufferView(t) ? this.__addimage__.arrayBufferToBinaryString(t) : t), s.numcomponents) {
				case 1:
					o = this.color_spaces.DEVICE_GRAY;
					break;
				case 4:
					o = this.color_spaces.DEVICE_CMYK;
					break;
				case 3: o = this.color_spaces.DEVICE_RGB;
			}
			c = {
				data: t,
				width: s.width,
				height: s.height,
				colorSpace: o,
				bitsPerComponent: 8,
				filter: u,
				index: r,
				alias: n
			};
		}
		return c;
	};
}(E.API), E.API.processPNG = function(t, i, a, o) {
	if (this.__addimage__.isArrayBuffer(t) && (t = new Uint8Array(t)), this.__addimage__.isArrayBufferView(t)) {
		var s, u = decodePng(t, { checkCrc: !0 }), c = u.width, l = u.height, h = u.channels, f = u.palette, d = u.depth;
		s = f && 1 === h ? function(t) {
			for (var e = t.width, n = t.height, i = t.data, a = t.palette, o = t.depth, s = !1, u = [], c = [], l = void 0, h = !1, f = 0, d = 0; d < a.length; d++) {
				var p = _slicedToArray(a[d], 4), g = p[0], m = p[1], v = p[2], b = p[3];
				u.push(g, m, v), null != b && (0 === b ? (f++, c.length < 1 && c.push(d)) : b < 255 && (h = !0));
			}
			if (h || f > 1) {
				s = !0, c = void 0;
				var y = e * n;
				l = new Uint8Array(y);
				for (var w = new DataView(i.buffer), N = 0; N < y; N++) {
					var x = _slicedToArray(a[ee(w, N, o)], 4)[3];
					l[N] = x;
				}
			} else 0 === f && (c = void 0);
			return {
				colorSpace: "Indexed",
				colorsPerPixel: 1,
				sMaskBitsPerComponent: s ? 8 : void 0,
				colorBytes: i,
				alphaBytes: l,
				needSMask: s,
				palette: u,
				mask: c
			};
		}(u) : 2 === h || 4 === h ? function(t) {
			for (var e = t.data, r = t.width, n = t.height, i = t.channels, a = t.depth, o = 2 === i ? "DeviceGray" : "DeviceRGB", s = i - 1, u = r * n, c = s, l = u * c, h = 1 * u, f = Math.ceil(l * a / 8), d = Math.ceil(h * a / 8), p = new Uint8Array(f), g = new Uint8Array(d), m = new DataView(e.buffer), v = new DataView(p.buffer), b = new DataView(g.buffer), y = !1, w = 0; w < u; w++) {
				for (var N = w * i, L = 0; L < c; L++) re(v, ee(m, N + L, a), w * c + L, a);
				var x = ee(m, N + c, a);
				x < (1 << a) - 1 && (y = !0), re(b, x, 1 * w, a);
			}
			return {
				colorSpace: o,
				colorsPerPixel: s,
				sMaskBitsPerComponent: y ? a : void 0,
				colorBytes: p,
				alphaBytes: g,
				needSMask: y
			};
		}(u) : function(t) {
			var e = t.data, r = 1 === t.channels ? "DeviceGray" : "DeviceRGB";
			return {
				colorSpace: r,
				colorsPerPixel: "DeviceGray" === r ? 1 : 3,
				colorBytes: e instanceof Uint16Array ? function(t) {
					for (var e = t.length, r = new Uint8Array(2 * e), n = new DataView(r.buffer, r.byteOffset, r.byteLength), i = 0; i < e; i++) n.setUint16(2 * i, t[i], !1);
					return r;
				}(e) : e,
				needSMask: !1
			};
		}(u);
		var p, g, m, v = s, b = v.colorSpace, y = v.colorsPerPixel, w = v.sMaskBitsPerComponent, N = v.colorBytes, L = v.alphaBytes, x = v.needSMask, A = v.palette, S = v.mask, _ = null;
		return o !== E.API.image_compression.NONE && "function" == typeof zlibSync ? (_ = function(t) {
			var e;
			switch (t) {
				case E.API.image_compression.FAST:
					e = 11;
					break;
				case E.API.image_compression.MEDIUM:
					e = 13;
					break;
				case E.API.image_compression.SLOW:
					e = 14;
					break;
				default: e = 12;
			}
			return e;
		}(o), p = this.decode.FLATE_DECODE, g = "/Predictor ".concat(_, " /Colors ").concat(y, " /BitsPerComponent ").concat(d, " /Columns ").concat(c), t = Yt(N, Math.ceil(c * y * d / 8), y, d, o), x && (m = Yt(L, Math.ceil(c * w / 8), 1, w, o))) : (p = void 0, g = void 0, t = N, x && (m = L)), (this.__addimage__.isArrayBuffer(t) || this.__addimage__.isArrayBufferView(t)) && (t = this.__addimage__.arrayBufferToBinaryString(t)), (m && this.__addimage__.isArrayBuffer(m) || this.__addimage__.isArrayBufferView(m)) && (m = this.__addimage__.arrayBufferToBinaryString(m)), {
			alias: a,
			data: t,
			index: i,
			filter: p,
			decodeParameters: g,
			transparency: S,
			palette: A,
			sMask: m,
			predictor: _,
			width: c,
			height: l,
			bitsPerComponent: d,
			sMaskBitsPerComponent: w,
			colorSpace: b
		};
	}
}, function(t) {
	t.processGIF89A = function(e, r, n, i) {
		var a = new ie(e), o = a.width, s = a.height, u = [];
		a.decodeAndBlitFrameRGBA(0, u);
		var c = {
			data: u,
			width: o,
			height: s
		}, l = new oe(100).encode(c, 100);
		return t.processJPEG.call(this, l, r, n, i);
	}, t.processGIF87A = t.processGIF89A;
}(E.API), se.prototype.parseHeader = function() {
	if (this.fileSize = this.datav.getUint32(this.pos, !0), this.pos += 4, this.reserved = this.datav.getUint32(this.pos, !0), this.pos += 4, this.offset = this.datav.getUint32(this.pos, !0), this.pos += 4, this.headerSize = this.datav.getUint32(this.pos, !0), this.pos += 4, this.width = this.datav.getUint32(this.pos, !0), this.pos += 4, this.height = this.datav.getInt32(this.pos, !0), this.pos += 4, this.planes = this.datav.getUint16(this.pos, !0), this.pos += 2, this.bitPP = this.datav.getUint16(this.pos, !0), this.pos += 2, this.compress = this.datav.getUint32(this.pos, !0), this.pos += 4, this.rawSize = this.datav.getUint32(this.pos, !0), this.pos += 4, this.hr = this.datav.getUint32(this.pos, !0), this.pos += 4, this.vr = this.datav.getUint32(this.pos, !0), this.pos += 4, this.colors = this.datav.getUint32(this.pos, !0), this.pos += 4, this.importantColors = this.datav.getUint32(this.pos, !0), this.pos += 4, 16 === this.bitPP && this.is_with_alpha && (this.bitPP = 15), this.bitPP < 15) {
		var t = 0 === this.colors ? 1 << this.bitPP : this.colors;
		this.palette = new Array(t);
		for (var e = 0; e < t; e++) {
			var r = this.datav.getUint8(this.pos++, !0), n = this.datav.getUint8(this.pos++, !0), i = this.datav.getUint8(this.pos++, !0), a = this.datav.getUint8(this.pos++, !0);
			this.palette[e] = {
				red: i,
				green: n,
				blue: r,
				quad: a
			};
		}
	}
	this.height < 0 && (this.height *= -1, this.bottom_up = !1);
}, se.prototype.parseBGR = function() {
	this.pos = this.offset;
	var t = "bit" + this.bitPP, e = this.width * this.height * 4;
	if (e > 536870912) throw new Error("Image dimensions exceed 512MB, which is too large.");
	this.data = new Uint8Array(e);
	try {
		this[t]();
	} catch (r) {
		o.log("bit decode error:" + r);
	}
}, se.prototype.bit1 = function() {
	var t, e = Math.ceil(this.width / 8), r = e % 4;
	for (t = this.height - 1; t >= 0; t--) {
		for (var n = this.bottom_up ? t : this.height - 1 - t, i = 0; i < e; i++) for (var a = this.datav.getUint8(this.pos++, !0), o = n * this.width * 4 + 8 * i * 4, s = 0; s < 8 && 8 * i + s < this.width; s++) {
			var u = this.palette[a >> 7 - s & 1];
			this.data[o + 4 * s] = u.blue, this.data[o + 4 * s + 1] = u.green, this.data[o + 4 * s + 2] = u.red, this.data[o + 4 * s + 3] = 255;
		}
		0 !== r && (this.pos += 4 - r);
	}
}, se.prototype.bit4 = function() {
	for (var t = Math.ceil(this.width / 2), e = t % 4, r = this.height - 1; r >= 0; r--) {
		for (var n = this.bottom_up ? r : this.height - 1 - r, i = 0; i < t; i++) {
			var a = this.datav.getUint8(this.pos++, !0), o = n * this.width * 4 + 2 * i * 4, s = a >> 4, u = 15 & a, c = this.palette[s];
			if (this.data[o] = c.blue, this.data[o + 1] = c.green, this.data[o + 2] = c.red, this.data[o + 3] = 255, 2 * i + 1 >= this.width) break;
			c = this.palette[u], this.data[o + 4] = c.blue, this.data[o + 4 + 1] = c.green, this.data[o + 4 + 2] = c.red, this.data[o + 4 + 3] = 255;
		}
		0 !== e && (this.pos += 4 - e);
	}
}, se.prototype.bit8 = function() {
	for (var t = this.width % 4, e = this.height - 1; e >= 0; e--) {
		for (var r = this.bottom_up ? e : this.height - 1 - e, n = 0; n < this.width; n++) {
			var i = this.datav.getUint8(this.pos++, !0), a = r * this.width * 4 + 4 * n;
			if (i < this.palette.length) {
				var o = this.palette[i];
				this.data[a] = o.red, this.data[a + 1] = o.green, this.data[a + 2] = o.blue, this.data[a + 3] = 255;
			} else this.data[a] = 255, this.data[a + 1] = 255, this.data[a + 2] = 255, this.data[a + 3] = 255;
		}
		0 !== t && (this.pos += 4 - t);
	}
}, se.prototype.bit15 = function() {
	for (var t = this.width % 3, e = parseInt("11111", 2), r = this.height - 1; r >= 0; r--) {
		for (var n = this.bottom_up ? r : this.height - 1 - r, i = 0; i < this.width; i++) {
			var a = this.datav.getUint16(this.pos, !0);
			this.pos += 2;
			var o = (a & e) / e * 255 | 0, s = (a >> 5 & e) / e * 255 | 0, u = (a >> 10 & e) / e * 255 | 0, c = a >> 15 ? 255 : 0, l = n * this.width * 4 + 4 * i;
			this.data[l] = u, this.data[l + 1] = s, this.data[l + 2] = o, this.data[l + 3] = c;
		}
		this.pos += t;
	}
}, se.prototype.bit16 = function() {
	for (var t = this.width % 3, e = parseInt("11111", 2), r = parseInt("111111", 2), n = this.height - 1; n >= 0; n--) {
		for (var i = this.bottom_up ? n : this.height - 1 - n, a = 0; a < this.width; a++) {
			var o = this.datav.getUint16(this.pos, !0);
			this.pos += 2;
			var s = (o & e) / e * 255 | 0, u = (o >> 5 & r) / r * 255 | 0, c = (o >> 11) / e * 255 | 0, l = i * this.width * 4 + 4 * a;
			this.data[l] = c, this.data[l + 1] = u, this.data[l + 2] = s, this.data[l + 3] = 255;
		}
		this.pos += t;
	}
}, se.prototype.bit24 = function() {
	for (var t = this.height - 1; t >= 0; t--) {
		for (var e = this.bottom_up ? t : this.height - 1 - t, r = 0; r < this.width; r++) {
			var n = this.datav.getUint8(this.pos++, !0), i = this.datav.getUint8(this.pos++, !0), a = this.datav.getUint8(this.pos++, !0), o = e * this.width * 4 + 4 * r;
			this.data[o] = a, this.data[o + 1] = i, this.data[o + 2] = n, this.data[o + 3] = 255;
		}
		this.pos += this.width % 4;
	}
}, se.prototype.bit32 = function() {
	for (var t = this.height - 1; t >= 0; t--) for (var e = this.bottom_up ? t : this.height - 1 - t, r = 0; r < this.width; r++) {
		var n = this.datav.getUint8(this.pos++, !0), i = this.datav.getUint8(this.pos++, !0), a = this.datav.getUint8(this.pos++, !0), o = this.datav.getUint8(this.pos++, !0), s = e * this.width * 4 + 4 * r;
		this.data[s] = a, this.data[s + 1] = i, this.data[s + 2] = n, this.data[s + 3] = o;
	}
}, se.prototype.getData = function() {
	return this.data;
}, function(t) {
	/**
	* @license
	* Copyright (c) 2018 Aras Abbasi
	*
	* Licensed under the MIT License.
	* http://opensource.org/licenses/mit-license
	*/
	t.processBMP = function(e, r, n, i) {
		var a = new se(e, !1), o = a.width, s = a.height, u = {
			data: a.getData(),
			width: o,
			height: s
		}, c = new oe(100).encode(u, 100);
		return t.processJPEG.call(this, c, r, n, i);
	};
}(E.API), ue.prototype.getData = function() {
	return this.data;
}, function(t) {
	/**
	* @license
	* Copyright (c) 2019 Aras Abbasi
	*
	* Licensed under the MIT License.
	* http://opensource.org/licenses/mit-license
	*/
	t.processWEBP = function(e, r, n, i) {
		var a = new ue(e), o = a.width, s = a.height, u = {
			data: a.getData(),
			width: o,
			height: s
		}, c = new oe(100).encode(u, 100);
		return t.processJPEG.call(this, c, r, n, i);
	};
}(E.API), E.API.processRGBA = function(t, e, r) {
	for (var n = t.data, i = n.length, a = new Uint8Array(i / 4 * 3), o = new Uint8Array(i / 4), s = 0, u = 0, c = 0; c < i; c += 4) {
		var l = n[c], h = n[c + 1], f = n[c + 2], d = n[c + 3];
		a[s++] = l, a[s++] = h, a[s++] = f, o[u++] = d;
	}
	var p = this.__addimage__.arrayBufferToBinaryString(a);
	return {
		alpha: this.__addimage__.arrayBufferToBinaryString(o),
		data: p,
		index: e,
		alias: r,
		colorSpace: "DeviceRGB",
		bitsPerComponent: 8,
		width: t.width,
		height: t.height
	};
}, E.API.setLanguage = function(t) {
	return void 0 === this.internal.languageSettings && (this.internal.languageSettings = {}, this.internal.languageSettings.isSubscribed = !1), void 0 !== {
		af: "Afrikaans",
		sq: "Albanian",
		ar: "Arabic (Standard)",
		"ar-DZ": "Arabic (Algeria)",
		"ar-BH": "Arabic (Bahrain)",
		"ar-EG": "Arabic (Egypt)",
		"ar-IQ": "Arabic (Iraq)",
		"ar-JO": "Arabic (Jordan)",
		"ar-KW": "Arabic (Kuwait)",
		"ar-LB": "Arabic (Lebanon)",
		"ar-LY": "Arabic (Libya)",
		"ar-MA": "Arabic (Morocco)",
		"ar-OM": "Arabic (Oman)",
		"ar-QA": "Arabic (Qatar)",
		"ar-SA": "Arabic (Saudi Arabia)",
		"ar-SY": "Arabic (Syria)",
		"ar-TN": "Arabic (Tunisia)",
		"ar-AE": "Arabic (U.A.E.)",
		"ar-YE": "Arabic (Yemen)",
		an: "Aragonese",
		hy: "Armenian",
		as: "Assamese",
		ast: "Asturian",
		az: "Azerbaijani",
		eu: "Basque",
		be: "Belarusian",
		bn: "Bengali",
		bs: "Bosnian",
		br: "Breton",
		bg: "Bulgarian",
		my: "Burmese",
		ca: "Catalan",
		ch: "Chamorro",
		ce: "Chechen",
		zh: "Chinese",
		"zh-HK": "Chinese (Hong Kong)",
		"zh-CN": "Chinese (PRC)",
		"zh-SG": "Chinese (Singapore)",
		"zh-TW": "Chinese (Taiwan)",
		cv: "Chuvash",
		co: "Corsican",
		cr: "Cree",
		hr: "Croatian",
		cs: "Czech",
		da: "Danish",
		nl: "Dutch (Standard)",
		"nl-BE": "Dutch (Belgian)",
		en: "English",
		"en-AU": "English (Australia)",
		"en-BZ": "English (Belize)",
		"en-CA": "English (Canada)",
		"en-IE": "English (Ireland)",
		"en-JM": "English (Jamaica)",
		"en-NZ": "English (New Zealand)",
		"en-PH": "English (Philippines)",
		"en-ZA": "English (South Africa)",
		"en-TT": "English (Trinidad & Tobago)",
		"en-GB": "English (United Kingdom)",
		"en-US": "English (United States)",
		"en-ZW": "English (Zimbabwe)",
		eo: "Esperanto",
		et: "Estonian",
		fo: "Faeroese",
		fj: "Fijian",
		fi: "Finnish",
		fr: "French (Standard)",
		"fr-BE": "French (Belgium)",
		"fr-CA": "French (Canada)",
		"fr-FR": "French (France)",
		"fr-LU": "French (Luxembourg)",
		"fr-MC": "French (Monaco)",
		"fr-CH": "French (Switzerland)",
		fy: "Frisian",
		fur: "Friulian",
		gd: "Gaelic (Scots)",
		"gd-IE": "Gaelic (Irish)",
		gl: "Galacian",
		ka: "Georgian",
		de: "German (Standard)",
		"de-AT": "German (Austria)",
		"de-DE": "German (Germany)",
		"de-LI": "German (Liechtenstein)",
		"de-LU": "German (Luxembourg)",
		"de-CH": "German (Switzerland)",
		el: "Greek",
		gu: "Gujurati",
		ht: "Haitian",
		he: "Hebrew",
		hi: "Hindi",
		hu: "Hungarian",
		is: "Icelandic",
		id: "Indonesian",
		iu: "Inuktitut",
		ga: "Irish",
		it: "Italian (Standard)",
		"it-CH": "Italian (Switzerland)",
		ja: "Japanese",
		kn: "Kannada",
		ks: "Kashmiri",
		kk: "Kazakh",
		km: "Khmer",
		ky: "Kirghiz",
		tlh: "Klingon",
		ko: "Korean",
		"ko-KP": "Korean (North Korea)",
		"ko-KR": "Korean (South Korea)",
		la: "Latin",
		lv: "Latvian",
		lt: "Lithuanian",
		lb: "Luxembourgish",
		mk: "North Macedonia",
		ms: "Malay",
		ml: "Malayalam",
		mt: "Maltese",
		mi: "Maori",
		mr: "Marathi",
		mo: "Moldavian",
		nv: "Navajo",
		ng: "Ndonga",
		ne: "Nepali",
		no: "Norwegian",
		nb: "Norwegian (Bokmal)",
		nn: "Norwegian (Nynorsk)",
		oc: "Occitan",
		or: "Oriya",
		om: "Oromo",
		fa: "Persian",
		"fa-IR": "Persian/Iran",
		pl: "Polish",
		pt: "Portuguese",
		"pt-BR": "Portuguese (Brazil)",
		pa: "Punjabi",
		"pa-IN": "Punjabi (India)",
		"pa-PK": "Punjabi (Pakistan)",
		qu: "Quechua",
		rm: "Rhaeto-Romanic",
		ro: "Romanian",
		"ro-MO": "Romanian (Moldavia)",
		ru: "Russian",
		"ru-MO": "Russian (Moldavia)",
		sz: "Sami (Lappish)",
		sg: "Sango",
		sa: "Sanskrit",
		sc: "Sardinian",
		sd: "Sindhi",
		si: "Singhalese",
		sr: "Serbian",
		sk: "Slovak",
		sl: "Slovenian",
		so: "Somani",
		sb: "Sorbian",
		es: "Spanish",
		"es-AR": "Spanish (Argentina)",
		"es-BO": "Spanish (Bolivia)",
		"es-CL": "Spanish (Chile)",
		"es-CO": "Spanish (Colombia)",
		"es-CR": "Spanish (Costa Rica)",
		"es-DO": "Spanish (Dominican Republic)",
		"es-EC": "Spanish (Ecuador)",
		"es-SV": "Spanish (El Salvador)",
		"es-GT": "Spanish (Guatemala)",
		"es-HN": "Spanish (Honduras)",
		"es-MX": "Spanish (Mexico)",
		"es-NI": "Spanish (Nicaragua)",
		"es-PA": "Spanish (Panama)",
		"es-PY": "Spanish (Paraguay)",
		"es-PE": "Spanish (Peru)",
		"es-PR": "Spanish (Puerto Rico)",
		"es-ES": "Spanish (Spain)",
		"es-UY": "Spanish (Uruguay)",
		"es-VE": "Spanish (Venezuela)",
		sx: "Sutu",
		sw: "Swahili",
		sv: "Swedish",
		"sv-FI": "Swedish (Finland)",
		"sv-SV": "Swedish (Sweden)",
		ta: "Tamil",
		tt: "Tatar",
		te: "Teluga",
		th: "Thai",
		tig: "Tigre",
		ts: "Tsonga",
		tn: "Tswana",
		tr: "Turkish",
		tk: "Turkmen",
		uk: "Ukrainian",
		hsb: "Upper Sorbian",
		ur: "Urdu",
		ve: "Venda",
		vi: "Vietnamese",
		vo: "Volapuk",
		wa: "Walloon",
		cy: "Welsh",
		xh: "Xhosa",
		ji: "Yiddish",
		zu: "Zulu"
	}[t] && (this.internal.languageSettings.languageCode = t, !1 === this.internal.languageSettings.isSubscribed && (this.internal.events.subscribe("putCatalog", function() {
		this.internal.write("/Lang (" + this.internal.languageSettings.languageCode + ")");
	}), this.internal.languageSettings.isSubscribed = !0)), this;
}, zt = E.API, Ut = zt.getCharWidthsArray = function(e, r) {
	var n, i, a = (r = r || {}).font || this.internal.getFont(), o = r.fontSize || this.internal.getFontSize(), s = r.charSpace || this.internal.getCharSpace(), u = r.widths ? r.widths : a.metadata.Unicode.widths, c = u.fof ? u.fof : 1, l = r.kerning ? r.kerning : a.metadata.Unicode.kerning, h = l.fof ? l.fof : 1, f = !1 !== r.doKerning, d = 0, p = e.length, g = 0, m = u[0] || c, v = [];
	for (n = 0; n < p; n++) i = e.charCodeAt(n), "function" == typeof a.metadata.widthOfString ? v.push((a.metadata.widthOfGlyph(a.metadata.characterToGlyph(i)) + s * (1e3 / o) || 0) / 1e3) : (d = f && "object" === _typeof(l[i]) && !isNaN(parseInt(l[i][g], 10)) ? l[i][g] / h : 0, v.push((u[i] || m) / c + d)), g = i;
	return v;
}, Ht = zt.getStringUnitWidth = function(t, e) {
	var r = (e = e || {}).fontSize || this.internal.getFontSize(), n = e.font || this.internal.getFont(), i = e.charSpace || this.internal.getCharSpace();
	return zt.processArabic && (t = zt.processArabic(t)), "function" == typeof n.metadata.widthOfString ? n.metadata.widthOfString(t, r, i) / r : Ut.apply(this, arguments).reduce(function(t, e) {
		return t + e;
	}, 0);
}, Wt = function(t, e, r, n) {
	for (var i = [], a = 0, o = t.length, s = 0; a !== o && s + e[a] < r;) s += e[a], a++;
	i.push(t.slice(0, a));
	var u = a;
	for (s = 0; a !== o;) s + e[a] > n && (i.push(t.slice(u, a)), s = 0, u = a), s += e[a], a++;
	return u !== a && i.push(t.slice(u, a)), i;
}, Vt = function(t, e, r) {
	r || (r = {});
	var n, i, a, o, s, u, c, l = [], h = [l], f = r.textIndent || 0, d = 0, p = 0, g = t.split(" "), m = Ut.apply(this, [" ", r])[0];
	if (u = -1 === r.lineIndent ? g[0].length + 2 : r.lineIndent || 0) {
		var v = Array(u).join(" "), b = [];
		g.map(function(t) {
			(t = t.split(/\s*\n/)).length > 1 ? b = b.concat(t.map(function(t, e) {
				return (e && t.length ? "\n" : "") + t;
			})) : b.push(t[0]);
		}), g = b, u = Ht.apply(this, [v, r]);
	}
	for (a = 0, o = g.length; a < o; a++) {
		var y = 0;
		if (n = g[a], u && "\n" == n[0] && (n = n.substr(1), y = 1), f + d + (p = (i = Ut.apply(this, [n, r])).reduce(function(t, e) {
			return t + e;
		}, 0)) > e || y) {
			if (p > e) {
				for (s = Wt.apply(this, [
					n,
					i,
					e - (f + d),
					e
				]), l.push(s.shift()), l = [s.pop()]; s.length;) h.push([s.shift()]);
				p = i.slice(n.length - (l[0] ? l[0].length : 0)).reduce(function(t, e) {
					return t + e;
				}, 0);
			} else l = [n];
			h.push(l), f = p + u, d = m;
		} else l.push(n), f += d + p, d = m;
	}
	return c = u ? function(t, e) {
		return (e ? v : "") + t.join(" ");
	} : function(t) {
		return t.join(" ");
	}, h.map(c);
}, zt.splitTextToSize = function(t, e, r) {
	var n, i = (r = r || {}).fontSize || this.internal.getFontSize(), a = function(t) {
		if (t.widths && t.kerning) return {
			widths: t.widths,
			kerning: t.kerning
		};
		var e = this.internal.getFont(t.fontName, t.fontStyle), r = "Unicode";
		return e.metadata[r] ? {
			widths: e.metadata[r].widths || { 0: 1 },
			kerning: e.metadata[r].kerning || {}
		} : {
			font: e.metadata,
			fontSize: this.internal.getFontSize(),
			charSpace: this.internal.getCharSpace()
		};
	}.call(this, r);
	n = Array.isArray(t) ? t : String(t).split(/\r?\n/);
	var o = 1 * this.internal.scaleFactor * e / i;
	a.textIndent = r.textIndent ? 1 * r.textIndent * this.internal.scaleFactor / i : 0, a.lineIndent = r.lineIndent;
	var s, u, c = [];
	for (s = 0, u = n.length; s < u; s++) c = c.concat(Vt.apply(this, [
		n[s],
		o,
		a
	]));
	return c;
}, function(e) {
	e.__fontmetrics__ = e.__fontmetrics__ || {};
	for (var r = "0123456789abcdef", n = "klmnopqrstuvwxyz", i = {}, a = {}, o = 0; o < 16; o++) i[n[o]] = r[o], a[r[o]] = n[o];
	var s = function(t) {
		return "0x" + parseInt(t, 10).toString(16);
	}, u = e.__fontmetrics__.compress = function(e) {
		var r, n, i, o, c = ["{"];
		for (var l in e) {
			if (r = e[l], isNaN(parseInt(l, 10)) ? n = "'" + l + "'" : (l = parseInt(l, 10), n = (n = s(l).slice(2)).slice(0, -1) + a[n.slice(-1)]), "number" == typeof r) r < 0 ? (i = s(r).slice(3), o = "-") : (i = s(r).slice(2), o = ""), i = o + i.slice(0, -1) + a[i.slice(-1)];
			else {
				if ("object" !== _typeof(r)) throw new Error("Don't know what to do with value type " + _typeof(r) + ".");
				i = u(r);
			}
			c.push(n + i);
		}
		return c.push("}"), c.join("");
	}, c = e.__fontmetrics__.uncompress = function(t) {
		if ("string" != typeof t) throw new Error("Invalid argument passed to uncompress.");
		for (var e, r, n, a, o = {}, s = 1, u = o, c = [], l = "", h = "", f = t.length - 1, d = 1; d < f; d += 1) "'" == (a = t[d]) ? e ? (n = e.join(""), e = void 0) : e = [] : e ? e.push(a) : "{" == a ? (c.push([u, n]), u = {}, n = void 0) : "}" == a ? ((r = c.pop())[0][r[1]] = u, n = void 0, u = r[0]) : "-" == a ? s = -1 : void 0 === n ? i.hasOwnProperty(a) ? (l += i[a], n = parseInt(l, 16) * s, s = 1, l = "") : l += a : i.hasOwnProperty(a) ? (h += i[a], u[n] = parseInt(h, 16) * s, s = 1, n = void 0, h = "") : h += a;
		return o;
	}, l = {
		codePages: ["WinAnsiEncoding"],
		WinAnsiEncoding: c("{19m8n201n9q201o9r201s9l201t9m201u8m201w9n201x9o201y8o202k8q202l8r202m9p202q8p20aw8k203k8t203t8v203u9v2cq8s212m9t15m8w15n9w2dw9s16k8u16l9u17s9z17x8y17y9y}")
	}, h = { Unicode: {
		Courier: l,
		"Courier-Bold": l,
		"Courier-BoldOblique": l,
		"Courier-Oblique": l,
		Helvetica: l,
		"Helvetica-Bold": l,
		"Helvetica-BoldOblique": l,
		"Helvetica-Oblique": l,
		"Times-Roman": l,
		"Times-Bold": l,
		"Times-BoldItalic": l,
		"Times-Italic": l
	} }, f = { Unicode: {
		"Courier-Oblique": c("{'widths'{k3w'fof'6o}'kerning'{'fof'-6o}}"),
		"Times-BoldItalic": c("{'widths'{k3o2q4ycx2r201n3m201o6o201s2l201t2l201u2l201w3m201x3m201y3m2k1t2l2r202m2n2n3m2o3m2p5n202q6o2r1w2s2l2t2l2u3m2v3t2w1t2x2l2y1t2z1w3k3m3l3m3m3m3n3m3o3m3p3m3q3m3r3m3s3m203t2l203u2l3v2l3w3t3x3t3y3t3z3m4k5n4l4m4m4m4n4m4o4s4p4m4q4m4r4s4s4y4t2r4u3m4v4m4w3x4x5t4y4s4z4s5k3x5l4s5m4m5n3r5o3x5p4s5q4m5r5t5s4m5t3x5u3x5v2l5w1w5x2l5y3t5z3m6k2l6l3m6m3m6n2w6o3m6p2w6q2l6r3m6s3r6t1w6u1w6v3m6w1w6x4y6y3r6z3m7k3m7l3m7m2r7n2r7o1w7p3r7q2w7r4m7s3m7t2w7u2r7v2n7w1q7x2n7y3t202l3mcl4mal2ram3man3mao3map3mar3mas2lat4uau1uav3maw3way4uaz2lbk2sbl3t'fof'6obo2lbp3tbq3mbr1tbs2lbu1ybv3mbz3mck4m202k3mcm4mcn4mco4mcp4mcq5ycr4mcs4mct4mcu4mcv4mcw2r2m3rcy2rcz2rdl4sdm4sdn4sdo4sdp4sdq4sds4sdt4sdu4sdv4sdw4sdz3mek3mel3mem3men3meo3mep3meq4ser2wes2wet2weu2wev2wew1wex1wey1wez1wfl3rfm3mfn3mfo3mfp3mfq3mfr3tfs3mft3rfu3rfv3rfw3rfz2w203k6o212m6o2dw2l2cq2l3t3m3u2l17s3x19m3m}'kerning'{cl{4qu5kt5qt5rs17ss5ts}201s{201ss}201t{cks4lscmscnscoscpscls2wu2yu201ts}201x{2wu2yu}2k{201ts}2w{4qx5kx5ou5qx5rs17su5tu}2x{17su5tu5ou}2y{4qx5kx5ou5qx5rs17ss5ts}'fof'-6ofn{17sw5tw5ou5qw5rs}7t{cksclscmscnscoscps4ls}3u{17su5tu5os5qs}3v{17su5tu5os5qs}7p{17su5tu}ck{4qu5kt5qt5rs17ss5ts}4l{4qu5kt5qt5rs17ss5ts}cm{4qu5kt5qt5rs17ss5ts}cn{4qu5kt5qt5rs17ss5ts}co{4qu5kt5qt5rs17ss5ts}cp{4qu5kt5qt5rs17ss5ts}6l{4qu5ou5qw5rt17su5tu}5q{ckuclucmucnucoucpu4lu}5r{ckuclucmucnucoucpu4lu}7q{cksclscmscnscoscps4ls}6p{4qu5ou5qw5rt17sw5tw}ek{4qu5ou5qw5rt17su5tu}el{4qu5ou5qw5rt17su5tu}em{4qu5ou5qw5rt17su5tu}en{4qu5ou5qw5rt17su5tu}eo{4qu5ou5qw5rt17su5tu}ep{4qu5ou5qw5rt17su5tu}es{17ss5ts5qs4qu}et{4qu5ou5qw5rt17sw5tw}eu{4qu5ou5qw5rt17ss5ts}ev{17ss5ts5qs4qu}6z{17sw5tw5ou5qw5rs}fm{17sw5tw5ou5qw5rs}7n{201ts}fo{17sw5tw5ou5qw5rs}fp{17sw5tw5ou5qw5rs}fq{17sw5tw5ou5qw5rs}7r{cksclscmscnscoscps4ls}fs{17sw5tw5ou5qw5rs}ft{17su5tu}fu{17su5tu}fv{17su5tu}fw{17su5tu}fz{cksclscmscnscoscps4ls}}}"),
		"Helvetica-Bold": c("{'widths'{k3s2q4scx1w201n3r201o6o201s1w201t1w201u1w201w3m201x3m201y3m2k1w2l2l202m2n2n3r2o3r2p5t202q6o2r1s2s2l2t2l2u2r2v3u2w1w2x2l2y1w2z1w3k3r3l3r3m3r3n3r3o3r3p3r3q3r3r3r3s3r203t2l203u2l3v2l3w3u3x3u3y3u3z3x4k6l4l4s4m4s4n4s4o4s4p4m4q3x4r4y4s4s4t1w4u3r4v4s4w3x4x5n4y4s4z4y5k4m5l4y5m4s5n4m5o3x5p4s5q4m5r5y5s4m5t4m5u3x5v2l5w1w5x2l5y3u5z3r6k2l6l3r6m3x6n3r6o3x6p3r6q2l6r3x6s3x6t1w6u1w6v3r6w1w6x5t6y3x6z3x7k3x7l3x7m2r7n3r7o2l7p3x7q3r7r4y7s3r7t3r7u3m7v2r7w1w7x2r7y3u202l3rcl4sal2lam3ran3rao3rap3rar3ras2lat4tau2pav3raw3uay4taz2lbk2sbl3u'fof'6obo2lbp3xbq3rbr1wbs2lbu2obv3rbz3xck4s202k3rcm4scn4sco4scp4scq6ocr4scs4mct4mcu4mcv4mcw1w2m2zcy1wcz1wdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3xek3rel3rem3ren3reo3rep3req5ter3res3ret3reu3rev3rew1wex1wey1wez1wfl3xfm3xfn3xfo3xfp3xfq3xfr3ufs3xft3xfu3xfv3xfw3xfz3r203k6o212m6o2dw2l2cq2l3t3r3u2l17s4m19m3r}'kerning'{cl{4qs5ku5ot5qs17sv5tv}201t{2ww4wy2yw}201w{2ks}201x{2ww4wy2yw}2k{201ts201xs}2w{7qs4qu5kw5os5qw5rs17su5tu7tsfzs}2x{5ow5qs}2y{7qs4qu5kw5os5qw5rs17su5tu7tsfzs}'fof'-6o7p{17su5tu5ot}ck{4qs5ku5ot5qs17sv5tv}4l{4qs5ku5ot5qs17sv5tv}cm{4qs5ku5ot5qs17sv5tv}cn{4qs5ku5ot5qs17sv5tv}co{4qs5ku5ot5qs17sv5tv}cp{4qs5ku5ot5qs17sv5tv}6l{17st5tt5os}17s{2kwclvcmvcnvcovcpv4lv4wwckv}5o{2kucltcmtcntcotcpt4lt4wtckt}5q{2ksclscmscnscoscps4ls4wvcks}5r{2ks4ws}5t{2kwclvcmvcnvcovcpv4lv4wwckv}eo{17st5tt5os}fu{17su5tu5ot}6p{17ss5ts}ek{17st5tt5os}el{17st5tt5os}em{17st5tt5os}en{17st5tt5os}6o{201ts}ep{17st5tt5os}es{17ss5ts}et{17ss5ts}eu{17ss5ts}ev{17ss5ts}6z{17su5tu5os5qt}fm{17su5tu5os5qt}fn{17su5tu5os5qt}fo{17su5tu5os5qt}fp{17su5tu5os5qt}fq{17su5tu5os5qt}fs{17su5tu5os5qt}ft{17su5tu5ot}7m{5os}fv{17su5tu5ot}fw{17su5tu5ot}}}"),
		Courier: c("{'widths'{k3w'fof'6o}'kerning'{'fof'-6o}}"),
		"Courier-BoldOblique": c("{'widths'{k3w'fof'6o}'kerning'{'fof'-6o}}"),
		"Times-Bold": c("{'widths'{k3q2q5ncx2r201n3m201o6o201s2l201t2l201u2l201w3m201x3m201y3m2k1t2l2l202m2n2n3m2o3m2p6o202q6o2r1w2s2l2t2l2u3m2v3t2w1t2x2l2y1t2z1w3k3m3l3m3m3m3n3m3o3m3p3m3q3m3r3m3s3m203t2l203u2l3v2l3w3t3x3t3y3t3z3m4k5x4l4s4m4m4n4s4o4s4p4m4q3x4r4y4s4y4t2r4u3m4v4y4w4m4x5y4y4s4z4y5k3x5l4y5m4s5n3r5o4m5p4s5q4s5r6o5s4s5t4s5u4m5v2l5w1w5x2l5y3u5z3m6k2l6l3m6m3r6n2w6o3r6p2w6q2l6r3m6s3r6t1w6u2l6v3r6w1w6x5n6y3r6z3m7k3r7l3r7m2w7n2r7o2l7p3r7q3m7r4s7s3m7t3m7u2w7v2r7w1q7x2r7y3o202l3mcl4sal2lam3man3mao3map3mar3mas2lat4uau1yav3maw3tay4uaz2lbk2sbl3t'fof'6obo2lbp3rbr1tbs2lbu2lbv3mbz3mck4s202k3mcm4scn4sco4scp4scq6ocr4scs4mct4mcu4mcv4mcw2r2m3rcy2rcz2rdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3rek3mel3mem3men3meo3mep3meq4ser2wes2wet2weu2wev2wew1wex1wey1wez1wfl3rfm3mfn3mfo3mfp3mfq3mfr3tfs3mft3rfu3rfv3rfw3rfz3m203k6o212m6o2dw2l2cq2l3t3m3u2l17s4s19m3m}'kerning'{cl{4qt5ks5ot5qy5rw17sv5tv}201t{cks4lscmscnscoscpscls4wv}2k{201ts}2w{4qu5ku7mu5os5qx5ru17su5tu}2x{17su5tu5ou5qs}2y{4qv5kv7mu5ot5qz5ru17su5tu}'fof'-6o7t{cksclscmscnscoscps4ls}3u{17su5tu5os5qu}3v{17su5tu5os5qu}fu{17su5tu5ou5qu}7p{17su5tu5ou5qu}ck{4qt5ks5ot5qy5rw17sv5tv}4l{4qt5ks5ot5qy5rw17sv5tv}cm{4qt5ks5ot5qy5rw17sv5tv}cn{4qt5ks5ot5qy5rw17sv5tv}co{4qt5ks5ot5qy5rw17sv5tv}cp{4qt5ks5ot5qy5rw17sv5tv}6l{17st5tt5ou5qu}17s{ckuclucmucnucoucpu4lu4wu}5o{ckuclucmucnucoucpu4lu4wu}5q{ckzclzcmzcnzcozcpz4lz4wu}5r{ckxclxcmxcnxcoxcpx4lx4wu}5t{ckuclucmucnucoucpu4lu4wu}7q{ckuclucmucnucoucpu4lu}6p{17sw5tw5ou5qu}ek{17st5tt5qu}el{17st5tt5ou5qu}em{17st5tt5qu}en{17st5tt5qu}eo{17st5tt5qu}ep{17st5tt5ou5qu}es{17ss5ts5qu}et{17sw5tw5ou5qu}eu{17sw5tw5ou5qu}ev{17ss5ts5qu}6z{17sw5tw5ou5qu5rs}fm{17sw5tw5ou5qu5rs}fn{17sw5tw5ou5qu5rs}fo{17sw5tw5ou5qu5rs}fp{17sw5tw5ou5qu5rs}fq{17sw5tw5ou5qu5rs}7r{cktcltcmtcntcotcpt4lt5os}fs{17sw5tw5ou5qu5rs}ft{17su5tu5ou5qu}7m{5os}fv{17su5tu5ou5qu}fw{17su5tu5ou5qu}fz{cksclscmscnscoscps4ls}}}"),
		Symbol: c("{'widths'{k3uaw4r19m3m2k1t2l2l202m2y2n3m2p5n202q6o3k3m2s2l2t2l2v3r2w1t3m3m2y1t2z1wbk2sbl3r'fof'6o3n3m3o3m3p3m3q3m3r3m3s3m3t3m3u1w3v1w3w3r3x3r3y3r3z2wbp3t3l3m5v2l5x2l5z3m2q4yfr3r7v3k7w1o7x3k}'kerning'{'fof'-6o}}"),
		Helvetica: c("{'widths'{k3p2q4mcx1w201n3r201o6o201s1q201t1q201u1q201w2l201x2l201y2l2k1w2l1w202m2n2n3r2o3r2p5t202q6o2r1n2s2l2t2l2u2r2v3u2w1w2x2l2y1w2z1w3k3r3l3r3m3r3n3r3o3r3p3r3q3r3r3r3s3r203t2l203u2l3v1w3w3u3x3u3y3u3z3r4k6p4l4m4m4m4n4s4o4s4p4m4q3x4r4y4s4s4t1w4u3m4v4m4w3r4x5n4y4s4z4y5k4m5l4y5m4s5n4m5o3x5p4s5q4m5r5y5s4m5t4m5u3x5v1w5w1w5x1w5y2z5z3r6k2l6l3r6m3r6n3m6o3r6p3r6q1w6r3r6s3r6t1q6u1q6v3m6w1q6x5n6y3r6z3r7k3r7l3r7m2l7n3m7o1w7p3r7q3m7r4s7s3m7t3m7u3m7v2l7w1u7x2l7y3u202l3rcl4mal2lam3ran3rao3rap3rar3ras2lat4tau2pav3raw3uay4taz2lbk2sbl3u'fof'6obo2lbp3rbr1wbs2lbu2obv3rbz3xck4m202k3rcm4mcn4mco4mcp4mcq6ocr4scs4mct4mcu4mcv4mcw1w2m2ncy1wcz1wdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3xek3rel3rem3ren3reo3rep3req5ter3mes3ret3reu3rev3rew1wex1wey1wez1wfl3rfm3rfn3rfo3rfp3rfq3rfr3ufs3xft3rfu3rfv3rfw3rfz3m203k6o212m6o2dw2l2cq2l3t3r3u1w17s4m19m3r}'kerning'{5q{4wv}cl{4qs5kw5ow5qs17sv5tv}201t{2wu4w1k2yu}201x{2wu4wy2yu}17s{2ktclucmucnu4otcpu4lu4wycoucku}2w{7qs4qz5k1m17sy5ow5qx5rsfsu5ty7tufzu}2x{17sy5ty5oy5qs}2y{7qs4qz5k1m17sy5ow5qx5rsfsu5ty7tufzu}'fof'-6o7p{17sv5tv5ow}ck{4qs5kw5ow5qs17sv5tv}4l{4qs5kw5ow5qs17sv5tv}cm{4qs5kw5ow5qs17sv5tv}cn{4qs5kw5ow5qs17sv5tv}co{4qs5kw5ow5qs17sv5tv}cp{4qs5kw5ow5qs17sv5tv}6l{17sy5ty5ow}do{17st5tt}4z{17st5tt}7s{fst}dm{17st5tt}dn{17st5tt}5o{ckwclwcmwcnwcowcpw4lw4wv}dp{17st5tt}dq{17st5tt}7t{5ow}ds{17st5tt}5t{2ktclucmucnu4otcpu4lu4wycoucku}fu{17sv5tv5ow}6p{17sy5ty5ow5qs}ek{17sy5ty5ow}el{17sy5ty5ow}em{17sy5ty5ow}en{5ty}eo{17sy5ty5ow}ep{17sy5ty5ow}es{17sy5ty5qs}et{17sy5ty5ow5qs}eu{17sy5ty5ow5qs}ev{17sy5ty5ow5qs}6z{17sy5ty5ow5qs}fm{17sy5ty5ow5qs}fn{17sy5ty5ow5qs}fo{17sy5ty5ow5qs}fp{17sy5ty5qs}fq{17sy5ty5ow5qs}7r{5ow}fs{17sy5ty5ow5qs}ft{17sv5tv5ow}7m{5ow}fv{17sv5tv5ow}fw{17sv5tv5ow}}}"),
		"Helvetica-BoldOblique": c("{'widths'{k3s2q4scx1w201n3r201o6o201s1w201t1w201u1w201w3m201x3m201y3m2k1w2l2l202m2n2n3r2o3r2p5t202q6o2r1s2s2l2t2l2u2r2v3u2w1w2x2l2y1w2z1w3k3r3l3r3m3r3n3r3o3r3p3r3q3r3r3r3s3r203t2l203u2l3v2l3w3u3x3u3y3u3z3x4k6l4l4s4m4s4n4s4o4s4p4m4q3x4r4y4s4s4t1w4u3r4v4s4w3x4x5n4y4s4z4y5k4m5l4y5m4s5n4m5o3x5p4s5q4m5r5y5s4m5t4m5u3x5v2l5w1w5x2l5y3u5z3r6k2l6l3r6m3x6n3r6o3x6p3r6q2l6r3x6s3x6t1w6u1w6v3r6w1w6x5t6y3x6z3x7k3x7l3x7m2r7n3r7o2l7p3x7q3r7r4y7s3r7t3r7u3m7v2r7w1w7x2r7y3u202l3rcl4sal2lam3ran3rao3rap3rar3ras2lat4tau2pav3raw3uay4taz2lbk2sbl3u'fof'6obo2lbp3xbq3rbr1wbs2lbu2obv3rbz3xck4s202k3rcm4scn4sco4scp4scq6ocr4scs4mct4mcu4mcv4mcw1w2m2zcy1wcz1wdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3xek3rel3rem3ren3reo3rep3req5ter3res3ret3reu3rev3rew1wex1wey1wez1wfl3xfm3xfn3xfo3xfp3xfq3xfr3ufs3xft3xfu3xfv3xfw3xfz3r203k6o212m6o2dw2l2cq2l3t3r3u2l17s4m19m3r}'kerning'{cl{4qs5ku5ot5qs17sv5tv}201t{2ww4wy2yw}201w{2ks}201x{2ww4wy2yw}2k{201ts201xs}2w{7qs4qu5kw5os5qw5rs17su5tu7tsfzs}2x{5ow5qs}2y{7qs4qu5kw5os5qw5rs17su5tu7tsfzs}'fof'-6o7p{17su5tu5ot}ck{4qs5ku5ot5qs17sv5tv}4l{4qs5ku5ot5qs17sv5tv}cm{4qs5ku5ot5qs17sv5tv}cn{4qs5ku5ot5qs17sv5tv}co{4qs5ku5ot5qs17sv5tv}cp{4qs5ku5ot5qs17sv5tv}6l{17st5tt5os}17s{2kwclvcmvcnvcovcpv4lv4wwckv}5o{2kucltcmtcntcotcpt4lt4wtckt}5q{2ksclscmscnscoscps4ls4wvcks}5r{2ks4ws}5t{2kwclvcmvcnvcovcpv4lv4wwckv}eo{17st5tt5os}fu{17su5tu5ot}6p{17ss5ts}ek{17st5tt5os}el{17st5tt5os}em{17st5tt5os}en{17st5tt5os}6o{201ts}ep{17st5tt5os}es{17ss5ts}et{17ss5ts}eu{17ss5ts}ev{17ss5ts}6z{17su5tu5os5qt}fm{17su5tu5os5qt}fn{17su5tu5os5qt}fo{17su5tu5os5qt}fp{17su5tu5os5qt}fq{17su5tu5os5qt}fs{17su5tu5os5qt}ft{17su5tu5ot}7m{5os}fv{17su5tu5ot}fw{17su5tu5ot}}}"),
		ZapfDingbats: c("{'widths'{k4u2k1w'fof'6o}'kerning'{'fof'-6o}}"),
		"Courier-Bold": c("{'widths'{k3w'fof'6o}'kerning'{'fof'-6o}}"),
		"Times-Italic": c("{'widths'{k3n2q4ycx2l201n3m201o5t201s2l201t2l201u2l201w3r201x3r201y3r2k1t2l2l202m2n2n3m2o3m2p5n202q5t2r1p2s2l2t2l2u3m2v4n2w1t2x2l2y1t2z1w3k3m3l3m3m3m3n3m3o3m3p3m3q3m3r3m3s3m203t2l203u2l3v2l3w4n3x4n3y4n3z3m4k5w4l3x4m3x4n4m4o4s4p3x4q3x4r4s4s4s4t2l4u2w4v4m4w3r4x5n4y4m4z4s5k3x5l4s5m3x5n3m5o3r5p4s5q3x5r5n5s3x5t3r5u3r5v2r5w1w5x2r5y2u5z3m6k2l6l3m6m3m6n2w6o3m6p2w6q1w6r3m6s3m6t1w6u1w6v2w6w1w6x4s6y3m6z3m7k3m7l3m7m2r7n2r7o1w7p3m7q2w7r4m7s2w7t2w7u2r7v2s7w1v7x2s7y3q202l3mcl3xal2ram3man3mao3map3mar3mas2lat4wau1vav3maw4nay4waz2lbk2sbl4n'fof'6obo2lbp3mbq3obr1tbs2lbu1zbv3mbz3mck3x202k3mcm3xcn3xco3xcp3xcq5tcr4mcs3xct3xcu3xcv3xcw2l2m2ucy2lcz2ldl4mdm4sdn4sdo4sdp4sdq4sds4sdt4sdu4sdv4sdw4sdz3mek3mel3mem3men3meo3mep3meq4mer2wes2wet2weu2wev2wew1wex1wey1wez1wfl3mfm3mfn3mfo3mfp3mfq3mfr4nfs3mft3mfu3mfv3mfw3mfz2w203k6o212m6m2dw2l2cq2l3t3m3u2l17s3r19m3m}'kerning'{cl{5kt4qw}201s{201sw}201t{201tw2wy2yy6q-t}201x{2wy2yy}2k{201tw}2w{7qs4qy7rs5ky7mw5os5qx5ru17su5tu}2x{17ss5ts5os}2y{7qs4qy7rs5ky7mw5os5qx5ru17su5tu}'fof'-6o6t{17ss5ts5qs}7t{5os}3v{5qs}7p{17su5tu5qs}ck{5kt4qw}4l{5kt4qw}cm{5kt4qw}cn{5kt4qw}co{5kt4qw}cp{5kt4qw}6l{4qs5ks5ou5qw5ru17su5tu}17s{2ks}5q{ckvclvcmvcnvcovcpv4lv}5r{ckuclucmucnucoucpu4lu}5t{2ks}6p{4qs5ks5ou5qw5ru17su5tu}ek{4qs5ks5ou5qw5ru17su5tu}el{4qs5ks5ou5qw5ru17su5tu}em{4qs5ks5ou5qw5ru17su5tu}en{4qs5ks5ou5qw5ru17su5tu}eo{4qs5ks5ou5qw5ru17su5tu}ep{4qs5ks5ou5qw5ru17su5tu}es{5ks5qs4qs}et{4qs5ks5ou5qw5ru17su5tu}eu{4qs5ks5qw5ru17su5tu}ev{5ks5qs4qs}ex{17ss5ts5qs}6z{4qv5ks5ou5qw5ru17su5tu}fm{4qv5ks5ou5qw5ru17su5tu}fn{4qv5ks5ou5qw5ru17su5tu}fo{4qv5ks5ou5qw5ru17su5tu}fp{4qv5ks5ou5qw5ru17su5tu}fq{4qv5ks5ou5qw5ru17su5tu}7r{5os}fs{4qv5ks5ou5qw5ru17su5tu}ft{17su5tu5qs}fu{17su5tu5qs}fv{17su5tu5qs}fw{17su5tu5qs}}}"),
		"Times-Roman": c("{'widths'{k3n2q4ycx2l201n3m201o6o201s2l201t2l201u2l201w2w201x2w201y2w2k1t2l2l202m2n2n3m2o3m2p5n202q6o2r1m2s2l2t2l2u3m2v3s2w1t2x2l2y1t2z1w3k3m3l3m3m3m3n3m3o3m3p3m3q3m3r3m3s3m203t2l203u2l3v1w3w3s3x3s3y3s3z2w4k5w4l4s4m4m4n4m4o4s4p3x4q3r4r4s4s4s4t2l4u2r4v4s4w3x4x5t4y4s4z4s5k3r5l4s5m4m5n3r5o3x5p4s5q4s5r5y5s4s5t4s5u3x5v2l5w1w5x2l5y2z5z3m6k2l6l2w6m3m6n2w6o3m6p2w6q2l6r3m6s3m6t1w6u1w6v3m6w1w6x4y6y3m6z3m7k3m7l3m7m2l7n2r7o1w7p3m7q3m7r4s7s3m7t3m7u2w7v3k7w1o7x3k7y3q202l3mcl4sal2lam3man3mao3map3mar3mas2lat4wau1vav3maw3say4waz2lbk2sbl3s'fof'6obo2lbp3mbq2xbr1tbs2lbu1zbv3mbz2wck4s202k3mcm4scn4sco4scp4scq5tcr4mcs3xct3xcu3xcv3xcw2l2m2tcy2lcz2ldl4sdm4sdn4sdo4sdp4sdq4sds4sdt4sdu4sdv4sdw4sdz3mek2wel2wem2wen2weo2wep2weq4mer2wes2wet2weu2wev2wew1wex1wey1wez1wfl3mfm3mfn3mfo3mfp3mfq3mfr3sfs3mft3mfu3mfv3mfw3mfz3m203k6o212m6m2dw2l2cq2l3t3m3u1w17s4s19m3m}'kerning'{cl{4qs5ku17sw5ou5qy5rw201ss5tw201ws}201s{201ss}201t{ckw4lwcmwcnwcowcpwclw4wu201ts}2k{201ts}2w{4qs5kw5os5qx5ru17sx5tx}2x{17sw5tw5ou5qu}2y{4qs5kw5os5qx5ru17sx5tx}'fof'-6o7t{ckuclucmucnucoucpu4lu5os5rs}3u{17su5tu5qs}3v{17su5tu5qs}7p{17sw5tw5qs}ck{4qs5ku17sw5ou5qy5rw201ss5tw201ws}4l{4qs5ku17sw5ou5qy5rw201ss5tw201ws}cm{4qs5ku17sw5ou5qy5rw201ss5tw201ws}cn{4qs5ku17sw5ou5qy5rw201ss5tw201ws}co{4qs5ku17sw5ou5qy5rw201ss5tw201ws}cp{4qs5ku17sw5ou5qy5rw201ss5tw201ws}6l{17su5tu5os5qw5rs}17s{2ktclvcmvcnvcovcpv4lv4wuckv}5o{ckwclwcmwcnwcowcpw4lw4wu}5q{ckyclycmycnycoycpy4ly4wu5ms}5r{cktcltcmtcntcotcpt4lt4ws}5t{2ktclvcmvcnvcovcpv4lv4wuckv}7q{cksclscmscnscoscps4ls}6p{17su5tu5qw5rs}ek{5qs5rs}el{17su5tu5os5qw5rs}em{17su5tu5os5qs5rs}en{17su5qs5rs}eo{5qs5rs}ep{17su5tu5os5qw5rs}es{5qs}et{17su5tu5qw5rs}eu{17su5tu5qs5rs}ev{5qs}6z{17sv5tv5os5qx5rs}fm{5os5qt5rs}fn{17sv5tv5os5qx5rs}fo{17sv5tv5os5qx5rs}fp{5os5qt5rs}fq{5os5qt5rs}7r{ckuclucmucnucoucpu4lu5os}fs{17sv5tv5os5qx5rs}ft{17ss5ts5qs}fu{17sw5tw5qs}fv{17sw5tw5qs}fw{17ss5ts5qs}fz{ckuclucmucnucoucpu4lu5os5rs}}}"),
		"Helvetica-Oblique": c("{'widths'{k3p2q4mcx1w201n3r201o6o201s1q201t1q201u1q201w2l201x2l201y2l2k1w2l1w202m2n2n3r2o3r2p5t202q6o2r1n2s2l2t2l2u2r2v3u2w1w2x2l2y1w2z1w3k3r3l3r3m3r3n3r3o3r3p3r3q3r3r3r3s3r203t2l203u2l3v1w3w3u3x3u3y3u3z3r4k6p4l4m4m4m4n4s4o4s4p4m4q3x4r4y4s4s4t1w4u3m4v4m4w3r4x5n4y4s4z4y5k4m5l4y5m4s5n4m5o3x5p4s5q4m5r5y5s4m5t4m5u3x5v1w5w1w5x1w5y2z5z3r6k2l6l3r6m3r6n3m6o3r6p3r6q1w6r3r6s3r6t1q6u1q6v3m6w1q6x5n6y3r6z3r7k3r7l3r7m2l7n3m7o1w7p3r7q3m7r4s7s3m7t3m7u3m7v2l7w1u7x2l7y3u202l3rcl4mal2lam3ran3rao3rap3rar3ras2lat4tau2pav3raw3uay4taz2lbk2sbl3u'fof'6obo2lbp3rbr1wbs2lbu2obv3rbz3xck4m202k3rcm4mcn4mco4mcp4mcq6ocr4scs4mct4mcu4mcv4mcw1w2m2ncy1wcz1wdl4sdm4ydn4ydo4ydp4ydq4yds4ydt4sdu4sdv4sdw4sdz3xek3rel3rem3ren3reo3rep3req5ter3mes3ret3reu3rev3rew1wex1wey1wez1wfl3rfm3rfn3rfo3rfp3rfq3rfr3ufs3xft3rfu3rfv3rfw3rfz3m203k6o212m6o2dw2l2cq2l3t3r3u1w17s4m19m3r}'kerning'{5q{4wv}cl{4qs5kw5ow5qs17sv5tv}201t{2wu4w1k2yu}201x{2wu4wy2yu}17s{2ktclucmucnu4otcpu4lu4wycoucku}2w{7qs4qz5k1m17sy5ow5qx5rsfsu5ty7tufzu}2x{17sy5ty5oy5qs}2y{7qs4qz5k1m17sy5ow5qx5rsfsu5ty7tufzu}'fof'-6o7p{17sv5tv5ow}ck{4qs5kw5ow5qs17sv5tv}4l{4qs5kw5ow5qs17sv5tv}cm{4qs5kw5ow5qs17sv5tv}cn{4qs5kw5ow5qs17sv5tv}co{4qs5kw5ow5qs17sv5tv}cp{4qs5kw5ow5qs17sv5tv}6l{17sy5ty5ow}do{17st5tt}4z{17st5tt}7s{fst}dm{17st5tt}dn{17st5tt}5o{ckwclwcmwcnwcowcpw4lw4wv}dp{17st5tt}dq{17st5tt}7t{5ow}ds{17st5tt}5t{2ktclucmucnu4otcpu4lu4wycoucku}fu{17sv5tv5ow}6p{17sy5ty5ow5qs}ek{17sy5ty5ow}el{17sy5ty5ow}em{17sy5ty5ow}en{5ty}eo{17sy5ty5ow}ep{17sy5ty5ow}es{17sy5ty5qs}et{17sy5ty5ow5qs}eu{17sy5ty5ow5qs}ev{17sy5ty5ow5qs}6z{17sy5ty5ow5qs}fm{17sy5ty5ow5qs}fn{17sy5ty5ow5qs}fo{17sy5ty5ow5qs}fp{17sy5ty5qs}fq{17sy5ty5ow5qs}7r{5ow}fs{17sy5ty5ow5qs}ft{17sv5tv5ow}7m{5ow}fv{17sv5tv5ow}fw{17sv5tv5ow}}}")
	} };
	e.events.push(["addFont", function(t) {
		var e = t.font, r = f.Unicode[e.postScriptName];
		r && (e.metadata.Unicode = {}, e.metadata.Unicode.widths = r.widths, e.metadata.Unicode.kerning = r.kerning);
		var n = h.Unicode[e.postScriptName];
		n && (e.metadata.Unicode.encoding = n, e.encoding = n.codePages[0]);
	}]);
}(E.API), function(t) {
	/**
	* @license
	* Licensed under the MIT License.
	* http://opensource.org/licenses/mit-license
	*/
	var e = function(t) {
		for (var e = t.length, r = new Uint8Array(e), n = 0; n < e; n++) r[n] = t.charCodeAt(n);
		return r;
	};
	t.API.events.push(["addFont", function(r) {
		var n = void 0, i = r.font, a = r.instance;
		if (!i.isStandardFont) {
			if (void 0 === a) throw new Error("Font does not exist in vFS, import fonts or remove declaration doc.addFont('" + i.postScriptName + "').");
			if ("string" != typeof (n = !1 === a.existsFileInVFS(i.postScriptName) ? a.loadFile(i.postScriptName) : a.getFileFromVFS(i.postScriptName))) throw new Error("Font is not stored as string-data in vFS, import fonts or remove declaration doc.addFont('" + i.postScriptName + "').");
			(function(r, n) {
				n = /^\x00\x01\x00\x00/.test(n) ? e(n) : e(f(n)), r.metadata = t.API.TTFFont.open(n), r.metadata.Unicode = r.metadata.Unicode || {
					encoding: {},
					kerning: {},
					widths: []
				}, r.metadata.glyIdsUsed = [0];
			})(i, n);
		}
	}]);
}(E), E.API.addSvgAsImage = function(t, e, r, n, a, s, u, c) {
	if (isNaN(e) || isNaN(r)) throw o.error("jsPDF.addSvgAsImage: Invalid coordinates", arguments), /* @__PURE__ */ new Error("Invalid coordinates passed to jsPDF.addSvgAsImage");
	if (isNaN(n) || isNaN(a)) throw o.error("jsPDF.addSvgAsImage: Invalid measurements", arguments), /* @__PURE__ */ new Error("Invalid measurements (width and/or height) passed to jsPDF.addSvgAsImage");
	var l = document.createElement("canvas");
	l.width = n, l.height = a;
	var h = l.getContext("2d");
	h.fillStyle = "#fff", h.fillRect(0, 0, l.width, l.height);
	var f = {
		ignoreMouse: !0,
		ignoreAnimation: !0,
		ignoreDimensions: !0
	}, d = this;
	return (i.canvg ? Promise.resolve(i.canvg) : __vitePreload(() => import("./index.es-DJwz8Ydb.js"), __vite__mapDeps([2,1]))).catch(function(t) {
		return Promise.reject(/* @__PURE__ */ new Error("Could not load canvg: " + t));
	}).then(function(t) {
		return t.default ? t.default : t;
	}).then(function(e) {
		return e.fromString(h, t, f);
	}, function() {
		return Promise.reject(/* @__PURE__ */ new Error("Could not load canvg."));
	}).then(function(t) {
		return t.render(f);
	}).then(function() {
		d.addImage(l.toDataURL("image/jpeg", 1), e, r, n, a, u, c);
	});
}, E.API.putTotalPages = function(t) {
	var e, r = 0;
	parseInt(this.internal.getFont().id.substr(1), 10) < 15 ? (e = new RegExp(t, "g"), r = this.internal.getNumberOfPages()) : (e = new RegExp(this.pdfEscape16(t, this.internal.getFont()), "g"), r = this.pdfEscape16(this.internal.getNumberOfPages() + "", this.internal.getFont()));
	for (var n = 1; n <= this.internal.getNumberOfPages(); n++) for (var i = 0; i < this.internal.pages[n].length; i++) this.internal.pages[n][i] = this.internal.pages[n][i].replace(e, r);
	return this;
}, E.API.viewerPreferences = function(e, r) {
	var n;
	e = e || {}, r = r || !1;
	var i, a, o, s = {
		HideToolbar: {
			defaultValue: !1,
			value: !1,
			type: "boolean",
			explicitSet: !1,
			valueSet: [!0, !1],
			pdfVersion: 1.3
		},
		HideMenubar: {
			defaultValue: !1,
			value: !1,
			type: "boolean",
			explicitSet: !1,
			valueSet: [!0, !1],
			pdfVersion: 1.3
		},
		HideWindowUI: {
			defaultValue: !1,
			value: !1,
			type: "boolean",
			explicitSet: !1,
			valueSet: [!0, !1],
			pdfVersion: 1.3
		},
		FitWindow: {
			defaultValue: !1,
			value: !1,
			type: "boolean",
			explicitSet: !1,
			valueSet: [!0, !1],
			pdfVersion: 1.3
		},
		CenterWindow: {
			defaultValue: !1,
			value: !1,
			type: "boolean",
			explicitSet: !1,
			valueSet: [!0, !1],
			pdfVersion: 1.3
		},
		DisplayDocTitle: {
			defaultValue: !1,
			value: !1,
			type: "boolean",
			explicitSet: !1,
			valueSet: [!0, !1],
			pdfVersion: 1.4
		},
		NonFullScreenPageMode: {
			defaultValue: "UseNone",
			value: "UseNone",
			type: "name",
			explicitSet: !1,
			valueSet: [
				"UseNone",
				"UseOutlines",
				"UseThumbs",
				"UseOC"
			],
			pdfVersion: 1.3
		},
		Direction: {
			defaultValue: "L2R",
			value: "L2R",
			type: "name",
			explicitSet: !1,
			valueSet: ["L2R", "R2L"],
			pdfVersion: 1.3
		},
		ViewArea: {
			defaultValue: "CropBox",
			value: "CropBox",
			type: "name",
			explicitSet: !1,
			valueSet: [
				"MediaBox",
				"CropBox",
				"TrimBox",
				"BleedBox",
				"ArtBox"
			],
			pdfVersion: 1.4
		},
		ViewClip: {
			defaultValue: "CropBox",
			value: "CropBox",
			type: "name",
			explicitSet: !1,
			valueSet: [
				"MediaBox",
				"CropBox",
				"TrimBox",
				"BleedBox",
				"ArtBox"
			],
			pdfVersion: 1.4
		},
		PrintArea: {
			defaultValue: "CropBox",
			value: "CropBox",
			type: "name",
			explicitSet: !1,
			valueSet: [
				"MediaBox",
				"CropBox",
				"TrimBox",
				"BleedBox",
				"ArtBox"
			],
			pdfVersion: 1.4
		},
		PrintClip: {
			defaultValue: "CropBox",
			value: "CropBox",
			type: "name",
			explicitSet: !1,
			valueSet: [
				"MediaBox",
				"CropBox",
				"TrimBox",
				"BleedBox",
				"ArtBox"
			],
			pdfVersion: 1.4
		},
		PrintScaling: {
			defaultValue: "AppDefault",
			value: "AppDefault",
			type: "name",
			explicitSet: !1,
			valueSet: ["AppDefault", "None"],
			pdfVersion: 1.6
		},
		Duplex: {
			defaultValue: "",
			value: "none",
			type: "name",
			explicitSet: !1,
			valueSet: [
				"Simplex",
				"DuplexFlipShortEdge",
				"DuplexFlipLongEdge",
				"none"
			],
			pdfVersion: 1.7
		},
		PickTrayByPDFSize: {
			defaultValue: !1,
			value: !1,
			type: "boolean",
			explicitSet: !1,
			valueSet: [!0, !1],
			pdfVersion: 1.7
		},
		PrintPageRange: {
			defaultValue: "",
			value: "",
			type: "array",
			explicitSet: !1,
			valueSet: null,
			pdfVersion: 1.7
		},
		NumCopies: {
			defaultValue: 1,
			value: 1,
			type: "integer",
			explicitSet: !1,
			valueSet: null,
			pdfVersion: 1.7
		}
	}, u = Object.keys(s), c = [], l = 0, h = 0, f = 0;
	function d(t, e) {
		var r, n = !1;
		for (r = 0; r < t.length; r += 1) t[r] === e && (n = !0);
		return n;
	}
	if (void 0 === this.internal.viewerpreferences && (this.internal.viewerpreferences = {}, this.internal.viewerpreferences.configuration = JSON.parse(JSON.stringify(s)), this.internal.viewerpreferences.isSubscribed = !1), n = this.internal.viewerpreferences.configuration, "reset" === e || !0 === r) {
		var p = u.length;
		for (f = 0; f < p; f += 1) n[u[f]].value = n[u[f]].defaultValue, n[u[f]].explicitSet = !1;
	}
	if ("object" === _typeof(e)) {
		for (a in e) if (o = e[a], d(u, a) && void 0 !== o) {
			if ("boolean" === n[a].type && "boolean" == typeof o) n[a].value = o;
			else if ("name" === n[a].type && d(n[a].valueSet, o)) n[a].value = o;
			else if ("integer" === n[a].type && Number.isInteger(o)) n[a].value = o;
			else if ("array" === n[a].type) {
				for (l = 0; l < o.length; l += 1) if (i = !0, 1 === o[l].length && "number" == typeof o[l][0]) c.push(String(o[l] - 1));
				else if (o[l].length > 1) {
					for (h = 0; h < o[l].length; h += 1) "number" != typeof o[l][h] && (i = !1);
					!0 === i && c.push([o[l][0] - 1, o[l][1] - 1].join(" "));
				}
				n[a].value = "[" + c.join(" ") + "]";
			} else n[a].value = n[a].defaultValue;
			n[a].explicitSet = !0;
		}
	}
	return !1 === this.internal.viewerpreferences.isSubscribed && (this.internal.events.subscribe("putCatalog", function() {
		var t, e = [];
		for (t in n) !0 === n[t].explicitSet && ("name" === n[t].type ? e.push("/" + t + " /" + n[t].value) : e.push("/" + t + " " + n[t].value));
		0 !== e.length && this.internal.write("/ViewerPreferences\n<<\n" + e.join("\n") + "\n>>");
	}), this.internal.viewerpreferences.isSubscribed = !0), this.internal.viewerpreferences.configuration = n, this;
}, E.API.addMetadata = function(t, e) {
	return void 0 === this.internal.__metadata__ && (this.internal.__metadata__ = {
		metadata: t,
		namespaceUri: null != e ? e : "http://jspdf.default.namespaceuri/",
		rawXml: "boolean" == typeof e && e
	}, this.internal.events.subscribe("putCatalog", le), this.internal.events.subscribe("postPutResources", ce)), this;
}, function(t) {
	var e = t.API, r = e.pdfEscape16 = function(t, e) {
		for (var r, n = e.metadata.Unicode.widths, i = [
			"",
			"0",
			"00",
			"000",
			"0000"
		], a = [""], o = 0, s = t.length; o < s; ++o) {
			if (r = e.metadata.characterToGlyph(t.charCodeAt(o)), e.metadata.glyIdsUsed.push(r), e.metadata.toUnicode[r] = t.charCodeAt(o), -1 == n.indexOf(r) && (n.push(r), n.push([parseInt(e.metadata.widthOfGlyph(r), 10)])), "0" == r) return a.join("");
			r = r.toString(16), a.push(i[4 - r.length], r);
		}
		return a.join("");
	}, n = function(t) {
		var e, r, n, i, a, o, s;
		for (a = "/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n/CIDSystemInfo <<\n  /Registry (Adobe)\n  /Ordering (UCS)\n  /Supplement 0\n>> def\n/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n1 begincodespacerange\n<0000><ffff>\nendcodespacerange", n = [], o = 0, s = (r = Object.keys(t).sort(function(t, e) {
			return t - e;
		})).length; o < s; o++) e = r[o], n.length >= 100 && (a += "\n" + n.length + " beginbfchar\n" + n.join("\n") + "\nendbfchar", n = []), void 0 !== t[e] && null !== t[e] && "function" == typeof t[e].toString && (i = ("0000" + t[e].toString(16)).slice(-4), e = ("0000" + (+e).toString(16)).slice(-4), n.push("<" + e + "><" + i + ">"));
		return n.length && (a += "\n" + n.length + " beginbfchar\n" + n.join("\n") + "\nendbfchar\n"), a + "endcmap\nCMapName currentdict /CMap defineresource pop\nend\nend";
	};
	e.events.push(["putFont", function(e) {
		(function(e) {
			var r = e.font, i = e.out, a = e.newObject, o = e.putStream;
			if (r.metadata instanceof t.API.TTFFont && "Identity-H" === r.encoding) {
				for (var s = r.metadata.Unicode.widths, u = r.metadata.subset.encode(r.metadata.glyIdsUsed, 1), c = "", l = 0; l < u.length; l++) c += String.fromCharCode(u[l]);
				var h = a();
				o({
					data: c,
					addLength1: !0,
					objectId: h
				}), i("endobj");
				var f = a();
				o({
					data: n(r.metadata.toUnicode),
					addLength1: !0,
					objectId: f
				}), i("endobj");
				var d = a();
				i("<<"), i("/Type /FontDescriptor"), i("/FontName /" + C(r.fontName)), i("/FontFile2 " + h + " 0 R"), i("/FontBBox " + t.API.PDFObject.convert(r.metadata.bbox)), i("/Flags " + r.metadata.flags), i("/StemV " + r.metadata.stemV), i("/ItalicAngle " + r.metadata.italicAngle), i("/Ascent " + r.metadata.ascender), i("/Descent " + r.metadata.decender), i("/CapHeight " + r.metadata.capHeight), i(">>"), i("endobj");
				var p = a();
				i("<<"), i("/Type /Font"), i("/BaseFont /" + C(r.fontName)), i("/FontDescriptor " + d + " 0 R"), i("/W " + t.API.PDFObject.convert(s)), i("/CIDToGIDMap /Identity"), i("/DW 1000"), i("/Subtype /CIDFontType2"), i("/CIDSystemInfo"), i("<<"), i("/Supplement 0"), i("/Registry (Adobe)"), i("/Ordering (" + r.encoding + ")"), i(">>"), i(">>"), i("endobj"), r.objectNumber = a(), i("<<"), i("/Type /Font"), i("/Subtype /Type0"), i("/ToUnicode " + f + " 0 R"), i("/BaseFont /" + C(r.fontName)), i("/Encoding /" + r.encoding), i("/DescendantFonts [" + p + " 0 R]"), i(">>"), i("endobj"), r.isAlreadyPutted = !0;
			}
		})(e);
	}]), e.events.push(["putFont", function(e) {
		(function(e) {
			var r = e.font, i = e.out, a = e.newObject, o = e.putStream;
			if (r.metadata instanceof t.API.TTFFont && "WinAnsiEncoding" === r.encoding) {
				for (var s = r.metadata.rawData, u = "", c = 0; c < s.length; c++) u += String.fromCharCode(s[c]);
				var l = a();
				o({
					data: u,
					addLength1: !0,
					objectId: l
				}), i("endobj");
				var h = a();
				o({
					data: n(r.metadata.toUnicode),
					addLength1: !0,
					objectId: h
				}), i("endobj");
				var f = a();
				i("<<"), i("/Descent " + r.metadata.decender), i("/CapHeight " + r.metadata.capHeight), i("/StemV " + r.metadata.stemV), i("/Type /FontDescriptor"), i("/FontFile2 " + l + " 0 R"), i("/Flags 96"), i("/FontBBox " + t.API.PDFObject.convert(r.metadata.bbox)), i("/FontName /" + C(r.fontName)), i("/ItalicAngle " + r.metadata.italicAngle), i("/Ascent " + r.metadata.ascender), i(">>"), i("endobj"), r.objectNumber = a();
				for (var d = 0; d < r.metadata.hmtx.widths.length; d++) r.metadata.hmtx.widths[d] = parseInt(r.metadata.hmtx.widths[d] * (1e3 / r.metadata.head.unitsPerEm));
				i("<</Subtype/TrueType/Type/Font/ToUnicode " + h + " 0 R/BaseFont/" + C(r.fontName) + "/FontDescriptor " + f + " 0 R/Encoding/" + r.encoding + " /FirstChar 29 /LastChar 255 /Widths " + t.API.PDFObject.convert(r.metadata.hmtx.widths) + ">>"), i("endobj"), r.isAlreadyPutted = !0;
			}
		})(e);
	}]);
	var i = function(t) {
		var e, n = t.text || "", i = t.x, a = t.y, o = t.options || {}, s = t.mutex || {}, u = s.pdfEscape, c = s.activeFontKey, l = s.fonts, h = c, f = "", d = 0, p = "", g = l[h].encoding;
		if ("Identity-H" !== l[h].encoding) return {
			text: n,
			x: i,
			y: a,
			options: o,
			mutex: s
		};
		for (p = n, h = c, Array.isArray(n) && (p = n[0]), d = 0; d < p.length; d += 1) l[h].metadata.hasOwnProperty("cmap") && (e = l[h].metadata.cmap.unicode.codeMap[p[d].charCodeAt(0)]), e || p[d].charCodeAt(0) < 256 && l[h].metadata.hasOwnProperty("Unicode") ? f += p[d] : f += "";
		var m = "";
		return parseInt(h.slice(1)) < 14 || "WinAnsiEncoding" === g ? m = u(f, h).split("").map(function(t) {
			return t.charCodeAt(0).toString(16);
		}).join("") : "Identity-H" === g && (m = r(f, l[h])), s.isHex = !0, {
			text: m,
			x: i,
			y: a,
			options: o,
			mutex: s
		};
	};
	e.events.push(["postProcessText", function(t) {
		var e = t.text || "", r = [], n = {
			text: e,
			x: t.x,
			y: t.y,
			options: t.options,
			mutex: t.mutex
		};
		if (Array.isArray(e)) {
			var a = 0;
			for (a = 0; a < e.length; a += 1) Array.isArray(e[a]) && 3 === e[a].length ? r.push([
				i(Object.assign({}, n, { text: e[a][0] })).text,
				e[a][1],
				e[a][2]
			]) : r.push(i(Object.assign({}, n, { text: e[a] })).text);
			t.text = r;
		} else t.text = i(Object.assign({}, n, { text: e })).text;
	}]);
}(E), function(t) {
	/**
	* @license
	* jsPDF virtual FileSystem functionality
	*
	* Licensed under the MIT License.
	* http://opensource.org/licenses/mit-license
	*/
	var e = function() {
		return void 0 === this.internal.vFS && (this.internal.vFS = {}), !0;
	};
	t.existsFileInVFS = function(t) {
		return e.call(this), void 0 !== this.internal.vFS[t];
	}, t.addFileToVFS = function(t, r) {
		return e.call(this), this.internal.vFS[t] = r, this;
	}, t.getFileFromVFS = function(t) {
		return e.call(this), void 0 !== this.internal.vFS[t] ? this.internal.vFS[t] : null;
	};
}(E.API), function(t) {
	/**
	* @license
	* Unicode Bidi Engine based on the work of Alex Shensis (@asthensis)
	* MIT License
	*/
	t.__bidiEngine__ = t.prototype.__bidiEngine__ = function(t) {
		var r, n, i, a, o, s, u, c = e, l = [
			[
				0,
				3,
				0,
				1,
				0,
				0,
				0
			],
			[
				0,
				3,
				0,
				1,
				2,
				2,
				0
			],
			[
				0,
				3,
				0,
				17,
				2,
				0,
				1
			],
			[
				0,
				3,
				5,
				5,
				4,
				1,
				0
			],
			[
				0,
				3,
				21,
				21,
				4,
				0,
				1
			],
			[
				0,
				3,
				5,
				5,
				4,
				2,
				0
			]
		], h = [
			[
				2,
				0,
				1,
				1,
				0,
				1,
				0
			],
			[
				2,
				0,
				1,
				1,
				0,
				2,
				0
			],
			[
				2,
				0,
				2,
				1,
				3,
				2,
				0
			],
			[
				2,
				0,
				2,
				33,
				3,
				1,
				1
			]
		], f = {
			L: 0,
			R: 1,
			EN: 2,
			AN: 3,
			N: 4,
			B: 5,
			S: 6
		}, d = {
			0: 0,
			5: 1,
			6: 2,
			7: 3,
			32: 4,
			251: 5,
			254: 6,
			255: 7
		}, p = [
			"(",
			")",
			"(",
			"<",
			">",
			"<",
			"[",
			"]",
			"[",
			"{",
			"}",
			"{",
			"«",
			"»",
			"«",
			"‹",
			"›",
			"‹",
			"⁅",
			"⁆",
			"⁅",
			"⁽",
			"⁾",
			"⁽",
			"₍",
			"₎",
			"₍",
			"≤",
			"≥",
			"≤",
			"〈",
			"〉",
			"〈",
			"﹙",
			"﹚",
			"﹙",
			"﹛",
			"﹜",
			"﹛",
			"﹝",
			"﹞",
			"﹝",
			"﹤",
			"﹥",
			"﹤"
		], g = /* @__PURE__ */ new RegExp(/^([1-4|9]|1[0-9]|2[0-9]|3[0168]|4[04589]|5[012]|7[78]|159|16[0-9]|17[0-2]|21[569]|22[03489]|250)$/), m = !1, v = 0;
		this.__bidiEngine__ = {};
		var b = function(t) {
			var e = t.charCodeAt(), r = e >> 8, n = d[r];
			return void 0 !== n ? c[256 * n + (255 & e)] : 252 === r || 253 === r ? "AL" : g.test(r) ? "L" : 8 === r ? "R" : "N";
		}, y = function(t) {
			for (var e, r = 0; r < t.length; r++) {
				if ("L" === (e = b(t.charAt(r)))) return !1;
				if ("R" === e) return !0;
			}
			return !1;
		}, w = function(t, e, o, s) {
			var u, c, l, h, f = e[s];
			switch (f) {
				case "L":
				case "R":
				case "LRE":
				case "RLE":
				case "LRO":
				case "RLO":
				case "PDF":
					m = !1;
					break;
				case "N":
				case "AN": break;
				case "EN":
					m && (f = "AN");
					break;
				case "AL":
					m = !0, f = "R";
					break;
				case "WS":
				case "BN":
					f = "N";
					break;
				case "CS":
					s < 1 || s + 1 >= e.length || "EN" !== (u = o[s - 1]) && "AN" !== u || "EN" !== (c = e[s + 1]) && "AN" !== c ? f = "N" : m && (c = "AN"), f = c === u ? c : "N";
					break;
				case "ES":
					f = "EN" === (u = s > 0 ? o[s - 1] : "B") && s + 1 < e.length && "EN" === e[s + 1] ? "EN" : "N";
					break;
				case "ET":
					if (s > 0 && "EN" === o[s - 1]) {
						f = "EN";
						break;
					}
					if (m) {
						f = "N";
						break;
					}
					for (l = s + 1, h = e.length; l < h && "ET" === e[l];) l++;
					f = l < h && "EN" === e[l] ? "EN" : "N";
					break;
				case "NSM":
					if (i && !a) {
						for (h = e.length, l = s + 1; l < h && "NSM" === e[l];) l++;
						if (l < h) {
							var d = t[s], p = d >= 1425 && d <= 2303 || 64286 === d;
							if (u = e[l], p && ("R" === u || "AL" === u)) {
								f = "R";
								break;
							}
						}
					}
					f = s < 1 || "B" === (u = e[s - 1]) ? "N" : o[s - 1];
					break;
				case "B":
					m = !1, r = !0, f = v;
					break;
				case "S": n = !0, f = "N";
			}
			return f;
		}, N = function(t, e, r) {
			var n = t.split("");
			return r && L(n, r, { hiLevel: v }), n.reverse(), e && e.reverse(), n.join("");
		}, L = function(t, e, i) {
			var a, o, s, u, c, d = -1, p = t.length, g = 0, y = [], N = v ? h : l, L = [];
			for (m = !1, r = !1, n = !1, o = 0; o < p; o++) L[o] = b(t[o]);
			for (s = 0; s < p; s++) {
				if (c = g, y[s] = w(t, L, y, s), a = 240 & (g = N[c][f[y[s]]]), g &= 15, e[s] = u = N[g][5], a > 0) if (16 === a) {
					for (o = d; o < s; o++) e[o] = 1;
					d = -1;
				} else d = -1;
				if (N[g][6]) -1 === d && (d = s);
				else if (d > -1) {
					for (o = d; o < s; o++) e[o] = u;
					d = -1;
				}
				"B" === L[s] && (e[s] = 0), i.hiLevel |= u;
			}
			n && function(t, e, r) {
				for (var n = 0; n < r; n++) if ("S" === t[n]) {
					e[n] = v;
					for (var i = n - 1; i >= 0 && "WS" === t[i]; i--) e[i] = v;
				}
			}(L, e, p);
		}, x = function(t, e, n, i, a) {
			if (!(a.hiLevel < t)) {
				if (1 === t && 1 === v && !r) return e.reverse(), void (n && n.reverse());
				for (var o, s, u, c, l = e.length, h = 0; h < l;) {
					if (i[h] >= t) {
						for (u = h + 1; u < l && i[u] >= t;) u++;
						for (c = h, s = u - 1; c < s; c++, s--) o = e[c], e[c] = e[s], e[s] = o, n && (o = n[c], n[c] = n[s], n[s] = o);
						h = u;
					}
					h++;
				}
			}
		}, A = function(t, e, r) {
			var n = t.split(""), i = { hiLevel: v };
			return r || (r = []), L(n, r, i), function(t, e, r) {
				if (0 !== r.hiLevel && u) for (var n, i = 0; i < t.length; i++) 1 === e[i] && (n = p.indexOf(t[i])) >= 0 && (t[i] = p[n + 1]);
			}(n, r, i), x(2, n, e, r, i), x(1, n, e, r, i), n.join("");
		};
		return this.__bidiEngine__.doBidiReorder = function(t, e, r) {
			if (function(t, e) {
				if (e) for (var r = 0; r < t.length; r++) e[r] = r;
				void 0 === a && (a = y(t)), void 0 === s && (s = y(t));
			}(t, e), i || !o || s) if (i && o && a ^ s) v = a ? 1 : 0, t = N(t, e, r);
			else if (!i && o && s) v = a ? 1 : 0, t = A(t, e, r), t = N(t, e);
			else if (!i || a || o || s) {
				if (i && !o && a ^ s) t = N(t, e), a ? (v = 0, t = A(t, e, r)) : (v = 1, t = A(t, e, r), t = N(t, e));
				else if (i && a && !o && s) v = 1, t = A(t, e, r), t = N(t, e);
				else if (!i && !o && a ^ s) {
					var n = u;
					a ? (v = 1, t = A(t, e, r), v = 0, u = !1, t = A(t, e, r), u = n) : (v = 0, t = A(t, e, r), t = N(t, e), v = 1, u = !1, t = A(t, e, r), u = n, t = N(t, e));
				}
			} else v = 0, t = A(t, e, r);
			else v = a ? 1 : 0, t = A(t, e, r);
			return t;
		}, this.__bidiEngine__.setOptions = function(t) {
			t && (i = t.isInputVisual, o = t.isOutputVisual, a = t.isInputRtl, s = t.isOutputRtl, u = t.isSymmetricSwapping);
		}, this.__bidiEngine__.setOptions(t), this.__bidiEngine__;
	};
	var e = [
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"S",
		"B",
		"S",
		"WS",
		"B",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"B",
		"B",
		"B",
		"S",
		"WS",
		"N",
		"N",
		"ET",
		"ET",
		"ET",
		"N",
		"N",
		"N",
		"N",
		"N",
		"ES",
		"CS",
		"ES",
		"CS",
		"CS",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"CS",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"N",
		"N",
		"N",
		"N",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"B",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"CS",
		"N",
		"ET",
		"ET",
		"ET",
		"ET",
		"N",
		"N",
		"N",
		"N",
		"L",
		"N",
		"N",
		"BN",
		"N",
		"N",
		"ET",
		"ET",
		"EN",
		"EN",
		"N",
		"L",
		"N",
		"N",
		"N",
		"EN",
		"L",
		"N",
		"N",
		"N",
		"N",
		"N",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"N",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"N",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"N",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"N",
		"N",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"N",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"N",
		"L",
		"N",
		"N",
		"N",
		"N",
		"N",
		"ET",
		"N",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"R",
		"NSM",
		"R",
		"NSM",
		"NSM",
		"R",
		"NSM",
		"NSM",
		"R",
		"NSM",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"N",
		"N",
		"N",
		"N",
		"N",
		"R",
		"R",
		"R",
		"R",
		"R",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"AN",
		"AN",
		"AN",
		"AN",
		"AN",
		"AN",
		"N",
		"N",
		"AL",
		"ET",
		"ET",
		"AL",
		"CS",
		"AL",
		"N",
		"N",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"AL",
		"AL",
		"N",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"AN",
		"AN",
		"AN",
		"AN",
		"AN",
		"AN",
		"AN",
		"AN",
		"AN",
		"AN",
		"ET",
		"AN",
		"AN",
		"AL",
		"AL",
		"AL",
		"NSM",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"AN",
		"N",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"AL",
		"AL",
		"NSM",
		"NSM",
		"N",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"AL",
		"AL",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"N",
		"AL",
		"AL",
		"NSM",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"N",
		"N",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"AL",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"R",
		"R",
		"N",
		"N",
		"N",
		"N",
		"R",
		"N",
		"N",
		"N",
		"N",
		"N",
		"WS",
		"WS",
		"WS",
		"WS",
		"WS",
		"WS",
		"WS",
		"WS",
		"WS",
		"WS",
		"WS",
		"BN",
		"BN",
		"BN",
		"L",
		"R",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"WS",
		"B",
		"LRE",
		"RLE",
		"PDF",
		"LRO",
		"RLO",
		"CS",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"CS",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"WS",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"N",
		"LRI",
		"RLI",
		"FSI",
		"PDI",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"BN",
		"EN",
		"L",
		"N",
		"N",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"ES",
		"ES",
		"N",
		"N",
		"N",
		"L",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"ES",
		"ES",
		"N",
		"N",
		"N",
		"N",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"N",
		"N",
		"N",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"ET",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"L",
		"L",
		"L",
		"L",
		"L",
		"N",
		"N",
		"N",
		"N",
		"N",
		"R",
		"NSM",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"ES",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"N",
		"R",
		"R",
		"R",
		"R",
		"R",
		"N",
		"R",
		"N",
		"R",
		"R",
		"N",
		"R",
		"R",
		"N",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"R",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"NSM",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"CS",
		"N",
		"CS",
		"N",
		"N",
		"CS",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"ET",
		"N",
		"N",
		"ES",
		"ES",
		"N",
		"N",
		"N",
		"N",
		"N",
		"ET",
		"ET",
		"N",
		"N",
		"N",
		"N",
		"N",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"N",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"AL",
		"N",
		"N",
		"BN",
		"N",
		"N",
		"N",
		"ET",
		"ET",
		"ET",
		"N",
		"N",
		"N",
		"N",
		"N",
		"ES",
		"CS",
		"ES",
		"CS",
		"CS",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"EN",
		"CS",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"N",
		"N",
		"N",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"N",
		"N",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"N",
		"N",
		"L",
		"L",
		"L",
		"L",
		"L",
		"L",
		"N",
		"N",
		"L",
		"L",
		"L",
		"N",
		"N",
		"N",
		"ET",
		"ET",
		"N",
		"N",
		"N",
		"ET",
		"ET",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N",
		"N"
	], r = new t.__bidiEngine__({ isInputVisual: !0 });
	t.API.events.push(["postProcessText", function(t) {
		var e = t.text;
		t.x, t.y;
		var n = t.options || {};
		t.mutex, n.lang;
		var i = [];
		if (n.isInputVisual = "boolean" != typeof n.isInputVisual || n.isInputVisual, r.setOptions(n), "[object Array]" === Object.prototype.toString.call(e)) {
			var a = 0;
			for (i = [], a = 0; a < e.length; a += 1) "[object Array]" === Object.prototype.toString.call(e[a]) ? i.push([
				r.doBidiReorder(e[a][0]),
				e[a][1],
				e[a][2]
			]) : i.push([r.doBidiReorder(e[a])]);
			t.text = i;
		} else t.text = r.doBidiReorder(e);
		r.setOptions({ isInputVisual: !0 });
	}]);
}(E), E.API.TTFFont = function() {
	function t(t) {
		var e;
		if (this.rawData = t, e = this.contents = new fe(t), this.contents.pos = 4, "ttcf" === e.readString(4)) throw new Error("TTCF not supported.");
		e.pos = 0, this.parse(), this.subset = new Ce(this), this.registerTTF();
	}
	return t.open = function(e) {
		return new t(e);
	}, t.prototype.parse = function() {
		return this.directory = new de(this.contents), this.head = new me(this), this.name = new xe(this), this.cmap = new be(this), this.toUnicode = {}, this.hhea = new ye(this), this.maxp = new Ae(this), this.hmtx = new Se(this), this.post = new Ne(this), this.os2 = new we(this), this.loca = new Ie(this), this.glyf = new Pe(this), this.ascender = this.os2.exists && this.os2.ascender || this.hhea.ascender, this.decender = this.os2.exists && this.os2.decender || this.hhea.decender, this.lineGap = this.os2.exists && this.os2.lineGap || this.hhea.lineGap, this.bbox = [
			this.head.xMin,
			this.head.yMin,
			this.head.xMax,
			this.head.yMax
		];
	}, t.prototype.registerTTF = function() {
		var t, e, r, n, i;
		if (this.scaleFactor = 1e3 / this.head.unitsPerEm, this.bbox = function() {
			var e, r, n, i;
			for (i = [], e = 0, r = (n = this.bbox).length; e < r; e++) t = n[e], i.push(Math.round(t * this.scaleFactor));
			return i;
		}.call(this), this.stemV = 0, this.post.exists ? (r = 255 & (n = this.post.italic_angle), 32768 & (e = n >> 16) && (e = -(1 + (65535 ^ e))), this.italicAngle = +(e + "." + r)) : this.italicAngle = 0, this.ascender = Math.round(this.ascender * this.scaleFactor), this.decender = Math.round(this.decender * this.scaleFactor), this.lineGap = Math.round(this.lineGap * this.scaleFactor), this.capHeight = this.os2.exists && this.os2.capHeight || this.ascender, this.xHeight = this.os2.exists && this.os2.xHeight || 0, this.familyClass = (this.os2.exists && this.os2.familyClass || 0) >> 8, this.isSerif = 1 === (i = this.familyClass) || 2 === i || 3 === i || 4 === i || 5 === i || 7 === i, this.isScript = 10 === this.familyClass, this.flags = 0, this.post.isFixedPitch && (this.flags |= 1), this.isSerif && (this.flags |= 2), this.isScript && (this.flags |= 8), 0 !== this.italicAngle && (this.flags |= 64), this.flags |= 32, !this.cmap.unicode) throw new Error("No unicode cmap for font");
	}, t.prototype.characterToGlyph = function(t) {
		var e;
		return (null != (e = this.cmap.unicode) ? e.codeMap[t] : void 0) || 0;
	}, t.prototype.widthOfGlyph = function(t) {
		var e;
		return e = 1e3 / this.head.unitsPerEm, this.hmtx.forGlyph(t).advance * e;
	}, t.prototype.widthOfString = function(t, e, r) {
		var n, i, a, o;
		for (a = 0, i = 0, o = (t = "" + t).length; 0 <= o ? i < o : i > o; i = 0 <= o ? ++i : --i) n = t.charCodeAt(i), a += this.widthOfGlyph(this.characterToGlyph(n)) + r * (1e3 / e) || 0;
		return a * (e / 1e3);
	}, t.prototype.lineHeight = function(t, e) {
		var r;
		return e ??= !1, r = e ? this.lineGap : 0, (this.ascender + r - this.decender) / 1e3 * t;
	}, t;
}();
var he;
var fe = function() {
	function t(t) {
		this.data = null != t ? t : [], this.pos = 0, this.length = this.data.length;
	}
	return t.prototype.readByte = function() {
		return this.data[this.pos++];
	}, t.prototype.writeByte = function(t) {
		return this.data[this.pos++] = t;
	}, t.prototype.readUInt32 = function() {
		return 16777216 * this.readByte() + (this.readByte() << 16) + (this.readByte() << 8) + this.readByte();
	}, t.prototype.writeUInt32 = function(t) {
		return this.writeByte(t >>> 24 & 255), this.writeByte(t >> 16 & 255), this.writeByte(t >> 8 & 255), this.writeByte(255 & t);
	}, t.prototype.readInt32 = function() {
		var t;
		return (t = this.readUInt32()) >= 2147483648 ? t - 4294967296 : t;
	}, t.prototype.writeInt32 = function(t) {
		return t < 0 && (t += 4294967296), this.writeUInt32(t);
	}, t.prototype.readUInt16 = function() {
		return this.readByte() << 8 | this.readByte();
	}, t.prototype.writeUInt16 = function(t) {
		return this.writeByte(t >> 8 & 255), this.writeByte(255 & t);
	}, t.prototype.readInt16 = function() {
		var t;
		return (t = this.readUInt16()) >= 32768 ? t - 65536 : t;
	}, t.prototype.writeInt16 = function(t) {
		return t < 0 && (t += 65536), this.writeUInt16(t);
	}, t.prototype.readString = function(t) {
		var e, r;
		for (r = [], e = 0; 0 <= t ? e < t : e > t; e = 0 <= t ? ++e : --e) r[e] = String.fromCharCode(this.readByte());
		return r.join("");
	}, t.prototype.writeString = function(t) {
		var e, r, n;
		for (n = [], e = 0, r = t.length; 0 <= r ? e < r : e > r; e = 0 <= r ? ++e : --e) n.push(this.writeByte(t.charCodeAt(e)));
		return n;
	}, t.prototype.readShort = function() {
		return this.readInt16();
	}, t.prototype.writeShort = function(t) {
		return this.writeInt16(t);
	}, t.prototype.readLongLong = function() {
		var t, e, r, n, i, a, o, s;
		return t = this.readByte(), e = this.readByte(), r = this.readByte(), n = this.readByte(), i = this.readByte(), a = this.readByte(), o = this.readByte(), s = this.readByte(), 128 & t ? -1 * (72057594037927940 * (255 ^ t) + 281474976710656 * (255 ^ e) + 1099511627776 * (255 ^ r) + 4294967296 * (255 ^ n) + 16777216 * (255 ^ i) + 65536 * (255 ^ a) + 256 * (255 ^ o) + (255 ^ s) + 1) : 72057594037927940 * t + 281474976710656 * e + 1099511627776 * r + 4294967296 * n + 16777216 * i + 65536 * a + 256 * o + s;
	}, t.prototype.writeLongLong = function(t) {
		var e, r;
		return e = Math.floor(t / 4294967296), r = 4294967295 & t, this.writeByte(e >> 24 & 255), this.writeByte(e >> 16 & 255), this.writeByte(e >> 8 & 255), this.writeByte(255 & e), this.writeByte(r >> 24 & 255), this.writeByte(r >> 16 & 255), this.writeByte(r >> 8 & 255), this.writeByte(255 & r);
	}, t.prototype.readInt = function() {
		return this.readInt32();
	}, t.prototype.writeInt = function(t) {
		return this.writeInt32(t);
	}, t.prototype.read = function(t) {
		var e, r;
		for (e = [], r = 0; 0 <= t ? r < t : r > t; r = 0 <= t ? ++r : --r) e.push(this.readByte());
		return e;
	}, t.prototype.write = function(t) {
		var e, r, n, i;
		for (i = [], r = 0, n = t.length; r < n; r++) e = t[r], i.push(this.writeByte(e));
		return i;
	}, t;
}();
var de = function() {
	var t;
	function e(t) {
		var e, r, n;
		for (this.scalarType = t.readInt(), this.tableCount = t.readShort(), this.searchRange = t.readShort(), this.entrySelector = t.readShort(), this.rangeShift = t.readShort(), this.tables = {}, r = 0, n = this.tableCount; 0 <= n ? r < n : r > n; r = 0 <= n ? ++r : --r) e = {
			tag: t.readString(4),
			checksum: t.readInt(),
			offset: t.readInt(),
			length: t.readInt()
		}, this.tables[e.tag] = e;
	}
	return e.prototype.encode = function(e) {
		var r, n, i, a, o, s, u, c, l, h, f, d, p;
		for (p in f = Object.keys(e).length, s = Math.log(2), l = 16 * Math.floor(Math.log(f) / s), a = Math.floor(l / s), c = 16 * f - l, (n = new fe()).writeInt(this.scalarType), n.writeShort(f), n.writeShort(l), n.writeShort(a), n.writeShort(c), i = 16 * f, u = n.pos + i, o = null, d = [], e) for (h = e[p], n.writeString(p), n.writeInt(t(h)), n.writeInt(u), n.writeInt(h.length), d = d.concat(h), "head" === p && (o = u), u += h.length; u % 4;) d.push(0), u++;
		return n.write(d), r = 2981146554 - t(n.data), n.pos = o + 8, n.writeUInt32(r), n.data;
	}, t = function(t) {
		var e, r, n, i;
		for (t = _e.call(t); t.length % 4;) t.push(0);
		for (n = new fe(t), r = 0, e = 0, i = t.length; e < i; e = e += 4) r += n.readUInt32();
		return 4294967295 & r;
	}, e;
}();
var pe = {}.hasOwnProperty;
var ge = function(t, e) {
	for (var r in e) pe.call(e, r) && (t[r] = e[r]);
	function n() {
		this.constructor = t;
	}
	return n.prototype = e.prototype, t.prototype = new n(), t.__super__ = e.prototype, t;
};
he = function() {
	function t(t) {
		var e;
		this.file = t, e = this.file.directory.tables[this.tag], this.exists = !!e, e && (this.offset = e.offset, this.length = e.length, this.parse(this.file.contents));
	}
	return t.prototype.parse = function() {}, t.prototype.encode = function() {}, t.prototype.raw = function() {
		return this.exists ? (this.file.contents.pos = this.offset, this.file.contents.read(this.length)) : null;
	}, t;
}();
var me = function() {
	function t() {
		return t.__super__.constructor.apply(this, arguments);
	}
	return ge(t, he), t.prototype.tag = "head", t.prototype.parse = function(t) {
		return t.pos = this.offset, this.version = t.readInt(), this.revision = t.readInt(), this.checkSumAdjustment = t.readInt(), this.magicNumber = t.readInt(), this.flags = t.readShort(), this.unitsPerEm = t.readShort(), this.created = t.readLongLong(), this.modified = t.readLongLong(), this.xMin = t.readShort(), this.yMin = t.readShort(), this.xMax = t.readShort(), this.yMax = t.readShort(), this.macStyle = t.readShort(), this.lowestRecPPEM = t.readShort(), this.fontDirectionHint = t.readShort(), this.indexToLocFormat = t.readShort(), this.glyphDataFormat = t.readShort();
	}, t.prototype.encode = function(t) {
		var e;
		return (e = new fe()).writeInt(this.version), e.writeInt(this.revision), e.writeInt(this.checkSumAdjustment), e.writeInt(this.magicNumber), e.writeShort(this.flags), e.writeShort(this.unitsPerEm), e.writeLongLong(this.created), e.writeLongLong(this.modified), e.writeShort(this.xMin), e.writeShort(this.yMin), e.writeShort(this.xMax), e.writeShort(this.yMax), e.writeShort(this.macStyle), e.writeShort(this.lowestRecPPEM), e.writeShort(this.fontDirectionHint), e.writeShort(t), e.writeShort(this.glyphDataFormat), e.data;
	}, t;
}();
var ve = function() {
	function t(t, e) {
		var r, n, i, a, o, s, u, c, l, h, f, d, p, g, m, v, b;
		switch (this.platformID = t.readUInt16(), this.encodingID = t.readShort(), this.offset = e + t.readInt(), l = t.pos, t.pos = this.offset, this.format = t.readUInt16(), this.length = t.readUInt16(), this.language = t.readUInt16(), this.isUnicode = 3 === this.platformID && 1 === this.encodingID && 4 === this.format || 0 === this.platformID && 4 === this.format, this.codeMap = {}, this.format) {
			case 0:
				for (s = 0; s < 256; ++s) this.codeMap[s] = t.readByte();
				break;
			case 4: for (f = t.readUInt16(), h = f / 2, t.pos += 6, i = function() {
				var e, r;
				for (r = [], s = e = 0; 0 <= h ? e < h : e > h; s = 0 <= h ? ++e : --e) r.push(t.readUInt16());
				return r;
			}(), t.pos += 2, p = function() {
				var e, r;
				for (r = [], s = e = 0; 0 <= h ? e < h : e > h; s = 0 <= h ? ++e : --e) r.push(t.readUInt16());
				return r;
			}(), u = function() {
				var e, r;
				for (r = [], s = e = 0; 0 <= h ? e < h : e > h; s = 0 <= h ? ++e : --e) r.push(t.readUInt16());
				return r;
			}(), c = function() {
				var e, r;
				for (r = [], s = e = 0; 0 <= h ? e < h : e > h; s = 0 <= h ? ++e : --e) r.push(t.readUInt16());
				return r;
			}(), n = (this.length - t.pos + this.offset) / 2, o = function() {
				var e, r;
				for (r = [], s = e = 0; 0 <= n ? e < n : e > n; s = 0 <= n ? ++e : --e) r.push(t.readUInt16());
				return r;
			}(), s = m = 0, b = i.length; m < b; s = ++m) for (g = i[s], r = v = d = p[s]; d <= g ? v <= g : v >= g; r = d <= g ? ++v : --v) 0 === c[s] ? a = r + u[s] : 0 !== (a = o[c[s] / 2 + (r - d) - (h - s)] || 0) && (a += u[s]), this.codeMap[r] = 65535 & a;
		}
		t.pos = l;
	}
	return t.encode = function(t, e) {
		var r, n, i, a, o, s, u, c, l, h, f, d, p, g, m, v, b, y, w, N, L, x, A, S, _, P, k, F, I, C, j, O, B, M, q, E, R, D, T, z, U, H, W, V, G, Y;
		switch (F = new fe(), a = Object.keys(t).sort(function(t, e) {
			return t - e;
		}), e) {
			case "macroman":
				for (p = 0, g = function() {
					var t = [];
					for (d = 0; d < 256; ++d) t.push(0);
					return t;
				}(), v = { 0: 0 }, i = {}, I = 0, B = a.length; I < B; I++) v[W = t[n = a[I]]] ?? (v[W] = ++p), i[n] = {
					old: t[n],
					new: v[t[n]]
				}, g[n] = v[t[n]];
				return F.writeUInt16(1), F.writeUInt16(0), F.writeUInt32(12), F.writeUInt16(0), F.writeUInt16(262), F.writeUInt16(0), F.write(g), {
					charMap: i,
					subtable: F.data,
					maxGlyphID: p + 1
				};
			case "unicode":
				for (P = [], l = [], b = 0, v = {}, r = {}, m = u = null, C = 0, M = a.length; C < M; C++) v[w = t[n = a[C]]] ?? (v[w] = ++b), r[n] = {
					old: w,
					new: v[w]
				}, o = v[w] - n, null != m && o === u || (m && l.push(m), P.push(n), u = o), m = n;
				for (m && l.push(m), l.push(65535), P.push(65535), S = 2 * (A = P.length), x = 2 * Math.pow(Math.log(A) / Math.LN2, 2), h = Math.log(x / 2) / Math.LN2, L = 2 * A - x, s = [], N = [], f = [], d = j = 0, q = P.length; j < q; d = ++j) {
					if (_ = P[d], c = l[d], 65535 === _) {
						s.push(0), N.push(0);
						break;
					}
					if (_ - (k = r[_].new) >= 32768) for (s.push(0), N.push(2 * (f.length + A - d)), n = O = _; _ <= c ? O <= c : O >= c; n = _ <= c ? ++O : --O) f.push(r[n].new);
					else s.push(k - _), N.push(0);
				}
				for (F.writeUInt16(3), F.writeUInt16(1), F.writeUInt32(12), F.writeUInt16(4), F.writeUInt16(16 + 8 * A + 2 * f.length), F.writeUInt16(0), F.writeUInt16(S), F.writeUInt16(x), F.writeUInt16(h), F.writeUInt16(L), U = 0, E = l.length; U < E; U++) n = l[U], F.writeUInt16(n);
				for (F.writeUInt16(0), H = 0, R = P.length; H < R; H++) n = P[H], F.writeUInt16(n);
				for (V = 0, D = s.length; V < D; V++) o = s[V], F.writeUInt16(o);
				for (G = 0, T = N.length; G < T; G++) y = N[G], F.writeUInt16(y);
				for (Y = 0, z = f.length; Y < z; Y++) p = f[Y], F.writeUInt16(p);
				return {
					charMap: r,
					subtable: F.data,
					maxGlyphID: b + 1
				};
		}
	}, t;
}();
var be = function() {
	function t() {
		return t.__super__.constructor.apply(this, arguments);
	}
	return ge(t, he), t.prototype.tag = "cmap", t.prototype.parse = function(t) {
		var e, r, n;
		for (t.pos = this.offset, this.version = t.readUInt16(), n = t.readUInt16(), this.tables = [], this.unicode = null, r = 0; 0 <= n ? r < n : r > n; r = 0 <= n ? ++r : --r) e = new ve(t, this.offset), this.tables.push(e), e.isUnicode && null == this.unicode && (this.unicode = e);
		return !0;
	}, t.encode = function(t, e) {
		var r, n;
		return e ??= "macroman", r = ve.encode(t, e), (n = new fe()).writeUInt16(0), n.writeUInt16(1), r.table = n.data.concat(r.subtable), r;
	}, t;
}();
var ye = function() {
	function t() {
		return t.__super__.constructor.apply(this, arguments);
	}
	return ge(t, he), t.prototype.tag = "hhea", t.prototype.parse = function(t) {
		return t.pos = this.offset, this.version = t.readInt(), this.ascender = t.readShort(), this.decender = t.readShort(), this.lineGap = t.readShort(), this.advanceWidthMax = t.readShort(), this.minLeftSideBearing = t.readShort(), this.minRightSideBearing = t.readShort(), this.xMaxExtent = t.readShort(), this.caretSlopeRise = t.readShort(), this.caretSlopeRun = t.readShort(), this.caretOffset = t.readShort(), t.pos += 8, this.metricDataFormat = t.readShort(), this.numberOfMetrics = t.readUInt16();
	}, t;
}();
var we = function() {
	function t() {
		return t.__super__.constructor.apply(this, arguments);
	}
	return ge(t, he), t.prototype.tag = "OS/2", t.prototype.parse = function(t) {
		if (t.pos = this.offset, this.version = t.readUInt16(), this.averageCharWidth = t.readShort(), this.weightClass = t.readUInt16(), this.widthClass = t.readUInt16(), this.type = t.readShort(), this.ySubscriptXSize = t.readShort(), this.ySubscriptYSize = t.readShort(), this.ySubscriptXOffset = t.readShort(), this.ySubscriptYOffset = t.readShort(), this.ySuperscriptXSize = t.readShort(), this.ySuperscriptYSize = t.readShort(), this.ySuperscriptXOffset = t.readShort(), this.ySuperscriptYOffset = t.readShort(), this.yStrikeoutSize = t.readShort(), this.yStrikeoutPosition = t.readShort(), this.familyClass = t.readShort(), this.panose = function() {
			var e, r;
			for (r = [], e = 0; e < 10; ++e) r.push(t.readByte());
			return r;
		}(), this.charRange = function() {
			var e, r;
			for (r = [], e = 0; e < 4; ++e) r.push(t.readInt());
			return r;
		}(), this.vendorID = t.readString(4), this.selection = t.readShort(), this.firstCharIndex = t.readShort(), this.lastCharIndex = t.readShort(), this.version > 0 && (this.ascent = t.readShort(), this.descent = t.readShort(), this.lineGap = t.readShort(), this.winAscent = t.readShort(), this.winDescent = t.readShort(), this.codePageRange = function() {
			var e, r;
			for (r = [], e = 0; e < 2; e = ++e) r.push(t.readInt());
			return r;
		}(), this.version > 1)) return this.xHeight = t.readShort(), this.capHeight = t.readShort(), this.defaultChar = t.readShort(), this.breakChar = t.readShort(), this.maxContext = t.readShort();
	}, t;
}();
var Ne = function() {
	function t() {
		return t.__super__.constructor.apply(this, arguments);
	}
	return ge(t, he), t.prototype.tag = "post", t.prototype.parse = function(t) {
		var e, r, n;
		switch (t.pos = this.offset, this.format = t.readInt(), this.italicAngle = t.readInt(), this.underlinePosition = t.readShort(), this.underlineThickness = t.readShort(), this.isFixedPitch = t.readInt(), this.minMemType42 = t.readInt(), this.maxMemType42 = t.readInt(), this.minMemType1 = t.readInt(), this.maxMemType1 = t.readInt(), this.format) {
			case 65536:
			case 196608: break;
			case 131072:
				var i;
				for (r = t.readUInt16(), this.glyphNameIndex = [], i = 0; 0 <= r ? i < r : i > r; i = 0 <= r ? ++i : --i) this.glyphNameIndex.push(t.readUInt16());
				for (this.names = [], n = []; t.pos < this.offset + this.length;) e = t.readByte(), n.push(this.names.push(t.readString(e)));
				return n;
			case 151552: return r = t.readUInt16(), this.offsets = t.read(r);
			case 262144: return this.map = function() {
				var e, r, n;
				for (n = [], i = e = 0, r = this.file.maxp.numGlyphs; 0 <= r ? e < r : e > r; i = 0 <= r ? ++e : --e) n.push(t.readUInt32());
				return n;
			}.call(this);
		}
	}, t;
}();
var Le = function(t, e) {
	this.raw = t, this.length = t.length, this.platformID = e.platformID, this.encodingID = e.encodingID, this.languageID = e.languageID;
};
var xe = function() {
	function t() {
		return t.__super__.constructor.apply(this, arguments);
	}
	return ge(t, he), t.prototype.tag = "name", t.prototype.parse = function(t) {
		var e, r, n, i, a, o, s, u, c, l, h;
		for (t.pos = this.offset, t.readShort(), e = t.readShort(), o = t.readShort(), r = [], i = 0; 0 <= e ? i < e : i > e; i = 0 <= e ? ++i : --i) r.push({
			platformID: t.readShort(),
			encodingID: t.readShort(),
			languageID: t.readShort(),
			nameID: t.readShort(),
			length: t.readShort(),
			offset: this.offset + o + t.readShort()
		});
		for (s = {}, i = c = 0, l = r.length; c < l; i = ++c) n = r[i], t.pos = n.offset, u = t.readString(n.length), a = new Le(u, n), s[h = n.nameID] ?? (s[h] = []), s[n.nameID].push(a);
		this.strings = s, this.copyright = s[0], this.fontFamily = s[1], this.fontSubfamily = s[2], this.uniqueSubfamily = s[3], this.fontName = s[4], this.version = s[5];
		try {
			this.postscriptName = s[6][0].raw.replace(/[\x00-\x19\x80-\xff]/g, "");
		} catch (f) {
			this.postscriptName = s[4][0].raw.replace(/[\x00-\x19\x80-\xff]/g, "");
		}
		return this.trademark = s[7], this.manufacturer = s[8], this.designer = s[9], this.description = s[10], this.vendorUrl = s[11], this.designerUrl = s[12], this.license = s[13], this.licenseUrl = s[14], this.preferredFamily = s[15], this.preferredSubfamily = s[17], this.compatibleFull = s[18], this.sampleText = s[19];
	}, t;
}();
var Ae = function() {
	function t() {
		return t.__super__.constructor.apply(this, arguments);
	}
	return ge(t, he), t.prototype.tag = "maxp", t.prototype.parse = function(t) {
		return t.pos = this.offset, this.version = t.readInt(), this.numGlyphs = t.readUInt16(), this.maxPoints = t.readUInt16(), this.maxContours = t.readUInt16(), this.maxCompositePoints = t.readUInt16(), this.maxComponentContours = t.readUInt16(), this.maxZones = t.readUInt16(), this.maxTwilightPoints = t.readUInt16(), this.maxStorage = t.readUInt16(), this.maxFunctionDefs = t.readUInt16(), this.maxInstructionDefs = t.readUInt16(), this.maxStackElements = t.readUInt16(), this.maxSizeOfInstructions = t.readUInt16(), this.maxComponentElements = t.readUInt16(), this.maxComponentDepth = t.readUInt16();
	}, t;
}();
var Se = function() {
	function t() {
		return t.__super__.constructor.apply(this, arguments);
	}
	return ge(t, he), t.prototype.tag = "hmtx", t.prototype.parse = function(t) {
		var e, r, n, i, a, o, s;
		for (t.pos = this.offset, this.metrics = [], e = 0, o = this.file.hhea.numberOfMetrics; 0 <= o ? e < o : e > o; e = 0 <= o ? ++e : --e) this.metrics.push({
			advance: t.readUInt16(),
			lsb: t.readInt16()
		});
		for (n = this.file.maxp.numGlyphs - this.file.hhea.numberOfMetrics, this.leftSideBearings = function() {
			var r, i;
			for (i = [], e = r = 0; 0 <= n ? r < n : r > n; e = 0 <= n ? ++r : --r) i.push(t.readInt16());
			return i;
		}(), this.widths = function() {
			var t, e, r, n;
			for (n = [], t = 0, e = (r = this.metrics).length; t < e; t++) i = r[t], n.push(i.advance);
			return n;
		}.call(this), r = this.widths[this.widths.length - 1], s = [], e = a = 0; 0 <= n ? a < n : a > n; e = 0 <= n ? ++a : --a) s.push(this.widths.push(r));
		return s;
	}, t.prototype.forGlyph = function(t) {
		return t in this.metrics ? this.metrics[t] : {
			advance: this.metrics[this.metrics.length - 1].advance,
			lsb: this.leftSideBearings[t - this.metrics.length]
		};
	}, t;
}();
var _e = [].slice;
var Pe = function() {
	function t() {
		return t.__super__.constructor.apply(this, arguments);
	}
	return ge(t, he), t.prototype.tag = "glyf", t.prototype.parse = function() {
		return this.cache = {};
	}, t.prototype.glyphFor = function(t) {
		var e, r, n, i, a, o, s, u, c, l;
		return t in this.cache ? this.cache[t] : (i = this.file.loca, e = this.file.contents, r = i.indexOf(t), 0 === (n = i.lengthOf(t)) ? this.cache[t] = null : (e.pos = this.offset + r, a = (o = new fe(e.read(n))).readShort(), u = o.readShort(), l = o.readShort(), s = o.readShort(), c = o.readShort(), this.cache[t] = -1 === a ? new Fe(o, u, l, s, c) : new ke(o, a, u, l, s, c), this.cache[t]));
	}, t.prototype.encode = function(t, e, r) {
		var n, i, a, o, s;
		for (a = [], i = [], o = 0, s = e.length; o < s; o++) n = t[e[o]], i.push(a.length), n && (a = a.concat(n.encode(r)));
		return i.push(a.length), {
			table: a,
			offsets: i
		};
	}, t;
}();
var ke = function() {
	function t(t, e, r, n, i, a) {
		this.raw = t, this.numberOfContours = e, this.xMin = r, this.yMin = n, this.xMax = i, this.yMax = a, this.compound = !1;
	}
	return t.prototype.encode = function() {
		return this.raw.data;
	}, t;
}();
var Fe = function() {
	function t(t, e, r, n, i) {
		var a, o;
		for (this.raw = t, this.xMin = e, this.yMin = r, this.xMax = n, this.yMax = i, this.compound = !0, this.glyphIDs = [], this.glyphOffsets = [], a = this.raw; o = a.readShort(), this.glyphOffsets.push(a.pos), this.glyphIDs.push(a.readUInt16()), 32 & o;) a.pos += 1 & o ? 4 : 2, 128 & o ? a.pos += 8 : 64 & o ? a.pos += 4 : 8 & o && (a.pos += 2);
	}
	return t.prototype.encode = function() {
		var t, e, r;
		for (e = new fe(_e.call(this.raw.data)), t = 0, r = this.glyphIDs.length; t < r; ++t) e.pos = this.glyphOffsets[t];
		return e.data;
	}, t;
}();
var Ie = function() {
	function t() {
		return t.__super__.constructor.apply(this, arguments);
	}
	return ge(t, he), t.prototype.tag = "loca", t.prototype.parse = function(t) {
		var e, r;
		return t.pos = this.offset, e = this.file.head.indexToLocFormat, this.offsets = 0 === e ? function() {
			var e, n;
			for (n = [], r = 0, e = this.length; r < e; r += 2) n.push(2 * t.readUInt16());
			return n;
		}.call(this) : function() {
			var e, n;
			for (n = [], r = 0, e = this.length; r < e; r += 4) n.push(t.readUInt32());
			return n;
		}.call(this);
	}, t.prototype.indexOf = function(t) {
		return this.offsets[t];
	}, t.prototype.lengthOf = function(t) {
		return this.offsets[t + 1] - this.offsets[t];
	}, t.prototype.encode = function(t, e) {
		for (var r = new Uint32Array(this.offsets.length), n = 0, i = 0, a = 0; a < r.length; ++a) if (r[a] = n, i < e.length && e[i] == a) {
			++i, r[a] = n;
			var o = this.offsets[a], s = this.offsets[a + 1] - o;
			s > 0 && (n += s);
		}
		for (var u = new Array(4 * r.length), c = 0; c < r.length; ++c) u[4 * c + 3] = 255 & r[c], u[4 * c + 2] = (65280 & r[c]) >> 8, u[4 * c + 1] = (16711680 & r[c]) >> 16, u[4 * c] = (4278190080 & r[c]) >> 24;
		return u;
	}, t;
}();
var Ce = function() {
	function t(t) {
		this.font = t, this.subset = {}, this.unicodes = {}, this.next = 33;
	}
	return t.prototype.generateCmap = function() {
		var t, e, r, n, i;
		for (e in n = this.font.cmap.tables[0].codeMap, t = {}, i = this.subset) r = i[e], t[e] = n[r];
		return t;
	}, t.prototype.glyphsFor = function(t) {
		var e, r, n, i, a, o, s;
		for (n = {}, a = 0, o = t.length; a < o; a++) n[i = t[a]] = this.font.glyf.glyphFor(i);
		for (i in e = [], n) null != (r = n[i]) && r.compound && e.push.apply(e, r.glyphIDs);
		if (e.length > 0) for (i in s = this.glyphsFor(e)) r = s[i], n[i] = r;
		return n;
	}, t.prototype.encode = function(t, e) {
		var r, n, i, a, o, s, u, c, l, h, f, d, p, g, m;
		for (n in r = be.encode(this.generateCmap(), "unicode"), a = this.glyphsFor(t), f = { 0: 0 }, m = r.charMap) f[(s = m[n]).old] = s.new;
		for (d in h = r.maxGlyphID, a) d in f || (f[d] = h++);
		return c = function(t) {
			var e, r;
			for (e in r = {}, t) r[t[e]] = e;
			return r;
		}(f), l = Object.keys(c).sort(function(t, e) {
			return t - e;
		}), p = function() {
			var t, e, r;
			for (r = [], t = 0, e = l.length; t < e; t++) o = l[t], r.push(c[o]);
			return r;
		}(), i = this.font.glyf.encode(a, p, f), u = this.font.loca.encode(i.offsets, p), g = {
			cmap: this.font.cmap.raw(),
			glyf: i.table,
			loca: u,
			hmtx: this.font.hmtx.raw(),
			hhea: this.font.hhea.raw(),
			maxp: this.font.maxp.raw(),
			post: this.font.post.raw(),
			name: this.font.name.raw(),
			head: this.font.head.encode(e)
		}, this.font.os2.exists && (g["OS/2"] = this.font.os2.raw()), this.font.directory.encode(g);
	}, t;
}();
E.API.PDFObject = function() {
	var t;
	function e() {}
	return t = function(t, e) {
		return (Array(e + 1).join("0") + t).slice(-e);
	}, e.convert = function(r) {
		var n, i, a, o;
		if (Array.isArray(r)) return "[" + function() {
			var t, i, a;
			for (a = [], t = 0, i = r.length; t < i; t++) n = r[t], a.push(e.convert(n));
			return a;
		}().join(" ") + "]";
		if ("string" == typeof r) return "/" + r;
		if (null != r ? r.isString : void 0) return "(" + r + ")";
		if (r instanceof Date) return "(D:" + t(r.getUTCFullYear(), 4) + t(r.getUTCMonth(), 2) + t(r.getUTCDate(), 2) + t(r.getUTCHours(), 2) + t(r.getUTCMinutes(), 2) + t(r.getUTCSeconds(), 2) + "Z)";
		if ("[object Object]" === {}.toString.call(r)) {
			for (i in a = ["<<"], r) o = r[i], a.push("/" + i + " " + e.convert(o));
			return a.push(">>"), a.join("\n");
		}
		return "" + r;
	}, e;
}();
//#endregion
//#region src/export/pdf-generator.ts
async function generatePDF(imageBlob, pageSize = "a4", watermarkUrl) {
	const dataUrl = await blobToDataUrl(imageBlob);
	let imgWidth = 0;
	let imgHeight = 0;
	if (typeof createImageBitmap === "function") {
		const bitmap = await createImageBitmap(imageBlob);
		imgWidth = bitmap.width;
		imgHeight = bitmap.height;
		if (typeof bitmap.close === "function") bitmap.close();
	} else if (typeof Image !== "undefined") {
		const img = new Image();
		img.src = dataUrl;
		await new Promise((resolve, reject) => {
			img.onload = () => resolve();
			img.onerror = () => reject(/* @__PURE__ */ new Error("Failed to load image for PDF"));
		});
		imgWidth = img.width;
		imgHeight = img.height;
	}
	if (imgWidth === 0 || imgHeight === 0) throw new Error("Invalid image dimensions for PDF generation");
	const PAGE_SIZES = {
		a4: {
			width: 595.28,
			height: 841.89
		},
		letter: {
			width: 612,
			height: 792
		}
	};
	const selectedSize = PAGE_SIZES[pageSize] || PAGE_SIZES.a4;
	const isLandscape = imgWidth > imgHeight && imgHeight <= selectedSize.width;
	const pageW = isLandscape ? selectedSize.height : selectedSize.width;
	const pageH = isLandscape ? selectedSize.width : selectedSize.height;
	const scale = pageW / imgWidth;
	const scaledTotalH = imgHeight * scale;
	const totalPages = Math.max(1, Math.ceil(scaledTotalH / pageH));
	const pdf = new E({
		unit: "pt",
		format: [pageW, pageH],
		orientation: isLandscape ? "landscape" : "portrait"
	});
	for (let i = 0; i < totalPages; i++) {
		if (i > 0) pdf.addPage([pageW, pageH], isLandscape ? "landscape" : "portrait");
		pdf.addImage(dataUrl, "PNG", 0, -(i * pageH), pageW, scaledTotalH, void 0, "FAST");
		if (watermarkUrl) {
			pdf.setFontSize(8);
			pdf.setTextColor(150, 150, 150);
			pdf.text(watermarkUrl, 14, pageH - 10);
			if (totalPages > 1) pdf.text(`Page ${i + 1} of ${totalPages}`, pageW - 75, pageH - 10);
		}
	}
	return pdf.output("blob");
}
function blobToDataUrl(blob) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(reader.result);
		reader.onerror = reject;
		reader.readAsDataURL(blob);
	});
}
//#endregion
//#region src/utils/rate-nudge.ts
var RATE_URL = "https://chromewebstore.google.com/detail/gofully/akfbmhmdlbmljklgajkgoekobofhhofc";
var STATE_KEY = "gf_rate";
var PENDING_KEY = "gf_rate_pending";
var DEFAULT_STATE = {
	count: 0,
	status: "none",
	dismissCount: 0,
	lastShownAt: 0
};
async function getState() {
	const stored = await chrome.storage.local.get(STATE_KEY);
	return {
		...DEFAULT_STATE,
		...stored[STATE_KEY]
	};
}
async function setState(state) {
	await chrome.storage.local.set({ [STATE_KEY]: state });
}
/**
* Called once per completed capture, from the background service worker —
* the single point every capture mode (full-page, visible, selected,
* scrolling-area, scrollable-element, keyboard shortcuts) already funnels
* through. Decides whether the rating nudge is due, and if so leaves a
* one-shot flag for whichever UI surface renders first (result bar or the
* editor) to claim.
*/
async function recordCaptureCompleted() {
	try {
		const state = await getState();
		if (state.status !== "none") return;
		state.count += 1;
		const dueForFirst = state.count === 3;
		const dueForRepeat = state.count > 3 && state.count - state.lastShownAt >= 15;
		if (dueForFirst || dueForRepeat) {
			state.lastShownAt = state.count;
			await chrome.storage.local.set({ [PENDING_KEY]: true });
		}
		await setState(state);
	} catch {}
}
/**
* Claims the pending nudge flag, if any. Read-then-clear, so at most one UI
* surface renders the nudge for a given eligible capture — whichever calls
* this first (in practice, almost always the result bar, since it appears
* immediately after every capture).
*/
async function claimPendingRateNudge() {
	try {
		if (!(await chrome.storage.local.get(PENDING_KEY))[PENDING_KEY]) return false;
		await chrome.storage.local.remove(PENDING_KEY);
		return true;
	} catch {
		return false;
	}
}
/** User clicked "Yes, rate it" (or the persistent header button). */
async function markRatedYes() {
	try {
		const state = await getState();
		state.status = "rated";
		await setState(state);
	} catch {}
	try {
		window.open(RATE_URL, "_blank");
	} catch {}
}
/** User dismissed the nudge card ("Not now" or its close button). */
async function markDismissed() {
	try {
		const state = await getState();
		state.dismissCount += 1;
		if (state.dismissCount >= 2) state.status = "dismissed";
		await setState(state);
	} catch {}
}
//#endregion
export { generatePDF as a, recordCaptureCompleted as i, markDismissed as n, __vitePreload as o, markRatedYes as r, _typeof as s, claimPendingRateNudge as t };
