import { t as DEFAULT_SETTINGS } from "./types-By7y4T4D.js";
//#region src/utils/theme.ts
async function resolveTheme() {
	try {
		const theme = (await chrome.storage.sync.get("settings")).settings?.theme ?? DEFAULT_SETTINGS.theme;
		if (theme === "dark") return "dark";
		if (theme === "light") return "light";
		return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
	} catch {
		return "light";
	}
}
async function applyTheme() {
	document.documentElement.dataset.theme = await resolveTheme();
}
function watchTheme() {
	chrome.storage.onChanged.addListener((changes, area) => {
		if (area === "sync" && changes.settings) applyTheme();
	});
	window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => applyTheme());
}
//#endregion
export { watchTheme as n, applyTheme as t };
