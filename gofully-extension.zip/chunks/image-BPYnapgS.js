//#region src/utils/image.ts
function dataUrlToBlob(dataUrl) {
	const [header, base64] = dataUrl.split(",");
	const mime = header.match(/:(.*?);/)?.[1] || "image/png";
	const binary = atob(base64);
	const bytes = new Uint8Array(binary.length);
	for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
	return new Blob([bytes], { type: mime });
}
async function loadImage(src) {
	if (src.startsWith("data:")) {
		const blob = await (await fetch(src)).blob();
		return createImageBitmap(blob);
	}
	const blob = await (await fetch(src)).blob();
	return createImageBitmap(blob);
}
function canvasToBlob(canvas, type = "image/png", quality = 1) {
	if (canvas instanceof OffscreenCanvas) return canvas.convertToBlob({
		type,
		quality
	});
	return new Promise((resolve, reject) => {
		canvas.toBlob((blob) => blob ? resolve(blob) : reject(/* @__PURE__ */ new Error("toBlob failed")), type, quality);
	});
}
function generateFilename(domain, ext) {
	const ts = (/* @__PURE__ */ new Date()).toISOString().replace(/[-:T]/g, "").slice(0, 14);
	return `gofully-${domain.replace(/[^a-zA-Z0-9.-]/g, "_").slice(0, 50)}-${ts}.${ext}`;
}
var MAX_CANVAS_DIM = 16384;
var MAX_CANVAS_AREA = 268435456;
function computeTiles(totalWidth, totalHeight) {
	const cols = Math.ceil(totalWidth / MAX_CANVAS_DIM);
	const rows = Math.ceil(totalHeight / MAX_CANVAS_DIM);
	const tiles = [];
	for (let row = 0; row < rows; row++) for (let col = 0; col < cols; col++) {
		const x = col * MAX_CANVAS_DIM;
		const y = row * MAX_CANVAS_DIM;
		const w = Math.min(MAX_CANVAS_DIM, totalWidth - x);
		const h = Math.min(MAX_CANVAS_DIM, totalHeight - y);
		if (w > 0 && h > 0) tiles.push({
			x,
			y,
			width: w,
			height: h
		});
	}
	return tiles;
}
function needsTiling(width, height) {
	return width > MAX_CANVAS_DIM || height > MAX_CANVAS_DIM || width * height > MAX_CANVAS_AREA;
}
//#endregion
export { loadImage as a, generateFilename as i, computeTiles as n, needsTiling as o, dataUrlToBlob as r, canvasToBlob as t };
