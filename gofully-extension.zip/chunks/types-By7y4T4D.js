//#region src/types.ts
var DEFAULT_SETTINGS = {
	defaultAction: "result-bar",
	pngSaveAs: false,
	pdfPageSize: "a4",
	pdfWatermark: false,
	captureDelay: 150,
	scrollPadding: 0,
	lazyLoadWait: 2e3,
	captureSound: true,
	captureCountdown: 0,
	skipStickyHeaders: true,
	defaultExportFormat: "png",
	jpgQuality: .92,
	editorShortcuts: {},
	captureStamp: false,
	theme: "system",
	ocrLanguage: "eng",
	language: "system"
};
//#endregion
export { DEFAULT_SETTINGS as t };
