//#region src/utils/url-validator.ts
/**
* Validates whether a URL can be captured by GoFully.
* Used centrally across popup, background service-worker, and interactive modes.
*/
function isSupportedCapturePage(url) {
	if (!url || typeof url !== "string" || url.trim() === "") return {
		supported: false,
		type: "unknown",
		title: "This page can't be captured",
		message: "Chrome doesn't allow GoFully to capture this page."
	};
	const cleanUrl = url.trim().toLowerCase();
	if (cleanUrl.startsWith("https://chromewebstore.google.com") || cleanUrl.startsWith("https://chrome.google.com/webstore") || cleanUrl.startsWith("http://chromewebstore.google.com") || cleanUrl.startsWith("http://chrome.google.com/webstore")) return {
		supported: false,
		type: "web_store",
		title: "Capture isn't available here",
		message: "GoFully doesn't capture Chrome Web Store pages."
	};
	if (cleanUrl.startsWith("devtools://")) return {
		supported: false,
		type: "devtools",
		title: "Capture isn't available here",
		message: "GoFully can't capture Chrome Developer Tools."
	};
	if (cleanUrl.startsWith("chrome://") || cleanUrl.startsWith("edge://") || cleanUrl.startsWith("brave://") || cleanUrl.startsWith("opera://") || cleanUrl.startsWith("about:") || cleanUrl.startsWith("chrome-search://")) return {
		supported: false,
		type: "browser_internal",
		title: "Capture isn't available here",
		message: "GoFully can't capture browser-internal pages."
	};
	if (cleanUrl.startsWith("chrome-extension://") || cleanUrl.startsWith("moz-extension://")) return {
		supported: false,
		type: "extension_page",
		title: "Capture isn't available here",
		message: "GoFully can't capture extension pages."
	};
	if (cleanUrl.startsWith("view-source:")) return {
		supported: false,
		type: "view_source",
		title: "Capture isn't available here",
		message: "GoFully can't capture source-code view pages."
	};
	if (cleanUrl.startsWith("http://") || cleanUrl.startsWith("https://") || cleanUrl.startsWith("file://")) return {
		supported: true,
		type: "supported"
	};
	return {
		supported: false,
		type: "restricted",
		title: "This page can't be captured",
		message: "Chrome doesn't allow GoFully to capture this page."
	};
}
//#endregion
export { isSupportedCapturePage as t };
