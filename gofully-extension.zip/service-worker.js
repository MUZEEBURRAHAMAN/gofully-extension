import { a as loadImage, r as dataUrlToBlob, t as canvasToBlob } from "./chunks/image-BPYnapgS.js";
import { t as generatePDF } from "./chunks/pdf-generator-Dg4k4FqC.js";
import { t as isSupportedCapturePage } from "./chunks/url-validator-CInVwRGC.js";
//#region src/utils/permissions.ts
async function getCaptureMethod(pageHeight) {
	if (pageHeight > 16384) return "scroll-stitch";
	return "cdp";
}
//#endregion
//#region src/background/cdp-capture.ts
async function captureWithCDP(tabId, dimensions) {
	const debuggee = { tabId };
	await chrome.debugger.attach(debuggee, "1.3");
	try {
		const layoutMetrics = await chrome.debugger.sendCommand(debuggee, "Page.getLayoutMetrics", {});
		const contentWidth = layoutMetrics.cssContentSize?.width || layoutMetrics.contentSize?.width || dimensions.scrollWidth;
		const contentHeight = layoutMetrics.cssContentSize?.height || layoutMetrics.contentSize?.height || dimensions.scrollHeight;
		const captureScale = Math.max(2, dimensions.devicePixelRatio);
		await chrome.debugger.sendCommand(debuggee, "Emulation.setDeviceMetricsOverride", {
			width: Math.ceil(contentWidth),
			height: Math.ceil(contentHeight),
			deviceScaleFactor: captureScale,
			mobile: false
		});
		const result = await chrome.debugger.sendCommand(debuggee, "Page.captureScreenshot", {
			format: "png",
			captureBeyondViewport: true,
			clip: {
				x: 0,
				y: 0,
				width: contentWidth,
				height: contentHeight,
				scale: captureScale
			}
		});
		await chrome.debugger.sendCommand(debuggee, "Emulation.clearDeviceMetricsOverride", {});
		const dataUrl = `data:image/png;base64,${result.data}`;
		const blob = dataUrlToBlob(dataUrl);
		const tab = await chrome.tabs.get(tabId);
		return {
			blob,
			width: Math.ceil(contentWidth * captureScale),
			height: Math.ceil(contentHeight * captureScale),
			mode: "full-page",
			method: "cdp",
			timestamp: Date.now(),
			url: tab.url || "",
			title: tab.title || ""
		};
	} finally {
		try {
			await chrome.debugger.detach(debuggee);
		} catch {}
	}
}
//#endregion
//#region src/utils/dpr-handler.ts
function detectDPRFromCapture(capturedWidth, cssWidth) {
	if (cssWidth === 0) return 1;
	return capturedWidth / cssWidth;
}
//#endregion
//#region src/background/stitch-capture.ts
var CAPTURE_DELAY = 800;
async function captureWithScrollStitch(tabId, dimensions, onProgress) {
	const { scrollWidth, scrollHeight, viewportWidth, viewportHeight } = dimensions;
	await chrome.tabs.sendMessage(tabId, { type: "HIDE_STICKY" }).catch(() => {});
	await chrome.tabs.sendMessage(tabId, {
		type: "PRE_SCROLL_LAZY",
		payload: { maxWait: 2e3 }
	}).catch(() => {});
	const frames = [];
	const yStep = viewportHeight;
	const totalSteps = Math.ceil(scrollHeight / yStep);
	let dpr = dimensions.devicePixelRatio;
	for (let step = 0; step < totalSteps; step++) {
		const scrollY = Math.min(step * yStep, scrollHeight - viewportHeight);
		await chrome.scripting.executeScript({
			target: { tabId },
			func: (x, y) => window.scrollTo(x, y),
			args: [0, scrollY]
		});
		await sleep$2(CAPTURE_DELAY);
		const dataUrl = await captureWithRetry$1();
		if (step === 0) dpr = detectDPRFromCapture((await loadImage(dataUrl)).width, viewportWidth);
		frames.push({
			dataUrl,
			x: 0,
			y: scrollY,
			width: viewportWidth,
			height: viewportHeight,
			scrollX: 0,
			scrollY
		});
		onProgress?.({
			current: step + 1,
			total: totalSteps,
			phase: "capturing"
		});
	}
	await chrome.tabs.sendMessage(tabId, { type: "RESTORE_STICKY" }).catch(() => {});
	await chrome.scripting.executeScript({
		target: { tabId },
		func: () => window.scrollTo(0, 0),
		args: []
	});
	onProgress?.({
		current: 0,
		total: 0,
		phase: "stitching"
	});
	const blob = await stitchFrames(frames, scrollWidth, scrollHeight, dpr, viewportHeight);
	const tab = await chrome.tabs.get(tabId);
	return {
		blob,
		width: Math.round(scrollWidth * dpr),
		height: Math.round(scrollHeight * dpr),
		mode: "full-page",
		method: "scroll-stitch",
		timestamp: Date.now(),
		url: tab.url || "",
		title: tab.title || ""
	};
}
async function stitchFrames(frames, totalWidth, totalHeight, dpr, viewportHeight) {
	const canvasWidth = Math.round(totalWidth * dpr);
	const canvasHeight = Math.round(totalHeight * dpr);
	const canvas = new OffscreenCanvas(canvasWidth, canvasHeight);
	const ctx = canvas.getContext("2d");
	for (let fi = 0; fi < frames.length; fi++) {
		const frame = frames[fi];
		const img = await loadImage(frame.dataUrl);
		const dstX = 0;
		const dstY = Math.round(frame.scrollY * dpr);
		const dstW = Math.min(img.width, canvasWidth);
		const maxDstH = canvasHeight - dstY;
		if (maxDstH <= 0) continue;
		if (img.height <= maxDstH) ctx.drawImage(img, 0, 0, img.width, img.height, dstX, dstY, dstW, img.height);
		else {
			const srcY = img.height - maxDstH;
			ctx.drawImage(img, 0, srcY, img.width, maxDstH, dstX, dstY, dstW, maxDstH);
		}
	}
	return canvasToBlob(canvas);
}
async function captureWithRetry$1(maxRetries = 3) {
	for (let i = 0; i < maxRetries; i++) try {
		return await chrome.tabs.captureVisibleTab({ format: "png" });
	} catch (e) {
		if (e?.message?.includes("MAX_CAPTURE") && i < maxRetries - 1) {
			await sleep$2(1e3);
			continue;
		}
		throw e;
	}
	return await chrome.tabs.captureVisibleTab({ format: "png" });
}
function sleep$2(ms) {
	return new Promise((r) => setTimeout(r, ms));
}
//#endregion
//#region src/background/capture-engine.ts
async function captureFullPage(tabId, onProgress) {
	const dimensions = await getPageDimensions(tabId);
	if (await getCaptureMethod(dimensions.scrollHeight) === "cdp") try {
		return await captureWithCDP(tabId, dimensions);
	} catch (e) {
		console.warn("CDP capture failed, falling back to scroll-stitch:", e);
		return captureWithScrollStitch(tabId, dimensions, onProgress);
	}
	return captureWithScrollStitch(tabId, dimensions, onProgress);
}
async function captureVisibleArea(tabId) {
	const dataUrl = await chrome.tabs.captureVisibleTab({ format: "png" });
	const blob = dataUrlToBlob(dataUrl);
	const img = await loadImage(dataUrl);
	const tab = await chrome.tabs.get(tabId);
	return {
		blob,
		width: img.width,
		height: img.height,
		mode: "visible-area",
		method: "cdp",
		timestamp: Date.now(),
		url: tab.url || "",
		title: tab.title || ""
	};
}
async function captureSelectedArea(tabId, region) {
	const dataUrl = await chrome.tabs.captureVisibleTab({ format: "png" });
	const img = await loadImage(dataUrl);
	const [{ result: vpWidth }] = await chrome.scripting.executeScript({
		target: { tabId },
		func: () => window.innerWidth
	});
	const dpr = detectDPRFromCapture(img.width, vpWidth || img.width);
	const sx = Math.round(region.x * dpr);
	const sy = Math.round(region.y * dpr);
	const sw = Math.round(region.width * dpr);
	const sh = Math.round(region.height * dpr);
	const canvas = new OffscreenCanvas(sw, sh);
	canvas.getContext("2d").drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
	const blob = await canvas.convertToBlob({ type: "image/png" });
	const tab = await chrome.tabs.get(tabId);
	return {
		blob,
		width: sw,
		height: sh,
		mode: "selected-area",
		method: "cdp",
		timestamp: Date.now(),
		url: tab.url || "",
		title: tab.title || ""
	};
}
async function getPageDimensions(tabId) {
	const [{ result }] = await chrome.scripting.executeScript({
		target: { tabId },
		func: () => {
			const body = document.body;
			const html = document.documentElement;
			return {
				scrollWidth: Math.max(body.scrollWidth, body.offsetWidth, html.clientWidth, html.scrollWidth, html.offsetWidth),
				scrollHeight: Math.max(body.scrollHeight, body.offsetHeight, html.clientHeight, html.scrollHeight, html.offsetHeight),
				viewportWidth: window.innerWidth,
				viewportHeight: window.innerHeight,
				devicePixelRatio: window.devicePixelRatio || 1
			};
		}
	});
	return result;
}
//#endregion
//#region src/capture-modes/scrolling-area.ts
var SPEED_MAP = {
	slow: 800,
	medium: 600,
	fast: 500
};
async function captureScrollingArea(tabId, region, speed, onProgress) {
	const frames = [];
	const delay = SPEED_MAP[speed];
	const [{ result: pageInfo }] = await chrome.scripting.executeScript({
		target: { tabId },
		func: () => ({
			scrollHeight: Math.max(document.body.scrollHeight, document.documentElement.scrollHeight),
			scrollY: window.scrollY,
			viewportHeight: window.innerHeight
		})
	});
	const pi = pageInfo;
	const scrollStep = region.height;
	const estimatedSteps = Math.ceil((pi.scrollHeight - pi.scrollY) / scrollStep);
	let dpr = 1;
	let lastFrameHash = "";
	let step = 0;
	const firstFrame = await captureAndCropFrame(tabId, region);
	if (firstFrame) {
		dpr = detectDPRFromCapture((await loadImage(firstFrame.dataUrl)).width, region.width);
		if (dpr === 0) dpr = 1;
		frames.push(firstFrame);
		lastFrameHash = await hashFrame(firstFrame.dataUrl);
		step++;
		onProgress?.({
			current: step,
			total: estimatedSteps,
			phase: "capturing"
		});
	}
	let reachedEnd = false;
	let lastScrollY = pi.scrollY;
	while (!reachedEnd) {
		const [{ result: currentPos }] = await chrome.scripting.executeScript({
			target: { tabId },
			func: (dy) => {
				const prev = window.scrollY;
				window.scrollBy({
					top: dy,
					behavior: "instant"
				});
				return {
					prev,
					current: window.scrollY,
					maxScroll: Math.max(document.body.scrollHeight, document.documentElement.scrollHeight) - window.innerHeight
				};
			},
			args: [scrollStep]
		});
		await sleep$1(delay);
		const pos = currentPos;
		if (Math.abs(pos.current - lastScrollY) < 2 || pos.current >= pos.maxScroll) {
			const finalFrame = await captureAndCropFrame(tabId, region);
			if (finalFrame) {
				if (await hashFrame(finalFrame.dataUrl) !== lastFrameHash) frames.push(finalFrame);
			}
			reachedEnd = true;
			break;
		}
		lastScrollY = pos.current;
		const frame = await captureAndCropFrame(tabId, region);
		if (!frame) break;
		const hash = await hashFrame(frame.dataUrl);
		if (hash === lastFrameHash) {
			reachedEnd = true;
			break;
		}
		frames.push(frame);
		lastFrameHash = hash;
		step++;
		onProgress?.({
			current: step,
			total: estimatedSteps,
			phase: "capturing"
		});
		if (frames.length >= 100) break;
	}
	onProgress?.({
		current: 0,
		total: 0,
		phase: "stitching"
	});
	const blob = await stitchScrollingFrames(frames, region, dpr);
	const tab = await chrome.tabs.get(tabId);
	return {
		blob,
		width: Math.round(region.width * dpr),
		height: Math.round(region.height * frames.length * dpr),
		mode: "scrolling-area",
		method: "scroll-stitch",
		timestamp: Date.now(),
		url: tab.url || "",
		title: tab.title || ""
	};
}
async function captureManualFrame(tabId, region) {
	return captureAndCropFrame(tabId, region);
}
async function stitchManualFrames(frames, region, tabId) {
	const firstImg = frames.length > 0 ? await loadImage(frames[0].dataUrl) : null;
	const dpr = firstImg ? firstImg.width / region.width : 1;
	const blob = await stitchScrollingFrames(frames, region, dpr);
	const tab = await chrome.tabs.get(tabId);
	return {
		blob,
		width: Math.round(region.width * dpr),
		height: Math.round(region.height * frames.length * dpr),
		mode: "scrolling-area",
		method: "scroll-stitch",
		timestamp: Date.now(),
		url: tab.url || "",
		title: tab.title || ""
	};
}
async function captureAndCropFrame(tabId, region) {
	try {
		const dataUrl = await captureWithRetry();
		const img = await loadImage(dataUrl);
		const [{ result: vpWidth }] = await chrome.scripting.executeScript({
			target: { tabId },
			func: () => window.innerWidth
		});
		const dpr = img.width / (vpWidth || img.width);
		const sx = Math.round(region.x * dpr);
		const sy = Math.round(region.y * dpr);
		const sw = Math.round(region.width * dpr);
		const sh = Math.round(region.height * dpr);
		const canvas = new OffscreenCanvas(sw, sh);
		canvas.getContext("2d").drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
		return {
			dataUrl: await blobToDataUrl$1(await canvas.convertToBlob({ type: "image/png" })),
			x: region.x,
			y: region.y,
			width: region.width,
			height: region.height,
			scrollX: 0,
			scrollY: 0
		};
	} catch {
		return null;
	}
}
async function stitchScrollingFrames(frames, region, dpr) {
	if (frames.length === 0) throw new Error("No frames to stitch");
	const firstImg = await loadImage(frames[0].dataUrl);
	const frameWidth = firstImg.width;
	const frameHeight = firstImg.height;
	const totalHeight = frameHeight * frames.length;
	const canvas = new OffscreenCanvas(frameWidth, totalHeight);
	const ctx = canvas.getContext("2d");
	for (let i = 0; i < frames.length; i++) {
		const img = await loadImage(frames[i].dataUrl);
		ctx.drawImage(img, 0, i * frameHeight);
	}
	return canvasToBlob(canvas);
}
async function hashFrame(dataUrl) {
	const img = await loadImage(dataUrl);
	const ctx = new OffscreenCanvas(16, 16).getContext("2d");
	ctx.drawImage(img, 0, 0, 16, 16);
	const data = ctx.getImageData(0, 0, 16, 16).data;
	let hash = 0;
	for (let i = 0; i < data.length; i += 4) {
		hash = (hash << 5) - hash + data[i] | 0;
		hash = (hash << 5) - hash + data[i + 1] | 0;
		hash = (hash << 5) - hash + data[i + 2] | 0;
	}
	return hash.toString(36);
}
async function captureWithRetry(maxRetries = 3) {
	for (let i = 0; i < maxRetries; i++) try {
		return await chrome.tabs.captureVisibleTab({ format: "png" });
	} catch (e) {
		if (e?.message?.includes("MAX_CAPTURE") && i < maxRetries - 1) {
			await sleep$1(1e3);
			continue;
		}
		throw e;
	}
	return await chrome.tabs.captureVisibleTab({ format: "png" });
}
function sleep$1(ms) {
	return new Promise((r) => setTimeout(r, ms));
}
async function blobToDataUrl$1(blob) {
	const buffer = await blob.arrayBuffer();
	const bytes = new Uint8Array(buffer);
	let binary = "";
	for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
	return `data:${blob.type};base64,${btoa(binary)}`;
}
//#endregion
//#region src/background/service-worker.ts
chrome.runtime.onInstalled.addListener(() => {
	if (chrome.runtime.setUninstallURL) chrome.runtime.setUninstallURL("https://gofully-extension.vercel.app/uninstall-feedback.html");
});
var lastCaptureResult = null;
var lastCaptureBlob = null;
var lastCaptureDataUrl = null;
var manualFrames = [];
async function ensureOffscreenDocument() {
	if ((await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] })).length > 0) return;
	await chrome.offscreen.createDocument({
		url: "offscreen.html",
		reasons: [chrome.offscreen.Reason.BLOBS, chrome.offscreen.Reason.DOM_SCRAPING],
		justification: "Process offscreen canvas and OCR operations"
	});
}
async function blobToDataUrl(blob) {
	const buffer = await blob.arrayBuffer();
	const bytes = new Uint8Array(buffer);
	let binary = "";
	for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
	return `data:${blob.type};base64,${btoa(binary)}`;
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	if (message.type === "START_CAPTURE") {
		const { mode, region, speed, tabId } = message.payload;
		const senderTabId = sender.tab?.id || tabId;
		handleCapture(mode, region, speed, senderTabId).then(async (result) => {
			lastCaptureBlob = result.blob;
			lastCaptureDataUrl = await blobToDataUrl(result.blob);
			lastCaptureResult = {
				...result,
				blob: null
			};
			const payload = {
				width: result.width,
				height: result.height,
				mode: result.mode,
				method: result.method,
				url: result.url,
				title: result.title,
				timestamp: result.timestamp,
				dataUrl: lastCaptureDataUrl
			};
			sendResponse({
				type: "CAPTURE_COMPLETE",
				payload
			});
			let targetTab = senderTabId;
			if (!targetTab) {
				const [activeTab] = await chrome.tabs.query({
					active: true,
					currentWindow: true
				});
				targetTab = activeTab?.id;
			}
			if (targetTab && (mode === "selected-area" || mode === "scrolling-area" || mode === "full-page" || mode === "visible-area")) await showResultBarOnTab(targetTab, payload);
			chrome.runtime.sendMessage({
				type: "CAPTURE_COMPLETE",
				payload
			}).catch(() => {});
		}).catch((error) => {
			sendResponse({
				type: "CAPTURE_ERROR",
				payload: { message: error.message }
			});
		});
		return true;
	}
	if (message.type === "GET_LAST_CAPTURE") {
		sendResponse({
			result: lastCaptureResult,
			hasBlob: !!lastCaptureBlob
		});
		return true;
	}
	if (message.type === "EXPORT_CAPTURE") {
		const { format } = message.payload;
		if (lastCaptureBlob) handleExport(lastCaptureBlob, lastCaptureResult, format).then((result) => sendResponse(result));
		else sendResponse({ error: "No capture available" });
		return true;
	}
	if (message.type === "GET_CAPTURE_BLOB_URL") {
		if (lastCaptureDataUrl) sendResponse({ url: lastCaptureDataUrl });
		else sendResponse({ url: null });
		return true;
	}
	if (message.type === "OPEN_EDITOR") {
		const editorUrl = chrome.runtime.getURL("editor.html");
		chrome.tabs.create({ url: editorUrl });
		sendResponse({ opened: true });
		return true;
	}
	if (message.type === "INIT_INTERACTIVE_MODE") {
		const { mode, tabId } = message.payload;
		initInteractiveMode(mode, tabId);
		sendResponse({ started: true });
		return true;
	}
	if (message.type === "SCROLLING_REGION_SELECTED") {
		const { region, speed } = message.payload;
		const tabId = sender.tab?.id;
		if (!tabId) {
			sendResponse({ started: false });
			return false;
		}
		captureScrollingArea(tabId, region, speed || "medium", (progress) => {
			chrome.tabs.sendMessage(tabId, {
				type: "SCROLLING_PROGRESS",
				payload: progress
			}).catch(() => {});
		}).then(async (result) => {
			lastCaptureBlob = result.blob;
			lastCaptureDataUrl = await blobToDataUrl(result.blob);
			lastCaptureResult = {
				...result,
				blob: null
			};
			await showResultBarOnTab(tabId, {
				width: result.width,
				height: result.height,
				mode: result.mode,
				method: result.method
			});
		}).catch((err) => {
			chrome.tabs.sendMessage(tabId, {
				type: "CAPTURE_ERROR_INLINE",
				payload: { message: err.message }
			}).catch(() => {});
		});
		sendResponse({ started: true });
		return true;
	}
	if (message.type === "MANUAL_CAPTURE_FRAME") {
		const { region } = message.payload;
		const tabId = sender.tab?.id;
		if (!tabId) {
			sendResponse({ success: false });
			return false;
		}
		captureManualFrame(tabId, region).then((frame) => {
			if (frame) manualFrames.push(frame);
			sendResponse({
				success: !!frame,
				count: manualFrames.length
			});
		});
		return true;
	}
	if (message.type === "FINISH_MANUAL_CAPTURE") {
		const { region } = message.payload;
		const tabId = sender.tab?.id;
		if (!tabId || manualFrames.length === 0) {
			sendResponse({ success: false });
			return false;
		}
		const framesToStitch = [...manualFrames];
		manualFrames = [];
		stitchManualFrames(framesToStitch, region, tabId).then(async (result) => {
			lastCaptureBlob = result.blob;
			lastCaptureDataUrl = await blobToDataUrl(result.blob);
			lastCaptureResult = {
				...result,
				blob: null
			};
			await showResultBarOnTab(tabId, {
				width: result.width,
				height: result.height,
				mode: result.mode,
				method: result.method
			});
			sendResponse({ success: true });
		}).catch((err) => {
			sendResponse({
				success: false,
				error: err.message
			});
		});
		return true;
	}
	if (message.type === "EXECUTE_OCR") {
		const { region } = message.payload;
		const tabId = sender.tab?.id;
		if (!tabId) {
			sendResponse({ error: "No active tab" });
			return false;
		}
		captureSelectedArea(tabId, region).then(async (result) => {
			const dataUrl = await blobToDataUrl(result.blob);
			await ensureOffscreenDocument();
			const ocrResp = await chrome.runtime.sendMessage({
				type: "PERFORM_OCR",
				payload: { dataUrl }
			});
			if (ocrResp?.error) sendResponse({ error: ocrResp.error });
			else sendResponse({ text: ocrResp?.text || "" });
		}).catch((err) => {
			console.error("OCR execution error:", err);
			sendResponse({ error: err.message || "OCR failed" });
		});
		return true;
	}
	return false;
});
chrome.commands.onCommand.addListener(async (command) => {
	const [tab] = await chrome.tabs.query({
		active: true,
		currentWindow: true
	});
	if (!tab?.id) return;
	if (command === "capture-full-page") try {
		const result = await captureFullPage(tab.id);
		lastCaptureBlob = result.blob;
		lastCaptureDataUrl = await blobToDataUrl(result.blob);
		lastCaptureResult = {
			...result,
			blob: null
		};
		await handleExport(result.blob, result, "png");
	} catch (e) {
		console.error("Keyboard shortcut capture failed:", e);
	}
	if (command === "capture-visible") try {
		const result = await captureVisibleArea(tab.id);
		lastCaptureBlob = result.blob;
		lastCaptureDataUrl = await blobToDataUrl(result.blob);
		lastCaptureResult = {
			...result,
			blob: null
		};
		await handleExport(result.blob, result, "png");
	} catch (e) {
		console.error("Keyboard shortcut capture failed:", e);
	}
});
async function handleCapture(mode, region, speed, explicitTabId) {
	let targetTabId = explicitTabId;
	let tab;
	if (targetTabId) try {
		tab = await chrome.tabs.get(targetTabId);
	} catch {}
	if (!tab) {
		const [activeTab] = await chrome.tabs.query({
			active: true,
			currentWindow: true
		});
		tab = activeTab;
		targetTabId = tab?.id;
	}
	if (!tab?.id) throw new Error("No active tab");
	const tabUrl = tab.url || "";
	const support = isSupportedCapturePage(tabUrl);
	if (!support.supported) throw new Error(support.message || "This page cannot be captured.");
	if (mode === "full-page" || mode === "scrolling-area") await injectContentScripts(tab.id);
	const sendProgress = (progress) => {
		chrome.runtime.sendMessage({
			type: "CAPTURE_PROGRESS",
			payload: progress
		}).catch(() => {});
	};
	switch (mode) {
		case "full-page": return captureFullPage(targetTabId, sendProgress);
		case "visible-area": return captureVisibleArea(targetTabId);
		case "selected-area":
			if (!region) throw new Error("Region required for selected-area mode");
			return captureSelectedArea(targetTabId, region);
		case "scrolling-area":
			if (!region) throw new Error("Region required for scrolling-area mode");
			return captureScrollingArea(targetTabId, region, speed || "medium", sendProgress);
		default: throw new Error(`Unknown capture mode: ${mode}`);
	}
}
async function initInteractiveMode(mode, tabId) {
	try {
		const tab = await chrome.tabs.get(tabId);
		const support = isSupportedCapturePage(tab.url || "");
		if (!support.supported) {
			chrome.runtime.sendMessage({
				type: "CAPTURE_ERROR",
				payload: { message: support.message || "Cannot capture this type of page." }
			}).catch(() => {});
			return;
		}
		await injectContentScripts(tabId);
		if (mode === "selected-area") {
			await chrome.scripting.executeScript({
				target: { tabId },
				files: ["region-selector.js"]
			});
			await sleep(100);
			await chrome.tabs.sendMessage(tabId, {
				type: "START_REGION_SELECT_MODE",
				payload: { tabId }
			});
		}
		if (mode === "scrolling-area") {
			await chrome.scripting.executeScript({
				target: { tabId },
				files: ["scrolling-area-ui.js"]
			});
			await sleep(100);
			await chrome.tabs.sendMessage(tabId, {
				type: "START_SCROLLING_AREA_MODE",
				payload: { tabId }
			});
		}
		if (mode === "capture-text") {
			await chrome.scripting.executeScript({
				target: { tabId },
				files: ["ocr-overlay.js"]
			});
			await sleep(100);
			await chrome.tabs.sendMessage(tabId, {
				type: "START_OCR_MODE",
				payload: { tabId }
			});
		}
	} catch (err) {
		console.error("initInteractiveMode failed:", err);
	}
}
function sleep(ms) {
	return new Promise((r) => setTimeout(r, ms));
}
async function showResultBarOnTab(tabId, payload) {
	try {
		await chrome.scripting.executeScript({
			target: { tabId },
			files: ["result-bar.js"]
		}).catch(() => {});
		await chrome.scripting.executeScript({
			target: { tabId },
			func: (info) => {
				if (typeof window.__snapforge_show_result_bar === "function") window.__snapforge_show_result_bar(info);
			},
			args: [payload]
		}).catch(() => {});
		await chrome.tabs.sendMessage(tabId, {
			type: "SHOW_RESULT_BAR",
			payload
		}).catch(() => {});
	} catch (err) {
		console.error("showResultBarOnTab failed:", err);
	}
}
async function injectContentScripts(tabId) {
	try {
		await chrome.scripting.executeScript({
			target: { tabId },
			files: [
				"page-analyzer.js",
				"sticky-manager.js",
				"lazy-loader.js"
			]
		});
	} catch {}
}
async function handleExport(blob, result, format) {
	try {
		switch (format) {
			case "clipboard": return { success: true };
			case "png": {
				const filename = generateFilename(getDomain(result.url), "png");
				const dataUrl = await blobToDataUrl(blob);
				await chrome.downloads.download({
					url: dataUrl,
					filename,
					saveAs: false
				});
				return { success: true };
			}
			case "pdf": {
				const filename = generateFilename(getDomain(result.url), "pdf");
				const pdfDataUrl = await blobToDataUrl(await generatePDF(blob, "a4"));
				await chrome.downloads.download({
					url: pdfDataUrl,
					filename,
					saveAs: false
				});
				return { success: true };
			}
			default: return {
				success: false,
				error: `Unknown format: ${format}`
			};
		}
	} catch (e) {
		return {
			success: false,
			error: e.message
		};
	}
}
function getDomain(url) {
	try {
		return new URL(url).hostname;
	} catch {
		return "unknown";
	}
}
function generateFilename(domain, ext) {
	const ts = (/* @__PURE__ */ new Date()).toISOString().replace(/[-:T]/g, "").slice(0, 14);
	return `gofully-${domain.replace(/[^a-zA-Z0-9.-]/g, "_").slice(0, 50)}-${ts}.${ext}`;
}
//#endregion
