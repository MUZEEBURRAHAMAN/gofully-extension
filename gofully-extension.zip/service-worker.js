import { a as loadImage, r as dataUrlToBlob$1, t as canvasToBlob } from "./chunks/image-BPYnapgS.js";
import { t as generatePDF } from "./chunks/pdf-generator-Dg4k4FqC.js";
import { t as isSupportedCapturePage } from "./chunks/url-validator-CInVwRGC.js";
//#region src/utils/permissions.ts
async function getCaptureMethod(pageHeight) {
	if (pageHeight > 16384) return "scroll-stitch";
	return "cdp";
}
//#endregion
//#region src/background/cdp-capture.ts
async function captureWithCDP(tabId, dimensions) {
	const debuggee = { tabId };
	await chrome.debugger.attach(debuggee, "1.3");
	try {
		const layoutMetrics = await chrome.debugger.sendCommand(debuggee, "Page.getLayoutMetrics", {});
		const contentWidth = layoutMetrics.cssContentSize?.width || layoutMetrics.contentSize?.width || dimensions.scrollWidth;
		const contentHeight = layoutMetrics.cssContentSize?.height || layoutMetrics.contentSize?.height || dimensions.scrollHeight;
		const captureScale = Math.max(2, dimensions.devicePixelRatio);
		await chrome.debugger.sendCommand(debuggee, "Emulation.setDeviceMetricsOverride", {
			width: Math.ceil(contentWidth),
			height: Math.ceil(contentHeight),
			deviceScaleFactor: captureScale,
			mobile: false
		});
		const result = await chrome.debugger.sendCommand(debuggee, "Page.captureScreenshot", {
			format: "png",
			captureBeyondViewport: true,
			clip: {
				x: 0,
				y: 0,
				width: contentWidth,
				height: contentHeight,
				scale: captureScale
			}
		});
		await chrome.debugger.sendCommand(debuggee, "Emulation.clearDeviceMetricsOverride", {});
		const dataUrl = `data:image/png;base64,${result.data}`;
		const blob = dataUrlToBlob$1(dataUrl);
		const tab = await chrome.tabs.get(tabId);
		return {
			blob,
			width: Math.ceil(contentWidth * captureScale),
			height: Math.ceil(contentHeight * captureScale),
			mode: "full-page",
			method: "cdp",
			timestamp: Date.now(),
			url: tab.url || "",
			title: tab.title || ""
		};
	} finally {
		try {
			await chrome.debugger.detach(debuggee);
		} catch {}
	}
}
//#endregion
//#region src/utils/dpr-handler.ts
function detectDPRFromCapture(capturedWidth, cssWidth) {
	if (cssWidth === 0) return 1;
	return capturedWidth / cssWidth;
}
//#endregion
//#region src/background/stitch-capture.ts
var CAPTURE_DELAY = 800;
async function captureWithScrollStitch(tabId, dimensions, onProgress) {
	const { scrollWidth, scrollHeight, viewportWidth, viewportHeight } = dimensions;
	await chrome.tabs.sendMessage(tabId, { type: "HIDE_STICKY" }).catch(() => {});
	await chrome.tabs.sendMessage(tabId, {
		type: "PRE_SCROLL_LAZY",
		payload: { maxWait: 2e3 }
	}).catch(() => {});
	const frames = [];
	const yStep = viewportHeight;
	const totalSteps = Math.ceil(scrollHeight / yStep);
	let dpr = dimensions.devicePixelRatio;
	for (let step = 0; step < totalSteps; step++) {
		const scrollY = Math.min(step * yStep, scrollHeight - viewportHeight);
		await chrome.scripting.executeScript({
			target: { tabId },
			func: (x, y) => window.scrollTo(x, y),
			args: [0, scrollY]
		});
		await sleep$3(CAPTURE_DELAY);
		const dataUrl = await captureWithRetry$1();
		if (step === 0) dpr = detectDPRFromCapture((await loadImage(dataUrl)).width, viewportWidth);
		frames.push({
			dataUrl,
			x: 0,
			y: scrollY,
			width: viewportWidth,
			height: viewportHeight,
			scrollX: 0,
			scrollY
		});
		onProgress?.({
			current: step + 1,
			total: totalSteps,
			phase: "capturing"
		});
	}
	await chrome.tabs.sendMessage(tabId, { type: "RESTORE_STICKY" }).catch(() => {});
	await chrome.scripting.executeScript({
		target: { tabId },
		func: () => window.scrollTo(0, 0),
		args: []
	});
	onProgress?.({
		current: 0,
		total: 0,
		phase: "stitching"
	});
	const blob = await stitchFrames(frames, scrollWidth, scrollHeight, dpr, viewportHeight);
	const tab = await chrome.tabs.get(tabId);
	return {
		blob,
		width: Math.round(scrollWidth * dpr),
		height: Math.round(scrollHeight * dpr),
		mode: "full-page",
		method: "scroll-stitch",
		timestamp: Date.now(),
		url: tab.url || "",
		title: tab.title || ""
	};
}
async function stitchFrames(frames, totalWidth, totalHeight, dpr, viewportHeight) {
	const canvasWidth = Math.round(totalWidth * dpr);
	const canvasHeight = Math.round(totalHeight * dpr);
	const canvas = new OffscreenCanvas(canvasWidth, canvasHeight);
	const ctx = canvas.getContext("2d");
	for (let fi = 0; fi < frames.length; fi++) {
		const frame = frames[fi];
		const img = await loadImage(frame.dataUrl);
		const dstX = 0;
		const dstY = Math.round(frame.scrollY * dpr);
		const dstW = Math.min(img.width, canvasWidth);
		const maxDstH = canvasHeight - dstY;
		if (maxDstH <= 0) continue;
		if (img.height <= maxDstH) ctx.drawImage(img, 0, 0, img.width, img.height, dstX, dstY, dstW, img.height);
		else {
			const srcY = img.height - maxDstH;
			ctx.drawImage(img, 0, srcY, img.width, maxDstH, dstX, dstY, dstW, maxDstH);
		}
	}
	return canvasToBlob(canvas);
}
async function captureWithRetry$1(maxRetries = 3) {
	for (let i = 0; i < maxRetries; i++) try {
		return await chrome.tabs.captureVisibleTab({ format: "png" });
	} catch (e) {
		if (e?.message?.includes("MAX_CAPTURE") && i < maxRetries - 1) {
			await sleep$3(1e3);
			continue;
		}
		throw e;
	}
	return await chrome.tabs.captureVisibleTab({ format: "png" });
}
function sleep$3(ms) {
	return new Promise((r) => setTimeout(r, ms));
}
//#endregion
//#region src/background/capture-engine.ts
async function captureFullPage(tabId, onProgress) {
	const dimensions = await getPageDimensions(tabId);
	if (await getCaptureMethod(dimensions.scrollHeight) === "cdp") try {
		return await captureWithCDP(tabId, dimensions);
	} catch (e) {
		console.warn("CDP capture failed, falling back to scroll-stitch:", e);
		return captureWithScrollStitch(tabId, dimensions, onProgress);
	}
	return captureWithScrollStitch(tabId, dimensions, onProgress);
}
async function captureVisibleArea(tabId) {
	const dataUrl = await chrome.tabs.captureVisibleTab({ format: "png" });
	const blob = dataUrlToBlob$1(dataUrl);
	const img = await loadImage(dataUrl);
	const tab = await chrome.tabs.get(tabId);
	return {
		blob,
		width: img.width,
		height: img.height,
		mode: "visible-area",
		method: "cdp",
		timestamp: Date.now(),
		url: tab.url || "",
		title: tab.title || ""
	};
}
async function captureSelectedArea(tabId, region) {
	const dataUrl = await chrome.tabs.captureVisibleTab({ format: "png" });
	const img = await loadImage(dataUrl);
	const [{ result: vpWidth }] = await chrome.scripting.executeScript({
		target: { tabId },
		func: () => window.innerWidth
	});
	const dpr = detectDPRFromCapture(img.width, vpWidth || img.width);
	const sx = Math.round(region.x * dpr);
	const sy = Math.round(region.y * dpr);
	const sw = Math.round(region.width * dpr);
	const sh = Math.round(region.height * dpr);
	const canvas = new OffscreenCanvas(sw, sh);
	canvas.getContext("2d").drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
	const blob = await canvas.convertToBlob({ type: "image/png" });
	const tab = await chrome.tabs.get(tabId);
	return {
		blob,
		width: sw,
		height: sh,
		mode: "selected-area",
		method: "cdp",
		timestamp: Date.now(),
		url: tab.url || "",
		title: tab.title || ""
	};
}
async function getPageDimensions(tabId) {
	const [{ result }] = await chrome.scripting.executeScript({
		target: { tabId },
		func: () => {
			const body = document.body;
			const html = document.documentElement;
			return {
				scrollWidth: Math.max(body.scrollWidth, body.offsetWidth, html.clientWidth, html.scrollWidth, html.offsetWidth),
				scrollHeight: Math.max(body.scrollHeight, body.offsetHeight, html.clientHeight, html.scrollHeight, html.offsetHeight),
				viewportWidth: window.innerWidth,
				viewportHeight: window.innerHeight,
				devicePixelRatio: window.devicePixelRatio || 1
			};
		}
	});
	return result;
}
//#endregion
//#region src/capture-modes/scrolling-area.ts
var SPEED_MAP = {
	slow: 800,
	medium: 600,
	fast: 500
};
async function captureScrollingArea(tabId, region, speed, onProgress) {
	const frames = [];
	const delay = SPEED_MAP[speed];
	const [{ result: pageInfo }] = await chrome.scripting.executeScript({
		target: { tabId },
		func: () => ({
			scrollHeight: Math.max(document.body.scrollHeight, document.documentElement.scrollHeight),
			scrollY: window.scrollY,
			viewportHeight: window.innerHeight
		})
	});
	const pi = pageInfo;
	const scrollStep = region.height;
	const estimatedSteps = Math.ceil((pi.scrollHeight - pi.scrollY) / scrollStep);
	let dpr = 1;
	let lastFrameHash = "";
	let step = 0;
	const firstFrame = await captureAndCropFrame(tabId, region);
	if (firstFrame) {
		dpr = detectDPRFromCapture((await loadImage(firstFrame.dataUrl)).width, region.width);
		if (dpr === 0) dpr = 1;
		frames.push(firstFrame);
		lastFrameHash = await hashFrame(firstFrame.dataUrl);
		step++;
		onProgress?.({
			current: step,
			total: estimatedSteps,
			phase: "capturing"
		});
	}
	let reachedEnd = false;
	let lastScrollY = pi.scrollY;
	while (!reachedEnd) {
		const [{ result: currentPos }] = await chrome.scripting.executeScript({
			target: { tabId },
			func: (dy) => {
				const prev = window.scrollY;
				window.scrollBy({
					top: dy,
					behavior: "instant"
				});
				return {
					prev,
					current: window.scrollY,
					maxScroll: Math.max(document.body.scrollHeight, document.documentElement.scrollHeight) - window.innerHeight
				};
			},
			args: [scrollStep]
		});
		await sleep$2(delay);
		const pos = currentPos;
		if (Math.abs(pos.current - lastScrollY) < 2 || pos.current >= pos.maxScroll) {
			const finalFrame = await captureAndCropFrame(tabId, region);
			if (finalFrame) {
				if (await hashFrame(finalFrame.dataUrl) !== lastFrameHash) frames.push(finalFrame);
			}
			reachedEnd = true;
			break;
		}
		lastScrollY = pos.current;
		const frame = await captureAndCropFrame(tabId, region);
		if (!frame) break;
		const hash = await hashFrame(frame.dataUrl);
		if (hash === lastFrameHash) {
			reachedEnd = true;
			break;
		}
		frames.push(frame);
		lastFrameHash = hash;
		step++;
		onProgress?.({
			current: step,
			total: estimatedSteps,
			phase: "capturing"
		});
		if (frames.length >= 100) break;
	}
	onProgress?.({
		current: 0,
		total: 0,
		phase: "stitching"
	});
	const blob = await stitchScrollingFrames(frames, region, dpr);
	const tab = await chrome.tabs.get(tabId);
	return {
		blob,
		width: Math.round(region.width * dpr),
		height: Math.round(region.height * frames.length * dpr),
		mode: "scrolling-area",
		method: "scroll-stitch",
		timestamp: Date.now(),
		url: tab.url || "",
		title: tab.title || ""
	};
}
async function hideScrollUI(tabId, hide) {
	try {
		await chrome.tabs.sendMessage(tabId, {
			type: "SCROLL_UI_VISIBILITY",
			hide
		});
		await sleep$2(40);
	} catch {}
}
async function captureAndCropFrame(tabId, region) {
	try {
		await hideScrollUI(tabId, true);
		const dataUrl = await captureWithRetry();
		const img = await loadImage(dataUrl);
		const [{ result: vpWidth }] = await chrome.scripting.executeScript({
			target: { tabId },
			func: () => window.innerWidth
		});
		const dpr = img.width / (vpWidth || img.width);
		const sx = Math.round(region.x * dpr);
		const sy = Math.round(region.y * dpr);
		const sw = Math.round(region.width * dpr);
		const sh = Math.round(region.height * dpr);
		const canvas = new OffscreenCanvas(sw, sh);
		canvas.getContext("2d").drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
		const croppedUrl = await blobToDataUrl$2(await canvas.convertToBlob({ type: "image/png" }));
		await hideScrollUI(tabId, false);
		return {
			dataUrl: croppedUrl,
			x: region.x,
			y: region.y,
			width: region.width,
			height: region.height,
			scrollX: 0,
			scrollY: 0
		};
	} catch {
		await hideScrollUI(tabId, false);
		return null;
	}
}
async function stitchScrollingFrames(frames, _region, _dpr) {
	if (frames.length === 0) throw new Error("No frames to stitch");
	if (frames.length === 1) {
		const img = await loadImage(frames[0].dataUrl);
		const c = new OffscreenCanvas(img.width, img.height);
		c.getContext("2d").drawImage(img, 0, 0);
		return canvasToBlob(c);
	}
	const images = await Promise.all(frames.map((f) => loadImage(f.dataUrl)));
	const frameW = images[0].width;
	const frameH = images[0].height;
	const overlaps = [0];
	for (let i = 1; i < images.length; i++) {
		const ov = await findOverlap(images[i - 1], images[i], frameW, frameH);
		overlaps.push(ov);
	}
	let totalH = frameH;
	for (let i = 1; i < images.length; i++) totalH += frameH - overlaps[i];
	const canvas = new OffscreenCanvas(frameW, totalH);
	const ctx = canvas.getContext("2d");
	let y = 0;
	for (let i = 0; i < images.length; i++) {
		ctx.drawImage(images[i], 0, y);
		y += frameH - (overlaps[i + 1] ?? 0);
	}
	return canvasToBlob(canvas);
}
async function findOverlap(imgA, imgB, w, h) {
	const sampleW = Math.min(w, 160);
	const sampleH = h;
	sampleW / w;
	const ctxA = new OffscreenCanvas(sampleW, sampleH).getContext("2d");
	ctxA.drawImage(imgA, 0, 0, sampleW, sampleH);
	const dA = ctxA.getImageData(0, 0, sampleW, sampleH).data;
	const ctxB = new OffscreenCanvas(sampleW, sampleH).getContext("2d");
	ctxB.drawImage(imgB, 0, 0, sampleW, sampleH);
	const dB = ctxB.getImageData(0, 0, sampleW, sampleH).data;
	const marginX = Math.round(sampleW * .2);
	const endX = sampleW - marginX;
	const coarseStep = 4;
	const xStep = 3;
	const rowStep = 3;
	const minOv = Math.max(4, Math.round(sampleH * .02));
	const maxOv = Math.round(sampleH * .95);
	let bestOv = 0;
	let bestErr = Infinity;
	for (let ov = minOv; ov <= maxOv; ov += coarseStep) {
		let diff = 0, count = 0;
		for (let r = 0; r < ov; r += rowStep) {
			const rowA = sampleH - ov + r;
			const rowB = r;
			for (let x = marginX; x < endX; x += xStep) {
				const iA = (rowA * sampleW + x) * 4;
				const iB = (rowB * sampleW + x) * 4;
				diff += Math.abs(dA[iA] - dB[iB]) + Math.abs(dA[iA + 1] - dB[iB + 1]) + Math.abs(dA[iA + 2] - dB[iB + 2]);
				count++;
			}
		}
		const avg = count > 0 ? diff / (count * 3) : 255;
		if (avg < bestErr) {
			bestErr = avg;
			bestOv = ov;
		}
	}
	const lo = Math.max(minOv, bestOv - coarseStep);
	const hi = Math.min(maxOv, bestOv + coarseStep);
	for (let ov = lo; ov <= hi; ov++) {
		let diff = 0, count = 0;
		for (let r = 0; r < ov; r += rowStep) {
			const rowA = sampleH - ov + r;
			const rowB = r;
			for (let x = marginX; x < endX; x += xStep) {
				const iA = (rowA * sampleW + x) * 4;
				const iB = (rowB * sampleW + x) * 4;
				diff += Math.abs(dA[iA] - dB[iB]) + Math.abs(dA[iA + 1] - dB[iB + 1]) + Math.abs(dA[iA + 2] - dB[iB + 2]);
				count++;
			}
		}
		const avg = count > 0 ? diff / (count * 3) : 255;
		if (avg < bestErr) {
			bestErr = avg;
			bestOv = ov;
		}
	}
	if (bestErr > 40) return 0;
	return Math.round(bestOv * (h / sampleH));
}
async function hashFrame(dataUrl) {
	const img = await loadImage(dataUrl);
	const ctx = new OffscreenCanvas(16, 16).getContext("2d");
	ctx.drawImage(img, 0, 0, 16, 16);
	const data = ctx.getImageData(0, 0, 16, 16).data;
	let hash = 0;
	for (let i = 0; i < data.length; i += 4) {
		hash = (hash << 5) - hash + data[i] | 0;
		hash = (hash << 5) - hash + data[i + 1] | 0;
		hash = (hash << 5) - hash + data[i + 2] | 0;
	}
	return hash.toString(36);
}
async function captureWithRetry(maxRetries = 3) {
	for (let i = 0; i < maxRetries; i++) try {
		return await chrome.tabs.captureVisibleTab({ format: "png" });
	} catch (e) {
		if (e?.message?.includes("MAX_CAPTURE") && i < maxRetries - 1) {
			await sleep$2(1e3);
			continue;
		}
		throw e;
	}
	return await chrome.tabs.captureVisibleTab({ format: "png" });
}
function sleep$2(ms) {
	return new Promise((r) => setTimeout(r, ms));
}
async function blobToDataUrl$2(blob) {
	const bytes = new Uint8Array(await blob.arrayBuffer());
	const CHUNK = 32768;
	const parts = [];
	for (let i = 0; i < bytes.length; i += CHUNK) parts.push(String.fromCharCode(...bytes.subarray(i, i + CHUNK)));
	return `data:${blob.type};base64,${btoa(parts.join(""))}`;
}
//#endregion
//#region src/capture-modes/scroll-capturer.ts
var MAX_FRAMES = 300;
/** Chrome refuses to allocate a canvas taller than this. */
var MAX_CANVAS_H = 32e3;
/** Retries for a frame whose anchors moved mid-shutter. */
var SHUTTER_RETRIES = 4;
/** Anchors sampled per frame, spread down the region. */
var SAMPLE_POINTS = 14;
/** CSS px of anchor disagreement tolerated across the shutter. */
var SHUTTER_TOLERANCE = 1.5;
/** Below this CSS-px delta the view has not meaningfully moved. */
var MIN_SCROLL_DELTA = 2;
/** Consecutive dropped frames before the "too fast" hint appears. */
var TOO_FAST_AFTER = 2;
/** Fallback pixel matcher: max mean luma difference for a usable match. */
var LUMA_THRESHOLD = 18;
var MIN_OVERLAP_FRAC = .05;
var MAX_OVERLAP_FRAC = .95;
var THUMB_W = 90;
async function createScrollCapturer(tabId, region, onPreviewUpdated) {
	let lastStitched = null;
	let stitcher = null;
	let frameCount = 0;
	let stopped = false;
	let isPolling = false;
	let droppedInARow = 0;
	let hitLimit = false;
	async function poll() {
		if (stopped || isPolling || hitLimit || frameCount >= MAX_FRAMES) return null;
		isPolling = true;
		try {
			return await runPoll();
		} catch {
			return null;
		} finally {
			isPolling = false;
		}
	}
	async function runPoll() {
		const frame = await captureSyncedFrame(tabId, region);
		if (!frame || stopped) return null;
		if (!lastStitched || !stitcher) {
			lastStitched = frame;
			stitcher = initStitcher(frame);
			frameCount = 1;
			return emit();
		}
		const frameH = frame.bitmap.height;
		const deltaCss = measureScrollDelta(lastStitched.anchors, frame.anchors);
		let overlap = -1;
		if (deltaCss !== null) {
			if (deltaCss < MIN_SCROLL_DELTA) {
				frame.bitmap.close();
				droppedInARow = 0;
				return null;
			}
			const deltaPx = Math.round(deltaCss * frame.dpr);
			if (deltaPx >= frameH) {
				frame.bitmap.close();
				return dropFrame();
			}
			overlap = frameH - deltaPx;
		} else {
			overlap = await findOverlapByPixels(lastStitched.bitmap, frame.bitmap, lastStitched.sample, frame.sample);
			if (overlap < 0) {
				frame.bitmap.close();
				return dropFrame();
			}
		}
		const newRows = frameH - overlap;
		if (newRows < 2) {
			frame.bitmap.close();
			return null;
		}
		if (stitcher.totalHeight + newRows > MAX_CANVAS_H) {
			frame.bitmap.close();
			hitLimit = true;
			return emit({ atLimit: true });
		}
		appendToStitcher(stitcher, frame.bitmap, overlap, newRows);
		frameCount++;
		droppedInARow = 0;
		lastStitched.bitmap.close();
		lastStitched = frame;
		return emit();
	}
	function dropFrame() {
		droppedInARow++;
		if (droppedInARow < TOO_FAST_AFTER) return null;
		return emit({ tooFast: true });
	}
	function emit(extra) {
		const progress = {
			frameCount,
			totalHeight: stitcher?.totalHeight ?? 0,
			thumbDataUrl: null,
			...extra
		};
		onPreviewUpdated(progress);
		if (stitcher) makeThumb(stitcher.canvas, stitcher.totalHeight).then((thumbDataUrl) => {
			if (!stopped && thumbDataUrl) onPreviewUpdated({
				...progress,
				thumbDataUrl
			});
		}).catch(() => {});
		return progress;
	}
	async function finish() {
		stopped = true;
		releaseAnchors(tabId);
		if (!stitcher || frameCount === 0) return null;
		const { totalHeight, frameW } = stitcher;
		const out = new OffscreenCanvas(frameW, totalHeight);
		out.getContext("2d").drawImage(stitcher.canvas, 0, 0, frameW, totalHeight, 0, 0, frameW, totalHeight);
		const blob = await out.convertToBlob({ type: "image/png" });
		lastStitched?.bitmap.close();
		lastStitched = null;
		const tab = await chrome.tabs.get(tabId);
		return {
			blob,
			width: frameW,
			height: totalHeight,
			mode: "scrolling-area",
			method: "scroll-stitch",
			timestamp: Date.now(),
			url: tab.url || "",
			title: tab.title || ""
		};
	}
	function stop() {
		stopped = true;
		releaseAnchors(tabId);
		lastStitched?.bitmap.close();
		lastStitched = null;
		stitcher = null;
	}
	return {
		poll,
		finish,
		stop
	};
}
/**
* How far the page scrolled between two frames, in CSS pixels.
* Positive means scrolled down. `null` when nothing matched.
*
* Uses the median rather than the mean so a handful of elements that animate
* independently (parallax, reveal-on-scroll transforms) cannot skew the result.
*/
function measureScrollDelta(prev, curr) {
	const deltas = [];
	for (const id in curr) {
		const before = prev[id];
		if (before !== void 0) deltas.push(before - curr[id]);
	}
	if (deltas.length === 0) return null;
	deltas.sort((a, b) => a - b);
	const mid = deltas.length >> 1;
	return deltas.length % 2 ? deltas[mid] : (deltas[mid - 1] + deltas[mid]) / 2;
}
/**
* Capture one frame, guaranteeing the page did not move while the shutter was
* open. Anchors are read either side of the capture and must agree.
*/
async function captureSyncedFrame(tabId, region) {
	for (let attempt = 0; attempt < SHUTTER_RETRIES; attempt++) {
		const before = await readAnchors(tabId, region);
		if (!before) return null;
		await setUiVisible(tabId, false);
		const dataUrl = await captureTab();
		setUiVisible(tabId, true);
		if (!dataUrl) return null;
		const after = await readAnchors(tabId, region);
		if (!after) return null;
		if (!anchorsAgree(before.anchors, after.anchors)) continue;
		const frame = await cropToRegion(dataUrl, region, after.innerWidth, after.anchors);
		if (frame) return frame;
	}
	return null;
}
function anchorsAgree(a, b) {
	let compared = 0;
	for (const id in b) {
		const other = a[id];
		if (other === void 0) continue;
		if (Math.abs(other - b[id]) > SHUTTER_TOLERANCE) return false;
		compared++;
	}
	return compared > 0 || Object.keys(b).length === 0;
}
async function captureTab() {
	for (let i = 0; i < 3; i++) try {
		return await chrome.tabs.captureVisibleTab({ format: "png" });
	} catch (e) {
		if ((e?.message ?? "").includes("MAX_CAPTURE") && i < 2) {
			await sleep$1(400);
			continue;
		}
		return null;
	}
	return null;
}
async function setUiVisible(tabId, visible) {
	try {
		await chrome.tabs.sendMessage(tabId, { type: visible ? "SCROLL_UI_SHOW" : "SCROLL_UI_HIDE" });
	} catch {}
}
/**
* Sample scrollable elements down the middle of the capture region and report
* each one's viewport-relative top.
*
* State lives on `window` in the extension's isolated world, so ids stay stable
* across calls and no attribute is ever written to the page's own DOM.
*/
async function readAnchors(tabId, region) {
	try {
		const [injection] = await chrome.scripting.executeScript({
			target: { tabId },
			args: [
				region.x,
				region.y,
				region.width,
				region.height,
				SAMPLE_POINTS
			],
			func: (rx, ry, rw, rh, samples) => {
				const KEY = "__gofullyScrollAnchors";
				const store = window[KEY] || (window[KEY] = {
					seq: 0,
					tracked: /* @__PURE__ */ new Map()
				});
				const ids = /* @__PURE__ */ new WeakMap();
				for (const [id, el] of store.tracked) ids.set(el, id);
				const anchors = {};
				const track = (el, top) => {
					let id = ids.get(el);
					if (id === void 0) {
						id = String(++store.seq);
						store.tracked.set(id, el);
						ids.set(el, id);
					}
					anchors[id] = top;
				};
				for (const [id, el] of store.tracked) {
					if (!el.isConnected) {
						store.tracked.delete(id);
						continue;
					}
					anchors[id] = el.getBoundingClientRect().top;
				}
				const centerX = rx + rw / 2;
				for (let i = 0; i < samples; i++) {
					const y = ry + rh * (i + .5) / samples;
					for (const el of document.elementsFromPoint(centerX, y)) {
						if (el === document.body || el === document.documentElement) continue;
						const position = getComputedStyle(el).position;
						if (position === "fixed" || position === "sticky") continue;
						const rect = el.getBoundingClientRect();
						if (rect.height < 4) continue;
						track(el, rect.top);
						break;
					}
				}
				if (store.tracked.size > 240) {
					const excess = store.tracked.size - 120;
					let dropped = 0;
					for (const id of store.tracked.keys()) {
						if (dropped++ >= excess) break;
						store.tracked.delete(id);
						delete anchors[id];
					}
				}
				return {
					anchors,
					innerWidth: window.innerWidth
				};
			}
		});
		return injection?.result ?? null;
	} catch {
		return null;
	}
}
/** Drop the tracked-element map so the page is left exactly as we found it. */
function releaseAnchors(tabId) {
	chrome.scripting.executeScript({
		target: { tabId },
		func: () => {
			delete window.__gofullyScrollAnchors;
		}
	}).catch(() => {});
}
async function cropToRegion(dataUrl, region, innerWidth, anchors) {
	let full = null;
	try {
		const blob = dataUrlToBlob(dataUrl);
		if (!blob) return null;
		full = await createImageBitmap(blob);
		const dpr = innerWidth > 0 ? full.width / innerWidth : 1;
		const sx = clamp(Math.round(region.x * dpr), 0, full.width);
		const sy = clamp(Math.round(region.y * dpr), 0, full.height);
		const sw = clamp(Math.round(region.width * dpr), 1, full.width - sx);
		const sh = clamp(Math.round(region.height * dpr), 1, full.height - sy);
		if (sw < 1 || sh < 1) return null;
		const bitmap = await createImageBitmap(full, sx, sy, sw, sh);
		const ctx = new OffscreenCanvas(32, 32).getContext("2d");
		ctx.drawImage(bitmap, 0, 0, 32, 32);
		return {
			bitmap,
			anchors,
			dpr,
			sample: ctx.getImageData(0, 0, 32, 32).data
		};
	} catch {
		return null;
	} finally {
		full?.close();
	}
}
function initStitcher(frame) {
	const { width, height } = frame.bitmap;
	const canvas = new OffscreenCanvas(width, Math.min(height * 12, MAX_CANVAS_H));
	const ctx = canvas.getContext("2d");
	ctx.drawImage(frame.bitmap, 0, 0);
	return {
		canvas,
		ctx,
		totalHeight: height,
		frameW: width
	};
}
function appendToStitcher(s, frame, overlap, newRows) {
	const needed = s.totalHeight + newRows;
	if (needed > s.canvas.height) {
		const grown = new OffscreenCanvas(s.frameW, Math.min(needed + frame.height * 6, MAX_CANVAS_H));
		grown.getContext("2d").drawImage(s.canvas, 0, 0);
		s.canvas = grown;
		s.ctx = grown.getContext("2d");
	}
	s.ctx.drawImage(frame, 0, overlap, frame.width, newRows, 0, s.totalHeight, s.frameW, newRows);
	s.totalHeight += newRows;
}
async function findOverlapByPixels(frameA, frameB, sampleA, sampleB) {
	const H = Math.min(frameA.height, frameB.height);
	const W = Math.min(frameA.width, frameB.width);
	const stripW = Math.max(60, Math.round(W * .4));
	const stripX = Math.max(0, Math.round(W / 2 - stripW / 2));
	if (H < 40 || stripX + stripW > W) return -1;
	let digestDiff = 0;
	for (let i = 0; i < sampleA.length; i += 4) digestDiff += Math.abs(sampleA[i] - sampleB[i]) + Math.abs(sampleA[i + 1] - sampleB[i + 1]) + Math.abs(sampleA[i + 2] - sampleB[i + 2]);
	const estimate = 1 - Math.min(.95, digestDiff / (sampleA.length / 4) / 3 / 120);
	const hi = Math.round(H * clamp(estimate + .15, MIN_OVERLAP_FRAC, MAX_OVERLAP_FRAC));
	const lo = Math.max(1, Math.round(H * clamp(estimate - .35, MIN_OVERLAP_FRAC, MAX_OVERLAP_FRAC)));
	const step = Math.max(2, Math.round(H / 120));
	const ctx = new OffscreenCanvas(stripW, H * 2).getContext("2d");
	ctx.drawImage(frameA, stripX, 0, stripW, H, 0, 0, stripW, H);
	ctx.drawImage(frameB, stripX, 0, stripW, H, 0, H, stripW, H);
	const data = ctx.getImageData(0, 0, stripW, H * 2).data;
	const columns = [
		Math.round(stripW / 4),
		Math.round(stripW / 2),
		Math.round(stripW * 3 / 4)
	];
	let best = -1;
	let bestScore = Infinity;
	for (let overlap = hi; overlap >= lo; overlap -= step) {
		const rows = Math.min(overlap, 300);
		const strideY = Math.max(2, Math.round(rows / 60));
		let total = 0;
		let count = 0;
		for (let row = 0; row < rows; row += strideY) {
			const rowA = H - overlap + row;
			const rowB = H + row;
			for (const x of columns) {
				const ia = (rowA * stripW + x) * 4;
				const ib = (rowB * stripW + x) * 4;
				total += Math.abs(luma(data, ia) - luma(data, ib));
				count++;
			}
		}
		const score = count > 0 ? total / count : 255;
		if (score < bestScore) {
			bestScore = score;
			best = overlap;
		}
	}
	return bestScore > LUMA_THRESHOLD ? -1 : best;
}
function luma(d, i) {
	return d[i] * .299 + d[i + 1] * .587 + d[i + 2] * .114;
}
async function makeThumb(canvas, totalHeight) {
	try {
		const h = Math.max(1, Math.round(totalHeight / canvas.width * THUMB_W));
		const c = new OffscreenCanvas(THUMB_W, h);
		c.getContext("2d").drawImage(canvas, 0, 0, canvas.width, totalHeight, 0, 0, THUMB_W, h);
		return await blobToDataUrl$1(await c.convertToBlob({
			type: "image/jpeg",
			quality: .7
		}));
	} catch {
		return null;
	}
}
function clamp(n, min, max) {
	return Math.max(min, Math.min(max, n));
}
function sleep$1(ms) {
	return new Promise((r) => setTimeout(r, ms));
}
function dataUrlToBlob(dataUrl) {
	const comma = dataUrl.indexOf(",");
	if (comma < 0) return null;
	const mime = /^data:([^;,]+)/.exec(dataUrl)?.[1] ?? "image/png";
	try {
		const bytes = atob(dataUrl.slice(comma + 1));
		const arr = new Uint8Array(bytes.length);
		for (let i = 0; i < bytes.length; i++) arr[i] = bytes.charCodeAt(i);
		return new Blob([arr], { type: mime });
	} catch {
		return null;
	}
}
async function blobToDataUrl$1(blob) {
	const bytes = new Uint8Array(await blob.arrayBuffer());
	const CHUNK = 32768;
	const parts = [];
	for (let i = 0; i < bytes.length; i += CHUNK) parts.push(String.fromCharCode(...bytes.subarray(i, i + CHUNK)));
	return `data:${blob.type};base64,${btoa(parts.join(""))}`;
}
//#endregion
//#region src/background/service-worker.ts
chrome.runtime.onInstalled.addListener(() => {
	if (chrome.runtime.setUninstallURL) chrome.runtime.setUninstallURL("https://gofully-extension.vercel.app/uninstall-feedback");
});
var lastCaptureResult = null;
var lastCaptureBlob = null;
var lastCaptureDataUrl = null;
var activeCapturer = null;
async function ensureOffscreenDocument() {
	if ((await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] })).length > 0) return;
	await chrome.offscreen.createDocument({
		url: "offscreen.html",
		reasons: [chrome.offscreen.Reason.BLOBS, chrome.offscreen.Reason.DOM_SCRAPING],
		justification: "Process offscreen canvas and OCR operations"
	});
}
async function blobToDataUrl(blob) {
	const bytes = new Uint8Array(await blob.arrayBuffer());
	const CHUNK = 32768;
	const parts = [];
	for (let i = 0; i < bytes.length; i += CHUNK) parts.push(String.fromCharCode(...bytes.subarray(i, i + CHUNK)));
	return `data:${blob.type};base64,${btoa(parts.join(""))}`;
}
var SESSION_CACHE_LIMIT = 8388608;
function cacheCaptureInSession(dataUrl) {
	if (dataUrl.length > SESSION_CACHE_LIMIT) {
		chrome.storage.session.remove("lastCaptureDataUrl").catch(() => {});
		return;
	}
	chrome.storage.session.set({ lastCaptureDataUrl: dataUrl }).catch(() => {});
}
/**
* A content script is only as trustworthy as the page it runs in, so a region
* arriving over messaging is validated against the tab's real viewport before
* any pixels are read.
*/
async function sanitizeRegion(tabId, region) {
	const r = region;
	if (!r) return null;
	if (![
		r.x,
		r.y,
		r.width,
		r.height
	].every((n) => typeof n === "number" && Number.isFinite(n))) return null;
	if (r.width < 1 || r.height < 1) return null;
	let viewport = {
		width: 0,
		height: 0
	};
	try {
		const [{ result }] = await chrome.scripting.executeScript({
			target: { tabId },
			func: () => ({
				width: window.innerWidth,
				height: window.innerHeight
			})
		});
		viewport = result;
	} catch {
		return null;
	}
	if (!viewport.width || !viewport.height) return null;
	const x = Math.max(0, Math.min(r.x, viewport.width - 1));
	const y = Math.max(0, Math.min(r.y, viewport.height - 1));
	return {
		x,
		y,
		width: Math.max(1, Math.min(r.width, viewport.width - x)),
		height: Math.max(1, Math.min(r.height, viewport.height - y))
	};
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	if (message.type === "START_CAPTURE") {
		const { mode, region, speed, tabId } = message.payload;
		const senderTabId = sender.tab?.id || tabId;
		handleCapture(mode, region, speed, senderTabId).then(async (result) => {
			lastCaptureBlob = result.blob;
			lastCaptureDataUrl = await blobToDataUrl(result.blob);
			lastCaptureResult = {
				...result,
				blob: null
			};
			cacheCaptureInSession(lastCaptureDataUrl);
			const payload = {
				width: result.width,
				height: result.height,
				mode: result.mode,
				method: result.method,
				url: result.url,
				title: result.title,
				timestamp: result.timestamp,
				dataUrl: lastCaptureDataUrl
			};
			sendResponse({
				type: "CAPTURE_COMPLETE",
				payload
			});
			let targetTab = senderTabId;
			if (!targetTab) {
				const [activeTab] = await chrome.tabs.query({
					active: true,
					currentWindow: true
				});
				targetTab = activeTab?.id;
			}
			if (targetTab && (mode === "selected-area" || mode === "scrolling-area" || mode === "full-page" || mode === "visible-area")) await showResultBarOnTab(targetTab, payload);
			chrome.runtime.sendMessage({
				type: "CAPTURE_COMPLETE",
				payload
			}).catch(() => {});
		}).catch((error) => {
			sendResponse({
				type: "CAPTURE_ERROR",
				payload: { message: error.message }
			});
		});
		return true;
	}
	if (message.type === "GET_LAST_CAPTURE") {
		sendResponse({
			result: lastCaptureResult,
			hasBlob: !!lastCaptureBlob
		});
		return true;
	}
	if (message.type === "EXPORT_CAPTURE") {
		const { format } = message.payload;
		if (lastCaptureBlob) handleExport(lastCaptureBlob, lastCaptureResult, format).then((result) => sendResponse(result));
		else sendResponse({ error: "No capture available" });
		return true;
	}
	if (message.type === "GET_CAPTURE_BLOB_URL") {
		if (lastCaptureDataUrl) sendResponse({ url: lastCaptureDataUrl });
		else chrome.storage.session.get("lastCaptureDataUrl").then((s) => {
			const recovered = s.lastCaptureDataUrl ?? null;
			if (recovered) lastCaptureDataUrl = recovered;
			sendResponse({ url: recovered });
		}).catch(() => sendResponse({ url: null }));
		return true;
	}
	if (message.type === "OPEN_EDITOR") {
		const editorUrl = chrome.runtime.getURL("editor.html");
		chrome.tabs.create({ url: editorUrl });
		sendResponse({ opened: true });
		return true;
	}
	if (message.type === "INIT_INTERACTIVE_MODE") {
		const { mode, tabId } = message.payload;
		initInteractiveMode(mode, tabId);
		sendResponse({ started: true });
		return true;
	}
	if (message.type === "SCROLLING_REGION_SELECTED") {
		const { speed } = message.payload;
		const tabId = sender.tab?.id;
		if (!tabId) {
			sendResponse({ started: false });
			return false;
		}
		sanitizeRegion(tabId, message.payload?.region).then((region) => {
			if (!region) return;
			return captureScrollingArea(tabId, region, speed || "medium", (progress) => {
				chrome.tabs.sendMessage(tabId, {
					type: "SCROLLING_PROGRESS",
					payload: progress
				}).catch(() => {});
			}).then(async (result) => {
				lastCaptureBlob = result.blob;
				lastCaptureDataUrl = await blobToDataUrl(result.blob);
				lastCaptureResult = {
					...result,
					blob: null
				};
				cacheCaptureInSession(lastCaptureDataUrl);
				await showResultBarOnTab(tabId, {
					width: result.width,
					height: result.height,
					mode: result.mode,
					method: result.method
				});
			}).catch((err) => {
				chrome.tabs.sendMessage(tabId, {
					type: "CAPTURE_ERROR_INLINE",
					payload: { message: err.message }
				}).catch(() => {});
			});
		}).catch(() => {});
		sendResponse({ started: true });
		return true;
	}
	if (message.type === "SCROLL_START") {
		const tabId = sender.tab?.id;
		if (!tabId) {
			sendResponse({ started: false });
			return false;
		}
		activeCapturer?.stop();
		activeCapturer = null;
		sanitizeRegion(tabId, message.payload?.region).then((region) => {
			if (!region) {
				sendResponse({ started: false });
				return;
			}
			return createScrollCapturer(tabId, region, (progress) => {
				chrome.tabs.sendMessage(tabId, {
					type: "SCROLL_PROGRESS",
					payload: progress
				}).catch(() => {});
			}).then((capturer) => {
				activeCapturer = capturer;
				sendResponse({ started: true });
			});
		}).catch(() => sendResponse({ started: false }));
		return true;
	}
	if (message.type === "SCROLL_POLL") {
		if (!activeCapturer) {
			sendResponse({ progress: null });
			return false;
		}
		activeCapturer.poll().then((progress) => sendResponse({ progress }));
		return true;
	}
	if (message.type === "SCROLL_STOP") {
		activeCapturer?.stop();
		activeCapturer = null;
		sendResponse({ stopped: true });
		return false;
	}
	if (message.type === "SCROLL_FINISH") {
		const tabId = sender.tab?.id;
		if (!tabId || !activeCapturer) {
			sendResponse({ success: false });
			return false;
		}
		const capturer = activeCapturer;
		activeCapturer = null;
		capturer.finish().then(async (result) => {
			if (!result) {
				sendResponse({ success: false });
				return;
			}
			lastCaptureBlob = result.blob;
			lastCaptureDataUrl = await blobToDataUrl(result.blob);
			lastCaptureResult = {
				...result,
				blob: null
			};
			cacheCaptureInSession(lastCaptureDataUrl);
			await showResultBarOnTab(tabId, {
				width: result.width,
				height: result.height,
				mode: result.mode,
				method: result.method
			});
			sendResponse({ success: true });
		}).catch((err) => sendResponse({
			success: false,
			error: err.message
		}));
		return true;
	}
	if (message.type === "EXECUTE_OCR") {
		const { region } = message.payload;
		const tabId = sender.tab?.id;
		if (!tabId) {
			sendResponse({ error: "No active tab" });
			return false;
		}
		captureSelectedArea(tabId, region).then(async (result) => {
			const dataUrl = await blobToDataUrl(result.blob);
			await ensureOffscreenDocument();
			const ocrResp = await chrome.runtime.sendMessage({
				type: "PERFORM_OCR",
				payload: { dataUrl }
			});
			if (ocrResp?.error) sendResponse({ error: ocrResp.error });
			else sendResponse({ text: ocrResp?.text || "" });
		}).catch((err) => {
			console.error("OCR execution error:", err);
			sendResponse({ error: err.message || "OCR failed" });
		});
		return true;
	}
	return false;
});
chrome.commands.onCommand.addListener(async (command) => {
	const [tab] = await chrome.tabs.query({
		active: true,
		currentWindow: true
	});
	if (!tab?.id) return;
	if (command === "capture-full-page") try {
		const result = await captureFullPage(tab.id);
		lastCaptureBlob = result.blob;
		lastCaptureDataUrl = await blobToDataUrl(result.blob);
		lastCaptureResult = {
			...result,
			blob: null
		};
		await handleExport(result.blob, result, "png");
	} catch (e) {
		console.error("Keyboard shortcut capture failed:", e);
	}
	if (command === "capture-visible") try {
		const result = await captureVisibleArea(tab.id);
		lastCaptureBlob = result.blob;
		lastCaptureDataUrl = await blobToDataUrl(result.blob);
		lastCaptureResult = {
			...result,
			blob: null
		};
		await handleExport(result.blob, result, "png");
	} catch (e) {
		console.error("Keyboard shortcut capture failed:", e);
	}
	if (command === "capture-selected-area") await chrome.tabs.sendMessage(tab.id, {
		type: "INIT_REGION_SELECTOR",
		payload: {
			mode: "selected-area",
			tabId: tab.id
		}
	}).catch(() => {});
});
async function handleCapture(mode, region, speed, explicitTabId) {
	let targetTabId = explicitTabId;
	let tab;
	if (targetTabId) try {
		tab = await chrome.tabs.get(targetTabId);
	} catch {}
	if (!tab) {
		const [activeTab] = await chrome.tabs.query({
			active: true,
			currentWindow: true
		});
		tab = activeTab;
		targetTabId = tab?.id;
	}
	if (!tab?.id) throw new Error("No active tab");
	const tabUrl = tab.url || "";
	const support = isSupportedCapturePage(tabUrl);
	if (!support.supported) throw new Error(support.message || "This page cannot be captured.");
	if (mode === "full-page" || mode === "scrolling-area") await injectContentScripts(tab.id);
	const sendProgress = (progress) => {
		chrome.runtime.sendMessage({
			type: "CAPTURE_PROGRESS",
			payload: progress
		}).catch(() => {});
	};
	switch (mode) {
		case "full-page": return captureFullPage(targetTabId, sendProgress);
		case "visible-area": return captureVisibleArea(targetTabId);
		case "selected-area":
			if (!region) throw new Error("Region required for selected-area mode");
			return captureSelectedArea(targetTabId, region);
		case "scrolling-area":
			if (!region) throw new Error("Region required for scrolling-area mode");
			return captureScrollingArea(targetTabId, region, speed || "medium", sendProgress);
		default: throw new Error(`Unknown capture mode: ${mode}`);
	}
}
async function initInteractiveMode(mode, tabId) {
	try {
		const tab = await chrome.tabs.get(tabId);
		const support = isSupportedCapturePage(tab.url || "");
		if (!support.supported) {
			chrome.runtime.sendMessage({
				type: "CAPTURE_ERROR",
				payload: { message: support.message || "Cannot capture this type of page." }
			}).catch(() => {});
			return;
		}
		await injectContentScripts(tabId);
		if (mode === "selected-area") {
			await chrome.scripting.executeScript({
				target: { tabId },
				files: ["region-selector.js"]
			});
			await sleep(100);
			await chrome.tabs.sendMessage(tabId, {
				type: "START_REGION_SELECT_MODE",
				payload: { tabId }
			});
		}
		if (mode === "scrolling-area") {
			await chrome.scripting.executeScript({
				target: { tabId },
				files: ["scrolling-area-ui.js"]
			});
			await sleep(100);
			await chrome.tabs.sendMessage(tabId, {
				type: "START_SCROLLING_AREA_MODE",
				payload: { tabId }
			});
		}
		if (mode === "capture-text") {
			await chrome.scripting.executeScript({
				target: { tabId },
				files: ["ocr-overlay.js"]
			});
			await sleep(100);
			await chrome.tabs.sendMessage(tabId, {
				type: "START_OCR_MODE",
				payload: { tabId }
			});
		}
	} catch (err) {
		console.error("initInteractiveMode failed:", err);
	}
}
function sleep(ms) {
	return new Promise((r) => setTimeout(r, ms));
}
async function showResultBarOnTab(tabId, payload) {
	try {
		await chrome.scripting.executeScript({
			target: { tabId },
			files: ["result-bar.js"]
		}).catch(() => {});
		await chrome.scripting.executeScript({
			target: { tabId },
			func: (info) => {
				if (typeof window.__snapforge_show_result_bar === "function") window.__snapforge_show_result_bar(info);
			},
			args: [payload]
		}).catch(() => {});
		await chrome.tabs.sendMessage(tabId, {
			type: "SHOW_RESULT_BAR",
			payload
		}).catch(() => {});
	} catch (err) {
		console.error("showResultBarOnTab failed:", err);
	}
}
async function injectContentScripts(tabId) {
	try {
		await chrome.scripting.executeScript({
			target: { tabId },
			files: [
				"page-analyzer.js",
				"sticky-manager.js",
				"lazy-loader.js"
			]
		});
	} catch {}
}
async function handleExport(blob, result, format) {
	try {
		switch (format) {
			case "clipboard": return { success: true };
			case "png": {
				const filename = generateFilename(getDomain(result.url), "png");
				const dataUrl = await blobToDataUrl(blob);
				await chrome.downloads.download({
					url: dataUrl,
					filename,
					saveAs: false
				});
				return { success: true };
			}
			case "pdf": {
				const filename = generateFilename(getDomain(result.url), "pdf");
				const pdfDataUrl = await blobToDataUrl(await generatePDF(blob, "a4"));
				await chrome.downloads.download({
					url: pdfDataUrl,
					filename,
					saveAs: false
				});
				return { success: true };
			}
			default: return {
				success: false,
				error: `Unknown format: ${format}`
			};
		}
	} catch (e) {
		return {
			success: false,
			error: e.message
		};
	}
}
function getDomain(url) {
	try {
		return new URL(url).hostname;
	} catch {
		return "unknown";
	}
}
function generateFilename(domain, ext) {
	const ts = (/* @__PURE__ */ new Date()).toISOString().replace(/[-:T]/g, "").slice(0, 14);
	return `gofully-${domain.replace(/[^a-zA-Z0-9.-]/g, "_").slice(0, 50)}-${ts}.${ext}`;
}
//#endregion
