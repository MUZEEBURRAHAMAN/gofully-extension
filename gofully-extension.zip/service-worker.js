import { t as DEFAULT_SETTINGS } from "./chunks/types-BTm3mIuc.js";
import { a as loadImage, r as dataUrlToBlob$1, t as canvasToBlob } from "./chunks/image-BPYnapgS.js";
import { a as generatePDF, i as recordCaptureCompleted } from "./chunks/rate-nudge-Dw76hDuh.js";
import { t as isSupportedCapturePage } from "./chunks/url-validator-CInVwRGC.js";
//#region src/utils/dpr-handler.ts
function detectDPRFromCapture(capturedWidth, cssWidth) {
	if (cssWidth === 0) return 1;
	return capturedWidth / cssWidth;
}
//#endregion
//#region src/background/stitch-capture.ts
var CAPTURE_DELAY = 300;
var isCaptureCancelled = false;
function cancelActiveCapture() {
	isCaptureCancelled = true;
}
async function captureWithScrollStitch(tabId, dimensions, onProgress) {
	isCaptureCancelled = false;
	const tab = await chrome.tabs.get(tabId).catch(() => null);
	const windowId = tab?.windowId;
	if (windowId) await chrome.tabs.update(tabId, { active: true }).catch(() => {});
	await chrome.tabs.sendMessage(tabId, {
		type: "PRE_SCROLL_LAZY",
		payload: { maxWait: 1500 }
	}).catch(() => {});
	const pageInit = await initScrollCapture(tabId);
	let scrollHeight = Math.max(dimensions.scrollHeight, pageInit.scrollHeight);
	const viewportHeight = pageInit.viewportHeight || dimensions.viewportHeight || 800;
	const viewportWidth = pageInit.viewportWidth || dimensions.viewportWidth || 1280;
	const frames = [];
	let dpr = dimensions.devicePixelRatio || 1;
	const maxSteps = Math.min(150, Math.ceil(scrollHeight / (viewportHeight * .5)) + 10);
	let coveredY = 0;
	let lastFrameHash = "";
	let lastScrollY = -1;
	await chrome.tabs.sendMessage(tabId, { type: "CAPTURE_KEEPALIVE_START" }).catch(() => {});
	try {
		await performScroll(tabId, 0, pageInit.targetSelector);
		await sleep$3(250);
		const initialScroll = await getActualScrollPosition(tabId, pageInit.targetSelector);
		if (initialScroll.docHeight && initialScroll.docHeight > scrollHeight) scrollHeight = initialScroll.docHeight;
		await hideProgressInTab(tabId);
		const firstDataUrl = await captureWithRetry(windowId);
		dpr = detectDPRFromCapture((await loadImage(firstDataUrl)).width, viewportWidth);
		lastFrameHash = await hashFrame$1(firstDataUrl);
		lastScrollY = 0;
		const frame0Height = Math.min(viewportHeight, scrollHeight);
		frames.push({
			dataUrl: firstDataUrl,
			x: 0,
			y: 0,
			width: viewportWidth,
			height: viewportHeight,
			scrollX: 0,
			scrollY: 0,
			cropY: 0,
			cropHeight: frame0Height,
			dstY: 0
		});
		coveredY = frame0Height;
		onProgress?.({
			current: 1,
			total: Math.max(1, Math.ceil(scrollHeight / viewportHeight)),
			phase: "capturing"
		});
		if (scrollHeight > viewportHeight) {
			if (((await chrome.storage.sync?.get("settings").catch(() => null) || await chrome.storage.local.get("settings").catch(() => null))?.settings)?.skipStickyHeaders ?? true) {
				await chrome.tabs.sendMessage(tabId, { type: "HIDE_STICKY" }).catch(() => {});
				await sleep$3(50);
			}
			let step = 0;
			while (coveredY < scrollHeight && step < maxSteps) {
				if (isCaptureCancelled) break;
				step++;
				const remaining = scrollHeight - coveredY;
				if (remaining <= 0) break;
				let targetY;
				let isLastStep = false;
				if (remaining >= viewportHeight) targetY = coveredY;
				else {
					targetY = Math.max(0, scrollHeight - viewportHeight);
					isLastStep = true;
				}
				await performScroll(tabId, targetY, pageInit.targetSelector);
				await sleep$3(CAPTURE_DELAY);
				const scrollInfo = await getActualScrollPosition(tabId, pageInit.targetSelector);
				if (scrollInfo.docHeight && scrollInfo.docHeight > scrollHeight) scrollHeight = scrollInfo.docHeight;
				if (Math.abs(scrollInfo.currentY - lastScrollY) < 1 && step > 1) break;
				await hideProgressInTab(tabId);
				const dataUrl = await captureWithRetry(windowId);
				const currentHash = await hashFrame$1(dataUrl);
				if (currentHash === lastFrameHash && step > 1) break;
				lastFrameHash = currentHash;
				lastScrollY = scrollInfo.currentY;
				if (!isLastStep) {
					frames.push({
						dataUrl,
						x: 0,
						y: coveredY,
						width: viewportWidth,
						height: viewportHeight,
						scrollX: 0,
						scrollY: scrollInfo.currentY,
						cropY: 0,
						cropHeight: viewportHeight,
						dstY: coveredY
					});
					coveredY += viewportHeight;
				} else {
					const cropY = Math.max(0, viewportHeight - remaining);
					frames.push({
						dataUrl,
						x: 0,
						y: coveredY,
						width: viewportWidth,
						height: viewportHeight,
						scrollX: 0,
						scrollY: scrollInfo.currentY,
						cropY,
						cropHeight: remaining,
						dstY: coveredY
					});
					coveredY += remaining;
					break;
				}
				onProgress?.({
					current: step + 1,
					total: Math.max(1, Math.ceil(scrollHeight / viewportHeight)),
					phase: "capturing"
				});
				if (scrollInfo.isAtBottom) break;
			}
		}
	} finally {
		await chrome.tabs.sendMessage(tabId, { type: "RESTORE_STICKY" }).catch(() => {});
		await cleanupScrollCapture(tabId, pageInit.initialScrollY, pageInit.targetSelector).catch(() => {});
		await chrome.tabs.sendMessage(tabId, { type: "CAPTURE_KEEPALIVE_STOP" }).catch(() => {});
		onProgress?.({
			current: 0,
			total: 0,
			phase: "done"
		});
	}
	onProgress?.({
		current: 0,
		total: 0,
		phase: "stitching"
	});
	const totalWidth = viewportWidth;
	const actualHeight = calculateStitchedHeight(frames, viewportHeight);
	return {
		blob: await stitchFrames$1(frames, totalWidth, actualHeight, dpr),
		width: Math.round(totalWidth * dpr),
		height: Math.round(actualHeight * dpr),
		mode: "full-page",
		method: "scroll-stitch",
		timestamp: Date.now(),
		url: tab?.url || "",
		title: tab?.title || ""
	};
}
async function hideProgressInTab(tabId) {
	await chrome.scripting.executeScript({
		target: { tabId },
		func: () => {
			const el = document.getElementById("gofully-progress-overlay");
			if (el) el.style.setProperty("display", "none", "important");
		}
	}).catch(() => {});
}
async function initScrollCapture(tabId) {
	const [{ result }] = await chrome.scripting.executeScript({
		target: { tabId },
		func: () => {
			const initialScrollY = window.scrollY || (document.scrollingElement ? document.scrollingElement.scrollTop : 0) || document.documentElement.scrollTop || document.body.scrollTop || 0;
			const styleEl = document.createElement("style");
			styleEl.id = "__gf_no_smooth_scroll";
			styleEl.textContent = "* { scroll-behavior: auto !important; }";
			(document.head || document.documentElement).appendChild(styleEl);
			const html = document.documentElement;
			const body = document.body;
			const htmlCs = window.getComputedStyle(html);
			const bodyCs = window.getComputedStyle(body);
			if (htmlCs.overflowY === "hidden") html.style.setProperty("overflow-y", "auto", "important");
			if (bodyCs.overflowY === "hidden") body.style.setProperty("overflow-y", "auto", "important");
			let docHeight = Math.max(body.scrollHeight, body.offsetHeight, html.clientHeight, html.scrollHeight, html.offsetHeight);
			const origY = window.scrollY || (document.scrollingElement ? document.scrollingElement.scrollTop : 0);
			window.scrollTo({
				top: origY + 5,
				behavior: "instant"
			});
			const testY = window.scrollY || (document.scrollingElement ? document.scrollingElement.scrollTop : 0);
			const windowCanScroll = Math.abs(testY - origY) >= 1;
			window.scrollTo({
				top: origY,
				behavior: "instant"
			});
			let targetSelector = null;
			let scrollHeight = docHeight;
			if (!windowCanScroll) {
				const all = document.querySelectorAll("*");
				let bestContainer = null;
				let maxH = 0;
				for (const el of all) {
					if (el === html || el === body) continue;
					const cs = getComputedStyle(el);
					if ((cs.overflowY === "auto" || cs.overflowY === "scroll") && el.scrollHeight > el.clientHeight + 20 && el.scrollHeight > maxH) {
						maxH = el.scrollHeight;
						bestContainer = el;
					}
				}
				if (bestContainer) {
					bestContainer.setAttribute("data-gf-scroll-target", "1");
					targetSelector = "[data-gf-scroll-target='1']";
					scrollHeight = maxH;
				}
			}
			return {
				initialScrollY,
				scrollHeight,
				viewportHeight: window.innerHeight,
				viewportWidth: window.innerWidth,
				targetSelector
			};
		}
	});
	return result;
}
async function performScroll(tabId, targetY, targetSelector) {
	await chrome.scripting.executeScript({
		target: { tabId },
		func: (y, selector) => {
			if (selector) {
				const el = document.querySelector(selector);
				if (el) {
					el.scrollTo({
						top: y,
						left: 0,
						behavior: "instant"
					});
					el.scrollTop = y;
					el.dispatchEvent(new Event("scroll"));
					return;
				}
			}
			window.scrollTo({
				top: y,
				left: 0,
				behavior: "instant"
			});
			if (document.scrollingElement) document.scrollingElement.scrollTop = y;
			document.documentElement.scrollTop = y;
			document.body.scrollTop = y;
			window.dispatchEvent(new Event("scroll"));
		},
		args: [targetY, targetSelector]
	});
}
async function getActualScrollPosition(tabId, targetSelector) {
	const [{ result }] = await chrome.scripting.executeScript({
		target: { tabId },
		func: (selector) => {
			if (selector) {
				const el = document.querySelector(selector);
				if (el) {
					const maxScroll = el.scrollHeight - el.clientHeight;
					return {
						currentY: el.scrollTop,
						isAtBottom: el.scrollTop >= maxScroll - 4,
						docHeight: el.scrollHeight
					};
				}
			}
			const currentY = window.scrollY || (document.scrollingElement ? document.scrollingElement.scrollTop : 0) || document.documentElement.scrollTop || document.body.scrollTop || 0;
			const docHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight, document.documentElement.offsetHeight);
			return {
				currentY,
				isAtBottom: currentY >= docHeight - window.innerHeight - 4,
				docHeight
			};
		},
		args: [targetSelector]
	});
	return result;
}
async function cleanupScrollCapture(tabId, initialScrollY, targetSelector) {
	await chrome.scripting.executeScript({
		target: { tabId },
		func: (initY, selector) => {
			if (selector) {
				const el = document.querySelector(selector);
				if (el) {
					el.scrollTop = initY;
					el.removeAttribute("data-gf-scroll-target");
				}
			}
			window.scrollTo({
				top: initY,
				left: 0,
				behavior: "instant"
			});
			if (document.scrollingElement) document.scrollingElement.scrollTop = initY;
			document.documentElement.scrollTop = initY;
			document.body.scrollTop = initY;
			document.getElementById("__gf_no_smooth_scroll")?.remove();
			const html = document.documentElement;
			const body = document.body;
			const origHtml = window.__gfOrigHtmlScrollBehavior;
			const origBody = window.__gfOrigBodyScrollBehavior;
			if (origHtml) html.style.scrollBehavior = origHtml;
			else html.style.removeProperty("scroll-behavior");
			if (origBody) body.style.scrollBehavior = origBody;
			else body.style.removeProperty("scroll-behavior");
			delete window.__gfOrigHtmlScrollBehavior;
			delete window.__gfOrigBodyScrollBehavior;
		},
		args: [initialScrollY, targetSelector]
	}).catch(() => {});
}
function calculateStitchedHeight(frames, fallbackHeight) {
	if (frames.length === 0) return fallbackHeight;
	let maxH = 0;
	for (const f of frames) {
		const endY = (f.dstY ?? f.scrollY) + (f.cropHeight ?? f.height);
		if (endY > maxH) maxH = endY;
	}
	return maxH || fallbackHeight;
}
async function stitchFrames$1(frames, totalWidth, totalHeight, dpr) {
	if (frames.length === 0) {
		const emptyCanvas = new OffscreenCanvas(100, 100);
		return canvasToBlob(emptyCanvas);
	}
	const canvasWidth = Math.round(totalWidth * dpr);
	const canvasHeight = Math.round(totalHeight * dpr);
	const canvas = new OffscreenCanvas(canvasWidth, canvasHeight);
	const ctx = canvas.getContext("2d", { alpha: false });
	ctx.fillStyle = "#ffffff";
	ctx.fillRect(0, 0, canvasWidth, canvasHeight);
	for (let fi = 0; fi < frames.length; fi++) {
		const frame = frames[fi];
		const img = await loadImage(frame.dataUrl);
		const frameDpr = img.width / frame.width;
		const cropY = Math.round((frame.cropY ?? 0) * frameDpr);
		const cropH = Math.round((frame.cropHeight ?? frame.height) * frameDpr);
		const dstY = Math.round((frame.dstY ?? frame.scrollY) * dpr);
		const dstH = Math.round((frame.cropHeight ?? frame.height) * dpr);
		const dstW = Math.min(canvasWidth, img.width);
		if (dstH <= 0 || cropH <= 0 || dstY >= canvasHeight) continue;
		const actualCropH = Math.min(cropH, img.height - cropY);
		const actualDstH = Math.min(dstH, canvasHeight - dstY);
		ctx.drawImage(img, 0, cropY, img.width, actualCropH, 0, dstY, dstW, actualDstH);
	}
	return canvasToBlob(canvas);
}
async function hashFrame$1(dataUrl) {
	const img = await loadImage(dataUrl);
	const ctx = new OffscreenCanvas(16, 16).getContext("2d");
	ctx.drawImage(img, 0, 0, 16, 16);
	const data = ctx.getImageData(0, 0, 16, 16).data;
	let hash = 0;
	for (let i = 0; i < data.length; i += 4) {
		hash = (hash << 5) - hash + data[i] | 0;
		hash = (hash << 5) - hash + data[i + 1] | 0;
		hash = (hash << 5) - hash + data[i + 2] | 0;
	}
	return hash.toString(36);
}
async function captureWithRetry(windowId, maxRetries = 3) {
	for (let i = 0; i < maxRetries; i++) try {
		if (typeof windowId === "number") return await chrome.tabs.captureVisibleTab(windowId, { format: "png" });
		return await chrome.tabs.captureVisibleTab({ format: "png" });
	} catch (e) {
		if (e?.message?.includes("MAX_CAPTURE") && i < maxRetries - 1) {
			await sleep$3(1e3);
			continue;
		}
		if (i < maxRetries - 1) {
			await sleep$3(300);
			continue;
		}
		throw e;
	}
	return typeof windowId === "number" ? await chrome.tabs.captureVisibleTab(windowId, { format: "png" }) : await chrome.tabs.captureVisibleTab({ format: "png" });
}
function sleep$3(ms) {
	return new Promise((r) => setTimeout(r, ms));
}
//#endregion
//#region src/background/capture-engine.ts
async function captureFullPage(tabId, onProgress) {
	onProgress?.({
		phase: "preparing",
		current: 1,
		total: 3
	});
	const dimensions = await prepareFullPageLayout(tabId);
	try {
		await restoreFullPageLayout(tabId);
		return await captureWithScrollStitch(tabId, dimensions, onProgress);
	} finally {
		await restoreFullPageLayout(tabId);
	}
}
async function captureVisibleArea(tabId, onProgress) {
	onProgress?.({
		phase: "capturing",
		current: 1,
		total: 1
	});
	const tab = await chrome.tabs.get(tabId);
	if (tab.windowId) await chrome.tabs.update(tabId, { active: true }).catch(() => {});
	const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
	const blob = dataUrlToBlob$1(dataUrl);
	const img = await loadImage(dataUrl);
	onProgress?.({
		phase: "done",
		current: 1,
		total: 1
	});
	return {
		blob,
		width: img.width,
		height: img.height,
		mode: "visible-area",
		method: "visible-tab",
		timestamp: Date.now(),
		url: tab.url || "",
		title: tab.title || ""
	};
}
async function captureSelectedArea(tabId, region) {
	const tab = await chrome.tabs.get(tabId);
	if (tab.windowId) await chrome.tabs.update(tabId, { active: true }).catch(() => {});
	const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
	const img = await loadImage(dataUrl);
	const [{ result: vpWidth }] = await chrome.scripting.executeScript({
		target: { tabId },
		func: () => window.innerWidth
	});
	const dpr = detectDPRFromCapture(img.width, vpWidth || img.width);
	const sx = Math.round(region.x * dpr);
	const sy = Math.round(region.y * dpr);
	const sw = Math.round(region.width * dpr);
	const sh = Math.round(region.height * dpr);
	const canvas = new OffscreenCanvas(sw, sh);
	canvas.getContext("2d").drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
	return {
		blob: await canvas.convertToBlob({ type: "image/png" }),
		width: sw,
		height: sh,
		mode: "selected-area",
		method: "visible-tab",
		timestamp: Date.now(),
		url: tab.url || "",
		title: tab.title || ""
	};
}
/**
* Measures the page and — for the common SPA layout where <html>/<body> are
* pinned to 100vh with overflow:hidden and the real content scrolls inside a
* nested container — temporarily forces that container (and any overflow-
* hidden ancestors up to <body>) to lay out at its full natural height.
*
* Without this, document.body/documentElement.scrollHeight report only one
* viewport of height on such pages (the document genuinely is only that
* tall; the overflow is happening inside a child), so the scroll-stitch
* capture would only ever produce a viewport-sized screenshot no matter how
* "full page" capture is invoked. Ordinary pages
* where body/html itself is the scrolling element are untouched by this —
* the expansion only runs when body/html scrollHeight doesn't already
* exceed one viewport.
*/
async function prepareFullPageLayout(tabId) {
	const [{ result }] = await chrome.scripting.executeScript({
		target: { tabId },
		func: () => {
			const body = document.body;
			const html = document.documentElement;
			const viewportHeight = window.innerHeight;
			const bodyScrollHeight = Math.max(body.scrollHeight, body.offsetHeight, html.clientHeight, html.scrollHeight, html.offsetHeight);
			let innerContainer = null;
			let innerHeight = 0;
			if (bodyScrollHeight <= viewportHeight + 4) {
				const all = document.querySelectorAll("*");
				for (const el of all) {
					const cs = getComputedStyle(el);
					if ((cs.overflowY === "auto" || cs.overflowY === "scroll") && el.scrollHeight > el.clientHeight + 40 && el.scrollHeight > innerHeight) {
						innerHeight = el.scrollHeight;
						innerContainer = el;
					}
				}
			}
			const restore = [];
			const forceExpand = (el) => {
				restore.push({
					el,
					prop: "overflow",
					value: el.style.overflow
				});
				restore.push({
					el,
					prop: "height",
					value: el.style.height
				});
				restore.push({
					el,
					prop: "maxHeight",
					value: el.style.maxHeight
				});
				el.style.setProperty("overflow", "visible", "important");
				el.style.setProperty("height", "auto", "important");
				el.style.setProperty("max-height", "none", "important");
			};
			if (innerContainer) {
				forceExpand(html);
				forceExpand(body);
				forceExpand(innerContainer);
				let p = innerContainer.parentElement;
				while (p && p !== body) {
					const pcs = getComputedStyle(p);
					if (pcs.overflow !== "visible" || pcs.height === "0px") forceExpand(p);
					p = p.parentElement;
				}
			}
			window.__gfRestoreLayout = restore;
			return {
				scrollWidth: Math.max(body.scrollWidth, body.offsetWidth, html.clientWidth, html.scrollWidth, html.offsetWidth),
				scrollHeight: Math.max(bodyScrollHeight, document.documentElement.scrollHeight, document.body.scrollHeight, innerHeight),
				viewportWidth: window.innerWidth,
				viewportHeight,
				devicePixelRatio: window.devicePixelRatio || 1
			};
		}
	});
	return result;
}
async function restoreFullPageLayout(tabId) {
	await chrome.scripting.executeScript({
		target: { tabId },
		func: () => {
			const restore = window.__gfRestoreLayout;
			if (!restore) return;
			for (const r of restore) if (r.value) r.el.style[r.prop] = r.value;
			else r.el.style.removeProperty(r.prop === "maxHeight" ? "max-height" : r.prop);
			delete window.__gfRestoreLayout;
		}
	}).catch(() => {});
}
//#endregion
//#region src/capture-modes/scrolling-area.ts
var SPEED_MAP = {
	slow: 1e3,
	medium: 700,
	fast: 500
};
var MAX_FRAMES$1 = 100;
async function captureScrollingArea(tabId, region, speed, onProgress) {
	const frames = [];
	const frameScrollYs = [];
	const delay = SPEED_MAP[speed];
	onProgress?.({
		current: 0,
		total: 0,
		phase: "preparing"
	});
	await findAndTagScrollContainer(tabId, region);
	const pageState = await getPageState(tabId);
	const scrollStep = Math.max(50, Math.floor(region.height * .85));
	const estimatedSteps = Math.ceil((pageState.scrollHeight - pageState.scrollY) / scrollStep);
	let dpr = 1;
	let lastFrameHash = "";
	let step = 0;
	try {
		const firstFrame = await captureFrame(tabId, region);
		if (!firstFrame) throw new Error("Failed to capture first frame");
		dpr = detectDPRFromCapture((await loadImage(firstFrame.dataUrl)).width, region.width);
		if (dpr === 0) dpr = 1;
		frames.push(firstFrame);
		frameScrollYs.push(pageState.scrollY);
		lastFrameHash = await hashFrame(firstFrame.dataUrl);
		step++;
		onProgress?.({
			current: step,
			total: estimatedSteps,
			phase: "capturing"
		});
		let lastScrollY = pageState.scrollY;
		let consecutiveFails = 0;
		while (frames.length < MAX_FRAMES$1) {
			const scrollResult = await scrollPage(tabId, scrollStep);
			if (Math.abs(scrollResult.current - lastScrollY) < 2) {
				const finalFrame = await captureFrame(tabId, region);
				if (finalFrame) {
					if (await hashFrame(finalFrame.dataUrl) !== lastFrameHash) {
						frames.push(finalFrame);
						frameScrollYs.push(scrollResult.current);
					}
				}
				break;
			}
			if (scrollResult.current >= scrollResult.maxScroll) {
				const finalFrame = await captureFrame(tabId, region);
				if (finalFrame) {
					if (await hashFrame(finalFrame.dataUrl) !== lastFrameHash) {
						frames.push(finalFrame);
						frameScrollYs.push(scrollResult.current);
					}
				}
				break;
			}
			lastScrollY = scrollResult.current;
			await sleep$2(delay);
			await waitForPageStable(tabId);
			const frame = await captureFrame(tabId, region);
			if (!frame) {
				consecutiveFails++;
				if (consecutiveFails >= 3) break;
				continue;
			}
			consecutiveFails = 0;
			const hash = await hashFrame(frame.dataUrl);
			if (hash === lastFrameHash) break;
			frames.push(frame);
			frameScrollYs.push(scrollResult.current);
			lastFrameHash = hash;
			step++;
			onProgress?.({
				current: step,
				total: estimatedSteps,
				phase: "capturing"
			});
		}
		await restoreScroll(tabId, pageState.scrollY);
	} finally {
		await showAllExtensionUI(tabId);
		untagScrollContainer(tabId);
	}
	if (frames.length === 0) throw new Error("No frames were captured");
	onProgress?.({
		current: 0,
		total: 0,
		phase: "stitching"
	});
	const blob = await stitchFrames(frames, dpr, frameScrollYs);
	const tab = await chrome.tabs.get(tabId);
	const stitchedImg = await loadImage(await blobToDataUrl$2(blob));
	const actualWidth = stitchedImg.width;
	const actualHeight = stitchedImg.height;
	onProgress?.({
		current: 0,
		total: 0,
		phase: "done"
	});
	return {
		blob,
		width: actualWidth,
		height: actualHeight,
		mode: "scrolling-area",
		method: "scroll-stitch",
		timestamp: Date.now(),
		url: tab.url || "",
		title: tab.title || ""
	};
}
var TARGET_ATTR = "data-gf-scroll-target";
async function findAndTagScrollContainer(tabId, region) {
	try {
		await chrome.scripting.executeScript({
			target: { tabId },
			func: (attr, rx, ry, rw, rh) => {
				const cx = rx + rw / 2;
				const cy = ry + rh / 2;
				let el = document.elementFromPoint(cx, cy);
				while (el && el !== document.body && el !== document.documentElement) {
					const style = getComputedStyle(el);
					if ((style.overflowY === "auto" || style.overflowY === "scroll") && el.scrollHeight > el.clientHeight + 2) {
						el.setAttribute(attr, "1");
						return;
					}
					el = el.parentElement;
				}
			},
			args: [
				TARGET_ATTR,
				region.x,
				region.y,
				region.width,
				region.height
			]
		});
	} catch {}
}
function untagScrollContainer(tabId) {
	chrome.scripting.executeScript({
		target: { tabId },
		func: (attr) => document.querySelector(`[${attr}]`)?.removeAttribute(attr),
		args: [TARGET_ATTR]
	}).catch(() => {});
}
async function getPageState(tabId) {
	const [{ result }] = await chrome.scripting.executeScript({
		target: { tabId },
		func: (attr) => {
			const el = document.querySelector(`[${attr}]`);
			if (el) return {
				scrollHeight: el.scrollHeight,
				scrollY: el.scrollTop,
				viewportHeight: el.clientHeight
			};
			return {
				scrollHeight: Math.max(document.body.scrollHeight, document.documentElement.scrollHeight),
				scrollY: window.scrollY,
				viewportHeight: window.innerHeight
			};
		},
		args: [TARGET_ATTR]
	});
	return result;
}
async function scrollPage(tabId, dy) {
	const [{ result }] = await chrome.scripting.executeScript({
		target: { tabId },
		func: (attr, step) => {
			const el = document.querySelector(`[${attr}]`);
			if (el) {
				const prev = el.scrollTop;
				el.scrollBy({
					top: step,
					behavior: "instant"
				});
				return {
					prev,
					current: el.scrollTop,
					maxScroll: el.scrollHeight - el.clientHeight
				};
			}
			const prev = window.scrollY;
			window.scrollBy({
				top: step,
				behavior: "instant"
			});
			return {
				prev,
				current: window.scrollY,
				maxScroll: Math.max(document.body.scrollHeight, document.documentElement.scrollHeight) - window.innerHeight
			};
		},
		args: [TARGET_ATTR, dy]
	});
	return result;
}
async function restoreScroll(tabId, scrollY) {
	try {
		await chrome.scripting.executeScript({
			target: { tabId },
			func: (attr, y) => {
				const el = document.querySelector(`[${attr}]`);
				if (el) {
					el.scrollTop = y;
					return;
				}
				window.scrollTo({
					top: y,
					behavior: "instant"
				});
			},
			args: [TARGET_ATTR, scrollY]
		});
	} catch {}
}
async function hideAllExtensionUI(tabId) {
	try {
		await chrome.tabs.sendMessage(tabId, {
			type: "SCROLL_UI_VISIBILITY",
			hide: true
		});
	} catch {}
	await forceRepaint(tabId);
	await forceRepaint(tabId);
}
async function showAllExtensionUI(tabId) {
	try {
		await chrome.tabs.sendMessage(tabId, {
			type: "SCROLL_UI_VISIBILITY",
			hide: false
		});
	} catch {}
	await forceRepaint(tabId);
}
async function forceRepaint(tabId) {
	try {
		await chrome.scripting.executeScript({
			target: { tabId },
			func: () => new Promise((resolve) => {
				requestAnimationFrame(() => {
					requestAnimationFrame(() => {
						resolve();
					});
				});
			})
		});
	} catch {
		await sleep$2(120);
	}
}
async function waitForPageStable(tabId) {
	try {
		await chrome.scripting.executeScript({
			target: { tabId },
			func: () => {
				return new Promise((resolve) => {
					const imgs = document.querySelectorAll("img");
					const pending = [];
					const vp = window.innerHeight;
					imgs.forEach((img) => {
						const rect = img.getBoundingClientRect();
						if (rect.top < vp && rect.bottom > 0 && !img.complete && img.src) pending.push(new Promise((r) => {
							img.addEventListener("load", () => r(), { once: true });
							img.addEventListener("error", () => r(), { once: true });
							setTimeout(r, 600);
						}));
					});
					if (pending.length > 0) Promise.all(pending).then(() => {
						requestAnimationFrame(() => requestAnimationFrame(() => resolve()));
					});
					else requestAnimationFrame(() => requestAnimationFrame(() => resolve()));
				});
			}
		});
	} catch {
		await sleep$2(200);
	}
}
async function captureFrame(tabId, region) {
	try {
		const tab = await chrome.tabs.get(tabId).catch(() => null);
		if (tab?.windowId) await chrome.tabs.update(tabId, { active: true }).catch(() => {});
		await hideAllExtensionUI(tabId);
		let dataUrl;
		try {
			dataUrl = await captureVisibleTabWithRetry(tab?.windowId);
		} finally {
			showAllExtensionUI(tabId);
		}
		const img = await loadImage(dataUrl);
		const [{ result: vpWidth }] = await chrome.scripting.executeScript({
			target: { tabId },
			func: () => window.innerWidth
		});
		const dpr = img.width / (vpWidth || img.width);
		const sx = Math.round(region.x * dpr);
		const sy = Math.round(region.y * dpr);
		const sw = Math.round(region.width * dpr);
		const sh = Math.round(region.height * dpr);
		const clampedSx = Math.min(sx, img.width - 1);
		const clampedSy = Math.min(sy, img.height - 1);
		const clampedSw = Math.min(sw, img.width - clampedSx);
		const clampedSh = Math.min(sh, img.height - clampedSy);
		if (clampedSw <= 0 || clampedSh <= 0) return null;
		const canvas = new OffscreenCanvas(clampedSw, clampedSh);
		canvas.getContext("2d").drawImage(img, clampedSx, clampedSy, clampedSw, clampedSh, 0, 0, clampedSw, clampedSh);
		return {
			dataUrl: await blobToDataUrl$2(await canvas.convertToBlob({ type: "image/png" })),
			x: region.x,
			y: region.y,
			width: region.width,
			height: region.height,
			scrollX: 0,
			scrollY: 0
		};
	} catch {
		return null;
	}
}
async function captureVisibleTabWithRetry(windowId, maxRetries = 3) {
	for (let i = 0; i < maxRetries; i++) try {
		return windowId !== void 0 ? await chrome.tabs.captureVisibleTab(windowId, { format: "png" }) : await chrome.tabs.captureVisibleTab({ format: "png" });
	} catch (e) {
		if (e?.message?.includes("MAX_CAPTURE") && i < maxRetries - 1) {
			await sleep$2(1e3);
			continue;
		}
		throw e;
	}
	return windowId !== void 0 ? await chrome.tabs.captureVisibleTab(windowId, { format: "png" }) : await chrome.tabs.captureVisibleTab({ format: "png" });
}
async function stitchFrames(frames, dpr, scrollYs) {
	if (frames.length === 0) throw new Error("No frames to stitch");
	const images = await Promise.all(frames.map((f) => loadImage(f.dataUrl)));
	if (images.length === 1) {
		const c = new OffscreenCanvas(images[0].width, images[0].height);
		c.getContext("2d").drawImage(images[0], 0, 0);
		return canvasToBlob(c);
	}
	const frameW = images[0].width;
	const frameH = images[0].height;
	const overlaps = [0];
	for (let i = 1; i < images.length; i++) {
		let ov;
		if (scrollYs && scrollYs.length === images.length) {
			const deltaPx = Math.round((scrollYs[i] - scrollYs[i - 1]) * dpr);
			ov = Math.max(0, Math.min(frameH, frameH - deltaPx));
		} else ov = await findOverlap(images[i - 1], images[i], frameW, frameH);
		overlaps.push(ov);
	}
	let totalH = frameH;
	for (let i = 1; i < images.length; i++) totalH += frameH - overlaps[i];
	const canvas = new OffscreenCanvas(frameW, totalH);
	const ctx = canvas.getContext("2d");
	ctx.drawImage(images[0], 0, 0);
	let y = frameH;
	for (let i = 1; i < images.length; i++) {
		const newRows = frameH - overlaps[i];
		if (newRows <= 0) continue;
		ctx.drawImage(images[i], 0, overlaps[i], frameW, newRows, 0, y, frameW, newRows);
		y += newRows;
	}
	return canvasToBlob(canvas);
}
async function findOverlap(imgA, imgB, w, h) {
	const sampleW = Math.min(w, 200);
	const sampleH = Math.min(h, 800);
	const ctxA = new OffscreenCanvas(sampleW, sampleH).getContext("2d");
	ctxA.drawImage(imgA, 0, 0, sampleW, sampleH);
	const dA = ctxA.getImageData(0, 0, sampleW, sampleH).data;
	const ctxB = new OffscreenCanvas(sampleW, sampleH).getContext("2d");
	ctxB.drawImage(imgB, 0, 0, sampleW, sampleH);
	const dB = ctxB.getImageData(0, 0, sampleW, sampleH).data;
	const marginX = Math.round(sampleW * .15);
	const endX = sampleW - marginX;
	const minOv = Math.max(4, Math.round(sampleH * .02));
	const maxOv = Math.round(sampleH * .95);
	let bestOv = 0;
	let bestErr = Infinity;
	for (let ov = minOv; ov <= maxOv; ov += 4) {
		const err = computeOverlapError(dA, dB, sampleW, sampleH, ov, marginX, endX);
		if (err < bestErr) {
			bestErr = err;
			bestOv = ov;
		}
	}
	const lo = Math.max(minOv, bestOv - 4);
	const hi = Math.min(maxOv, bestOv + 4);
	for (let ov = lo; ov <= hi; ov++) {
		const err = computeOverlapError(dA, dB, sampleW, sampleH, ov, marginX, endX);
		if (err < bestErr) {
			bestErr = err;
			bestOv = ov;
		}
	}
	if (bestErr > 30) return 0;
	return Math.round(bestOv * (h / sampleH));
}
function computeOverlapError(dA, dB, w, h, overlap, marginX, endX) {
	let diff = 0;
	let count = 0;
	const rowStep = 2;
	const xStep = 2;
	for (let r = 0; r < overlap; r += rowStep) {
		const rowA = h - overlap + r;
		const rowB = r;
		for (let x = marginX; x < endX; x += xStep) {
			const iA = (rowA * w + x) * 4;
			const iB = (rowB * w + x) * 4;
			diff += Math.abs(dA[iA] - dB[iB]) + Math.abs(dA[iA + 1] - dB[iB + 1]) + Math.abs(dA[iA + 2] - dB[iB + 2]);
			count++;
		}
	}
	return count > 0 ? diff / (count * 3) : 255;
}
async function hashFrame(dataUrl) {
	const img = await loadImage(dataUrl);
	const ctx = new OffscreenCanvas(16, 16).getContext("2d");
	ctx.drawImage(img, 0, 0, 16, 16);
	const data = ctx.getImageData(0, 0, 16, 16).data;
	let hash = 0;
	for (let i = 0; i < data.length; i += 4) {
		hash = (hash << 5) - hash + data[i] | 0;
		hash = (hash << 5) - hash + data[i + 1] | 0;
		hash = (hash << 5) - hash + data[i + 2] | 0;
	}
	return hash.toString(36);
}
function sleep$2(ms) {
	return new Promise((r) => setTimeout(r, ms));
}
async function blobToDataUrl$2(blob) {
	const bytes = new Uint8Array(await blob.arrayBuffer());
	const CHUNK = 32768;
	const parts = [];
	for (let i = 0; i < bytes.length; i += CHUNK) parts.push(String.fromCharCode(...bytes.subarray(i, i + CHUNK)));
	return `data:${blob.type};base64,${btoa(parts.join(""))}`;
}
//#endregion
//#region src/capture-modes/scroll-capturer.ts
var MAX_FRAMES = 300;
/** Chrome refuses to allocate a canvas taller than this. */
var MAX_CANVAS_H = 32e3;
/** Retries for a frame whose anchors moved mid-shutter. */
var SHUTTER_RETRIES = 4;
/** Anchors sampled per frame, spread down the region. */
var SAMPLE_POINTS = 14;
/** CSS px of anchor disagreement tolerated across the shutter. */
var SHUTTER_TOLERANCE = 1.5;
/** Below this CSS-px delta the view has not meaningfully moved. */
var MIN_SCROLL_DELTA = 2;
/** Consecutive dropped frames before the "too fast" hint appears. */
var TOO_FAST_AFTER = 2;
/** Fallback pixel matcher: max mean luma difference for a usable match. */
var LUMA_THRESHOLD = 18;
var MIN_OVERLAP_FRAC = .05;
var MAX_OVERLAP_FRAC = .95;
var THUMB_W = 90;
async function createScrollCapturer(tabId, region, onPreviewUpdated) {
	let lastStitched = null;
	let stitcher = null;
	let frameCount = 0;
	let stopped = false;
	let isPolling = false;
	let droppedInARow = 0;
	let hitLimit = false;
	async function poll() {
		if (stopped || isPolling || hitLimit || frameCount >= MAX_FRAMES) return null;
		isPolling = true;
		try {
			return await runPoll();
		} catch {
			return null;
		} finally {
			isPolling = false;
		}
	}
	async function runPoll() {
		const frame = await captureSyncedFrame(tabId, region);
		if (!frame || stopped) return null;
		if (!lastStitched || !stitcher) {
			lastStitched = frame;
			stitcher = initStitcher(frame);
			frameCount = 1;
			return emit();
		}
		const frameH = frame.bitmap.height;
		const deltaCss = measureScrollDelta(lastStitched.anchors, frame.anchors);
		let overlap = -1;
		if (deltaCss !== null) {
			if (deltaCss < MIN_SCROLL_DELTA) {
				frame.bitmap.close();
				droppedInARow = 0;
				return null;
			}
			const deltaPx = Math.round(deltaCss * frame.dpr);
			if (deltaPx >= frameH) return resyncWithGap(frame, frameH);
			overlap = frameH - deltaPx;
		} else {
			overlap = await findOverlapByPixels(lastStitched.bitmap, frame.bitmap, lastStitched.sample, frame.sample);
			if (overlap < 0) {
				frame.bitmap.close();
				return dropFrame();
			}
		}
		overlap = Math.max(overlap, frame.stickyBottom);
		const newRows = frameH - overlap;
		if (newRows < 2) {
			frame.bitmap.close();
			return null;
		}
		if (stitcher.totalHeight + newRows > MAX_CANVAS_H) {
			frame.bitmap.close();
			hitLimit = true;
			return emit({ atLimit: true });
		}
		appendToStitcher(stitcher, frame.bitmap, overlap, newRows);
		frameCount++;
		droppedInARow = 0;
		lastStitched.bitmap.close();
		lastStitched = frame;
		return emit();
	}
	/** Append a frame with no assumed overlap (beyond any sticky zone) and advance the stitch reference to it. */
	function resyncWithGap(frame, frameH) {
		if (!stitcher || !lastStitched) {
			frame.bitmap.close();
			return null;
		}
		const overlap = frame.stickyBottom;
		const newRows = frameH - overlap;
		if (stitcher.totalHeight + newRows > MAX_CANVAS_H) {
			frame.bitmap.close();
			hitLimit = true;
			return emit({ atLimit: true });
		}
		appendToStitcher(stitcher, frame.bitmap, overlap, newRows);
		frameCount++;
		lastStitched.bitmap.close();
		lastStitched = frame;
		droppedInARow = 0;
		return emit({ tooFast: true });
	}
	function dropFrame() {
		droppedInARow++;
		if (droppedInARow < TOO_FAST_AFTER) return null;
		return emit({ tooFast: true });
	}
	function emit(extra) {
		const progress = {
			frameCount,
			totalHeight: stitcher?.totalHeight ?? 0,
			thumbDataUrl: null,
			...extra
		};
		onPreviewUpdated(progress);
		if (stitcher) makeThumb(stitcher.canvas, stitcher.totalHeight).then((thumbDataUrl) => {
			if (!stopped && thumbDataUrl) onPreviewUpdated({
				...progress,
				thumbDataUrl
			});
		}).catch(() => {});
		return progress;
	}
	async function finish() {
		stopped = true;
		releaseAnchors(tabId);
		if (!stitcher || frameCount === 0) return null;
		const { totalHeight, frameW } = stitcher;
		const out = new OffscreenCanvas(frameW, totalHeight);
		out.getContext("2d").drawImage(stitcher.canvas, 0, 0, frameW, totalHeight, 0, 0, frameW, totalHeight);
		const blob = await out.convertToBlob({ type: "image/png" });
		lastStitched?.bitmap.close();
		lastStitched = null;
		const tab = await chrome.tabs.get(tabId);
		return {
			blob,
			width: frameW,
			height: totalHeight,
			mode: "scrolling-area",
			method: "scroll-stitch",
			timestamp: Date.now(),
			url: tab.url || "",
			title: tab.title || ""
		};
	}
	function stop() {
		stopped = true;
		releaseAnchors(tabId);
		lastStitched?.bitmap.close();
		lastStitched = null;
		stitcher = null;
	}
	return {
		poll,
		finish,
		stop
	};
}
/**
* How far the page scrolled between two frames, in CSS pixels.
* Positive means scrolled down. `null` when nothing matched.
*
* Uses the median rather than the mean so a handful of elements that animate
* independently (parallax, reveal-on-scroll transforms) cannot skew the result.
*/
function measureScrollDelta(prev, curr) {
	const deltas = [];
	for (const id in curr) {
		const before = prev[id];
		if (before !== void 0) deltas.push(before - curr[id]);
	}
	if (deltas.length === 0) return null;
	deltas.sort((a, b) => a - b);
	const mid = deltas.length >> 1;
	return deltas.length % 2 ? deltas[mid] : (deltas[mid - 1] + deltas[mid]) / 2;
}
/**
* Capture one frame, guaranteeing the page did not move while the shutter was
* open. Anchors are read either side of the capture and must agree.
*
* No hide/show of our own UI around the shutter here — unlike auto mode, the
* manual capture panel is placed by `placePanelClearOfRegion` in the content
* script to always fall outside the region actually being cropped (or, in
* the corner case where there's no room, the region's width is trimmed to
* exclude it), and the selection marquee's border/fill are cleared before
* manual capture starts. So nothing we draw can ever land inside `region`,
* and hiding it 5x/second (every poll) bought nothing but a visible strobe
* for the whole capture — confirmed by removing it and re-running the same
* capture with identical output.
*/
async function captureSyncedFrame(tabId, region) {
	for (let attempt = 0; attempt < SHUTTER_RETRIES; attempt++) {
		await waitForCaptureSlot();
		const before = await readAnchors(tabId, region);
		if (!before) return null;
		const dataUrl = await captureTab();
		if (!dataUrl) return null;
		const after = await readAnchors(tabId, region);
		if (!after) return null;
		if (!anchorsAgree(before.anchors, after.anchors)) continue;
		const frame = await cropToRegion(dataUrl, region, after.innerWidth, after.anchors, after.stickyBottom);
		if (frame) return frame;
	}
	return null;
}
function anchorsAgree(a, b) {
	let compared = 0;
	for (const id in b) {
		const other = a[id];
		if (other === void 0) continue;
		if (Math.abs(other - b[id]) > SHUTTER_TOLERANCE) return false;
		compared++;
	}
	return compared > 0 || Object.keys(b).length === 0;
}
var lastCaptureAttempt = 0;
var MIN_CAPTURE_SPACING_MS = 520;
async function waitForCaptureSlot() {
	const wait = MIN_CAPTURE_SPACING_MS - (Date.now() - lastCaptureAttempt);
	if (wait > 0) await sleep$1(wait);
}
async function captureTab() {
	for (let i = 0; i < 3; i++) {
		lastCaptureAttempt = Date.now();
		try {
			return await chrome.tabs.captureVisibleTab({ format: "png" });
		} catch (e) {
			if ((e?.message ?? "").includes("MAX_CAPTURE") && i < 2) {
				await sleep$1(MIN_CAPTURE_SPACING_MS);
				continue;
			}
			return null;
		}
	}
	return null;
}
/**
* Sample scrollable elements down the middle of the capture region and report
* each one's viewport-relative top.
*
* State lives on `window` in the extension's isolated world, so ids stay stable
* across calls and no attribute is ever written to the page's own DOM.
*/
async function readAnchors(tabId, region) {
	try {
		const [injection] = await chrome.scripting.executeScript({
			target: { tabId },
			args: [
				region.x,
				region.y,
				region.width,
				region.height,
				SAMPLE_POINTS
			],
			func: (rx, ry, rw, rh, samples) => {
				const KEY = "__gofullyScrollAnchors";
				const store = window[KEY] || (window[KEY] = {
					seq: 0,
					tracked: /* @__PURE__ */ new Map()
				});
				const ids = /* @__PURE__ */ new WeakMap();
				for (const [id, el] of store.tracked) ids.set(el, id);
				const anchors = {};
				let stickyBottom = 0;
				const track = (el, top) => {
					let id = ids.get(el);
					if (id === void 0) {
						id = String(++store.seq);
						store.tracked.set(id, el);
						ids.set(el, id);
					}
					anchors[id] = top;
				};
				for (const [id, el] of store.tracked) {
					if (!el.isConnected) {
						store.tracked.delete(id);
						continue;
					}
					anchors[id] = el.getBoundingClientRect().top;
				}
				const centerX = rx + rw / 2;
				for (let i = 0; i < samples; i++) {
					const y = ry + rh * (i + .5) / samples;
					for (const el of document.elementsFromPoint(centerX, y)) {
						if (el === document.body || el === document.documentElement) continue;
						const position = getComputedStyle(el).position;
						if (position === "fixed" || position === "sticky") {
							const stickyRect = el.getBoundingClientRect();
							stickyBottom = Math.max(stickyBottom, stickyRect.bottom - ry);
							continue;
						}
						const rect = el.getBoundingClientRect();
						if (rect.height < 4) continue;
						track(el, rect.top);
						break;
					}
				}
				if (store.tracked.size > 240) {
					const excess = store.tracked.size - 120;
					let dropped = 0;
					for (const id of store.tracked.keys()) {
						if (dropped++ >= excess) break;
						store.tracked.delete(id);
						delete anchors[id];
					}
				}
				return {
					anchors,
					innerWidth: window.innerWidth,
					stickyBottom: Math.max(0, Math.min(stickyBottom, rh))
				};
			}
		});
		return injection?.result ?? null;
	} catch {
		return null;
	}
}
/** Drop the tracked-element map so the page is left exactly as we found it. */
function releaseAnchors(tabId) {
	chrome.scripting.executeScript({
		target: { tabId },
		func: () => {
			delete window.__gofullyScrollAnchors;
		}
	}).catch(() => {});
}
async function cropToRegion(dataUrl, region, innerWidth, anchors, stickyBottom) {
	let full = null;
	try {
		const blob = dataUrlToBlob(dataUrl);
		if (!blob) return null;
		full = await createImageBitmap(blob);
		const dpr = innerWidth > 0 ? full.width / innerWidth : 1;
		const sx = clamp(Math.round(region.x * dpr), 0, full.width);
		const sy = clamp(Math.round(region.y * dpr), 0, full.height);
		const sw = clamp(Math.round(region.width * dpr), 1, full.width - sx);
		const sh = clamp(Math.round(region.height * dpr), 1, full.height - sy);
		if (sw < 1 || sh < 1) return null;
		const bitmap = await createImageBitmap(full, sx, sy, sw, sh);
		const ctx = new OffscreenCanvas(32, 32).getContext("2d");
		ctx.drawImage(bitmap, 0, 0, 32, 32);
		return {
			bitmap,
			anchors,
			dpr,
			sample: ctx.getImageData(0, 0, 32, 32).data,
			stickyBottom: stickyBottom * dpr
		};
	} catch {
		return null;
	} finally {
		full?.close();
	}
}
function initStitcher(frame) {
	const { width, height } = frame.bitmap;
	const canvas = new OffscreenCanvas(width, Math.min(height * 12, MAX_CANVAS_H));
	const ctx = canvas.getContext("2d");
	ctx.drawImage(frame.bitmap, 0, 0);
	return {
		canvas,
		ctx,
		totalHeight: height,
		frameW: width
	};
}
function appendToStitcher(s, frame, overlap, newRows) {
	const needed = s.totalHeight + newRows;
	if (needed > s.canvas.height) {
		const grown = new OffscreenCanvas(s.frameW, Math.min(needed + frame.height * 6, MAX_CANVAS_H));
		grown.getContext("2d").drawImage(s.canvas, 0, 0);
		s.canvas = grown;
		s.ctx = grown.getContext("2d");
	}
	s.ctx.drawImage(frame, 0, overlap, frame.width, newRows, 0, s.totalHeight, s.frameW, newRows);
	s.totalHeight += newRows;
}
async function findOverlapByPixels(frameA, frameB, sampleA, sampleB) {
	const H = Math.min(frameA.height, frameB.height);
	const W = Math.min(frameA.width, frameB.width);
	const stripW = Math.max(60, Math.round(W * .4));
	const stripX = Math.max(0, Math.round(W / 2 - stripW / 2));
	if (H < 40 || stripX + stripW > W) return -1;
	let digestDiff = 0;
	for (let i = 0; i < sampleA.length; i += 4) digestDiff += Math.abs(sampleA[i] - sampleB[i]) + Math.abs(sampleA[i + 1] - sampleB[i + 1]) + Math.abs(sampleA[i + 2] - sampleB[i + 2]);
	const estimate = 1 - Math.min(.95, digestDiff / (sampleA.length / 4) / 3 / 120);
	const hi = Math.round(H * clamp(estimate + .15, MIN_OVERLAP_FRAC, MAX_OVERLAP_FRAC));
	const lo = Math.max(1, Math.round(H * clamp(estimate - .35, MIN_OVERLAP_FRAC, MAX_OVERLAP_FRAC)));
	const step = Math.max(2, Math.round(H / 120));
	const ctx = new OffscreenCanvas(stripW, H * 2).getContext("2d");
	ctx.drawImage(frameA, stripX, 0, stripW, H, 0, 0, stripW, H);
	ctx.drawImage(frameB, stripX, 0, stripW, H, 0, H, stripW, H);
	const data = ctx.getImageData(0, 0, stripW, H * 2).data;
	const columns = [
		Math.round(stripW / 4),
		Math.round(stripW / 2),
		Math.round(stripW * 3 / 4)
	];
	let best = -1;
	let bestScore = Infinity;
	for (let overlap = hi; overlap >= lo; overlap -= step) {
		const rows = Math.min(overlap, 300);
		const strideY = Math.max(2, Math.round(rows / 60));
		let total = 0;
		let count = 0;
		for (let row = 0; row < rows; row += strideY) {
			const rowA = H - overlap + row;
			const rowB = H + row;
			for (const x of columns) {
				const ia = (rowA * stripW + x) * 4;
				const ib = (rowB * stripW + x) * 4;
				total += Math.abs(luma(data, ia) - luma(data, ib));
				count++;
			}
		}
		const score = count > 0 ? total / count : 255;
		if (score < bestScore) {
			bestScore = score;
			best = overlap;
		}
	}
	return bestScore > LUMA_THRESHOLD ? -1 : best;
}
function luma(d, i) {
	return d[i] * .299 + d[i + 1] * .587 + d[i + 2] * .114;
}
async function makeThumb(canvas, totalHeight) {
	try {
		const h = Math.max(1, Math.round(totalHeight / canvas.width * THUMB_W));
		const c = new OffscreenCanvas(THUMB_W, h);
		c.getContext("2d").drawImage(canvas, 0, 0, canvas.width, totalHeight, 0, 0, THUMB_W, h);
		return await blobToDataUrl$1(await c.convertToBlob({
			type: "image/jpeg",
			quality: .7
		}));
	} catch {
		return null;
	}
}
function clamp(n, min, max) {
	return Math.max(min, Math.min(max, n));
}
function sleep$1(ms) {
	return new Promise((r) => setTimeout(r, ms));
}
function dataUrlToBlob(dataUrl) {
	const comma = dataUrl.indexOf(",");
	if (comma < 0) return null;
	const mime = /^data:([^;,]+)/.exec(dataUrl)?.[1] ?? "image/png";
	try {
		const bytes = atob(dataUrl.slice(comma + 1));
		const arr = new Uint8Array(bytes.length);
		for (let i = 0; i < bytes.length; i++) arr[i] = bytes.charCodeAt(i);
		return new Blob([arr], { type: mime });
	} catch {
		return null;
	}
}
async function blobToDataUrl$1(blob) {
	const bytes = new Uint8Array(await blob.arrayBuffer());
	const CHUNK = 32768;
	const parts = [];
	for (let i = 0; i < bytes.length; i += CHUNK) parts.push(String.fromCharCode(...bytes.subarray(i, i + CHUNK)));
	return `data:${blob.type};base64,${btoa(parts.join(""))}`;
}
//#endregion
//#region src/background/service-worker.ts
chrome.runtime.onInstalled.addListener(async (details) => {
	if (chrome.runtime.setUninstallURL) chrome.runtime.setUninstallURL("https://gofully-extension.vercel.app/uninstall-feedback");
	if (details.reason === "install") chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") });
	try {
		const tabs = await chrome.tabs.query({ url: ["http://*/*", "https://*/*"] });
		for (const tab of tabs) if (tab.id) injectContentScripts(tab.id).catch(() => {});
	} catch {}
});
chrome.runtime.onConnect.addListener(() => {});
var lastCaptureResult = null;
var lastCaptureBlob = null;
var lastCaptureDataUrl = null;
var activeCapturer = null;
async function ensureOffscreenDocument() {
	if ((await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] })).length === 0) await chrome.offscreen.createDocument({
		url: "offscreen.html",
		reasons: [chrome.offscreen.Reason.BLOBS, chrome.offscreen.Reason.DOM_SCRAPING],
		justification: "Process offscreen canvas and OCR operations"
	});
	for (let i = 0; i < 100; i++) {
		try {
			if ((await chrome.runtime.sendMessage({ type: "OFFSCREEN_PING" }))?.ok) return;
		} catch {}
		await new Promise((r) => setTimeout(r, 150));
	}
}
async function blobToDataUrl(blob) {
	const bytes = new Uint8Array(await blob.arrayBuffer());
	const CHUNK = 32768;
	const parts = [];
	for (let i = 0; i < bytes.length; i += CHUNK) parts.push(String.fromCharCode(...bytes.subarray(i, i + CHUNK)));
	return `data:${blob.type};base64,${btoa(parts.join(""))}`;
}
function formatStampTimestamp(ts) {
	const d = new Date(ts);
	const pad = (n) => String(n).padStart(2, "0");
	return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}
function truncateUrl(url, max = 64) {
	return url.length > max ? `${url.slice(0, max - 1)}…` : url;
}
async function stampCapture(result) {
	const bitmap = await createImageBitmap(result.blob);
	const { width, height } = bitmap;
	if (width < 120) {
		bitmap.close();
		return result.blob;
	}
	const canvas = new OffscreenCanvas(width, height);
	const ctx = canvas.getContext("2d");
	ctx.drawImage(bitmap, 0, 0);
	bitmap.close();
	const fontSize = Math.max(12, Math.min(22, Math.round(width / 90)));
	ctx.font = `${fontSize}px -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif`;
	const paddingX = fontSize * .9;
	const paddingY = fontSize * .6;
	const margin = Math.max(12, Math.round(width / 120));
	const maxTextWidth = width - margin * 2 - paddingX * 2;
	const timestampStr = formatStampTimestamp(result.timestamp);
	let urlStr = truncateUrl(result.url);
	const buildLabel = (u) => `${u}  ·  ${timestampStr}`;
	let label = buildLabel(urlStr);
	while (ctx.measureText(label).width > maxTextWidth && urlStr.length > 4) {
		urlStr = urlStr.replace(/…?$/, "").slice(0, -1);
		label = buildLabel(`${urlStr}…`);
	}
	if (ctx.measureText(buildLabel("")).width > maxTextWidth) return canvas.convertToBlob({ type: result.blob.type || "image/png" });
	const boxW = ctx.measureText(label).width + paddingX * 2;
	const boxH = fontSize + paddingY * 2;
	const boxX = margin;
	const boxY = height - boxH - margin;
	ctx.fillStyle = "rgba(0, 0, 0, 0.6)";
	if (typeof ctx.roundRect === "function") {
		ctx.beginPath();
		ctx.roundRect(boxX, boxY, boxW, boxH, boxH / 4);
		ctx.fill();
	} else ctx.fillRect(boxX, boxY, boxW, boxH);
	ctx.fillStyle = "#FFFFFF";
	ctx.textBaseline = "middle";
	ctx.fillText(label, boxX + paddingX, boxY + boxH / 2);
	return canvas.convertToBlob({ type: result.blob.type || "image/png" });
}
async function maybeStampCapture(result) {
	try {
		const stored = await chrome.storage.sync.get("settings");
		if (!{
			...DEFAULT_SETTINGS,
			...stored.settings || {}
		}.captureStamp) return result.blob;
		return await stampCapture(result);
	} catch {
		return result.blob;
	}
}
var SESSION_CACHE_LIMIT = 8388608;
function cacheCaptureInSession(dataUrl) {
	if (dataUrl.length > SESSION_CACHE_LIMIT) {
		chrome.storage.session.remove("lastCaptureDataUrl").catch(() => {});
		return;
	}
	chrome.storage.session.set({ lastCaptureDataUrl: dataUrl }).catch(() => {});
}
/**
* A content script is only as trustworthy as the page it runs in, so a region
* arriving over messaging is validated against the tab's real viewport before
* any pixels are read.
*/
async function sanitizeRegion(tabId, region) {
	const r = region;
	if (!r) return null;
	if (![
		r.x,
		r.y,
		r.width,
		r.height
	].every((n) => typeof n === "number" && Number.isFinite(n))) return null;
	if (r.width < 1 || r.height < 1) return null;
	let viewport = {
		width: 0,
		height: 0
	};
	try {
		const [{ result }] = await chrome.scripting.executeScript({
			target: { tabId },
			func: () => ({
				width: window.innerWidth,
				height: window.innerHeight
			})
		});
		viewport = result;
	} catch {
		return null;
	}
	if (!viewport.width || !viewport.height) return null;
	const x = Math.max(0, Math.min(r.x, viewport.width - 1));
	const y = Math.max(0, Math.min(r.y, viewport.height - 1));
	return {
		x,
		y,
		width: Math.max(1, Math.min(r.width, viewport.width - x)),
		height: Math.max(1, Math.min(r.height, viewport.height - y))
	};
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	if (message.type === "START_CAPTURE") {
		const { mode, region, speed, tabId } = message.payload;
		const targetTabId = tabId ?? sender.tab?.id;
		const fromContentScript = !!sender.tab;
		if (targetTabId) injectContentScripts(targetTabId).catch(() => {});
		handleCapture(mode, region, speed, targetTabId).then(async (result) => {
			lastCaptureBlob = await maybeStampCapture(result);
			lastCaptureDataUrl = await blobToDataUrl(lastCaptureBlob);
			lastCaptureResult = {
				...result,
				blob: null
			};
			cacheCaptureInSession(lastCaptureDataUrl);
			recordCaptureCompleted().catch(() => {});
			const payload = {
				width: result.width,
				height: result.height,
				mode: result.mode,
				method: result.method,
				url: result.url,
				title: result.title,
				timestamp: result.timestamp,
				dataUrl: lastCaptureDataUrl
			};
			if (targetTabId) await handleCaptureCompletionUI(mode, targetTabId, fromContentScript, lastCaptureDataUrl);
			sendResponse({
				type: "CAPTURE_COMPLETE",
				payload
			});
		}).catch((error) => {
			if (targetTabId) chrome.tabs.sendMessage(targetTabId, {
				type: "CAPTURE_ERROR_INLINE",
				payload: { message: error.message }
			}).catch(() => {});
			sendResponse({
				type: "CAPTURE_ERROR",
				payload: { message: error.message }
			});
		});
		return true;
	}
	if (message.type === "CANCEL_CAPTURE") {
		cancelActiveCapture();
		sendResponse({ cancelled: true });
		return true;
	}
	if (message.type === "GET_LAST_CAPTURE") {
		sendResponse({
			result: lastCaptureResult,
			hasBlob: !!lastCaptureBlob
		});
		return true;
	}
	if (message.type === "EXPORT_CAPTURE") {
		const { format } = message.payload;
		if (lastCaptureBlob) handleExport(lastCaptureBlob, lastCaptureResult, format).then((result) => sendResponse(result));
		else sendResponse({ error: "No capture available" });
		return true;
	}
	if (message.type === "GET_CAPTURE_BLOB_URL") {
		if (lastCaptureDataUrl) sendResponse({ url: lastCaptureDataUrl });
		else chrome.storage.session.get("lastCaptureDataUrl").then((s) => {
			const recovered = s.lastCaptureDataUrl ?? null;
			if (recovered) lastCaptureDataUrl = recovered;
			sendResponse({ url: recovered });
		}).catch(() => sendResponse({ url: null }));
		return true;
	}
	if (message.type === "OPEN_EDITOR") {
		const editorUrl = chrome.runtime.getURL("editor.html");
		(async () => {
			let targetIndex = void 0;
			let openerId = void 0;
			if (sender.tab && typeof sender.tab.index === "number") {
				targetIndex = sender.tab.index + 1;
				openerId = sender.tab.id;
			} else {
				const [activeTab] = await chrome.tabs.query({
					active: true,
					currentWindow: true
				});
				if (activeTab && typeof activeTab.index === "number") {
					targetIndex = activeTab.index + 1;
					openerId = activeTab.id;
				}
			}
			await chrome.tabs.create({
				url: editorUrl,
				index: targetIndex,
				openerTabId: openerId
			});
			sendResponse({ opened: true });
		})().catch((err) => {
			console.error("Failed to open editor tab next to source:", err);
			chrome.tabs.create({ url: editorUrl });
			sendResponse({ opened: true });
		});
		return true;
	}
	if (message.type === "INIT_INTERACTIVE_MODE") {
		const mode = message.payload?.mode || message.mode;
		const tabId = message.payload?.tabId || message.tabId || sender.tab?.id;
		if (tabId) initInteractiveMode(mode, tabId);
		sendResponse({
			ok: true,
			started: true
		});
		return true;
	}
	if (message.type === "SCROLLING_REGION_SELECTED") {
		const { speed } = message.payload;
		const tabId = sender.tab?.id;
		if (!tabId || sender.tab?.url?.startsWith("chrome-extension://")) {
			sendResponse({ started: false });
			return false;
		}
		sanitizeRegion(tabId, message.payload?.region).then((region) => {
			if (!region) return;
			return captureScrollingArea(tabId, region, speed || "medium", (progress) => {
				chrome.tabs.sendMessage(tabId, {
					type: "SCROLLING_PROGRESS",
					payload: progress
				}).catch(() => {});
			}).then(async (result) => {
				lastCaptureBlob = await maybeStampCapture(result);
				lastCaptureDataUrl = await blobToDataUrl(lastCaptureBlob);
				lastCaptureResult = {
					...result,
					blob: null
				};
				cacheCaptureInSession(lastCaptureDataUrl);
				recordCaptureCompleted().catch(() => {});
				chrome.tabs.sendMessage(tabId, { type: "SCROLLING_CAPTURE_DONE" }).catch(() => {});
				await openReviewTab(tabId);
			}).catch((err) => {
				chrome.tabs.sendMessage(tabId, { type: "SCROLLING_CAPTURE_DONE" }).catch(() => {});
				chrome.tabs.sendMessage(tabId, {
					type: "CAPTURE_ERROR_INLINE",
					payload: { message: err.message }
				}).catch(() => {});
			});
		}).catch(() => {});
		sendResponse({ started: true });
		return true;
	}
	if (message.type === "SCROLL_START") {
		const tabId = sender.tab?.id;
		if (!tabId) {
			sendResponse({ started: false });
			return false;
		}
		activeCapturer?.stop();
		activeCapturer = null;
		sanitizeRegion(tabId, message.payload?.region).then((region) => {
			if (!region) {
				sendResponse({ started: false });
				return;
			}
			return createScrollCapturer(tabId, region, (progress) => {
				chrome.tabs.sendMessage(tabId, {
					type: "SCROLL_PROGRESS",
					payload: progress
				}).catch(() => {});
			}).then((capturer) => {
				activeCapturer = capturer;
				sendResponse({ started: true });
			});
		}).catch(() => sendResponse({ started: false }));
		return true;
	}
	if (message.type === "SCROLL_POLL") {
		if (!activeCapturer) {
			sendResponse({ progress: null });
			return false;
		}
		activeCapturer.poll().then((progress) => sendResponse({ progress }));
		return true;
	}
	if (message.type === "SCROLL_STOP") {
		activeCapturer?.stop();
		activeCapturer = null;
		sendResponse({ stopped: true });
		return false;
	}
	if (message.type === "SCROLL_FINISH") {
		const tabId = sender.tab?.id;
		if (!tabId || !activeCapturer) {
			sendResponse({ success: false });
			return false;
		}
		const capturer = activeCapturer;
		activeCapturer = null;
		capturer.finish().then(async (result) => {
			if (!result) {
				sendResponse({ success: false });
				return;
			}
			lastCaptureBlob = await maybeStampCapture(result);
			lastCaptureDataUrl = await blobToDataUrl(lastCaptureBlob);
			lastCaptureResult = {
				...result,
				blob: null
			};
			cacheCaptureInSession(lastCaptureDataUrl);
			recordCaptureCompleted().catch(() => {});
			await openReviewTab(tabId);
			sendResponse({ success: true });
		}).catch((err) => sendResponse({
			success: false,
			error: err.message
		}));
		return true;
	}
	if (message.type === "EXECUTE_OCR") {
		const { region } = message.payload;
		const tabId = sender.tab?.id;
		if (!tabId) {
			sendResponse({ error: "No active tab" });
			return false;
		}
		captureSelectedArea(tabId, region).then(async (result) => {
			const dataUrl = await blobToDataUrl(result.blob);
			await ensureOffscreenDocument();
			const ocrLang = (await chrome.storage.sync.get("settings")).settings?.ocrLanguage || DEFAULT_SETTINGS.ocrLanguage;
			const ocrResp = await chrome.runtime.sendMessage({
				type: "PERFORM_OCR",
				payload: {
					dataUrl,
					lang: ocrLang
				}
			});
			if (ocrResp?.error) sendResponse({ error: ocrResp.error });
			else sendResponse({ text: ocrResp?.text || "" });
		}).catch((err) => {
			console.error("OCR execution error:", err);
			sendResponse({ error: err.message || "OCR failed" });
		});
		return true;
	}
	return false;
});
chrome.commands.onCommand.addListener(async (command) => {
	const [tab] = await chrome.tabs.query({
		active: true,
		currentWindow: true
	});
	if (!tab?.id) return;
	await injectContentScripts(tab.id);
	if (command === "capture-full-page") try {
		const result = await handleCapture("full-page", void 0, void 0, tab.id);
		lastCaptureBlob = await maybeStampCapture(result);
		lastCaptureDataUrl = await blobToDataUrl(lastCaptureBlob);
		lastCaptureResult = {
			...result,
			blob: null
		};
		cacheCaptureInSession(lastCaptureDataUrl);
		recordCaptureCompleted().catch(() => {});
		await openReviewTab(tab.id);
	} catch (e) {
		console.error("Keyboard shortcut capture-full-page failed:", e);
	}
	if (command === "capture-visible") try {
		const result = await handleCapture("visible-area", void 0, void 0, tab.id);
		lastCaptureBlob = await maybeStampCapture(result);
		lastCaptureDataUrl = await blobToDataUrl(lastCaptureBlob);
		lastCaptureResult = {
			...result,
			blob: null
		};
		cacheCaptureInSession(lastCaptureDataUrl);
		recordCaptureCompleted().catch(() => {});
		chrome.tabs.sendMessage(tab.id, {
			type: "QUICK_CAPTURE_TOAST",
			payload: { dataUrl: lastCaptureDataUrl }
		}).catch(() => {});
	} catch (e) {
		console.error("Keyboard shortcut capture-visible failed:", e);
	}
	if (command === "capture-selected-area") await initInteractiveMode("selected-area", tab.id);
});
async function handleCapture(mode, region, speed, explicitTabId) {
	let targetTabId = explicitTabId;
	let tab;
	if (targetTabId) try {
		tab = await chrome.tabs.get(targetTabId);
	} catch {}
	if (!tab) {
		const [activeTab] = await chrome.tabs.query({
			active: true,
			currentWindow: true
		});
		tab = activeTab;
		targetTabId = tab?.id;
	}
	if (!tab?.id) throw new Error("No active tab");
	const tabUrl = tab.url || "";
	const support = isSupportedCapturePage(tabUrl);
	if (!support.supported) throw new Error(support.message || "This page cannot be captured.");
	if (mode === "full-page" || mode === "scrolling-area") await injectContentScripts(tab.id);
	const sendProgress = (progress) => {
		chrome.runtime.sendMessage({
			type: "CAPTURE_PROGRESS",
			payload: progress
		}).catch(() => {});
		if (targetTabId) chrome.tabs.sendMessage(targetTabId, {
			type: "CAPTURE_PROGRESS",
			payload: progress
		}).catch(() => {});
	};
	switch (mode) {
		case "full-page": return captureFullPage(targetTabId, sendProgress);
		case "visible-area": return captureVisibleArea(targetTabId, sendProgress);
		case "selected-area":
			if (!region) throw new Error("Region required for selected-area mode");
			return captureSelectedArea(targetTabId, region);
		case "scrolling-area":
			if (!region) throw new Error("Region required for scrolling-area mode");
			return captureScrollingArea(targetTabId, region, speed || "medium", sendProgress);
		default: throw new Error(`Unknown capture mode: ${mode}`);
	}
}
async function initInteractiveMode(mode, tabId) {
	try {
		const tab = await chrome.tabs.get(tabId);
		const support = isSupportedCapturePage(tab.url || "");
		if (!support.supported) {
			chrome.runtime.sendMessage({
				type: "CAPTURE_ERROR",
				payload: { message: support.message || "Cannot capture this type of page." }
			}).catch(() => {});
			return;
		}
		await injectContentScripts(tabId);
		if (mode === "selected-area") {
			await chrome.scripting.executeScript({
				target: { tabId },
				files: ["region-selector.js"]
			});
			await sleep(100);
			await chrome.tabs.sendMessage(tabId, {
				type: "START_REGION_SELECT_MODE",
				payload: { tabId }
			});
		}
		if (mode === "scrolling-area") {
			await chrome.scripting.executeScript({
				target: { tabId },
				files: ["scrolling-area-ui.js"]
			});
			await sleep(100);
			await chrome.tabs.sendMessage(tabId, {
				type: "START_SCROLLING_AREA_MODE",
				payload: { tabId }
			});
		}
		if (mode === "capture-text") {
			await chrome.scripting.executeScript({
				target: { tabId },
				files: ["ocr-overlay.js"]
			});
			await sleep(100);
			await chrome.tabs.sendMessage(tabId, {
				type: "START_OCR_MODE",
				payload: { tabId }
			});
		}
	} catch (err) {
		console.error("initInteractiveMode failed:", err);
	}
}
function sleep(ms) {
	return new Promise((r) => setTimeout(r, ms));
}
/**
* Full-page and scrolling-area captures open a dedicated review tab — a big
* preview with proper export actions, instead of a cramped in-page card.
* Visible-area and selected-area stay instant: no tab, no card, just a
* clipboard copy and a small toast (see handleCaptureCompletionUI).
*/
async function openReviewTab(openerTabId) {
	try {
		await chrome.scripting.executeScript({
			target: { tabId: openerTabId },
			func: () => {
				if (typeof window.__gofully_remove_progress === "function") window.__gofully_remove_progress();
			}
		}).catch(() => {});
		const openerTab = await chrome.tabs.get(openerTabId).catch(() => null);
		const captureId = `cap_${Date.now()}`;
		await chrome.tabs.create({
			url: chrome.runtime.getURL(`review.html?id=${captureId}`),
			index: typeof openerTab?.index === "number" ? openerTab.index + 1 : void 0,
			openerTabId
		});
	} catch (err) {
		console.error("openReviewTab failed:", err);
	}
}
/**
* Routes a completed capture to the right post-capture UI: a review tab for
* the two "I want to look at this" modes, or an instant clipboard copy +
* lightweight in-page toast for the two "grab it and go" modes. Quick modes
* triggered from the popup are skipped here — the popup does its own copy
* and status line, since it already has the result in hand.
*/
async function handleCaptureCompletionUI(mode, targetTabId, fromContentScript, dataUrl) {
	if (mode === "full-page" || mode === "scrolling-area") {
		await openReviewTab(targetTabId);
		return;
	}
	if (fromContentScript) chrome.tabs.sendMessage(targetTabId, {
		type: "QUICK_CAPTURE_TOAST",
		payload: { dataUrl }
	}).catch(() => {});
	else await chrome.scripting.executeScript({
		target: { tabId: targetTabId },
		func: () => {
			if (typeof window.__gofully_remove_progress === "function") window.__gofully_remove_progress();
		}
	}).catch(() => {});
}
async function injectContentScripts(tabId) {
	try {
		await chrome.scripting.executeScript({
			target: { tabId },
			files: [
				"page-analyzer.js",
				"sticky-manager.js",
				"lazy-loader.js",
				"result-bar.js"
			]
		});
	} catch {}
}
async function handleExport(blob, result, format) {
	try {
		switch (format) {
			case "clipboard": return { success: true };
			case "png": {
				const filename = generateFilename(getDomain(result.url), "png");
				const dataUrl = await blobToDataUrl(blob);
				await chrome.downloads.download({
					url: dataUrl,
					filename,
					saveAs: false
				});
				return { success: true };
			}
			case "pdf": {
				const filename = generateFilename(getDomain(result.url), "pdf");
				const pdfDataUrl = await blobToDataUrl(await generatePDF(blob, "a4"));
				await chrome.downloads.download({
					url: pdfDataUrl,
					filename,
					saveAs: false
				});
				return { success: true };
			}
			default: return {
				success: false,
				error: `Unknown format: ${format}`
			};
		}
	} catch (e) {
		return {
			success: false,
			error: e.message
		};
	}
}
function getDomain(url) {
	try {
		return new URL(url).hostname;
	} catch {
		return "unknown";
	}
}
function generateFilename(domain, ext) {
	const ts = (/* @__PURE__ */ new Date()).toISOString().replace(/[-:T]/g, "").slice(0, 14);
	return `gofully-${domain.replace(/[^a-zA-Z0-9.-]/g, "_").slice(0, 50)}-${ts}.${ext}`;
}
//#endregion
