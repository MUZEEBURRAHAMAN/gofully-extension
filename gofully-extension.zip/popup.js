import { i as generateFilename } from "./chunks/image-BPYnapgS.js";
import { a as generatePDF, r as markRatedYes } from "./chunks/rate-nudge-Dw76hDuh.js";
import { t as isSupportedCapturePage } from "./chunks/url-validator-CInVwRGC.js";
import { n as watchTheme, t as applyTheme } from "./chunks/theme-DcC2xsTw.js";
import { n as t, r as watchLanguage, t as initI18n } from "./chunks/i18n-tSMNGUsg.js";
//#region src/popup/popup.ts
applyTheme();
watchTheme();
initI18n();
watchLanguage(() => applyPageSupportState(currentSupportState));
var modesSection = document.getElementById("modesSection");
var progressSection = document.getElementById("progressSection");
var progressLabel = document.getElementById("progressLabel");
var progressFill = document.getElementById("progressFill");
var resultBar = document.getElementById("resultBar");
var resultText = document.getElementById("resultText");
var errorBar = document.getElementById("errorBar");
var errorMsg = document.getElementById("errorMsg");
var copyBtn = document.getElementById("copyBtn");
var savePngBtn = document.getElementById("savePngBtn");
var savePdfBtn = document.getElementById("savePdfBtn");
var toast = document.getElementById("toast");
var unsupportedPanel = document.getElementById("unsupportedPanel");
var unsupportedTitle = document.getElementById("unsupportedTitle");
var unsupportedDesc = document.getElementById("unsupportedDesc");
var unsupportedDismissBtn = document.getElementById("unsupportedDismissBtn");
var statusLine = document.getElementById("statusLine");
var statusThumb = document.getElementById("statusThumb");
var statusText = document.getElementById("statusText");
var statusViewBtn = document.getElementById("statusViewBtn");
var currentBlobUrl = null;
var currentUrl = "";
var UNSUPPORTED_I18N_KEYS = {
	unknown: "unsupported.page_cant_be_captured",
	restricted: "unsupported.page_cant_be_captured",
	web_store: "unsupported.webstore",
	devtools: "unsupported.devtools",
	browser_internal: "unsupported.browser_internal",
	extension_page: "unsupported.extension_page",
	view_source: "unsupported.source_view"
};
var currentSupportState = {
	supported: true,
	type: "supported"
};
async function readSettings() {
	return (await chrome.storage.sync.get("settings")).settings ?? {};
}
async function playCaptureSound() {
	try {
		if (!((await readSettings()).captureSound !== false)) return;
		const url = chrome.runtime.getURL("assets/shutter.mp3");
		const audio = new Audio(url);
		audio.volume = .5;
		audio.play().catch(() => {});
	} catch {}
}
async function getCountdown() {
	try {
		return (await readSettings()).captureCountdown ?? 0;
	} catch {
		return 0;
	}
}
document.getElementById("settingsBtn")?.addEventListener("click", () => {
	chrome.runtime.openOptionsPage();
});
document.getElementById("helpBtn")?.addEventListener("click", () => {
	chrome.tabs.create({ url: chrome.runtime.getURL("help.html") });
});
document.getElementById("rateUsBtn")?.addEventListener("click", () => {
	markRatedYes().catch(() => {});
});
unsupportedDismissBtn?.addEventListener("click", () => {
	unsupportedPanel.classList.remove("active");
});
document.querySelectorAll(".mode-btn").forEach((btn) => {
	btn.addEventListener("mousedown", (e) => {
		e.preventDefault();
		const mode = btn.dataset.mode;
		if (btn.disabled) return;
		startCapture(mode);
	});
});
copyBtn.addEventListener("click", async () => {
	if (!currentBlobUrl) return;
	try {
		const blob = await (await fetch(currentBlobUrl)).blob();
		const uhdBlob = await upscaleToUHD(blob.type === "image/png" ? blob : await convertToPng(blob));
		await navigator.clipboard.write([new ClipboardItem({ "image/png": uhdBlob })]);
		const label = copyBtn.querySelector("span") ?? copyBtn;
		const orig = label.textContent ?? t("action.copy");
		label.textContent = t("toast.copied");
		copyBtn.style.opacity = "0.75";
		setTimeout(() => {
			label.textContent = orig;
			copyBtn.style.opacity = "";
		}, 2e3);
		showToast(t("toast.copied"));
	} catch {
		showToast(t("toast.copy_failed"));
	}
});
async function convertToPng(blob) {
	const bitmap = await createImageBitmap(blob);
	const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
	canvas.getContext("2d").drawImage(bitmap, 0, 0);
	return canvas.convertToBlob({ type: "image/png" });
}
var UHD_W = 3840;
var UHD_H = 2160;
async function upscaleToUHD(blob) {
	try {
		const bitmap = await createImageBitmap(blob);
		const { width: w, height: h } = bitmap;
		if (w >= UHD_W || h >= UHD_H) return blob;
		const scale = Math.max(UHD_W / w, UHD_H / h);
		const canvas = new OffscreenCanvas(Math.round(w * scale), Math.round(h * scale));
		const ctx = canvas.getContext("2d");
		ctx.imageSmoothingEnabled = true;
		ctx.imageSmoothingQuality = "high";
		ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
		return await canvas.convertToBlob({ type: "image/png" });
	} catch {
		return blob;
	}
}
savePngBtn.addEventListener("click", async () => {
	if (!currentBlobUrl) return;
	try {
		const domain = getDomain(currentUrl);
		const filename = generateFilename(domain, "png");
		await chrome.downloads.download({
			url: currentBlobUrl,
			filename,
			saveAs: false
		});
		showToast(t("toast.saved_png"));
	} catch {
		showToast(t("toast.save_failed"));
	}
});
document.getElementById("saveWebpBtn")?.addEventListener("click", async () => {
	if (!currentBlobUrl) return;
	try {
		const blob = await (await fetch(currentBlobUrl)).blob();
		const bitmap = await createImageBitmap(blob);
		const oc = new OffscreenCanvas(bitmap.width, bitmap.height);
		oc.getContext("2d").drawImage(bitmap, 0, 0);
		const webpBlob = await oc.convertToBlob({
			type: "image/webp",
			quality: .92
		});
		const downloadUrl = URL.createObjectURL(webpBlob);
		const domain = getDomain(currentUrl);
		const filename = generateFilename(domain, "webp");
		await chrome.downloads.download({
			url: downloadUrl,
			filename,
			saveAs: false
		});
		showToast(t("toast.saved_webp"));
	} catch {
		showToast(t("toast.save_failed"));
	}
});
document.getElementById("editBtn")?.addEventListener("click", async () => {
	if (!currentBlobUrl) return;
	chrome.runtime.sendMessage({ type: "OPEN_EDITOR" });
});
savePdfBtn.addEventListener("click", async () => {
	if (!currentBlobUrl) return;
	const btnLabel = savePdfBtn.querySelector("span") ?? savePdfBtn;
	const origText = btnLabel.textContent ?? "Save PDF";
	try {
		btnLabel.textContent = t("action.generating");
		savePdfBtn.style.opacity = "0.7";
		savePdfBtn.disabled = true;
		const blob = await (await fetch(currentBlobUrl)).blob();
		const domain = getDomain(currentUrl);
		const pdfBlob = await generatePDF(blob, "a4");
		const pdfObjUrl = URL.createObjectURL(pdfBlob);
		const filename = generateFilename(domain, "pdf");
		await chrome.downloads.download({
			url: pdfObjUrl,
			filename,
			saveAs: false
		});
		URL.revokeObjectURL(pdfObjUrl);
		showToast(t("toast.saved_pdf"));
	} catch (err) {
		console.error("PDF generation error:", err);
		showToast(t("toast.pdf_failed"));
	} finally {
		btnLabel.textContent = origText;
		savePdfBtn.style.opacity = "";
		savePdfBtn.disabled = false;
	}
});
chrome.runtime.onMessage.addListener((message) => {
	if (message.type === "CAPTURE_PROGRESS") updateProgress(message.payload);
	if (message.type === "CAPTURE_COMPLETE") {
		message.payload;
		currentUrl = message.payload.url;
		chrome.runtime.sendMessage({ type: "GET_CAPTURE_BLOB_URL" }, (resp) => {
			if (resp?.url) currentBlobUrl = resp.url;
			showResult(message.payload);
		});
	}
});
/**
* Initial page validation on popup open
*/
async function checkActiveTabSupport() {
	try {
		const [tab] = await chrome.tabs.query({
			active: true,
			currentWindow: true
		});
		const url = tab?.url || "";
		currentUrl = url;
		currentSupportState = isSupportedCapturePage(url);
		applyPageSupportState(currentSupportState);
	} catch {
		currentSupportState = {
			supported: true,
			type: "supported"
		};
		applyPageSupportState(currentSupportState);
	}
}
function applyPageSupportState(support) {
	const modeButtons = document.querySelectorAll(".mode-btn");
	if (!support.supported) {
		const i18nKeyForTitle = UNSUPPORTED_I18N_KEYS[support.type];
		const disabledTitle = i18nKeyForTitle ? t(`${i18nKeyForTitle}.message`) : support.message || "";
		modeButtons.forEach((btn) => {
			const button = btn;
			button.disabled = true;
			button.setAttribute("aria-disabled", "true");
			button.title = disabledTitle;
		});
		const i18nKey = UNSUPPORTED_I18N_KEYS[support.type];
		if (unsupportedTitle) unsupportedTitle.textContent = i18nKey ? t(`${i18nKey}.title`) : support.title || "";
		if (unsupportedDesc) unsupportedDesc.textContent = i18nKey ? t(`${i18nKey}.message`) : support.message || "";
		unsupportedPanel.classList.add("active");
	} else {
		modeButtons.forEach((btn) => {
			const button = btn;
			button.disabled = false;
			button.removeAttribute("aria-disabled");
			button.removeAttribute("title");
		});
		unsupportedPanel.classList.remove("active");
	}
}
async function startCapture(mode) {
	const [tab] = await chrome.tabs.query({
		active: true,
		currentWindow: true
	});
	if (!tab?.id) return;
	const support = isSupportedCapturePage(tab.url);
	if (!support.supported) {
		applyPageSupportState(support);
		return;
	}
	const countdown = await getCountdown();
	if (mode === "selected-area" || mode === "scrolling-area" || mode === "capture-text") {
		if (countdown > 0) await runCountdown(countdown, tab.id);
		chrome.runtime.sendMessage({
			type: "INIT_INTERACTIVE_MODE",
			payload: {
				mode,
				tabId: tab.id
			}
		});
		window.close();
		return;
	}
	if (countdown > 0) await runCountdown(countdown, tab.id);
	showProgress();
	chrome.runtime.sendMessage({
		type: "START_CAPTURE",
		payload: {
			mode,
			tabId: tab.id
		}
	}, (response) => {
		if (response?.type === "CAPTURE_COMPLETE") {
			if (mode === "full-page") completeReviewTabCapture();
			else completeQuickCapture(response.payload);
		} else if (response?.type === "CAPTURE_ERROR") showError(response.payload?.message || "Capture failed");
	});
}
function completeReviewTabCapture() {
	progressLabel.textContent = "Opened in new tab";
	progressFill.style.transform = "scaleX(1)";
	setTimeout(() => window.close(), 700);
}
async function completeQuickCapture(payload) {
	let copied = true;
	try {
		const blob = await (await fetch(payload.dataUrl)).blob();
		const uhdBlob = await upscaleToUHD(blob.type === "image/png" ? blob : await convertToPng(blob));
		await navigator.clipboard.write([new ClipboardItem({ "image/png": uhdBlob })]);
	} catch {
		copied = false;
	}
	progressLabel.textContent = copied ? t("toast.copied") : "Screenshot captured";
	progressFill.style.transform = "scaleX(1)";
	setTimeout(() => window.close(), 900);
}
function runCountdown(seconds, tabId) {
	return new Promise((resolve) => {
		chrome.tabs.sendMessage(tabId, {
			type: "SHOW_COUNTDOWN",
			payload: { seconds }
		}).catch(() => {});
		setTimeout(resolve, seconds * 1e3);
	});
}
function showProgress() {
	modesSection.style.display = "none";
	statusLine.classList.remove("active");
	progressSection.classList.add("active");
	resultBar.classList.remove("active");
	errorBar.classList.remove("active");
	progressLabel.textContent = t("progress.preparing");
	progressFill.style.transform = "scaleX(0)";
}
function updateProgress(progress) {
	const { current, total, phase } = progress;
	switch (phase) {
		case "preparing":
			progressLabel.textContent = t("progress.preparing_page");
			break;
		case "capturing":
			progressLabel.textContent = t("progress.capturing", {
				current,
				total
			});
			progressFill.style.transform = `scaleX(${current / total * .8})`;
			break;
		case "stitching":
			progressLabel.textContent = t("progress.stitching");
			progressFill.style.transform = "scaleX(0.9)";
			break;
		case "done": progressFill.style.transform = "scaleX(1)";
	}
}
function showResult(result) {
	progressSection.classList.remove("active");
	modesSection.style.display = "none";
	statusLine.classList.remove("active");
	resultBar.classList.add("active");
	const w = Math.round(result.width);
	const h = Math.round(result.height);
	const method = result.method === "scroll-stitch" ? "Scroll-Stitch" : "Snapshot";
	resultText.textContent = t("result.dimensions", {
		w,
		h,
		method
	});
	const previewContainer = document.getElementById("popupPreviewContainer");
	const previewImg = document.getElementById("popupPreviewImg");
	const previewFade = document.getElementById("popupPreviewFade");
	if (currentBlobUrl && previewContainer && previewImg) {
		previewImg.src = currentBlobUrl;
		previewContainer.style.display = "flex";
		const isLongCapture = result.mode === "full-page" || result.mode === "scrolling-area" || h > 800;
		if (previewFade) previewFade.style.display = isLongCapture ? "flex" : "none";
	}
	playCaptureSound();
}
function showError(message) {
	progressSection.classList.remove("active");
	modesSection.style.display = "grid";
	errorBar.classList.add("active");
	errorMsg.textContent = message;
	setTimeout(() => errorBar.classList.remove("active"), 5e3);
}
function showToast(message) {
	toast.textContent = message;
	toast.classList.add("show");
	setTimeout(() => toast.classList.remove("show"), 2500);
}
function getDomain(url) {
	try {
		return new URL(url).hostname;
	} catch {
		return "unknown";
	}
}
function timeAgo(ts) {
	const s = Math.max(0, Math.round((Date.now() - ts) / 1e3));
	if (s < 5) return "just now";
	if (s < 60) return `${s}s ago`;
	const m = Math.round(s / 60);
	if (m < 60) return `${m}m ago`;
	const h = Math.round(m / 60);
	if (h < 24) return `${h}h ago`;
	return `${Math.round(h / 24)}d ago`;
}
var MODE_LABEL = {
	"full-page": "Full page",
	"visible-area": "Visible area",
	"selected-area": "Selected area",
	"scrolling-area": "Scrolling area"
};
/** Shows a one-line summary of the last capture on a fresh popup open, so the
*  user doesn't have to re-capture just to grab or re-edit something they
*  already took a moment ago. Only shown when nothing else (progress/result/
*  error) is already occupying the popup body. */
async function loadLastCaptureStatus() {
	try {
		const resp = await chrome.runtime.sendMessage({ type: "GET_LAST_CAPTURE" });
		const result = resp?.result;
		if (!result || !resp?.hasBlob) return;
		if (resultBar.classList.contains("active") || errorBar.classList.contains("active")) return;
		statusText.innerHTML = `<b>${MODE_LABEL[result.mode] || result.mode}</b> · ${Math.round(result.width)}×${Math.round(result.height)} · ${timeAgo(result.timestamp)}`;
		const blobResp = await chrome.runtime.sendMessage({ type: "GET_CAPTURE_BLOB_URL" });
		if (blobResp?.url) {
			statusThumb.src = blobResp.url;
			currentBlobUrl = blobResp.url;
			currentUrl = result.url || "";
			statusLine.classList.add("active");
		}
	} catch {}
}
statusViewBtn.addEventListener("click", async () => {
	const resp = await chrome.runtime.sendMessage({ type: "GET_LAST_CAPTURE" });
	if (resp?.result) {
		resp.result;
		showResult(resp.result);
	}
});
function formatShortcutForDisplay(raw, isMac) {
	let s = raw;
	s = s.replace(/⌃/g, isMac ? "Ctrl+" : "Ctrl+");
	s = s.replace(/⌥/g, isMac ? "Option+" : "Alt+");
	s = s.replace(/⇧/g, "Shift+");
	s = s.replace(/⌘/g, isMac ? "Cmd+" : "Ctrl+");
	s = s.replace(/Command/gi, isMac ? "Cmd" : "Ctrl");
	const parts = s.split("+").map((p) => p.trim()).filter(Boolean);
	const key = parts[parts.length - 1];
	const mods = parts.slice(0, -1);
	const hasCmd = mods.some((m) => /^(cmd|command|ctrl)$/i.test(m));
	const hasAlt = mods.some((m) => /^(alt|option)$/i.test(m));
	const hasShift = mods.some((m) => /^shift$/i.test(m));
	const ordered = [];
	if (hasCmd) ordered.push(isMac ? "Cmd" : "Ctrl");
	if (hasAlt) ordered.push(isMac ? "Option" : "Alt");
	if (hasShift) ordered.push("Shift");
	if (key) ordered.push(key);
	return ordered.join("+");
}
function updateShortcutLabels() {
	const isMac = typeof navigator !== "undefined" && /Mac|iPhone|iPod|iPad/.test(navigator.platform || navigator.userAgent);
	const mod = isMac ? "Cmd" : "Ctrl";
	const defaultShortcuts = {
		"capture-full-page": `${mod}+Shift+F`,
		"capture-visible": `${mod}+Shift+V`,
		"capture-selected-area": `${mod}+Shift+A`
	};
	document.querySelectorAll(".m-kbd[data-command]").forEach((el) => {
		const cmd = el.dataset.command;
		if (cmd && defaultShortcuts[cmd]) el.textContent = defaultShortcuts[cmd];
	});
	if (chrome.commands?.getAll) chrome.commands.getAll((commands) => {
		commands.forEach((c) => {
			if (!c.name || !c.shortcut) return;
			const el = document.querySelector(`.m-kbd[data-command="${c.name}"]`);
			if (el) el.textContent = formatShortcutForDisplay(c.shortcut, isMac);
		});
	});
}
checkActiveTabSupport();
loadLastCaptureStatus();
updateShortcutLabels();
//#endregion
