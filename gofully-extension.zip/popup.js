import { i as generateFilename } from "./chunks/image-BPYnapgS.js";
import { t as generatePDF } from "./chunks/pdf-generator-Dg4k4FqC.js";
import { t as isSupportedCapturePage } from "./chunks/url-validator-CInVwRGC.js";
//#region src/popup/popup.ts
var modesSection = document.getElementById("modesSection");
var progressSection = document.getElementById("progressSection");
var progressLabel = document.getElementById("progressLabel");
var progressFill = document.getElementById("progressFill");
var resultBar = document.getElementById("resultBar");
var resultText = document.getElementById("resultText");
document.getElementById("errorBar");
document.getElementById("errorMsg");
var copyBtn = document.getElementById("copyBtn");
var savePngBtn = document.getElementById("savePngBtn");
var savePdfBtn = document.getElementById("savePdfBtn");
var toast = document.getElementById("toast");
var unsupportedPanel = document.getElementById("unsupportedPanel");
var unsupportedTitle = document.getElementById("unsupportedTitle");
var unsupportedDesc = document.getElementById("unsupportedDesc");
var unsupportedDismissBtn = document.getElementById("unsupportedDismissBtn");
var currentBlobUrl = null;
var currentUrl = "";
var currentSupportState = {
	supported: true,
	type: "supported"
};
function playCaptureSound() {
	try {
		const url = chrome.runtime.getURL("assets/shutter.mp3");
		const audio = new Audio(url);
		audio.volume = .5;
		audio.play().catch(() => {});
	} catch {}
}
document.getElementById("settingsBtn")?.addEventListener("click", () => {
	chrome.runtime.openOptionsPage();
});
document.getElementById("helpBtn")?.addEventListener("click", () => {
	chrome.tabs.create({ url: chrome.runtime.getURL("help.html") });
});
unsupportedDismissBtn?.addEventListener("click", () => {
	unsupportedPanel.classList.remove("active");
});
document.querySelectorAll(".mode-btn").forEach((btn) => {
	btn.addEventListener("click", () => {
		const mode = btn.dataset.mode;
		if (btn.disabled) return;
		startCapture(mode);
	});
});
copyBtn.addEventListener("click", async () => {
	if (!currentBlobUrl) return;
	try {
		const blob = await (await fetch(currentBlobUrl)).blob();
		const pngBlob = blob.type === "image/png" ? blob : await convertToPng(blob);
		await navigator.clipboard.write([new ClipboardItem({ "image/png": pngBlob })]);
		showToast("Copied!");
	} catch {
		showToast("Copy failed — try Save PNG");
	}
});
async function convertToPng(blob) {
	const bitmap = await createImageBitmap(blob);
	const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
	canvas.getContext("2d").drawImage(bitmap, 0, 0);
	return canvas.convertToBlob({ type: "image/png" });
}
savePngBtn.addEventListener("click", async () => {
	if (!currentBlobUrl) return;
	try {
		const domain = getDomain(currentUrl);
		const filename = generateFilename(domain, "png");
		await chrome.downloads.download({
			url: currentBlobUrl,
			filename,
			saveAs: false
		});
		showToast("Saved as PNG!");
	} catch {
		showToast("Save failed");
	}
});
document.getElementById("editBtn")?.addEventListener("click", async () => {
	if (!currentBlobUrl) return;
	chrome.runtime.sendMessage({ type: "OPEN_EDITOR" });
});
savePdfBtn.addEventListener("click", async () => {
	if (!currentBlobUrl) return;
	try {
		const blob = await (await fetch(currentBlobUrl)).blob();
		const domain = getDomain(currentUrl);
		const pdfDataUrl = await blobToDataUrlLocal(await generatePDF(blob, "a4"));
		const filename = generateFilename(domain, "pdf");
		await chrome.downloads.download({
			url: pdfDataUrl,
			filename,
			saveAs: false
		});
		showToast("Saved as PDF!");
	} catch {
		showToast("PDF generation failed");
	}
});
chrome.runtime.onMessage.addListener((message) => {
	if (message.type === "CAPTURE_PROGRESS") updateProgress(message.payload);
	if (message.type === "CAPTURE_COMPLETE") {
		message.payload;
		currentUrl = message.payload.url;
		chrome.runtime.sendMessage({ type: "GET_CAPTURE_BLOB_URL" }, (resp) => {
			if (resp?.url) currentBlobUrl = resp.url;
			showResult(message.payload);
		});
	}
});
/**
* Initial page validation on popup open
*/
async function checkActiveTabSupport() {
	try {
		const [tab] = await chrome.tabs.query({
			active: true,
			currentWindow: true
		});
		const url = tab?.url || "";
		currentUrl = url;
		currentSupportState = isSupportedCapturePage(url);
		applyPageSupportState(currentSupportState);
	} catch {
		currentSupportState = {
			supported: true,
			type: "supported"
		};
		applyPageSupportState(currentSupportState);
	}
}
function applyPageSupportState(support) {
	const modeButtons = document.querySelectorAll(".mode-btn");
	if (!support.supported) {
		modeButtons.forEach((btn) => {
			const button = btn;
			button.disabled = true;
			button.setAttribute("aria-disabled", "true");
			button.title = support.message || "Capture is unavailable on this page";
		});
		if (unsupportedTitle && support.title) unsupportedTitle.textContent = support.title;
		if (unsupportedDesc && support.message) unsupportedDesc.textContent = support.message;
		unsupportedPanel.classList.add("active");
	} else {
		modeButtons.forEach((btn) => {
			const button = btn;
			button.disabled = false;
			button.removeAttribute("aria-disabled");
			button.removeAttribute("title");
		});
		unsupportedPanel.classList.remove("active");
	}
}
async function startCapture(mode) {
	const [tab] = await chrome.tabs.query({
		active: true,
		currentWindow: true
	});
	if (!tab?.id) return;
	const support = isSupportedCapturePage(tab.url);
	if (!support.supported) {
		applyPageSupportState(support);
		return;
	}
	if (mode === "selected-area" || mode === "scrolling-area" || mode === "capture-text") {
		chrome.runtime.sendMessage({
			type: "INIT_INTERACTIVE_MODE",
			payload: {
				mode,
				tabId: tab.id
			}
		});
		window.close();
		return;
	}
	chrome.runtime.sendMessage({
		type: "START_CAPTURE",
		payload: {
			mode,
			tabId: tab.id
		}
	});
	window.close();
}
function updateProgress(progress) {
	const { current, total, phase } = progress;
	switch (phase) {
		case "preparing":
			progressLabel.textContent = "Preparing page...";
			break;
		case "capturing":
			progressLabel.textContent = `Capturing ${current}/${total}...`;
			progressFill.style.width = `${current / total * 80}%`;
			break;
		case "stitching":
			progressLabel.textContent = "Stitching frames...";
			progressFill.style.width = "90%";
			break;
		case "done": progressFill.style.width = "100%";
	}
}
function showResult(result) {
	progressSection.classList.remove("active");
	modesSection.style.display = "none";
	resultBar.classList.add("active");
	const w = Math.round(result.width);
	const h = Math.round(result.height);
	resultText.textContent = `${w}×${h}px captured via ${result.method === "cdp" ? "CDP" : "Scroll-Stitch"}`;
	const previewContainer = document.getElementById("popupPreviewContainer");
	const previewImg = document.getElementById("popupPreviewImg");
	const previewFade = document.getElementById("popupPreviewFade");
	if (currentBlobUrl && previewContainer && previewImg) {
		previewImg.src = currentBlobUrl;
		previewContainer.style.display = "flex";
		const isLongCapture = result.mode === "full-page" || result.mode === "scrolling-area" || h > 800;
		if (previewFade) previewFade.style.display = isLongCapture ? "flex" : "none";
	}
	playCaptureSound();
}
function showToast(message) {
	toast.textContent = message;
	toast.classList.add("show");
	setTimeout(() => toast.classList.remove("show"), 2500);
}
function getDomain(url) {
	try {
		return new URL(url).hostname;
	} catch {
		return "unknown";
	}
}
function blobToDataUrlLocal(blob) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(reader.result);
		reader.onerror = reject;
		reader.readAsDataURL(blob);
	});
}
checkActiveTabSupport();
//#endregion
