(function() {
	//#region src/content/sticky-manager.ts
	var hiddenElements = [];
	function findStickyElements() {
		const all = document.querySelectorAll("*");
		const sticky = [];
		for (const el of all) {
			const style = getComputedStyle(el);
			if (style.position === "fixed" || style.position === "sticky") {
				if (el instanceof HTMLElement && el.offsetHeight > 0) sticky.push(el);
			}
			if (el.shadowRoot) {
				const shadowEls = el.shadowRoot.querySelectorAll("*");
				for (const shadowEl of shadowEls) {
					const sStyle = getComputedStyle(shadowEl);
					if (sStyle.position === "fixed" || sStyle.position === "sticky") {
						if (shadowEl instanceof HTMLElement && shadowEl.offsetHeight > 0) sticky.push(shadowEl);
					}
				}
			}
		}
		return sticky;
	}
	function getUniqueSelector(el) {
		if (el.id) return `#${el.id}`;
		const path = [];
		let current = el;
		while (current && current !== document.body) {
			let selector = current.tagName.toLowerCase();
			if (current.id) {
				selector = `#${current.id}`;
				path.unshift(selector);
				break;
			}
			const parent = current.parentElement;
			if (parent) {
				const siblings = Array.from(parent.children).filter((c) => c.tagName === current.tagName);
				if (siblings.length > 1) {
					const index = siblings.indexOf(current) + 1;
					selector += `:nth-of-type(${index})`;
				}
			}
			path.unshift(selector);
			current = current.parentElement;
		}
		return path.join(" > ");
	}
	function hideStickyElements() {
		const elements = findStickyElements();
		hiddenElements = [];
		for (const el of elements) {
			hiddenElements.push({
				selector: getUniqueSelector(el),
				originalPosition: el.style.position,
				originalDisplay: el.style.display
			});
			el.style.setProperty("display", "none", "important");
		}
		return hiddenElements;
	}
	function restoreStickyElements() {
		const elements = findStickyElements();
		for (const el of elements) el.style.removeProperty("display");
		for (const saved of hiddenElements) try {
			const el = document.querySelector(saved.selector);
			if (el) {
				if (saved.originalDisplay) el.style.display = saved.originalDisplay;
				if (saved.originalPosition) el.style.position = saved.originalPosition;
			}
		} catch {}
		hiddenElements = [];
	}
	chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
		if (message.type === "HIDE_STICKY") {
			sendResponse({ count: hideStickyElements().length });
			return true;
		}
		if (message.type === "RESTORE_STICKY") {
			restoreStickyElements();
			sendResponse({ restored: true });
			return true;
		}
		return false;
	});
	//#endregion
})();
