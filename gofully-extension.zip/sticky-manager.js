(function() {
	//#region src/content/sticky-manager.ts
	function findStickyElements() {
		const all = document.querySelectorAll("*");
		const sticky = [];
		for (const el of all) {
			const style = getComputedStyle(el);
			if (style.position === "fixed" || style.position === "sticky") {
				if (el instanceof HTMLElement && el.offsetHeight > 0) sticky.push(el);
			}
			if (el.shadowRoot) {
				const shadowEls = el.shadowRoot.querySelectorAll("*");
				for (const shadowEl of shadowEls) {
					const sStyle = getComputedStyle(shadowEl);
					if (sStyle.position === "fixed" || sStyle.position === "sticky") {
						if (shadowEl instanceof HTMLElement && shadowEl.offsetHeight > 0) sticky.push(shadowEl);
					}
				}
			}
		}
		return sticky;
	}
	function getUniqueSelector(el) {
		if (el.id) return `#${el.id}`;
		const path = [];
		let current = el;
		while (current && current !== document.body) {
			let selector = current.tagName.toLowerCase();
			if (current.id) {
				selector = `#${current.id}`;
				path.unshift(selector);
				break;
			}
			const parent = current.parentElement;
			if (parent) {
				const siblings = Array.from(parent.children).filter((c) => c.tagName === current.tagName);
				if (siblings.length > 1) {
					const index = siblings.indexOf(current) + 1;
					selector += `:nth-of-type(${index})`;
				}
			}
			path.unshift(selector);
			current = current.parentElement;
		}
		return path.join(" > ");
	}
	var frozenElements = [];
	function freezeStickyElements() {
		const elements = findStickyElements();
		frozenElements = [];
		for (const el of elements) {
			const rect = el.getBoundingClientRect();
			const style = window.getComputedStyle(el);
			frozenElements.push({
				el,
				originalPosition: el.style.position,
				originalTop: el.style.top,
				originalLeft: el.style.left,
				originalWidth: el.style.width,
				originalZIndex: el.style.zIndex
			});
			const docTop = rect.top + window.scrollY;
			el.style.setProperty("position", "absolute", "important");
			el.style.setProperty("top", `${docTop}px`, "important");
			el.style.setProperty("left", `${rect.left + window.scrollX}px`, "important");
			el.style.setProperty("width", `${rect.width}px`, "important");
			el.style.setProperty("z-index", style.zIndex || "9999", "important");
		}
	}
	function restoreFrozenElements() {
		for (const saved of frozenElements) try {
			if (saved.originalPosition) saved.el.style.position = saved.originalPosition;
			else saved.el.style.removeProperty("position");
			if (saved.originalTop) saved.el.style.top = saved.originalTop;
			else saved.el.style.removeProperty("top");
			if (saved.originalLeft) saved.el.style.left = saved.originalLeft;
			else saved.el.style.removeProperty("left");
			if (saved.originalWidth) saved.el.style.width = saved.originalWidth;
			else saved.el.style.removeProperty("width");
			if (saved.originalZIndex) saved.el.style.zIndex = saved.originalZIndex;
			else saved.el.style.removeProperty("z-index");
		} catch {}
		frozenElements = [];
	}
	var hiddenStickyElements = [];
	function hideStickyElements() {
		const elements = findStickyElements();
		hiddenStickyElements = [];
		for (const el of elements) {
			if (el.id?.startsWith("gofully-") || el.id?.startsWith("snapforge-")) continue;
			hiddenStickyElements.push({
				el,
				originalVisibility: el.style.visibility
			});
			el.style.setProperty("visibility", "hidden", "important");
		}
		return hiddenStickyElements.map((h) => ({
			selector: getUniqueSelector(h.el),
			originalPosition: h.el.style.position,
			originalDisplay: h.el.style.display
		}));
	}
	function restoreStickyElements() {
		for (const saved of hiddenStickyElements) try {
			if (saved.originalVisibility) saved.el.style.setProperty("visibility", saved.originalVisibility);
			else {
				saved.el.style.removeProperty("visibility");
				saved.el.style.visibility = "";
			}
		} catch {}
		hiddenStickyElements = [];
		const all = document.querySelectorAll("*");
		for (const el of all) if (el.style.visibility === "hidden" && !el.id?.startsWith("gofully-") && !el.id?.startsWith("snapforge-")) {
			el.style.removeProperty("visibility");
			el.style.visibility = "";
		}
	}
	var captureKeepAlivePort = null;
	function startCaptureKeepAlive() {
		stopCaptureKeepAlive();
		try {
			captureKeepAlivePort = chrome.runtime.connect({ name: "gf-capture-keepalive" });
		} catch {
			captureKeepAlivePort = null;
		}
	}
	function stopCaptureKeepAlive() {
		try {
			captureKeepAlivePort?.disconnect();
		} catch {}
		captureKeepAlivePort = null;
	}
	window.__gofully_hide_sticky = hideStickyElements;
	window.__gofully_restore_sticky = () => {
		restoreStickyElements();
		restoreFrozenElements();
	};
	chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
		if (message.type === "FREEZE_STICKY") {
			freezeStickyElements();
			sendResponse({ frozen: true });
			return true;
		}
		if (message.type === "HIDE_STICKY") {
			sendResponse({ count: hideStickyElements().length });
			return true;
		}
		if (message.type === "RESTORE_STICKY") {
			restoreStickyElements();
			restoreFrozenElements();
			sendResponse({ restored: true });
			return true;
		}
		if (message.type === "CAPTURE_KEEPALIVE_START") {
			startCaptureKeepAlive();
			sendResponse({ started: true });
			return true;
		}
		if (message.type === "CAPTURE_KEEPALIVE_STOP") {
			stopCaptureKeepAlive();
			sendResponse({ stopped: true });
			return true;
		}
		return false;
	});
	//#endregion
})();
