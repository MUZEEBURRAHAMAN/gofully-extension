import { n as watchTheme, t as applyTheme } from "./chunks/theme-DcC2xsTw.js";
//#region src/welcome/welcome.ts
applyTheme();
watchTheme();
document.getElementById("getStartedBtn")?.addEventListener("click", () => {
	window.close();
});
//#endregion
