import { n as watchTheme, t as applyTheme } from "./chunks/theme-Yr0xuo90.js";
//#region src/welcome/welcome.ts
applyTheme();
watchTheme();
document.getElementById("getStartedBtn")?.addEventListener("click", () => {
	window.close();
});
//#endregion
