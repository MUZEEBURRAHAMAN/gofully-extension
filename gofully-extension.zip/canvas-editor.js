import { o as __toESM, t as __commonJSMin } from "./chunks/rolldown-runtime-CEgmsyvS.js";
import { a as generatePDF, n as markDismissed, r as markRatedYes, t as claimPendingRateNudge } from "./chunks/rate-nudge-BXoV-gqm.js";
import { n as watchTheme, t as applyTheme } from "./chunks/theme-Yr0xuo90.js";
//#region node_modules/fabric/dist/index.min.mjs
var e = Object.defineProperty;
var t = (t, n) => {
	let r = {};
	for (var i in t) e(r, i, {
		get: t[i],
		enumerable: !0
	});
	return n || e(r, Symbol.toStringTag, { value: `Module` }), r;
};
function n(e) {
	return n = typeof Symbol == `function` && typeof Symbol.iterator == `symbol` ? function(e) {
		return typeof e;
	} : function(e) {
		return e && typeof Symbol == `function` && e.constructor === Symbol && e !== Symbol.prototype ? `symbol` : typeof e;
	}, n(e);
}
function r(e) {
	var t = function(e, t) {
		if (n(e) != `object` || !e) return e;
		var r = e[Symbol.toPrimitive];
		if (r !== void 0) {
			var i = r.call(e, t || `default`);
			if (n(i) != `object`) return i;
			throw TypeError(`@@toPrimitive must return a primitive value.`);
		}
		return (t === `string` ? String : Number)(e);
	}(e, `string`);
	return n(t) == `symbol` ? t : t + ``;
}
function i(e, t, n) {
	return (t = r(t)) in e ? Object.defineProperty(e, t, {
		value: n,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[t] = n, e;
}
var a = class {
	constructor() {
		i(this, `browserShadowBlurConstant`, 1), i(this, `DPI`, 96), i(this, `devicePixelRatio`, typeof window < `u` ? window.devicePixelRatio : 1), i(this, `perfLimitSizeTotal`, 2097152), i(this, `maxCacheSideLimit`, 4096), i(this, `minCacheSideLimit`, 256), i(this, `disableStyleCopyPaste`, !1), i(this, `enableGLFiltering`, !0), i(this, `textureSize`, 4096), i(this, `forceGLPutImageData`, !1), i(this, `cachesBoundsOfCurve`, !1), i(this, `fontPaths`, {}), i(this, `NUM_FRACTION_DIGITS`, 4);
	}
};
var o = new class extends a {
	constructor(e) {
		super(), this.configure(e);
	}
	configure(e = {}) {
		Object.assign(this, e);
	}
	addFonts(e = {}) {
		this.fontPaths = {
			...this.fontPaths,
			...e
		};
	}
	removeFonts(e = []) {
		e.forEach((e) => {
			delete this.fontPaths[e];
		});
	}
	clearFonts() {
		this.fontPaths = {};
	}
	restoreDefaults(e) {
		let t = new a(), n = (e == null ? void 0 : e.reduce((e, n) => (e[n] = t[n], e), {})) || t;
		this.configure(n);
	}
}();
var s = (e, ...t) => console[e](`fabric`, ...t);
var c = class extends Error {
	constructor(e, t) {
		super(`fabric: ${e}`, t);
	}
};
var l = class extends c {
	constructor(e) {
		super(`${e} 'options.signal' is in 'aborted' state`);
	}
};
var u = class {};
var d = class extends u {
	testPrecision(e, t) {
		let n = `precision ${t} float;\nvoid main(){}`, r = e.createShader(e.FRAGMENT_SHADER);
		return !!r && (e.shaderSource(r, n), e.compileShader(r), !!e.getShaderParameter(r, e.COMPILE_STATUS));
	}
	queryWebGL(e) {
		let t = e.getContext(`webgl`);
		t && (this.maxTextureSize = t.getParameter(t.MAX_TEXTURE_SIZE), this.GLPrecision = [
			`highp`,
			`mediump`,
			`lowp`
		].find((e) => this.testPrecision(t, e)), t.getExtension(`WEBGL_lose_context`).loseContext(), s(`log`, `WebGL: max texture size ${this.maxTextureSize}`));
	}
	isSupported(e) {
		return !!this.maxTextureSize && this.maxTextureSize >= e;
	}
};
var f = {};
var p;
var h = () => p || (p = {
	document,
	window,
	isTouchSupported: `ontouchstart` in window || `ontouchstart` in document || window && window.navigator && window.navigator.maxTouchPoints > 0,
	WebGLProbe: new d(),
	dispose() {},
	copyPasteData: f
});
var g = () => h().document;
var _ = () => h().window;
var v = () => {
	var e;
	return Math.max((e = o.devicePixelRatio) == null ? _().devicePixelRatio : e, 1);
};
var y = new class {
	constructor() {
		i(this, `boundsOfCurveCache`, {}), this.charWidthsCache = /* @__PURE__ */ new Map();
	}
	getFontCache({ fontFamily: e, fontStyle: t, fontWeight: n }) {
		e = e.toLowerCase();
		let r = this.charWidthsCache;
		r.has(e) || r.set(e, /* @__PURE__ */ new Map());
		let i = r.get(e), a = `${t.toLowerCase()}_${(n + ``).toLowerCase()}`;
		return i.has(a) || i.set(a, /* @__PURE__ */ new Map()), i.get(a);
	}
	clearFontCache(e) {
		e ? this.charWidthsCache.delete((e || ``).toLowerCase()) : this.charWidthsCache = /* @__PURE__ */ new Map();
	}
	limitDimsByArea(e) {
		let { perfLimitSizeTotal: t } = o, n = Math.sqrt(t * e);
		return [Math.floor(n), Math.floor(t / n)];
	}
}();
var b = `7.4.0`;
function x() {}
var S = Math.PI / 2;
var C = Math.PI / 4;
var w = 2 * Math.PI;
var ee = Math.PI / 180;
var T = Object.freeze([
	1,
	0,
	0,
	1,
	0,
	0
]);
var E = `center`;
var D = `left`;
var O = `bottom`;
var k = `right`;
var te = `none`;
var ne = /\r?\n/;
var re = `moving`;
var ie = `scaling`;
var ae = `rotating`;
var oe = `rotate`;
var A = `skewing`;
var se = `resizing`;
var ce = `modifyPoly`;
var le = `changed`;
var ue = `scale`;
var de = `scaleX`;
var fe = `scaleY`;
var pe = `skewX`;
var me = `skewY`;
var j = `fill`;
var he = `stroke`;
var ge = `modified`;
var _e = `normal`;
var ve = `json`;
var M = new class {
	constructor() {
		this[ve] = /* @__PURE__ */ new Map(), this.svg = /* @__PURE__ */ new Map();
	}
	has(e) {
		return this[ve].has(e);
	}
	getClass(e) {
		let t = this[ve].get(e);
		if (!t) throw new c(`No class registered for ${e}`);
		return t;
	}
	setClass(e, t) {
		t ? this[ve].set(t, e) : (this[ve].set(e.type, e), this[ve].set(e.type.toLowerCase(), e));
	}
	getSVGClass(e) {
		return this.svg.get(e);
	}
	setSVGClass(e, t) {
		this.svg.set(t == null ? e.type.toLowerCase() : t, e);
	}
}();
var ye = new class extends Array {
	remove(e) {
		let t = this.indexOf(e);
		t > -1 && this.splice(t, 1);
	}
	cancelAll() {
		let e = this.splice(0);
		return e.forEach((e) => e.abort()), e;
	}
	cancelByCanvas(e) {
		if (!e) return [];
		let t = this.filter((t) => {
			var n;
			return t.target === e || typeof t.target == `object` && ((n = t.target) == null ? void 0 : n.canvas) === e;
		});
		return t.forEach((e) => e.abort()), t;
	}
	cancelByTarget(e) {
		if (!e) return [];
		let t = this.filter((t) => t.target === e);
		return t.forEach((e) => e.abort()), t;
	}
}();
var be = class {
	constructor() {
		i(this, `__eventListeners`, {});
	}
	on(e, t) {
		if (this.__eventListeners || (this.__eventListeners = {}), typeof e == `object`) return Object.entries(e).forEach(([e, t]) => {
			this.on(e, t);
		}), () => this.off(e);
		if (t) {
			let n = e;
			return this.__eventListeners[n] || (this.__eventListeners[n] = []), this.__eventListeners[n].push(t), () => this.off(n, t);
		}
		return () => !1;
	}
	once(e, t) {
		if (typeof e == `object`) {
			let t = [];
			return Object.entries(e).forEach(([e, n]) => {
				t.push(this.once(e, n));
			}), () => t.forEach((e) => e());
		}
		if (t) {
			let n = this.on(e, function(...e) {
				t.call(this, ...e), n();
			});
			return n;
		}
		return () => !1;
	}
	_removeEventListener(e, t) {
		if (this.__eventListeners[e]) if (t) {
			let n = this.__eventListeners[e], r = n.indexOf(t);
			r > -1 && n.splice(r, 1);
		} else this.__eventListeners[e] = [];
	}
	off(e, t) {
		if (this.__eventListeners) if (e === void 0) for (let e in this.__eventListeners) this._removeEventListener(e);
		else typeof e == `object` ? Object.entries(e).forEach(([e, t]) => {
			this._removeEventListener(e, t);
		}) : this._removeEventListener(e, t);
	}
	fire(e, t) {
		var n;
		if (!this.__eventListeners) return;
		let r = (n = this.__eventListeners[e]) == null ? void 0 : n.concat();
		if (r) for (let e = 0; e < r.length; e++) r[e].call(this, t || {});
	}
};
var xe = (e, t) => {
	let n = e.indexOf(t);
	return n !== -1 && e.splice(n, 1), e;
};
var Se = (e) => {
	if (e === 0) return 1;
	switch (Math.abs(e) / S) {
		case 1:
		case 3: return 0;
		case 2: return -1;
	}
	return Math.cos(e);
};
var Ce = (e) => {
	if (e === 0) return 0;
	let t = e / S, n = Math.sign(e);
	switch (t) {
		case 1: return n;
		case 2: return 0;
		case 3: return -n;
	}
	return Math.sin(e);
};
var N = class e {
	constructor(e = 0, t = 0) {
		typeof e == `object` ? (this.x = e.x, this.y = e.y) : (this.x = e, this.y = t);
	}
	add(t) {
		return new e(this.x + t.x, this.y + t.y);
	}
	addEquals(e) {
		return this.x += e.x, this.y += e.y, this;
	}
	scalarAdd(t) {
		return new e(this.x + t, this.y + t);
	}
	scalarAddEquals(e) {
		return this.x += e, this.y += e, this;
	}
	subtract(t) {
		return new e(this.x - t.x, this.y - t.y);
	}
	subtractEquals(e) {
		return this.x -= e.x, this.y -= e.y, this;
	}
	scalarSubtract(t) {
		return new e(this.x - t, this.y - t);
	}
	scalarSubtractEquals(e) {
		return this.x -= e, this.y -= e, this;
	}
	multiply(t) {
		return new e(this.x * t.x, this.y * t.y);
	}
	scalarMultiply(t) {
		return new e(this.x * t, this.y * t);
	}
	scalarMultiplyEquals(e) {
		return this.x *= e, this.y *= e, this;
	}
	divide(t) {
		return new e(this.x / t.x, this.y / t.y);
	}
	scalarDivide(t) {
		return new e(this.x / t, this.y / t);
	}
	scalarDivideEquals(e) {
		return this.x /= e, this.y /= e, this;
	}
	eq(e) {
		return this.x === e.x && this.y === e.y;
	}
	lt(e) {
		return this.x < e.x && this.y < e.y;
	}
	lte(e) {
		return this.x <= e.x && this.y <= e.y;
	}
	gt(e) {
		return this.x > e.x && this.y > e.y;
	}
	gte(e) {
		return this.x >= e.x && this.y >= e.y;
	}
	lerp(t, n = .5) {
		return n = Math.max(Math.min(1, n), 0), new e(this.x + (t.x - this.x) * n, this.y + (t.y - this.y) * n);
	}
	distanceFrom(e) {
		let t = this.x - e.x, n = this.y - e.y;
		return Math.sqrt(t * t + n * n);
	}
	midPointFrom(e) {
		return this.lerp(e);
	}
	min(t) {
		return new e(Math.min(this.x, t.x), Math.min(this.y, t.y));
	}
	max(t) {
		return new e(Math.max(this.x, t.x), Math.max(this.y, t.y));
	}
	toString() {
		return `${this.x},${this.y}`;
	}
	setXY(e, t) {
		return this.x = e, this.y = t, this;
	}
	setX(e) {
		return this.x = e, this;
	}
	setY(e) {
		return this.y = e, this;
	}
	setFromPoint(e) {
		return this.x = e.x, this.y = e.y, this;
	}
	swap(e) {
		let t = this.x, n = this.y;
		this.x = e.x, this.y = e.y, e.x = t, e.y = n;
	}
	clone() {
		return new e(this.x, this.y);
	}
	rotate(t, n = we) {
		let r = Ce(t), i = Se(t), a = this.subtract(n);
		return new e(a.x * i - a.y * r, a.x * r + a.y * i).add(n);
	}
	transform(t, n = !1) {
		return new e(t[0] * this.x + t[2] * this.y + (n ? 0 : t[4]), t[1] * this.x + t[3] * this.y + (n ? 0 : t[5]));
	}
};
var we = new N(0, 0);
var Te = (e) => !!e && Array.isArray(e._objects);
function Ee(e) {
	class t extends e {
		constructor(...e) {
			super(...e), i(this, `_objects`, []);
		}
		_onObjectAdded(e) {}
		_onObjectRemoved(e) {}
		_onStackOrderChanged(e) {}
		add(...e) {
			let t = this._objects.push(...e);
			return e.forEach((e) => this._onObjectAdded(e)), t;
		}
		insertAt(e, ...t) {
			return this._objects.splice(e, 0, ...t), t.forEach((e) => this._onObjectAdded(e)), this._objects.length;
		}
		remove(...e) {
			let t = this._objects, n = [];
			return e.forEach((e) => {
				let r = t.indexOf(e);
				r !== -1 && (t.splice(r, 1), n.push(e), this._onObjectRemoved(e));
			}), n;
		}
		forEachObject(e) {
			this.getObjects().forEach((t, n, r) => e(t, n, r));
		}
		getObjects(...e) {
			return e.length === 0 ? [...this._objects] : this._objects.filter((t) => t.isType(...e));
		}
		item(e) {
			return this._objects[e];
		}
		isEmpty() {
			return this._objects.length === 0;
		}
		size() {
			return this._objects.length;
		}
		contains(e, n) {
			return !!this._objects.includes(e) || !!n && this._objects.some((n) => n instanceof t && n.contains(e, !0));
		}
		complexity() {
			return this._objects.reduce((e, t) => e += t.complexity ? t.complexity() : 0, 0);
		}
		sendObjectToBack(e) {
			return !(!e || e === this._objects[0]) && (xe(this._objects, e), this._objects.unshift(e), this._onStackOrderChanged(e), !0);
		}
		bringObjectToFront(e) {
			return !(!e || e === this._objects[this._objects.length - 1]) && (xe(this._objects, e), this._objects.push(e), this._onStackOrderChanged(e), !0);
		}
		sendObjectBackwards(e, t) {
			if (!e) return !1;
			let n = this._objects.indexOf(e);
			if (n !== 0) {
				let r = this.findNewLowerIndex(e, n, t);
				return xe(this._objects, e), this._objects.splice(r, 0, e), this._onStackOrderChanged(e), !0;
			}
			return !1;
		}
		bringObjectForward(e, t) {
			if (!e) return !1;
			let n = this._objects.indexOf(e);
			if (n !== this._objects.length - 1) {
				let r = this.findNewUpperIndex(e, n, t);
				return xe(this._objects, e), this._objects.splice(r, 0, e), this._onStackOrderChanged(e), !0;
			}
			return !1;
		}
		moveObjectTo(e, t) {
			return e !== this._objects[t] && (xe(this._objects, e), this._objects.splice(t, 0, e), this._onStackOrderChanged(e), !0);
		}
		findNewLowerIndex(e, t, n) {
			let r;
			if (n) {
				r = t;
				for (let n = t - 1; n >= 0; --n) if (e.isOverlapping(this._objects[n])) {
					r = n;
					break;
				}
			} else r = t - 1;
			return r;
		}
		findNewUpperIndex(e, t, n) {
			let r;
			if (n) {
				r = t;
				for (let n = t + 1; n < this._objects.length; ++n) if (e.isOverlapping(this._objects[n])) {
					r = n;
					break;
				}
			} else r = t + 1;
			return r;
		}
		collectObjects({ left: e, top: t, width: n, height: r }, { includeIntersecting: i = !0 } = {}) {
			let a = [], o = new N(e, t), s = o.add(new N(n, r));
			for (let e = this._objects.length - 1; e >= 0; e--) {
				let t = this._objects[e];
				t.selectable && t.visible && (i && t.intersectsWithRect(o, s) || t.isContainedWithinRect(o, s) || i && t.containsPoint(o) || i && t.containsPoint(s)) && a.push(t);
			}
			return a;
		}
	}
	return t;
}
var De = class extends be {
	_setOptions(e = {}) {
		for (let t in e) this.set(t, e[t]);
	}
	_setObject(e) {
		for (let t in e) this._set(t, e[t]);
	}
	set(e, t) {
		return typeof e == `object` ? this._setObject(e) : this._set(e, t), this;
	}
	_set(e, t) {
		this[e] = t;
	}
	toggle(e) {
		let t = this.get(e);
		return typeof t == `boolean` && this.set(e, !t), this;
	}
	get(e) {
		return this[e];
	}
};
function Oe(e) {
	return _().requestAnimationFrame(e);
}
function ke(e) {
	return _().cancelAnimationFrame(e);
}
var Ae = 0;
var je = () => Ae++;
var P = () => {
	let e = g().createElement(`canvas`);
	if (!e || e.getContext === void 0) throw new c("Failed to create `canvas` element");
	return e;
};
var Me = () => g().createElement(`img`);
var Ne = (e) => {
	var t;
	let n = F(e);
	return (t = n.getContext(`2d`)) == null || t.drawImage(e, 0, 0), n;
};
var F = (e) => {
	let t = P();
	return t.width = e.width, t.height = e.height, t;
};
var Pe = (e, t, n) => e.toDataURL(`image/${t}`, n);
var Fe = (e, t, n) => new Promise((r, i) => {
	e.toBlob(r, `image/${t}`, n);
});
var I = (e) => e * ee;
var Ie = (e) => e / ee;
var Le = (e) => e.every((e, t) => e === T[t]);
var L = (e, t, n) => new N(e).transform(t, n);
var R = (e) => {
	let t = 1 / (e[0] * e[3] - e[1] * e[2]), n = [
		t * e[3],
		-t * e[1],
		-t * e[2],
		t * e[0],
		0,
		0
	], { x: r, y: i } = new N(e[4], e[5]).transform(n, !0);
	return n[4] = -r, n[5] = -i, n;
};
var z = (e, t, n) => [
	e[0] * t[0] + e[2] * t[1],
	e[1] * t[0] + e[3] * t[1],
	e[0] * t[2] + e[2] * t[3],
	e[1] * t[2] + e[3] * t[3],
	n ? 0 : e[0] * t[4] + e[2] * t[5] + e[4],
	n ? 0 : e[1] * t[4] + e[3] * t[5] + e[5]
];
var Re = (e, t) => e.reduceRight((e, n) => n && e ? z(n, e, t) : n || e, void 0) || T.concat();
var ze = ([e, t]) => Math.atan2(t, e);
var Be = ([e, t]) => Math.sqrt(e * e + t * t);
var Ve = ([, , e, t]) => Math.sqrt(e * e + t * t);
var He = (e) => {
	let t = ze(e), n = e[0] ** 2 + e[1] ** 2, r = Math.sqrt(n), i = (e[0] * e[3] - e[2] * e[1]) / r, a = Math.atan2(e[0] * e[2] + e[1] * e[3], n);
	return {
		angle: Ie(t),
		scaleX: r,
		scaleY: i,
		skewX: Ie(a),
		skewY: 0,
		translateX: e[4] || 0,
		translateY: e[5] || 0
	};
};
var Ue = (e, t = 0) => [
	1,
	0,
	0,
	1,
	e,
	t
];
function We({ angle: e = 0 } = {}, { x: t = 0, y: n = 0 } = {}) {
	let r = I(e), i = Se(r), a = Ce(r);
	return [
		i,
		a,
		-a,
		i,
		t ? t - (i * t - a * n) : 0,
		n ? n - (a * t + i * n) : 0
	];
}
var Ge = (e, t = e) => [
	e,
	0,
	0,
	t,
	0,
	0
];
var Ke = (e) => Math.tan(I(e));
var qe = (e) => [
	1,
	0,
	Ke(e),
	1,
	0,
	0
];
var Je = (e) => [
	1,
	Ke(e),
	0,
	1,
	0,
	0
];
var Ye = ({ scaleX: e = 1, scaleY: t = 1, flipX: n = !1, flipY: r = !1, skewX: i = 0, skewY: a = 0 }) => {
	let o = Ge(n ? -e : e, r ? -t : t);
	return i && (o = z(o, qe(i), !0)), a && (o = z(o, Je(a), !0)), o;
};
var Xe = (e) => {
	let { translateX: t = 0, translateY: n = 0, angle: r = 0 } = e, i = Ue(t, n);
	r && (i = z(i, We({ angle: r })));
	let a = Ye(e);
	return Le(a) || (i = z(i, a)), i;
};
var Ze = (e, { signal: t, crossOrigin: n = null } = {}) => new Promise(function(r, i) {
	if (t && t.aborted) return i(new l(`loadImage`));
	let a = Me(), o;
	t && (o = function(e) {
		a.src = ``, i(e);
	}, t.addEventListener(`abort`, o, { once: !0 }));
	let s = function() {
		a.onload = a.onerror = null, o && t?.removeEventListener(`abort`, o), r(a);
	};
	e ? (a.onload = s, a.onerror = function() {
		o && t?.removeEventListener(`abort`, o), i(new c(`Error loading ${a.src}`));
	}, n && (a.crossOrigin = n), a.src = e) : s();
});
var Qe = (e, { signal: t, reviver: n = x } = {}) => new Promise((r, i) => {
	let a = [];
	t && t.addEventListener(`abort`, i, { once: !0 }), Promise.allSettled(e.map((e) => M.getClass(e.type).fromObject(e, { signal: t }))).then(async (t) => {
		for (let [r, i] of t.entries()) if (i.status === `fulfilled` && (await n(e[r], i.value), a.push(i.value)), i.status === `rejected`) {
			let t = await n(e[r], void 0, i.reason);
			t && a.push(t);
		}
		r(a);
	}).catch((e) => {
		a.forEach((e) => {
			e.dispose && e.dispose();
		}), i(e);
	}).finally(() => {
		t && t.removeEventListener(`abort`, i);
	});
});
var $e = (e, { signal: t } = {}) => new Promise((n, r) => {
	let i = [];
	t && t.addEventListener(`abort`, r, { once: !0 });
	let a = Object.values(e).map((e) => e && e.type && M.has(e.type) ? Qe([e], { signal: t }).then(([e]) => (i.push(e), e)) : e), o = Object.keys(e);
	Promise.all(a).then((e) => e.reduce((e, t, n) => (e[o[n]] = t, e), {})).then(n).catch((e) => {
		i.forEach((e) => {
			e.dispose && e.dispose();
		}), r(e);
	}).finally(() => {
		t && t.removeEventListener(`abort`, r);
	});
});
var et = (e, t = []) => t.reduce((t, n) => (n in e && (t[n] = e[n]), t), {});
var tt = (e, t) => Object.keys(e).reduce((n, r) => (t(e[r], r, e) && (n[r] = e[r]), n), {});
var B = (e, t) => parseFloat(Number(e).toFixed(t));
var nt = (e) => `matrix(` + e.map((e) => B(e, o.NUM_FRACTION_DIGITS)).join(` `) + `)`;
var V = (e) => !!e && e.toLive !== void 0;
var rt = (e) => !!e && typeof e.toObject == `function`;
var it = (e) => !!e && e.offsetX !== void 0 && `source` in e;
var at = (e) => !!e && `multiSelectionStacking` in e;
function ot(e) {
	let t = e && H(e), n = 0, r = 0;
	if (!e || !t) return {
		left: n,
		top: r
	};
	let i = e, a = t.documentElement, o = t.body || {
		scrollLeft: 0,
		scrollTop: 0
	};
	for (; i && (i.parentNode || i.host) && (i = i.parentNode || i.host, i === t ? (n = o.scrollLeft || a.scrollLeft || 0, r = o.scrollTop || a.scrollTop || 0) : (n += i.scrollLeft || 0, r += i.scrollTop || 0), i.nodeType !== 1 || i.style.position !== `fixed`););
	return {
		left: n,
		top: r
	};
}
var H = (e) => e.ownerDocument || null;
var st = (e) => {
	var t;
	return ((t = e.ownerDocument) == null ? void 0 : t.defaultView) || null;
};
var ct = (e, t, { width: n, height: r }, i = 1) => {
	e.width = n, e.height = r, i > 1 && (e.setAttribute(`width`, (n * i).toString()), e.setAttribute(`height`, (r * i).toString()), t.scale(i, i));
};
var lt = (e, { width: t, height: n }) => {
	t && (e.style.width = typeof t == `number` ? `${t}px` : t), n && (e.style.height = typeof n == `number` ? `${n}px` : n);
};
function ut(e) {
	return e.onselectstart !== void 0 && (e.onselectstart = () => !1), e.style.userSelect = te, e;
}
var dt = class {
	constructor(e) {
		i(this, `_originalCanvasStyle`, void 0), i(this, `lower`, void 0);
		let t = this.createLowerCanvas(e);
		this.lower = {
			el: t,
			ctx: t.getContext(`2d`)
		};
	}
	createLowerCanvas(e) {
		let t = (n = e) && n.getContext !== void 0 ? e : e && g().getElementById(e) || P();
		var n;
		if (t.hasAttribute(`data-fabric`)) throw new c(`Trying to initialize a canvas that has already been initialized. Did you forget to dispose the canvas?`);
		return this._originalCanvasStyle = t.style.cssText, t.setAttribute(`data-fabric`, `main`), t.classList.add(`lower-canvas`), t;
	}
	cleanupDOM({ width: e, height: t }) {
		let { el: n } = this.lower;
		n.classList.remove(`lower-canvas`), n.removeAttribute(`data-fabric`), n.setAttribute(`width`, `${e}`), n.setAttribute(`height`, `${t}`), n.style.cssText = this._originalCanvasStyle || ``, this._originalCanvasStyle = void 0;
	}
	setDimensions(e, t) {
		let { el: n, ctx: r } = this.lower;
		ct(n, r, e, t);
	}
	setCSSDimensions(e) {
		lt(this.lower.el, e);
	}
	calcOffset() {
		return function(e) {
			var t;
			let n = e && H(e), r = {
				left: 0,
				top: 0
			};
			if (!n) return r;
			let i = ((t = st(e)) == null ? void 0 : t.getComputedStyle(e, null)) || {};
			r.left += parseInt(i.borderLeftWidth, 10) || 0, r.top += parseInt(i.borderTopWidth, 10) || 0, r.left += parseInt(i.paddingLeft, 10) || 0, r.top += parseInt(i.paddingTop, 10) || 0;
			let a = {
				left: 0,
				top: 0
			}, o = n.documentElement;
			e.getBoundingClientRect !== void 0 && (a = e.getBoundingClientRect());
			let s = ot(e);
			return {
				left: a.left + s.left - (o.clientLeft || 0) + r.left,
				top: a.top + s.top - (o.clientTop || 0) + r.top
			};
		}(this.lower.el);
	}
	dispose() {
		h().dispose(this.lower.el), delete this.lower;
	}
};
var ft = {
	backgroundVpt: !0,
	backgroundColor: ``,
	overlayVpt: !0,
	overlayColor: ``,
	includeDefaultValues: !0,
	svgViewportTransformation: !0,
	renderOnAddRemove: !0,
	skipOffscreen: !0,
	enableRetinaScaling: !0,
	imageSmoothingEnabled: !0,
	controlsAboveOverlay: !1,
	allowTouchScrolling: !1,
	viewportTransform: [...T],
	patternQuality: `best`
};
var pt = t({
	capitalize: () => mt,
	escapeXml: () => U,
	graphemeSplit: () => gt
});
var mt = (e, t = !1) => `${e.charAt(0).toUpperCase()}${t ? e.slice(1) : e.slice(1).toLowerCase()}`;
var U = (e) => e.toString().replace(/&/g, `&amp;`).replace(/"/g, `&quot;`).replace(/'/g, `&apos;`).replace(/</g, `&lt;`).replace(/>/g, `&gt;`);
var ht;
var gt = (e) => {
	if (ht || ht || (ht = `Intl` in _() && `Segmenter` in Intl && new Intl.Segmenter(void 0, { granularity: `grapheme` })), ht) {
		let t = ht.segment(e);
		return Array.from(t).map(({ segment: e }) => e);
	}
	return _t(e);
};
var _t = (e) => {
	let t = [];
	for (let n, r = 0; r < e.length; r++) !1 !== (n = vt(e, r)) && t.push(n);
	return t;
};
var vt = (e, t) => {
	let n = e.charCodeAt(t);
	if (isNaN(n)) return ``;
	if (n < 55296 || n > 57343) return e.charAt(t);
	if (55296 <= n && n <= 56319) {
		if (e.length <= t + 1) throw `High surrogate without following low surrogate`;
		let n = e.charCodeAt(t + 1);
		if (56320 > n || n > 57343) throw `High surrogate without following low surrogate`;
		return e.charAt(t) + e.charAt(t + 1);
	}
	if (t === 0) throw `Low surrogate without preceding high surrogate`;
	let r = e.charCodeAt(t - 1);
	if (55296 > r || r > 56319) throw `Low surrogate without preceding high surrogate`;
	return !1;
};
var yt = class e extends Ee(De) {
	get lowerCanvasEl() {
		var e;
		return (e = this.elements.lower) == null ? void 0 : e.el;
	}
	get contextContainer() {
		var e;
		return (e = this.elements.lower) == null ? void 0 : e.ctx;
	}
	static getDefaults() {
		return e.ownDefaults;
	}
	constructor(e, t = {}) {
		super(), Object.assign(this, this.constructor.getDefaults()), this.set(t), this.initElements(e), this._setDimensionsImpl({
			width: this.width || this.elements.lower.el.width || 0,
			height: this.height || this.elements.lower.el.height || 0
		}), this.skipControlsDrawing = !1, this.viewportTransform = [...this.viewportTransform], this.calcViewportBoundaries();
	}
	initElements(e) {
		this.elements = new dt(e);
	}
	add(...e) {
		let t = super.add(...e);
		return e.length > 0 && this.renderOnAddRemove && this.requestRenderAll(), t;
	}
	insertAt(e, ...t) {
		let n = super.insertAt(e, ...t);
		return t.length > 0 && this.renderOnAddRemove && this.requestRenderAll(), n;
	}
	remove(...e) {
		let t = super.remove(...e);
		return t.length > 0 && this.renderOnAddRemove && this.requestRenderAll(), t;
	}
	_onObjectAdded(e) {
		e.canvas && e.canvas !== this && (s(`warn`, `Canvas is trying to add an object that belongs to a different canvas.
Resulting to default behavior: removing object from previous canvas and adding to new canvas`), e.canvas.remove(e)), e._set(`canvas`, this), e.setCoords(), this.fire(`object:added`, { target: e }), e.fire(`added`, { target: this });
	}
	_onObjectRemoved(e) {
		e._set(`canvas`, void 0), this.fire(`object:removed`, { target: e }), e.fire(`removed`, { target: this });
	}
	_onStackOrderChanged() {
		this.renderOnAddRemove && this.requestRenderAll();
	}
	getRetinaScaling() {
		return this.enableRetinaScaling ? v() : 1;
	}
	calcOffset() {
		return this._offset = this.elements.calcOffset();
	}
	getWidth() {
		return this.width;
	}
	getHeight() {
		return this.height;
	}
	_setDimensionsImpl(e, { cssOnly: t = !1, backstoreOnly: n = !1 } = {}) {
		if (!t) {
			let t = {
				width: this.width,
				height: this.height,
				...e
			};
			this.elements.setDimensions(t, this.getRetinaScaling()), this.hasLostContext = !0, this.width = t.width, this.height = t.height;
		}
		n || this.elements.setCSSDimensions(e), this.calcOffset();
	}
	setDimensions(e, t) {
		this._setDimensionsImpl(e, t), t && t.cssOnly || this.requestRenderAll();
	}
	getZoom() {
		return Be(this.viewportTransform);
	}
	setViewportTransform(e) {
		this.viewportTransform = e, this.calcViewportBoundaries(), this.renderOnAddRemove && this.requestRenderAll();
	}
	zoomToPoint(e, t) {
		let n = e, r = [...this.viewportTransform], i = L(e, R(r));
		r[0] = t, r[3] = t;
		let a = L(i, r);
		r[4] += n.x - a.x, r[5] += n.y - a.y, this.setViewportTransform(r);
	}
	setZoom(e) {
		this.zoomToPoint(new N(0, 0), e);
	}
	absolutePan(e) {
		let t = [...this.viewportTransform];
		return t[4] = -e.x, t[5] = -e.y, this.setViewportTransform(t);
	}
	relativePan(e) {
		return this.absolutePan(new N(-e.x - this.viewportTransform[4], -e.y - this.viewportTransform[5]));
	}
	getElement() {
		return this.elements.lower.el;
	}
	clearContext(e) {
		e.clearRect(0, 0, this.width, this.height);
	}
	getContext() {
		return this.elements.lower.ctx;
	}
	clear() {
		this.remove(...this.getObjects()), this.backgroundImage = void 0, this.overlayImage = void 0, this.backgroundColor = ``, this.overlayColor = ``, this.clearContext(this.getContext()), this.fire(`canvas:cleared`), this.renderOnAddRemove && this.requestRenderAll();
	}
	renderAll() {
		this.cancelRequestedRender(), this.destroyed || this.renderCanvas(this.getContext(), this._objects);
	}
	renderAndReset() {
		this.nextRenderHandle = 0, this.renderAll();
	}
	requestRenderAll() {
		this.nextRenderHandle || this.disposed || this.destroyed || (this.nextRenderHandle = Oe(() => this.renderAndReset()));
	}
	calcViewportBoundaries() {
		let e = this.width, t = this.height, n = R(this.viewportTransform), r = L({
			x: 0,
			y: 0
		}, n), i = L({
			x: e,
			y: t
		}, n), a = r.min(i), o = r.max(i);
		return this.vptCoords = {
			tl: a,
			tr: new N(o.x, a.y),
			bl: new N(a.x, o.y),
			br: o
		};
	}
	cancelRequestedRender() {
		this.nextRenderHandle && (ke(this.nextRenderHandle), this.nextRenderHandle = 0);
	}
	drawControls(e) {}
	renderCanvas(e, t) {
		if (this.destroyed) return;
		let n = this.viewportTransform, r = this.clipPath;
		this.calcViewportBoundaries(), this.clearContext(e), e.imageSmoothingEnabled = this.imageSmoothingEnabled, e.patternQuality = this.patternQuality, this.fire(`before:render`, { ctx: e }), this._renderBackground(e), e.save(), e.transform(n[0], n[1], n[2], n[3], n[4], n[5]), this._renderObjects(e, t), e.restore(), this.controlsAboveOverlay || this.skipControlsDrawing || this.drawControls(e), r && (r._set(`canvas`, this), r.shouldCache(), r._transformDone = !0, r.renderCache({ forClipping: !0 }), this.drawClipPathOnCanvas(e, r)), this._renderOverlay(e), this.controlsAboveOverlay && !this.skipControlsDrawing && this.drawControls(e), this.fire(`after:render`, { ctx: e }), this.__cleanupTask && (this.__cleanupTask(), this.__cleanupTask = void 0);
	}
	drawClipPathOnCanvas(e, t) {
		let n = this.viewportTransform;
		e.save(), e.transform(...n), e.globalCompositeOperation = `destination-in`, t.transform(e), e.scale(1 / t.zoomX, 1 / t.zoomY), e.drawImage(t._cacheCanvas, -t.cacheTranslationX, -t.cacheTranslationY), e.restore();
	}
	_renderObjects(e, t) {
		for (let n = 0, r = t.length; n < r; ++n) t[n] && t[n].render(e);
	}
	_renderBackgroundOrOverlay(e, t) {
		let n = this[`${t}Color`], r = this[`${t}Image`], i = this.viewportTransform, a = this[`${t}Vpt`];
		if (!n && !r) return;
		let o = V(n);
		if (n) {
			if (e.save(), e.beginPath(), e.moveTo(0, 0), e.lineTo(this.width, 0), e.lineTo(this.width, this.height), e.lineTo(0, this.height), e.closePath(), e.fillStyle = o ? n.toLive(e) : n, a && e.transform(...i), o) {
				e.transform(1, 0, 0, 1, n.offsetX || 0, n.offsetY || 0);
				let t = n.gradientTransform || n.patternTransform;
				t && e.transform(...t);
			}
			e.fill(), e.restore();
		}
		if (r) {
			e.save();
			let { skipOffscreen: t } = this;
			this.skipOffscreen = a, a && e.transform(...i), r.render(e), this.skipOffscreen = t, e.restore();
		}
	}
	_renderBackground(e) {
		this._renderBackgroundOrOverlay(e, `background`);
	}
	_renderOverlay(e) {
		this._renderBackgroundOrOverlay(e, `overlay`);
	}
	getCenterPoint() {
		return new N(this.width / 2, this.height / 2);
	}
	centerObjectH(e) {
		return this._centerObject(e, new N(this.getCenterPoint().x, e.getCenterPoint().y));
	}
	centerObjectV(e) {
		return this._centerObject(e, new N(e.getCenterPoint().x, this.getCenterPoint().y));
	}
	centerObject(e) {
		return this._centerObject(e, this.getCenterPoint());
	}
	viewportCenterObject(e) {
		return this._centerObject(e, this.getVpCenter());
	}
	viewportCenterObjectH(e) {
		return this._centerObject(e, new N(this.getVpCenter().x, e.getCenterPoint().y));
	}
	viewportCenterObjectV(e) {
		return this._centerObject(e, new N(e.getCenterPoint().x, this.getVpCenter().y));
	}
	getVpCenter() {
		return L(this.getCenterPoint(), R(this.viewportTransform));
	}
	_centerObject(e, t) {
		e.setXY(t, E, E), e.setCoords(), this.renderOnAddRemove && this.requestRenderAll();
	}
	toDatalessJSON(e) {
		return this.toDatalessObject(e);
	}
	toObject(e) {
		return this._toObjectMethod(`toObject`, e);
	}
	toJSON() {
		return this.toObject();
	}
	toDatalessObject(e) {
		return this._toObjectMethod(`toDatalessObject`, e);
	}
	_toObjectMethod(e, t) {
		let n = this.clipPath, r = n && !n.excludeFromExport ? this._toObject(n, e, t) : null;
		return {
			version: b,
			...et(this, t),
			objects: this._objects.filter((e) => !e.excludeFromExport).map((n) => this._toObject(n, e, t)),
			...this.__serializeBgOverlay(e, t),
			...r ? { clipPath: r } : null
		};
	}
	_toObject(e, t, n) {
		let r;
		this.includeDefaultValues || (r = e.includeDefaultValues, e.includeDefaultValues = !1);
		let i = e[t](n);
		return this.includeDefaultValues || (e.includeDefaultValues = !!r), i;
	}
	__serializeBgOverlay(e, t) {
		let n = {}, r = this.backgroundImage, i = this.overlayImage, a = this.backgroundColor, o = this.overlayColor;
		return V(a) ? a.excludeFromExport || (n.background = a.toObject(t)) : a && (n.background = a), V(o) ? o.excludeFromExport || (n.overlay = o.toObject(t)) : o && (n.overlay = o), r && !r.excludeFromExport && (n.backgroundImage = this._toObject(r, e, t)), i && !i.excludeFromExport && (n.overlayImage = this._toObject(i, e, t)), n;
	}
	toSVG(e = {}, t) {
		e.reviver = t;
		let n = [];
		var r;
		return (this._setSVGPreamble(n, e), this._setSVGHeader(n, e), this.clipPath) && n.push(`<g clip-path="url(#${U((r = this.clipPath.clipPathId) == null ? `` : r)})" >\n`), this._setSVGBgOverlayColor(n, `background`), this._setSVGBgOverlayImage(n, `backgroundImage`, t), this._setSVGObjects(n, t), this.clipPath && n.push(`</g>
`), this._setSVGBgOverlayColor(n, `overlay`), this._setSVGBgOverlayImage(n, `overlayImage`, t), n.push(`</svg>`), n.join(``);
	}
	_setSVGPreamble(e, t) {
		t.suppressPreamble || e.push(`<?xml version="1.0" encoding="`, t.encoding || `UTF-8`, `" standalone="no" ?>
`, `<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" `, `"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
`);
	}
	_setSVGHeader(e, t) {
		let n = t.width || `${this.width}`, r = t.height || `${this.height}`, i = o.NUM_FRACTION_DIGITS, a = t.viewBox, s;
		if (a) s = `viewBox="${a.x} ${a.y} ${a.width} ${a.height}" `;
		else if (this.svgViewportTransformation) {
			let e = this.viewportTransform;
			s = `viewBox="${B(-e[4] / e[0], i)} ${B(-e[5] / e[3], i)} ${B(this.width / e[0], i)} ${B(this.height / e[3], i)}" `;
		} else s = `viewBox="0 0 ${this.width} ${this.height}" `;
		e.push(`<svg `, `xmlns="http://www.w3.org/2000/svg" `, `xmlns:xlink="http://www.w3.org/1999/xlink" `, `version="1.1" `, `width="`, n, `" `, `height="`, r, `" `, s, `xml:space="preserve">
`, `<desc>Created with Fabric.js `, b, `</desc>
`, `<defs>
`, this.createSVGFontFacesMarkup(), this.createSVGRefElementsMarkup(), this.createSVGClipPathMarkup(t), `</defs>
`);
	}
	createSVGClipPathMarkup(e) {
		let t = this.clipPath;
		return t ? (t.clipPathId = `CLIPPATH_${je()}`, `<clipPath id="${t.clipPathId}" >\n${t.toClipPathSVG(e.reviver)}</clipPath>\n`) : ``;
	}
	createSVGRefElementsMarkup() {
		return [`background`, `overlay`].map((e) => {
			let t = this[`${e}Color`];
			if (V(t)) {
				let n = this[`${e}Vpt`], r = this.viewportTransform, i = {
					isType: () => !1,
					width: this.width / (n ? r[0] : 1),
					height: this.height / (n ? r[3] : 1)
				};
				return t.toSVG(i, { additionalTransform: n ? nt(r) : `` });
			}
		}).join(``);
	}
	createSVGFontFacesMarkup() {
		let e = [], t = {}, n = o.fontPaths;
		this._objects.forEach(function t(n) {
			e.push(n), Te(n) && n._objects.forEach(t);
		}), e.forEach((e) => {
			if (!(r = e) || typeof r._renderText != `function`) return;
			var r;
			let { styles: i, fontFamily: a } = e;
			!t[a] && n[a] && (t[a] = !0, i && Object.values(i).forEach((e) => {
				Object.values(e).forEach(({ fontFamily: e = `` }) => {
					!t[e] && n[e] && (t[e] = !0);
				});
			}));
		});
		let r = Object.keys(t).map((e) => `\t\t@font-face {\n\t\t\tfont-family: '${e}';\n\t\t\tsrc: url('${n[e]}');\n\t\t}\n`).join(``);
		return r ? `\t<style type="text/css"><![CDATA[\n${r}]]></style>\n` : ``;
	}
	_setSVGObjects(e, t) {
		this.forEachObject((n) => {
			n.excludeFromExport || this._setSVGObject(e, n, t);
		});
	}
	_setSVGObject(e, t, n) {
		e.push(t.toSVG(n));
	}
	_setSVGBgOverlayImage(e, t, n) {
		let r = this[t];
		r && !r.excludeFromExport && r.toSVG && e.push(r.toSVG(n));
	}
	_setSVGBgOverlayColor(e, t) {
		let n = this[`${t}Color`];
		if (n) if (V(n)) {
			let r = n.repeat || ``, i = this.width, a = this.height, o = this[`${t}Vpt`] ? nt(R(this.viewportTransform)) : ``;
			e.push(`<rect transform="${o} translate(${i / 2},${a / 2})" x="${n.offsetX - i / 2}" y="${n.offsetY - a / 2}" width="${r !== `repeat-y` && r !== `no-repeat` || !it(n) ? i : n.source.width}" height="${r !== `repeat-x` && r !== `no-repeat` || !it(n) ? a : n.source.height}" fill="url(#SVGID_${n.id})"></rect>\n`);
		} else e.push(`<rect x="0" y="0" width="100%" height="100%" `, `fill="`, n, `"`, `></rect>
`);
	}
	loadFromJSON(e, t, { signal: n } = {}) {
		if (!e) return Promise.reject(new c("`json` is undefined"));
		let { objects: r = [], ...i } = typeof e == `string` ? JSON.parse(e) : e, { backgroundImage: a, background: o, overlayImage: s, overlay: l, clipPath: u } = i, d = this.renderOnAddRemove;
		return this.renderOnAddRemove = !1, Promise.all([Qe(r, {
			reviver: t,
			signal: n
		}), $e({
			backgroundImage: a,
			backgroundColor: o,
			overlayImage: s,
			overlayColor: l,
			clipPath: u
		}, { signal: n })]).then(([e, t]) => (this.clear(), this.add(...e), this.set(i), this.set(t), this.renderOnAddRemove = d, this));
	}
	clone(e) {
		let t = this.toObject(e);
		return this.cloneWithoutData().loadFromJSON(t);
	}
	cloneWithoutData() {
		let e = F(this);
		return new this.constructor(e);
	}
	toDataURL(e = {}) {
		let { format: t = `png`, quality: n = 1, multiplier: r = 1, enableRetinaScaling: i = !1 } = e, a = r * (i ? this.getRetinaScaling() : 1);
		return Pe(this.toCanvasElement(a, e), t, n);
	}
	toBlob(e = {}) {
		let { format: t = `png`, quality: n = 1, multiplier: r = 1, enableRetinaScaling: i = !1 } = e, a = r * (i ? this.getRetinaScaling() : 1);
		return Fe(this.toCanvasElement(a, e), t, n);
	}
	toCanvasElement(e = 1, { width: t, height: n, left: r, top: i, filter: a } = {}) {
		let o = (t || this.width) * e, s = (n || this.height) * e, c = this.getZoom(), l = this.width, u = this.height, d = this.skipControlsDrawing, f = c * e, p = this.viewportTransform, m = [
			f,
			0,
			0,
			f,
			(p[4] - (r || 0)) * e,
			(p[5] - (i || 0)) * e
		], h = this.enableRetinaScaling, g = F({
			width: o,
			height: s
		}), _ = a ? this._objects.filter((e) => a(e)) : this._objects;
		return this.enableRetinaScaling = !1, this.viewportTransform = m, this.width = o, this.height = s, this.skipControlsDrawing = !0, this.calcViewportBoundaries(), this.renderCanvas(g.getContext(`2d`), _), this.viewportTransform = p, this.width = l, this.height = u, this.calcViewportBoundaries(), this.enableRetinaScaling = h, this.skipControlsDrawing = d, g;
	}
	dispose() {
		return !this.disposed && this.elements.cleanupDOM({
			width: this.width,
			height: this.height
		}), ye.cancelByCanvas(this), this.disposed = !0, new Promise((e, t) => {
			let n = () => {
				this.destroy(), e(!0);
			};
			n.kill = t, this.__cleanupTask && this.__cleanupTask.kill(`aborted`), this.destroyed ? e(!1) : this.nextRenderHandle ? this.__cleanupTask = n : n();
		});
	}
	destroy() {
		this.destroyed = !0, this.cancelRequestedRender(), this.forEachObject((e) => e.dispose()), this._objects = [], this.backgroundImage && this.backgroundImage.dispose(), this.backgroundImage = void 0, this.overlayImage && this.overlayImage.dispose(), this.overlayImage = void 0, this.elements.dispose();
	}
	toString() {
		return `#<Canvas (${this.complexity()}): { objects: ${this._objects.length} }>`;
	}
};
i(yt, `ownDefaults`, ft);
var bt = [
	`touchstart`,
	`touchmove`,
	`touchend`
];
var xt = (e) => {
	let t = ot(e.target), n = function(e) {
		let t = e.changedTouches;
		return t && t[0] ? t[0] : e;
	}(e);
	return new N(n.clientX + t.left, n.clientY + t.top);
};
var St = (e) => bt.includes(e.type) || e.pointerType === `touch`;
var Ct = (e) => {
	e.preventDefault(), e.stopPropagation();
};
var wt = (e) => {
	let t = 0, n = 0, r = 0, i = 0;
	for (let a = 0, o = e.length; a < o; a++) {
		let { x: o, y: s } = e[a];
		(o > r || !a) && (r = o), (o < t || !a) && (t = o), (s > i || !a) && (i = s), (s < n || !a) && (n = s);
	}
	return {
		left: t,
		top: n,
		width: r - t,
		height: i - n
	};
};
var Tt = (e, t) => {
	Dt(e, z(R(t), e.calcOwnMatrix()));
};
var Et = (e, t) => Dt(e, z(t, e.calcOwnMatrix()));
var Dt = (e, t) => {
	let { translateX: n, translateY: r, scaleX: i, scaleY: a, ...o } = He(t), s = new N(n, r);
	e.flipX = !1, e.flipY = !1, Object.assign(e, o), e.set({
		scaleX: i,
		scaleY: a
	}), e.setPositionByOrigin(s, E, E);
};
var Ot = (e) => {
	e.scaleX = 1, e.scaleY = 1, e.skewX = 0, e.skewY = 0, e.flipX = !1, e.flipY = !1, e.rotate(0);
};
var kt = (e) => ({
	scaleX: e.scaleX,
	scaleY: e.scaleY,
	skewX: e.skewX,
	skewY: e.skewY,
	angle: e.angle,
	left: e.left,
	flipX: e.flipX,
	flipY: e.flipY,
	top: e.top
});
var At = (e, t, n) => {
	let r = e / 2, i = t / 2, a = wt([
		new N(-r, -i),
		new N(r, -i),
		new N(-r, i),
		new N(r, i)
	].map((e) => e.transform(n)));
	return new N(a.width, a.height);
};
var jt = (e = T, t = T) => z(R(t), e);
var Mt = (e, t = T, n = T) => e.transform(jt(t, n));
var Nt = (e, t = T, n = T) => e.transform(jt(t, n), !0);
var Pt = (e, t, n) => {
	let r = jt(t, n);
	return Dt(e, z(r, e.calcOwnMatrix())), r;
};
var Ft = {
	left: -.5,
	top: -.5,
	center: 0,
	bottom: .5,
	right: .5
};
var W = (e) => typeof e == `string` ? Ft[e] : e - .5;
var It = new N(1, 0);
var Lt = new N();
var Rt = (e, t) => e.rotate(t);
var zt = (e, t) => new N(t).subtract(e);
var Bt = (e) => e.distanceFrom(Lt);
var Vt = (e, t) => Math.atan2(Gt(e, t), Kt(e, t));
var Ht = (e) => Vt(It, e);
var Ut = (e) => e.eq(Lt) ? e : e.scalarDivide(Bt(e));
var Wt = (e, t = !0) => Ut(new N(-e.y, e.x).scalarMultiply(t ? 1 : -1));
var Gt = (e, t) => e.x * t.y - e.y * t.x;
var Kt = (e, t) => e.x * t.x + e.y * t.y;
var qt = (e, t, n) => {
	if (e.eq(t) || e.eq(n)) return !0;
	let r = Gt(t, n), i = Gt(t, e), a = Gt(n, e);
	return r >= 0 ? i >= 0 && a <= 0 : !(i <= 0 && a >= 0);
};
var Jt = `not-allowed`;
function Yt(e) {
	return W(e.originX) === W(`center`) && W(e.originY) === W(`center`);
}
function Xt(e) {
	return .5 - W(e);
}
var Zt = (e, t) => e[t];
var Qt = (e, t, n, r) => ({
	e,
	transform: t,
	pointer: new N(n, r)
});
function $t(e, t, n) {
	let r = n, i = Ht(zt(Mt(e.getCenterPoint(), e.canvas.viewportTransform, void 0), r)) + w;
	return Math.round(i % w / C);
}
function en({ target: e, corner: t }, n, r, i, a) {
	var o;
	let s = e.controls[t], c = ((o = e.canvas) == null ? void 0 : o.getZoom()) || 1, l = e.padding / c, u = function(e, t, n, r) {
		let i = e.getRelativeCenterPoint(), a = n !== void 0 && r !== void 0 ? e.translateToGivenOrigin(i, E, E, n, r) : new N(e.left, e.top);
		return (e.angle ? t.rotate(-I(e.angle), i) : t).subtract(a);
	}(e, new N(i, a), n, r);
	return u.x >= l && (u.x -= l), u.x <= -l && (u.x += l), u.y >= l && (u.y -= l), u.y <= l && (u.y += l), u.x -= s.offsetX, u.y -= s.offsetY, u;
}
var tn = new RegExp(String.raw`[\0-\x1F\x7F;<>\\]|\/\*|\*\/|url\s*\(|expression\s*\(|(?:java|vb)script\s*:|data\s*:|@import\b`, `iu`);
var nn = (e) => typeof e == `string` && e.trim().length > 0 && !tn.test(e);
var rn = (e, t = ``) => {
	let n = Number(e);
	return Number.isFinite(n) ? `${n}` : t;
};
var an = (e, t = ``) => typeof e == `string` && nn(e) ? e : t;
var on = (e) => e.replace(/\s+/g, ` `);
var sn = {
	aliceblue: `#F0F8FF`,
	antiquewhite: `#FAEBD7`,
	aqua: `#0FF`,
	aquamarine: `#7FFFD4`,
	azure: `#F0FFFF`,
	beige: `#F5F5DC`,
	bisque: `#FFE4C4`,
	black: `#000`,
	blanchedalmond: `#FFEBCD`,
	blue: `#00F`,
	blueviolet: `#8A2BE2`,
	brown: `#A52A2A`,
	burlywood: `#DEB887`,
	cadetblue: `#5F9EA0`,
	chartreuse: `#7FFF00`,
	chocolate: `#D2691E`,
	coral: `#FF7F50`,
	cornflowerblue: `#6495ED`,
	cornsilk: `#FFF8DC`,
	crimson: `#DC143C`,
	cyan: `#0FF`,
	darkblue: `#00008B`,
	darkcyan: `#008B8B`,
	darkgoldenrod: `#B8860B`,
	darkgray: `#A9A9A9`,
	darkgrey: `#A9A9A9`,
	darkgreen: `#006400`,
	darkkhaki: `#BDB76B`,
	darkmagenta: `#8B008B`,
	darkolivegreen: `#556B2F`,
	darkorange: `#FF8C00`,
	darkorchid: `#9932CC`,
	darkred: `#8B0000`,
	darksalmon: `#E9967A`,
	darkseagreen: `#8FBC8F`,
	darkslateblue: `#483D8B`,
	darkslategray: `#2F4F4F`,
	darkslategrey: `#2F4F4F`,
	darkturquoise: `#00CED1`,
	darkviolet: `#9400D3`,
	deeppink: `#FF1493`,
	deepskyblue: `#00BFFF`,
	dimgray: `#696969`,
	dimgrey: `#696969`,
	dodgerblue: `#1E90FF`,
	firebrick: `#B22222`,
	floralwhite: `#FFFAF0`,
	forestgreen: `#228B22`,
	fuchsia: `#F0F`,
	gainsboro: `#DCDCDC`,
	ghostwhite: `#F8F8FF`,
	gold: `#FFD700`,
	goldenrod: `#DAA520`,
	gray: `#808080`,
	grey: `#808080`,
	green: `#008000`,
	greenyellow: `#ADFF2F`,
	honeydew: `#F0FFF0`,
	hotpink: `#FF69B4`,
	indianred: `#CD5C5C`,
	indigo: `#4B0082`,
	ivory: `#FFFFF0`,
	khaki: `#F0E68C`,
	lavender: `#E6E6FA`,
	lavenderblush: `#FFF0F5`,
	lawngreen: `#7CFC00`,
	lemonchiffon: `#FFFACD`,
	lightblue: `#ADD8E6`,
	lightcoral: `#F08080`,
	lightcyan: `#E0FFFF`,
	lightgoldenrodyellow: `#FAFAD2`,
	lightgray: `#D3D3D3`,
	lightgrey: `#D3D3D3`,
	lightgreen: `#90EE90`,
	lightpink: `#FFB6C1`,
	lightsalmon: `#FFA07A`,
	lightseagreen: `#20B2AA`,
	lightskyblue: `#87CEFA`,
	lightslategray: `#789`,
	lightslategrey: `#789`,
	lightsteelblue: `#B0C4DE`,
	lightyellow: `#FFFFE0`,
	lime: `#0F0`,
	limegreen: `#32CD32`,
	linen: `#FAF0E6`,
	magenta: `#F0F`,
	maroon: `#800000`,
	mediumaquamarine: `#66CDAA`,
	mediumblue: `#0000CD`,
	mediumorchid: `#BA55D3`,
	mediumpurple: `#9370DB`,
	mediumseagreen: `#3CB371`,
	mediumslateblue: `#7B68EE`,
	mediumspringgreen: `#00FA9A`,
	mediumturquoise: `#48D1CC`,
	mediumvioletred: `#C71585`,
	midnightblue: `#191970`,
	mintcream: `#F5FFFA`,
	mistyrose: `#FFE4E1`,
	moccasin: `#FFE4B5`,
	navajowhite: `#FFDEAD`,
	navy: `#000080`,
	oldlace: `#FDF5E6`,
	olive: `#808000`,
	olivedrab: `#6B8E23`,
	orange: `#FFA500`,
	orangered: `#FF4500`,
	orchid: `#DA70D6`,
	palegoldenrod: `#EEE8AA`,
	palegreen: `#98FB98`,
	paleturquoise: `#AFEEEE`,
	palevioletred: `#DB7093`,
	papayawhip: `#FFEFD5`,
	peachpuff: `#FFDAB9`,
	peru: `#CD853F`,
	pink: `#FFC0CB`,
	plum: `#DDA0DD`,
	powderblue: `#B0E0E6`,
	purple: `#800080`,
	rebeccapurple: `#639`,
	red: `#F00`,
	rosybrown: `#BC8F8F`,
	royalblue: `#4169E1`,
	saddlebrown: `#8B4513`,
	salmon: `#FA8072`,
	sandybrown: `#F4A460`,
	seagreen: `#2E8B57`,
	seashell: `#FFF5EE`,
	sienna: `#A0522D`,
	silver: `#C0C0C0`,
	skyblue: `#87CEEB`,
	slateblue: `#6A5ACD`,
	slategray: `#708090`,
	slategrey: `#708090`,
	snow: `#FFFAFA`,
	springgreen: `#00FF7F`,
	steelblue: `#4682B4`,
	tan: `#D2B48C`,
	teal: `#008080`,
	thistle: `#D8BFD8`,
	tomato: `#FF6347`,
	turquoise: `#40E0D0`,
	violet: `#EE82EE`,
	wheat: `#F5DEB3`,
	white: `#FFF`,
	whitesmoke: `#F5F5F5`,
	yellow: `#FF0`,
	yellowgreen: `#9ACD32`
};
var cn = (e, t, n) => (n < 0 && (n += 1), n > 1 && --n, n < 1 / 6 ? e + 6 * (t - e) * n : n < .5 ? t : n < 2 / 3 ? e + (t - e) * (2 / 3 - n) * 6 : e);
var ln = (e, t, n, r) => {
	e /= 255, t /= 255, n /= 255;
	let i = Math.max(e, t, n), a = Math.min(e, t, n), o, s, c = (i + a) / 2;
	if (i === a) o = s = 0;
	else {
		let r = i - a;
		switch (s = c > .5 ? r / (2 - i - a) : r / (i + a), i) {
			case e:
				o = (t - n) / r + (t < n ? 6 : 0);
				break;
			case t:
				o = (n - e) / r + 2;
				break;
			case n: o = (e - t) / r + 4;
		}
		o /= 6;
	}
	return [
		Math.round(360 * o),
		Math.round(100 * s),
		Math.round(100 * c),
		r
	];
};
var un = (e = `1`) => parseFloat(e) / (e.endsWith(`%`) ? 100 : 1);
var dn = (e) => Math.min(Math.round(e), 255).toString(16).toUpperCase().padStart(2, `0`);
var fn = ([e, t, n, r = 1]) => {
	let i = Math.round(.3 * e + .59 * t + .11 * n);
	return [
		i,
		i,
		i,
		r
	];
};
var G = class e {
	constructor(t) {
		if (i(this, `isUnrecognised`, !1), t) if (t instanceof e) this.setSource([...t._source]);
		else if (Array.isArray(t)) {
			let [e, n, r, i = 1] = t;
			this.setSource([
				e,
				n,
				r,
				i
			]);
		} else this.setSource(this._tryParsingColor(t));
		else this.setSource([
			0,
			0,
			0,
			1
		]);
	}
	_tryParsingColor(t) {
		return (t = t.toLowerCase()) in sn && (t = sn[t]), t === `transparent` ? [
			255,
			255,
			255,
			0
		] : e.sourceFromHex(t) || e.sourceFromRgb(t) || e.sourceFromHsl(t) || (this.isUnrecognised = !0) && [
			0,
			0,
			0,
			1
		];
	}
	getSource() {
		return this._source;
	}
	setSource(e) {
		this._source = e;
	}
	toRgb() {
		let [e, t, n] = this.getSource();
		return `rgb(${e},${t},${n})`;
	}
	toRgba() {
		return `rgba(${this.getSource().join(`,`)})`;
	}
	toHsl() {
		let [e, t, n] = ln(...this.getSource());
		return `hsl(${e},${t}%,${n}%)`;
	}
	toHsla() {
		let [e, t, n, r] = ln(...this.getSource());
		return `hsla(${e},${t}%,${n}%,${r})`;
	}
	toHex() {
		return this.toHexa().slice(0, 6);
	}
	toHexa() {
		let [e, t, n, r] = this.getSource();
		return `${dn(e)}${dn(t)}${dn(n)}${dn(Math.round(255 * r))}`;
	}
	getAlpha() {
		return this.getSource()[3];
	}
	setAlpha(e) {
		return this._source[3] = e, this;
	}
	toGrayscale() {
		return this.setSource(fn(this.getSource())), this;
	}
	toBlackWhite(e) {
		let [t, , , n] = fn(this.getSource()), r = t < (e || 127) ? 0 : 255;
		return this.setSource([
			r,
			r,
			r,
			n
		]), this;
	}
	overlayWith(t) {
		t instanceof e || (t = new e(t));
		let n = this.getSource(), r = t.getSource(), [i, a, o] = n.map((e, t) => Math.round(.5 * e + .5 * r[t]));
		return this.setSource([
			i,
			a,
			o,
			n[3]
		]), this;
	}
	static fromRgb(t) {
		return e.fromRgba(t);
	}
	static fromRgba(t) {
		return new e(e.sourceFromRgb(t));
	}
	static sourceFromRgb(e) {
		let t = on(e).match(/^rgba?\(\s?(\d{0,3}(?:\.\d+)?%?)\s?[\s|,]\s?(\d{0,3}(?:\.\d+)?%?)\s?[\s|,]\s?(\d{0,3}(?:\.\d+)?%?)\s?(?:\s?[,/]\s?(\d{0,3}(?:\.\d+)?%?)\s?)?\)$/i);
		if (t) {
			let [e, n, r] = t.slice(1, 4).map((e) => {
				let t = parseFloat(e);
				return e.endsWith(`%`) ? Math.round(2.55 * t) : t;
			});
			return [
				e,
				n,
				r,
				un(t[4])
			];
		}
	}
	static fromHsl(t) {
		return e.fromHsla(t);
	}
	static fromHsla(t) {
		return new e(e.sourceFromHsl(t));
	}
	static sourceFromHsl(t) {
		let n = on(t).match(/^hsla?\(\s?([+-]?\d{0,3}(?:\.\d+)?(?:deg|turn|rad)?)\s?[\s|,]\s?(\d{0,3}(?:\.\d+)?%?)\s?[\s|,]\s?(\d{0,3}(?:\.\d+)?%?)\s?(?:\s?[,/]\s?(\d*(?:\.\d+)?%?)\s?)?\)$/i);
		if (!n) return;
		let r = (e.parseAngletoDegrees(n[1]) % 360 + 360) % 360 / 360, i = parseFloat(n[2]) / 100, a = parseFloat(n[3]) / 100, o, s, c;
		if (i === 0) o = s = c = a;
		else {
			let e = a <= .5 ? a * (i + 1) : a + i - a * i, t = 2 * a - e;
			o = cn(t, e, r + 1 / 3), s = cn(t, e, r), c = cn(t, e, r - 1 / 3);
		}
		return [
			Math.round(255 * o),
			Math.round(255 * s),
			Math.round(255 * c),
			un(n[4])
		];
	}
	static fromHex(t) {
		return new e(e.sourceFromHex(t));
	}
	static sourceFromHex(e) {
		if (e.match(/^#?(([0-9a-f]){3,4}|([0-9a-f]{2}){3,4})$/i)) {
			let t = e.slice(e.indexOf(`#`) + 1), n;
			n = t.length <= 4 ? t.split(``).map((e) => e + e) : t.match(/.{2}/g);
			let [r, i, a, o = 255] = n.map((e) => parseInt(e, 16));
			return [
				r,
				i,
				a,
				o / 255
			];
		}
	}
	static parseAngletoDegrees(e) {
		let t = e.toLowerCase(), n = parseFloat(t);
		return t.includes(`rad`) ? Ie(n) : t.includes(`turn`) ? 360 * n : n;
	}
};
var pn = (e) => {
	let t = [
		`instantiated_by_use`,
		`style`,
		`id`,
		`class`
	];
	switch (e) {
		case `linearGradient`: return t.concat([
			`x1`,
			`y1`,
			`x2`,
			`y2`,
			`gradientUnits`,
			`gradientTransform`
		]);
		case `radialGradient`: return t.concat([
			`gradientUnits`,
			`gradientTransform`,
			`cx`,
			`cy`,
			`r`,
			`fx`,
			`fy`,
			`fr`
		]);
		case `stop`: return t.concat([
			`offset`,
			`stop-color`,
			`stop-opacity`
		]);
	}
	return t;
};
var K = (e, t = 16) => {
	let n = /\D{0,2}$/.exec(e), r = parseFloat(e), i = o.DPI;
	switch (n == null ? void 0 : n[0]) {
		case `mm`: return r * i / 25.4;
		case `cm`: return r * i / 2.54;
		case `in`: return r * i;
		case `pt`: return r * i / 72;
		case `pc`: return r * i / 72 * 12;
		case `em`: return r * t;
		default: return r;
	}
};
var mn = (e) => {
	let [t, n] = e.trim().split(` `), [r, i] = (a = t) && a !== `none` ? [a.slice(1, 4), a.slice(5, 8)] : a === `none` ? [a, a] : [`Mid`, `Mid`];
	var a;
	return {
		meetOrSlice: n || `meet`,
		alignX: r,
		alignY: i
	};
};
var hn = (e, t, n = !0) => {
	let r, i;
	if (t) if (t.toLive) r = `url(#SVGID_${U(t.id)})`;
	else {
		let e = String(t);
		if (nn(e)) {
			let t = new G(e), n = t.getAlpha();
			r = t.toRgb(), n !== 1 && (i = n.toString());
		} else r = new G(`black`).toRgb();
	}
	else r = `none`;
	return n ? `${e}: ${r}; ${i ? `${e}-opacity: ${i}; ` : ``}` : `${e}="${r}" ${i ? `${e}-opacity="${i}" ` : ``}`;
};
var gn = class {
	getSvgStyles(e) {
		let t = this.fillRule == null ? `nonzero` : an(this.fillRule), n = this.strokeWidth == null ? `0` : rn(this.strokeWidth), r = this.strokeDashArray == null ? te : this.strokeDashArray.every((e) => Number.isFinite(Number(e))) ? this.strokeDashArray.join(` `) : ``, i = this.strokeDashOffset == null ? `0` : rn(this.strokeDashOffset), a = this.strokeLineCap == null ? `butt` : an(this.strokeLineCap), o = this.strokeLineJoin == null ? `miter` : an(this.strokeLineJoin), s = this.strokeMiterLimit == null ? `4` : rn(this.strokeMiterLimit), c = this.opacity == null ? `1` : rn(this.opacity), l = this.visible ? `` : ` visibility: hidden;`, u = e ? `` : this.getSvgFilter(), d = hn(j, this.fill);
		return [
			hn(he, this.stroke),
			n ? `stroke-width: ${n}; ` : ``,
			r ? `stroke-dasharray: ${r}; ` : ``,
			a ? `stroke-linecap: ${a}; ` : ``,
			i ? `stroke-dashoffset: ${i}; ` : ``,
			o ? `stroke-linejoin: ${o}; ` : ``,
			s ? `stroke-miterlimit: ${s}; ` : ``,
			d,
			t ? `fill-rule: ${t}; ` : ``,
			c ? `opacity: ${c};` : ``,
			u,
			l
		].map((e) => U(e)).join(``);
	}
	getSvgFilter() {
		return this.shadow ? `filter: url(#SVGID_${U(this.shadow.id)});` : ``;
	}
	getSvgCommons() {
		return [this.id ? `id="${U(String(this.id))}" ` : ``, this.clipPath ? `clip-path="url(#${U(this.clipPath.clipPathId)})" ` : ``].join(``);
	}
	getSvgTransform(e, t = ``) {
		return `transform="${nt(e ? this.calcTransformMatrix() : this.calcOwnMatrix())}${t}" `;
	}
	_toSVG(e) {
		return [``];
	}
	toSVG(e) {
		return this._createBaseSVGMarkup(this._toSVG(e), { reviver: e });
	}
	toClipPathSVG(e) {
		return `	` + this._createBaseClipPathSVGMarkup(this._toSVG(e), { reviver: e });
	}
	_createBaseClipPathSVGMarkup(e, { reviver: t, additionalTransform: n = `` } = {}) {
		let r = [this.getSvgTransform(!0, n), this.getSvgCommons()].join(``), i = e.indexOf(`COMMON_PARTS`);
		return e[i] = r, t ? t(e.join(``)) : e.join(``);
	}
	_createBaseSVGMarkup(e, { noStyle: t, reviver: n, withShadow: r, additionalTransform: i } = {}) {
		let a = t ? `` : `style="${this.getSvgStyles()}" `, o = r ? `style="${this.getSvgFilter()}" ` : ``, s = this.clipPath, c = this.strokeUniform ? `vector-effect="non-scaling-stroke" ` : ``, l = s && s.absolutePositioned, u = this.stroke, d = this.fill, f = this.shadow, p = [], m = e.indexOf(`COMMON_PARTS`), h;
		return s && (s.clipPathId = `CLIPPATH_${je()}`, h = `<clipPath id="${s.clipPathId}" >\n${s.toClipPathSVG(n)}</clipPath>\n`), l && p.push(`<g `, o, this.getSvgCommons(), ` >
`), p.push(`<g `, this.getSvgTransform(!1), l ? `` : o + this.getSvgCommons(), ` >
`), e[m] = [
			a,
			c,
			t ? `` : this.addPaintOrder(),
			` `,
			i ? `transform="${i}" ` : ``
		].join(``), V(d) && p.push(d.toSVG(this)), V(u) && p.push(u.toSVG(this)), f && p.push(f.toSVG(this)), s && p.push(h), p.push(e.join(``)), p.push(`</g>
`), l && p.push(`</g>
`), n ? n(p.join(``)) : p.join(``);
	}
	addPaintOrder() {
		return this.paintFirst === `fill` ? `` : ` paint-order="${U(this.paintFirst)}" `;
	}
};
function _n(e) {
	return RegExp(`^(` + e.join(`|`) + `)\\b`, `i`);
}
var vn = `textDecorationThickness`;
var yn = `textDecorationColor`;
var bn = [
	`fontSize`,
	`fontWeight`,
	`fontFamily`,
	`fontStyle`
];
var xn = [
	`underline`,
	`overline`,
	`linethrough`
];
var Sn = [
	...bn,
	`lineHeight`,
	`text`,
	`charSpacing`,
	`textAlign`,
	`styles`,
	`path`,
	`pathStartOffset`,
	`pathSide`,
	`pathAlign`
];
var Cn = [
	...Sn,
	...xn,
	`textBackgroundColor`,
	`direction`,
	vn,
	yn
];
var wn = [
	...bn,
	...xn,
	he,
	`strokeWidth`,
	j,
	`deltaY`,
	`textBackgroundColor`,
	vn,
	yn
];
var Tn = {
	_reNewline: ne,
	_reSpacesAndTabs: /[ \t\r]/g,
	_reSpaceAndTab: /[ \t\r]/,
	_reWords: /\S+/g,
	fontSize: 40,
	fontWeight: _e,
	fontFamily: `Times New Roman`,
	underline: !1,
	overline: !1,
	linethrough: !1,
	textAlign: D,
	fontStyle: _e,
	lineHeight: 1.16,
	textBackgroundColor: ``,
	stroke: null,
	shadow: null,
	path: void 0,
	pathStartOffset: 0,
	pathSide: D,
	pathAlign: `baseline`,
	charSpacing: 0,
	deltaY: 0,
	direction: `ltr`,
	CACHE_FONT_SIZE: 400,
	MIN_TEXT_WIDTH: 2,
	superscript: {
		size: .6,
		baseline: -.35
	},
	subscript: {
		size: .6,
		baseline: .11
	},
	_fontSizeFraction: .222,
	offsets: {
		underline: .1,
		linethrough: -.28167,
		overline: -.81333
	},
	_fontSizeMult: 1.13,
	[vn]: 66.667
};
var En = `justify`;
var Dn = String.raw`[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?`;
var On = String.raw`(?:\s*,?\s+|\s*,\s*)`;
var An = RegExp(`(normal|italic)?\\s*(normal|small-caps)?\\s*(normal|bold|bolder|lighter|100|200|300|400|500|600|700|800|900)?\\s*(` + Dn + `(?:px|cm|mm|em|pt|pc|in)*)(?:\\/(normal|` + Dn + `))?\\s+(.*)`);
var jn = {
	cx: D,
	x: D,
	r: `radius`,
	cy: `top`,
	y: `top`,
	display: `visible`,
	visibility: `visible`,
	transform: `transformMatrix`,
	"fill-opacity": `fillOpacity`,
	"fill-rule": `fillRule`,
	"font-family": `fontFamily`,
	"font-size": `fontSize`,
	"font-style": `fontStyle`,
	"font-weight": `fontWeight`,
	"letter-spacing": `charSpacing`,
	"paint-order": `paintFirst`,
	"stroke-dasharray": `strokeDashArray`,
	"stroke-dashoffset": `strokeDashOffset`,
	"stroke-linecap": `strokeLineCap`,
	"stroke-linejoin": `strokeLineJoin`,
	"stroke-miterlimit": `strokeMiterLimit`,
	"stroke-opacity": `strokeOpacity`,
	"stroke-width": `strokeWidth`,
	"text-decoration": `textDecoration`,
	"text-anchor": `textAnchor`,
	opacity: `opacity`,
	"clip-path": `clipPath`,
	"clip-rule": `clipRule`,
	"vector-effect": `strokeUniform`,
	"image-rendering": `imageSmoothing`,
	"text-decoration-thickness": vn,
	"text-decoration-color": yn
};
var Mn = `font-size`;
var Nn = `clip-path`;
_n([
	`path`,
	`circle`,
	`polygon`,
	`polyline`,
	`ellipse`,
	`rect`,
	`line`,
	`image`,
	`text`
]);
_n([
	`symbol`,
	`image`,
	`marker`,
	`pattern`,
	`view`,
	`svg`
]);
var In = _n([
	`symbol`,
	`g`,
	`a`,
	`svg`,
	`clipPath`,
	`defs`
]);
new RegExp(String.raw`^\s*(${Dn})${On}(${Dn})${On}(${Dn})${On}(${Dn})\s*$`);
var Rn = `(-?\\d+(?:\\.\\d*)?(?:px)?(?:\\s?|$))?`;
var zn = RegExp(`(?:\\s|^)` + Rn + Rn + `(` + Dn + `?(?:px)?)?(?:\\s?|$)(?:$|\\s)`);
var Bn = class e {
	constructor(t = {}) {
		let n = typeof t == `string` ? e.parseShadow(t) : t;
		Object.assign(this, e.ownDefaults, n), this.id = je();
	}
	static parseShadow(e) {
		let t = e.trim(), [, n = 0, r = 0, i = 0] = (zn.exec(t) || []).map((e) => parseFloat(e) || 0);
		return {
			color: (t.replace(zn, ``) || `rgb(0,0,0)`).trim(),
			offsetX: n,
			offsetY: r,
			blur: i
		};
	}
	toString() {
		return [
			this.offsetX,
			this.offsetY,
			this.blur,
			this.color
		].join(`px `);
	}
	toSVG(e) {
		let t = Rt(new N(this.offsetX, this.offsetY), I(-e.angle)), n = o.NUM_FRACTION_DIGITS, r = new G(this.color), i = 40, a = 40;
		return e.width && e.height && (i = 100 * B((Math.abs(t.x) + this.blur) / e.width, n) + 20, a = 100 * B((Math.abs(t.y) + this.blur) / e.height, n) + 20), e.flipX && (t.x *= -1), e.flipY && (t.y *= -1), `<filter id="SVGID_${U(this.id)}" y="-${a}%" height="${100 + 2 * a}%" x="-${i}%" width="${100 + 2 * i}%" >\n\t<feGaussianBlur in="SourceAlpha" stdDeviation="${B(this.blur ? this.blur / 2 : 0, n)}"></feGaussianBlur>\n\t<feOffset dx="${B(t.x, n)}" dy="${B(t.y, n)}" result="oBlur" ></feOffset>\n\t<feFlood flood-color="${r.toRgb()}" flood-opacity="${r.getAlpha()}"/>\n\t<feComposite in2="oBlur" operator="in" />\n\t<feMerge>\n\t\t<feMergeNode></feMergeNode>\n\t\t<feMergeNode in="SourceGraphic"></feMergeNode>\n\t</feMerge>\n</filter>\n`;
	}
	toObject() {
		let t = {
			color: this.color,
			blur: this.blur,
			offsetX: this.offsetX,
			offsetY: this.offsetY,
			affectStroke: this.affectStroke,
			nonScaling: this.nonScaling,
			type: this.constructor.type
		}, n = e.ownDefaults;
		return this.includeDefaultValues ? t : tt(t, (e, t) => e !== n[t]);
	}
	static async fromObject(e) {
		return new this(e);
	}
};
i(Bn, `ownDefaults`, {
	color: `rgb(0,0,0)`,
	blur: 0,
	offsetX: 0,
	offsetY: 0,
	affectStroke: !1,
	includeDefaultValues: !0,
	nonScaling: !1
}), i(Bn, `type`, `shadow`), M.setClass(Bn, `shadow`);
var Vn = (e, t, n) => Math.max(e, Math.min(t, n));
var Hn = [
	`top`,
	D,
	de,
	fe,
	`flipX`,
	`flipY`,
	`originX`,
	`originY`,
	`angle`,
	`opacity`,
	`globalCompositeOperation`,
	`shadow`,
	`visible`,
	pe,
	me
];
var Un = [
	j,
	he,
	`strokeWidth`,
	`strokeDashArray`,
	`width`,
	`height`,
	`paintFirst`,
	`strokeUniform`,
	`strokeLineCap`,
	`strokeDashOffset`,
	`strokeLineJoin`,
	`strokeMiterLimit`,
	`backgroundColor`,
	`clipPath`
];
var Wn = {
	top: 0,
	left: 0,
	width: 0,
	height: 0,
	angle: 0,
	flipX: !1,
	flipY: !1,
	scaleX: 1,
	scaleY: 1,
	minScaleLimit: 0,
	skewX: 0,
	skewY: 0,
	originX: E,
	originY: E,
	strokeWidth: 1,
	strokeUniform: !1,
	padding: 0,
	opacity: 1,
	paintFirst: j,
	fill: `rgb(0,0,0)`,
	fillRule: `nonzero`,
	stroke: null,
	strokeDashArray: null,
	strokeDashOffset: 0,
	strokeLineCap: `butt`,
	strokeLineJoin: `miter`,
	strokeMiterLimit: 4,
	globalCompositeOperation: `source-over`,
	backgroundColor: ``,
	shadow: null,
	visible: !0,
	includeDefaultValues: !0,
	excludeFromExport: !1,
	objectCaching: !0,
	clipPath: void 0,
	inverted: !1,
	absolutePositioned: !1,
	centeredRotation: !0,
	centeredScaling: !1,
	dirty: !0
};
var Gn = t({
	defaultEasing: () => Jn,
	easeInBack: () => gr,
	easeInBounce: () => br,
	easeInCirc: () => ur,
	easeInCubic: () => Yn,
	easeInElastic: () => pr,
	easeInExpo: () => sr,
	easeInOutBack: () => vr,
	easeInOutBounce: () => xr,
	easeInOutCirc: () => fr,
	easeInOutCubic: () => Zn,
	easeInOutElastic: () => hr,
	easeInOutExpo: () => lr,
	easeInOutQuad: () => wr,
	easeInOutQuart: () => er,
	easeInOutQuint: () => rr,
	easeInOutSine: () => or,
	easeInQuad: () => Sr,
	easeInQuart: () => Qn,
	easeInQuint: () => tr,
	easeInSine: () => ir,
	easeOutBack: () => _r,
	easeOutBounce: () => yr,
	easeOutCirc: () => dr,
	easeOutCubic: () => Xn,
	easeOutElastic: () => mr,
	easeOutExpo: () => cr,
	easeOutQuad: () => Cr,
	easeOutQuart: () => $n,
	easeOutQuint: () => nr,
	easeOutSine: () => ar
});
var Kn = (e, t, n, r) => (e < Math.abs(t) ? (e = t, r = n / 4) : r = t === 0 && e === 0 ? n / w * Math.asin(1) : n / w * Math.asin(t / e), {
	a: e,
	c: t,
	p: n,
	s: r
});
var qn = (e, t, n, r, i) => e * 2 ** (10 * --r) * Math.sin((r * i - t) * w / n);
var Jn = (e, t, n, r) => -n * Math.cos(e / r * S) + n + t;
var Yn = (e, t, n, r) => n * (e / r) ** 3 + t;
var Xn = (e, t, n, r) => n * ((e / r - 1) ** 3 + 1) + t;
var Zn = (e, t, n, r) => (e /= r / 2) < 1 ? n / 2 * e ** 3 + t : n / 2 * ((e - 2) ** 3 + 2) + t;
var Qn = (e, t, n, r) => n * (e /= r) * e ** 3 + t;
var $n = (e, t, n, r) => -n * ((e = e / r - 1) * e ** 3 - 1) + t;
var er = (e, t, n, r) => (e /= r / 2) < 1 ? n / 2 * e ** 4 + t : -n / 2 * ((e -= 2) * e ** 3 - 2) + t;
var tr = (e, t, n, r) => n * (e / r) ** 5 + t;
var nr = (e, t, n, r) => n * ((e / r - 1) ** 5 + 1) + t;
var rr = (e, t, n, r) => (e /= r / 2) < 1 ? n / 2 * e ** 5 + t : n / 2 * ((e - 2) ** 5 + 2) + t;
var ir = (e, t, n, r) => -n * Math.cos(e / r * S) + n + t;
var ar = (e, t, n, r) => n * Math.sin(e / r * S) + t;
var or = (e, t, n, r) => -n / 2 * (Math.cos(Math.PI * e / r) - 1) + t;
var sr = (e, t, n, r) => e === 0 ? t : n * 2 ** (10 * (e / r - 1)) + t;
var cr = (e, t, n, r) => e === r ? t + n : n * -(2 ** (-10 * e / r) + 1) + t;
var lr = (e, t, n, r) => e === 0 ? t : e === r ? t + n : (e /= r / 2) < 1 ? n / 2 * 2 ** (10 * (e - 1)) + t : n / 2 * -(2 ** (-10 * (e - 1)) + 2) + t;
var ur = (e, t, n, r) => -n * (Math.sqrt(1 - (e /= r) * e) - 1) + t;
var dr = (e, t, n, r) => n * Math.sqrt(1 - (e = e / r - 1) * e) + t;
var fr = (e, t, n, r) => (e /= r / 2) < 1 ? -n / 2 * (Math.sqrt(1 - e ** 2) - 1) + t : n / 2 * (Math.sqrt(1 - (e -= 2) * e) + 1) + t;
var pr = (e, t, n, r) => {
	let i = n, a = 0;
	if (e === 0) return t;
	if ((e /= r) === 1) return t + n;
	a || (a = .3 * r);
	let { a: o, s, p: c } = Kn(i, n, a, 1.70158);
	return -qn(o, s, c, e, r) + t;
};
var mr = (e, t, n, r) => {
	let i = n, a = 0;
	if (e === 0) return t;
	if ((e /= r) === 1) return t + n;
	a || (a = .3 * r);
	let { a: o, s, p: c, c: l } = Kn(i, n, a, 1.70158);
	return o * 2 ** (-10 * e) * Math.sin((e * r - s) * w / c) + l + t;
};
var hr = (e, t, n, r) => {
	let i = n, a = 0;
	if (e === 0) return t;
	if ((e /= r / 2) == 2) return t + n;
	a || (a = .3 * 1.5 * r);
	let { a: o, s, p: c, c: l } = Kn(i, n, a, 1.70158);
	return e < 1 ? -.5 * qn(o, s, c, e, r) + t : o * 2 ** (-10 * --e) * Math.sin((e * r - s) * w / c) * .5 + l + t;
};
var gr = (e, t, n, r, i = 1.70158) => n * (e /= r) * e * ((i + 1) * e - i) + t;
var _r = (e, t, n, r, i = 1.70158) => n * ((e = e / r - 1) * e * ((i + 1) * e + i) + 1) + t;
var vr = (e, t, n, r, i = 1.70158) => (e /= r / 2) < 1 ? n / 2 * (e * e * ((1 + (i *= 1.525)) * e - i)) + t : n / 2 * ((e -= 2) * e * ((1 + (i *= 1.525)) * e + i) + 2) + t;
var yr = (e, t, n, r) => (e /= r) < 1 / 2.75 ? n * (7.5625 * e * e) + t : e < 2 / 2.75 ? n * (7.5625 * (e -= 1.5 / 2.75) * e + .75) + t : e < 2.5 / 2.75 ? n * (7.5625 * (e -= 2.25 / 2.75) * e + .9375) + t : n * (7.5625 * (e -= 2.625 / 2.75) * e + .984375) + t;
var br = (e, t, n, r) => n - yr(r - e, 0, n, r) + t;
var xr = (e, t, n, r) => e < r / 2 ? .5 * br(2 * e, 0, n, r) + t : .5 * yr(2 * e - r, 0, n, r) + .5 * n + t;
var Sr = (e, t, n, r) => n * (e /= r) * e + t;
var Cr = (e, t, n, r) => -n * (e /= r) * (e - 2) + t;
var wr = (e, t, n, r) => (e /= r / 2) < 1 ? n / 2 * e ** 2 + t : -n / 2 * (--e * (e - 2) - 1) + t;
var Tr = () => !1;
var Er = class {
	constructor({ startValue: e, byValue: t, duration: n = 500, delay: r = 0, easing: a = Jn, onStart: o = x, onChange: s = x, onComplete: c = x, abort: l = Tr, target: u }) {
		i(this, `_state`, `pending`), i(this, `durationProgress`, 0), i(this, `valueProgress`, 0), this.tick = this.tick.bind(this), this.duration = n, this.delay = r, this.easing = a, this._onStart = o, this._onChange = s, this._onComplete = c, this._abort = l, this.target = u, this.startValue = e, this.byValue = t, this.value = this.startValue, this.endValue = Object.freeze(this.calculate(this.duration).value);
	}
	get state() {
		return this._state;
	}
	isDone() {
		return this._state === `aborted` || this._state === `completed`;
	}
	start() {
		let e = (e) => {
			this._state === `pending` && (this.startTime = e || +/* @__PURE__ */ new Date(), this._state = `running`, this._onStart(), this.tick(this.startTime));
		};
		this.register(), this.delay > 0 ? this.timeout = _().setTimeout(() => Oe(e), this.delay) : Oe(e);
	}
	tick(e) {
		let t = (e || +/* @__PURE__ */ new Date()) - this.startTime, n = Math.min(t, this.duration);
		this.durationProgress = n / this.duration;
		let { value: r, valueProgress: i } = this.calculate(n);
		this.value = Object.freeze(r), this.valueProgress = i, this._state !== `aborted` && (this._abort(this.value, this.valueProgress, this.durationProgress) ? (this._state = `aborted`, this.unregister()) : t >= this.duration ? (this.durationProgress = this.valueProgress = 1, this._onChange(this.endValue, this.valueProgress, this.durationProgress), this._state = `completed`, this._onComplete(this.endValue, this.valueProgress, this.durationProgress), this.unregister(), this.timeout = null) : (this._onChange(this.value, this.valueProgress, this.durationProgress), Oe(this.tick)));
	}
	register() {
		ye.push(this);
	}
	unregister() {
		ye.remove(this);
	}
	abort() {
		this._state = `aborted`, this.unregister(), this.timeout && _().clearTimeout(this.timeout);
	}
};
var Dr = class extends Er {
	constructor({ startValue: e = 0, endValue: t = 100, ...n }) {
		super({
			...n,
			startValue: e,
			byValue: t - e
		});
	}
	calculate(e) {
		let t = this.easing(e, this.startValue, this.byValue, this.duration);
		return {
			value: t,
			valueProgress: Math.abs((t - this.startValue) / this.byValue)
		};
	}
};
var Or = class extends Er {
	constructor({ startValue: e = [0], endValue: t = [100], ...n }) {
		super({
			...n,
			startValue: e,
			byValue: t.map((t, n) => t - e[n])
		});
	}
	calculate(e) {
		let t = this.startValue.map((t, n) => this.easing(e, t, this.byValue[n], this.duration, n));
		return {
			value: t,
			valueProgress: Math.abs((t[0] - this.startValue[0]) / this.byValue[0])
		};
	}
};
var kr = (e, t, n, r) => t + n * (1 - Math.cos(e / r * S));
var Ar = (e) => e && ((t, n, r) => e(new G(t).toRgba(), n, r));
var jr = class extends Er {
	constructor({ startValue: e, endValue: t, easing: n = kr, onChange: r, onComplete: i, abort: a, ...o }) {
		let s = new G(e).getSource(), c = new G(t).getSource();
		super({
			...o,
			startValue: s,
			byValue: c.map((e, t) => e - s[t]),
			easing: n,
			onChange: Ar(r),
			onComplete: Ar(i),
			abort: Ar(a)
		});
	}
	calculate(e) {
		let [t, n, r, i] = this.startValue.map((t, n) => this.easing(e, t, this.byValue[n], this.duration, n)), a = [...[
			t,
			n,
			r
		].map(Math.round), Vn(0, i, 1)];
		return {
			value: a,
			valueProgress: a.map((e, t) => this.byValue[t] === 0 ? 0 : Math.abs((e - this.startValue[t]) / this.byValue[t])).find((e) => e !== 0) || 0
		};
	}
};
function Mr(e) {
	let t = ((e) => Array.isArray(e.startValue) || Array.isArray(e.endValue))(e) ? new Or(e) : new Dr(e);
	return t.start(), t;
}
function Nr(e) {
	let t = new jr(e);
	return t.start(), t;
}
var Pr = class e {
	constructor(e) {
		this.status = e, this.points = [];
	}
	includes(e) {
		return this.points.some((t) => t.eq(e));
	}
	append(...e) {
		return this.points = this.points.concat(e.filter((e) => !this.includes(e))), this;
	}
	static isPointContained(e, t, n, r = !1) {
		if (t.eq(n)) return e.eq(t);
		if (t.x === n.x) return e.x === t.x && (r || e.y >= Math.min(t.y, n.y) && e.y <= Math.max(t.y, n.y));
		if (t.y === n.y) return e.y === t.y && (r || e.x >= Math.min(t.x, n.x) && e.x <= Math.max(t.x, n.x));
		{
			let i = zt(t, n), a = zt(t, e).divide(i);
			return r ? Math.abs(a.x) === Math.abs(a.y) : a.x === a.y && a.x >= 0 && a.x <= 1;
		}
	}
	static isPointInPolygon(e, t) {
		let n = new N(e).setX(Math.min(e.x - 1, ...t.map((e) => e.x))), r = 0;
		for (let i = 0; i < t.length; i++) {
			let a = this.intersectSegmentSegment(t[i], t[(i + 1) % t.length], e, n);
			if (a.includes(e)) return !0;
			r += Number(a.status === `Intersection`);
		}
		return r % 2 == 1;
	}
	static intersectLineLine(t, n, r, i, a = !0, o = !0) {
		let s = n.x - t.x, c = n.y - t.y, l = i.x - r.x, u = i.y - r.y, d = t.x - r.x, f = t.y - r.y, p = l * f - u * d, m = s * f - c * d, h = u * s - l * c;
		if (h !== 0) {
			let n = p / h, r = m / h;
			return (a || 0 <= n && n <= 1) && (o || 0 <= r && r <= 1) ? new e(`Intersection`).append(new N(t.x + n * s, t.y + n * c)) : new e();
		}
		return new e(p === 0 || m === 0 ? a || o || e.isPointContained(t, r, i) || e.isPointContained(n, r, i) || e.isPointContained(r, t, n) || e.isPointContained(i, t, n) ? `Coincident` : void 0 : `Parallel`);
	}
	static intersectSegmentLine(t, n, r, i) {
		return e.intersectLineLine(t, n, r, i, !1, !0);
	}
	static intersectSegmentSegment(t, n, r, i) {
		return e.intersectLineLine(t, n, r, i, !1, !1);
	}
	static intersectLinePolygon(t, n, r, i = !0) {
		let a = new e(), o = r.length;
		for (let s, c, l, u = 0; u < o; u++) {
			if (s = r[u], c = r[(u + 1) % o], l = e.intersectLineLine(t, n, s, c, i, !1), l.status === `Coincident`) return l;
			a.append(...l.points);
		}
		return a.points.length > 0 && (a.status = `Intersection`), a;
	}
	static intersectSegmentPolygon(t, n, r) {
		return e.intersectLinePolygon(t, n, r, !1);
	}
	static intersectPolygonPolygon(t, n) {
		let r = new e(), i = t.length, a = [];
		for (let o = 0; o < i; o++) {
			let s = t[o], c = t[(o + 1) % i], l = e.intersectSegmentPolygon(s, c, n);
			l.status === `Coincident` ? (a.push(l), r.append(s, c)) : r.append(...l.points);
		}
		return a.length > 0 && a.length === t.length ? new e(`Coincident`) : (r.points.length > 0 && (r.status = `Intersection`), r);
	}
	static intersectPolygonRectangle(t, n, r) {
		let i = n.min(r), a = n.max(r), o = new N(a.x, i.y), s = new N(i.x, a.y);
		return e.intersectPolygonPolygon(t, [
			i,
			o,
			a,
			s
		]);
	}
};
var Fr = class extends De {
	getX() {
		return this.getXY().x;
	}
	setX(e) {
		this.setXY(this.getXY().setX(e));
	}
	getY() {
		return this.getXY().y;
	}
	setY(e) {
		this.setXY(this.getXY().setY(e));
	}
	getRelativeX() {
		return this.left;
	}
	setRelativeX(e) {
		this.left = e;
	}
	getRelativeY() {
		return this.top;
	}
	setRelativeY(e) {
		this.top = e;
	}
	getXY() {
		let e = this.getRelativeXY();
		return this.group ? L(e, this.group.calcTransformMatrix()) : e;
	}
	setXY(e, t, n) {
		this.group && (e = L(e, R(this.group.calcTransformMatrix()))), this.setRelativeXY(e, t, n);
	}
	getRelativeXY() {
		return new N(this.left, this.top);
	}
	setRelativeXY(e, t = this.originX, n = this.originY) {
		this.setPositionByOrigin(e, t, n);
	}
	isStrokeAccountedForInDimensions() {
		return !1;
	}
	getCoords() {
		let { tl: e, tr: t, br: n, bl: r } = this.aCoords || (this.aCoords = this.calcACoords()), i = [
			e,
			t,
			n,
			r
		];
		if (this.group) {
			let e = this.group.calcTransformMatrix();
			return i.map((t) => L(t, e));
		}
		return i;
	}
	intersectsWithRect(e, t) {
		return Pr.intersectPolygonRectangle(this.getCoords(), e, t).status === `Intersection`;
	}
	intersectsWithObject(e) {
		let t = Pr.intersectPolygonPolygon(this.getCoords(), e.getCoords());
		return t.status === `Intersection` || t.status === `Coincident` || e.isContainedWithinObject(this) || this.isContainedWithinObject(e);
	}
	isContainedWithinObject(e) {
		return this.getCoords().every((t) => e.containsPoint(t));
	}
	isContainedWithinRect(e, t) {
		let { left: n, top: r, width: i, height: a } = this.getBoundingRect();
		return n >= e.x && n + i <= t.x && r >= e.y && r + a <= t.y;
	}
	isOverlapping(e) {
		return this.intersectsWithObject(e) || this.isContainedWithinObject(e) || e.isContainedWithinObject(this);
	}
	containsPoint(e) {
		return Pr.isPointInPolygon(e, this.getCoords());
	}
	isOnScreen() {
		if (!this.canvas) return !1;
		let { tl: e, br: t } = this.canvas.vptCoords;
		return !!this.getCoords().some((n) => n.x <= t.x && n.x >= e.x && n.y <= t.y && n.y >= e.y) || !!this.intersectsWithRect(e, t) || this.containsPoint(e.midPointFrom(t));
	}
	isPartiallyOnScreen() {
		if (!this.canvas) return !1;
		let { tl: e, br: t } = this.canvas.vptCoords;
		return !!this.intersectsWithRect(e, t) || this.getCoords().every((n) => (n.x >= t.x || n.x <= e.x) && (n.y >= t.y || n.y <= e.y)) && this.containsPoint(e.midPointFrom(t));
	}
	getBoundingRect() {
		return wt(this.getCoords());
	}
	getScaledWidth() {
		return this._getTransformedDimensions().x;
	}
	getScaledHeight() {
		return this._getTransformedDimensions().y;
	}
	scale(e) {
		this._set(de, e), this._set(fe, e), this.setCoords();
	}
	scaleToWidth(e) {
		let t = this.getBoundingRect().width / this.getScaledWidth();
		return this.scale(e / this.width / t);
	}
	scaleToHeight(e) {
		let t = this.getBoundingRect().height / this.getScaledHeight();
		return this.scale(e / this.height / t);
	}
	getCanvasRetinaScaling() {
		var e;
		return ((e = this.canvas) == null ? void 0 : e.getRetinaScaling()) || 1;
	}
	getTotalAngle() {
		return this.group ? Ie(ze(this.calcTransformMatrix())) : this.angle;
	}
	getViewportTransform() {
		var e;
		return ((e = this.canvas) == null ? void 0 : e.viewportTransform) || T.concat();
	}
	calcACoords() {
		let e = We({ angle: this.angle }), { x: t, y: n } = this.getRelativeCenterPoint(), r = z(Ue(t, n), e), i = this._getTransformedDimensions(), a = i.x / 2, o = i.y / 2;
		return {
			tl: L({
				x: -a,
				y: -o
			}, r),
			tr: L({
				x: a,
				y: -o
			}, r),
			bl: L({
				x: -a,
				y: o
			}, r),
			br: L({
				x: a,
				y: o
			}, r)
		};
	}
	setCoords() {
		this.aCoords = this.calcACoords();
	}
	transformMatrixKey(e = !1) {
		let t = [];
		return !e && this.group && (t = this.group.transformMatrixKey(e)), t.push(this.top, this.left, this.width, this.height, this.scaleX, this.scaleY, this.angle, this.strokeWidth, this.skewX, this.skewY, +this.flipX, +this.flipY, W(this.originX), W(this.originY)), t;
	}
	calcTransformMatrix(e = !1) {
		let t = this.calcOwnMatrix();
		if (e || !this.group) return t;
		let n = this.transformMatrixKey(e), r = this.matrixCache;
		return r && r.key.every((e, t) => e === n[t]) ? r.value : (this.group && (t = z(this.group.calcTransformMatrix(!1), t)), this.matrixCache = {
			key: n,
			value: t
		}, t);
	}
	calcOwnMatrix() {
		let e = this.transformMatrixKey(!0), t = this.ownMatrixCache;
		if (t && t.key.every((t, n) => t === e[n])) return t.value;
		let n = this.getRelativeCenterPoint(), r = Xe({
			angle: this.angle,
			translateX: n.x,
			translateY: n.y,
			scaleX: this.scaleX,
			scaleY: this.scaleY,
			skewX: this.skewX,
			skewY: this.skewY,
			flipX: this.flipX,
			flipY: this.flipY
		});
		return this.ownMatrixCache = {
			key: e,
			value: r
		}, r;
	}
	_getNonTransformedDimensions() {
		return new N(this.width, this.height).scalarAdd(this.strokeWidth);
	}
	_calculateCurrentDimensions(e) {
		var t;
		let n = (t = this.canvas) == null ? void 0 : t.viewportTransform, r = this._getTransformedDimensions(e);
		return n ? r.multiply(new N(Be(n), Ve(n))).scalarAdd(2 * this.padding) : r.scalarAdd(2 * this.padding);
	}
	_getTransformedDimensions(e = {}) {
		let t = {
			scaleX: this.scaleX,
			scaleY: this.scaleY,
			skewX: this.skewX,
			skewY: this.skewY,
			width: this.width,
			height: this.height,
			strokeWidth: this.strokeWidth,
			...e
		}, n = t.strokeWidth, r = n, i = 0;
		this.strokeUniform && (r = 0, i = n);
		let a = t.width + r, o = t.height + r, s;
		return s = t.skewX === 0 && t.skewY === 0 ? new N(a * t.scaleX, o * t.scaleY) : At(a, o, Ye(t)), s.scalarAdd(i);
	}
	translateToGivenOrigin(e, t, n, r, i) {
		let a = e.x, o = e.y, s = W(r) - W(t), c = W(i) - W(n);
		if (s || c) {
			let e = this._getTransformedDimensions();
			a += s * e.x, o += c * e.y;
		}
		return new N(a, o);
	}
	translateToCenterPoint(e, t, n) {
		if (t === `center` && n === `center`) return e;
		let r = this.translateToGivenOrigin(e, t, n, E, E);
		return this.angle ? r.rotate(I(this.angle), e) : r;
	}
	translateToOriginPoint(e, t, n) {
		let r = this.translateToGivenOrigin(e, E, E, t, n);
		return this.angle ? r.rotate(I(this.angle), e) : r;
	}
	getCenterPoint() {
		let e = this.getRelativeCenterPoint();
		return this.group ? L(e, this.group.calcTransformMatrix()) : e;
	}
	getRelativeCenterPoint() {
		return this.translateToCenterPoint(new N(this.left, this.top), this.originX, this.originY);
	}
	getPointByOrigin(e, t) {
		return this.getPositionByOrigin(e, t);
	}
	getPositionByOrigin(e, t) {
		return this.translateToOriginPoint(this.getRelativeCenterPoint(), e, t);
	}
	setPositionByOrigin(e, t, n) {
		let r = this.translateToCenterPoint(e, t, n), i = this.translateToOriginPoint(r, this.originX, this.originY);
		this.set({
			left: i.x,
			top: i.y
		});
	}
	_getLeftTopCoords() {
		return this.getPositionByOrigin(D, `top`);
	}
	positionByLeftTop(e) {
		return this.setPositionByOrigin(e, D, `top`);
	}
};
var Ir = class e extends Fr {
	static getDefaults() {
		return e.ownDefaults;
	}
	get type() {
		let e = this.constructor.type;
		return e === `FabricObject` ? `object` : e.toLowerCase();
	}
	set type(e) {
		s(`warn`, `Setting type has no effect`, e);
	}
	constructor(t) {
		super(), i(this, `_cacheContext`, null), Object.assign(this, e.ownDefaults), this.setOptions(t);
	}
	_createCacheCanvas() {
		this._cacheCanvas = P(), this._cacheContext = this._cacheCanvas.getContext(`2d`), this._updateCacheCanvas(), this.dirty = !0;
	}
	_limitCacheSize(e) {
		let t = e.width, n = e.height, r = o.maxCacheSideLimit, i = o.minCacheSideLimit;
		if (t <= r && n <= r && t * n <= o.perfLimitSizeTotal) return t < i && (e.width = i), n < i && (e.height = i), e;
		let a = t / n, [s, c] = y.limitDimsByArea(a), l = Vn(i, s, r), u = Vn(i, c, r);
		return t > l && (e.zoomX /= t / l, e.width = l, e.capped = !0), n > u && (e.zoomY /= n / u, e.height = u, e.capped = !0), e;
	}
	_getCacheCanvasDimensions() {
		let e = this.getTotalObjectScaling(), t = this._getTransformedDimensions({
			skewX: 0,
			skewY: 0
		}), n = t.x * e.x / this.scaleX, r = t.y * e.y / this.scaleY;
		return {
			width: Math.ceil(n + 2),
			height: Math.ceil(r + 2),
			zoomX: e.x,
			zoomY: e.y,
			x: n,
			y: r
		};
	}
	_updateCacheCanvas() {
		let e = this._cacheCanvas, t = this._cacheContext, { width: n, height: r, zoomX: i, zoomY: a, x: o, y: s } = this._limitCacheSize(this._getCacheCanvasDimensions()), c = n !== e.width || r !== e.height, l = this.zoomX !== i || this.zoomY !== a;
		if (!e || !t) return !1;
		if (c || l) {
			n !== e.width || r !== e.height ? (e.width = n, e.height = r) : (t.setTransform(1, 0, 0, 1, 0, 0), t.clearRect(0, 0, e.width, e.height));
			let c = o / 2, l = s / 2;
			return this.cacheTranslationX = Math.round(e.width / 2 - c) + c, this.cacheTranslationY = Math.round(e.height / 2 - l) + l, t.translate(this.cacheTranslationX, this.cacheTranslationY), t.scale(i, a), this.zoomX = i, this.zoomY = a, !0;
		}
		return !1;
	}
	setOptions(e = {}) {
		this._setOptions(e);
	}
	transform(e) {
		let t = this.group && !this.group._transformDone || this.group && this.canvas && e === this.canvas.contextTop, n = this.calcTransformMatrix(!t);
		e.transform(n[0], n[1], n[2], n[3], n[4], n[5]);
	}
	getObjectScaling() {
		if (!this.group) return new N(Math.abs(this.scaleX), Math.abs(this.scaleY));
		let e = He(this.calcTransformMatrix());
		return new N(Math.abs(e.scaleX), Math.abs(e.scaleY));
	}
	getTotalObjectScaling() {
		let e = this.getObjectScaling();
		if (this.canvas) {
			let t = this.canvas.getZoom(), n = this.getCanvasRetinaScaling();
			return e.scalarMultiply(t * n);
		}
		return e;
	}
	getObjectOpacity() {
		let e = this.opacity;
		return this.group && (e *= this.group.getObjectOpacity()), e;
	}
	_constrainScale(e) {
		return Math.abs(e) < this.minScaleLimit ? e < 0 ? -this.minScaleLimit : this.minScaleLimit : e === 0 ? 1e-4 : e;
	}
	_set(e, t) {
		e !== `scaleX` && e !== `scaleY` || (t = this._constrainScale(t)), e === `scaleX` && t < 0 ? (this.flipX = !this.flipX, t *= -1) : e === `scaleY` && t < 0 ? (this.flipY = !this.flipY, t *= -1) : e !== `shadow` || !t || t instanceof Bn || (t = new Bn(t));
		let n = this[e] !== t;
		return this[e] = t, n && this.constructor.cacheProperties.includes(e) && (this.dirty = !0), this.parent && (this.dirty || n && this.constructor.stateProperties.includes(e)) && this.parent._set(`dirty`, !0), this;
	}
	isNotVisible() {
		return this.opacity === 0 || !this.width && !this.height && this.strokeWidth === 0 || !this.visible;
	}
	render(e) {
		this.isNotVisible() || this.canvas && this.canvas.skipOffscreen && !this.group && !this.isOnScreen() || (e.save(), this._setupCompositeOperation(e), this.drawSelectionBackground(e), this.transform(e), this._setOpacity(e), this._setShadow(e), this.shouldCache() ? (this.renderCache(), this.drawCacheOnCanvas(e)) : (this._removeCacheCanvas(), this.drawObject(e, !1, {}), this.dirty = !1), e.restore());
	}
	drawSelectionBackground(e) {}
	renderCache(e) {
		if (e = e || {}, this._cacheCanvas && this._cacheContext || this._createCacheCanvas(), this.isCacheDirty() && this._cacheContext) {
			let { zoomX: t, zoomY: n, cacheTranslationX: r, cacheTranslationY: i } = this, { width: a, height: o } = this._cacheCanvas;
			this.drawObject(this._cacheContext, e.forClipping, {
				zoomX: t,
				zoomY: n,
				cacheTranslationX: r,
				cacheTranslationY: i,
				width: a,
				height: o,
				parentClipPaths: []
			}), this.dirty = !1;
		}
	}
	_removeCacheCanvas() {
		this._cacheCanvas = void 0, this._cacheContext = null;
	}
	hasStroke() {
		return !!this.stroke && this.stroke !== `transparent` && this.strokeWidth !== 0;
	}
	hasFill() {
		return !!this.fill && this.fill !== `transparent`;
	}
	needsItsOwnCache() {
		return !!(this.paintFirst === `stroke` && this.hasFill() && this.hasStroke() && this.shadow) || !!this.clipPath;
	}
	shouldCache() {
		return this.ownCaching = this.objectCaching && (!this.parent || !this.parent.isOnACache()) || this.needsItsOwnCache(), this.ownCaching;
	}
	willDrawShadow() {
		return !!this.shadow && (this.shadow.offsetX !== 0 || this.shadow.offsetY !== 0);
	}
	drawClipPathOnCache(e, t, n) {
		e.save(), t.inverted ? e.globalCompositeOperation = `destination-out` : e.globalCompositeOperation = `destination-in`, e.setTransform(1, 0, 0, 1, 0, 0), e.drawImage(n, 0, 0), e.restore();
	}
	drawObject(e, t, n) {
		let r = this.fill, i = this.stroke;
		t ? (this.fill = `black`, this.stroke = ``, this._setClippingProperties(e)) : this._renderBackground(e), this.fire(`before:render`, { ctx: e }), this._render(e), this._drawClipPath(e, this.clipPath, n), this.fill = r, this.stroke = i;
	}
	createClipPathLayer(e, t) {
		let n = F(t), r = n.getContext(`2d`);
		if (r.translate(t.cacheTranslationX, t.cacheTranslationY), r.scale(t.zoomX, t.zoomY), e._cacheCanvas = n, t.parentClipPaths.forEach((e) => {
			e.transform(r);
		}), t.parentClipPaths.push(e), e.absolutePositioned) {
			let e = R(this.calcTransformMatrix());
			r.transform(e[0], e[1], e[2], e[3], e[4], e[5]);
		}
		return e.transform(r), e.drawObject(r, !0, t), n;
	}
	_drawClipPath(e, t, n) {
		if (!t) return;
		t._transformDone = !0;
		let r = this.createClipPathLayer(t, n);
		this.drawClipPathOnCache(e, t, r);
	}
	drawCacheOnCanvas(e) {
		e.scale(1 / this.zoomX, 1 / this.zoomY), e.drawImage(this._cacheCanvas, -this.cacheTranslationX, -this.cacheTranslationY);
	}
	isCacheDirty(e = !1) {
		if (this.isNotVisible()) return !1;
		let t = this._cacheCanvas, n = this._cacheContext;
		return !(!t || !n || e || !this._updateCacheCanvas()) || !!(this.dirty || this.clipPath && this.clipPath.absolutePositioned) && (t && n && !e && (n.save(), n.setTransform(1, 0, 0, 1, 0, 0), n.clearRect(0, 0, t.width, t.height), n.restore()), !0);
	}
	_renderBackground(e) {
		if (!this.backgroundColor) return;
		let t = this._getNonTransformedDimensions();
		e.fillStyle = this.backgroundColor, e.fillRect(-t.x / 2, -t.y / 2, t.x, t.y), this._removeShadow(e);
	}
	_setOpacity(e) {
		this.group && !this.group._transformDone ? e.globalAlpha = this.getObjectOpacity() : e.globalAlpha *= this.opacity;
	}
	_setStrokeStyles(e, t) {
		let n = t.stroke;
		n && (e.lineWidth = t.strokeWidth, e.lineCap = t.strokeLineCap, e.lineDashOffset = t.strokeDashOffset, e.lineJoin = t.strokeLineJoin, e.miterLimit = t.strokeMiterLimit, V(n) ? n.gradientUnits === `percentage` || n.gradientTransform || n.patternTransform ? this._applyPatternForTransformedGradient(e, n) : (e.strokeStyle = n.toLive(e), this._applyPatternGradientTransform(e, n)) : e.strokeStyle = t.stroke);
	}
	_setFillStyles(e, { fill: t }) {
		t && (V(t) ? (e.fillStyle = t.toLive(e), this._applyPatternGradientTransform(e, t)) : e.fillStyle = t);
	}
	_setClippingProperties(e) {
		e.globalAlpha = 1, e.strokeStyle = `transparent`, e.fillStyle = `#000000`;
	}
	_setLineDash(e, t) {
		t && t.length !== 0 && e.setLineDash(t);
	}
	_setShadow(e) {
		if (!this.shadow) return;
		let t = this.shadow, n = this.canvas, r = this.getCanvasRetinaScaling(), [i, , , a] = (n == null ? void 0 : n.viewportTransform) || T, s = i * r, c = a * r, l = t.nonScaling ? new N(1, 1) : this.getObjectScaling();
		e.shadowColor = t.color, e.shadowBlur = t.blur * o.browserShadowBlurConstant * (s + c) * (l.x + l.y) / 4, e.shadowOffsetX = t.offsetX * s * l.x, e.shadowOffsetY = t.offsetY * c * l.y;
	}
	_removeShadow(e) {
		this.shadow && (e.shadowColor = ``, e.shadowBlur = e.shadowOffsetX = e.shadowOffsetY = 0);
	}
	_applyPatternGradientTransform(e, t) {
		if (!V(t)) return {
			offsetX: 0,
			offsetY: 0
		};
		let n = t.gradientTransform || t.patternTransform, r = -this.width / 2 + t.offsetX || 0, i = -this.height / 2 + t.offsetY || 0;
		return t.gradientUnits === `percentage` ? e.transform(this.width, 0, 0, this.height, r, i) : e.transform(1, 0, 0, 1, r, i), n && e.transform(n[0], n[1], n[2], n[3], n[4], n[5]), {
			offsetX: r,
			offsetY: i
		};
	}
	_renderPaintInOrder(e) {
		this.paintFirst === `stroke` ? (this._renderStroke(e), this._renderFill(e)) : (this._renderFill(e), this._renderStroke(e));
	}
	_render(e) {}
	_renderFill(e) {
		this.fill && (e.save(), this._setFillStyles(e, this), this.fillRule === `evenodd` ? e.fill(`evenodd`) : e.fill(), e.restore());
	}
	_renderStroke(e) {
		if (this.stroke && this.strokeWidth !== 0) {
			if (this.shadow && !this.shadow.affectStroke && this._removeShadow(e), e.save(), this.strokeUniform) {
				let t = this.getObjectScaling();
				e.scale(1 / t.x, 1 / t.y);
			}
			this._setLineDash(e, this.strokeDashArray), this._setStrokeStyles(e, this), e.stroke(), e.restore();
		}
	}
	_applyPatternForTransformedGradient(e, t) {
		var n;
		let r = this._limitCacheSize(this._getCacheCanvasDimensions()), i = this.getCanvasRetinaScaling(), a = r.x / this.scaleX / i, o = r.y / this.scaleY / i, s = F({
			width: Math.ceil(a),
			height: Math.ceil(o)
		}), c = s.getContext(`2d`);
		c && (c.beginPath(), c.moveTo(0, 0), c.lineTo(a, 0), c.lineTo(a, o), c.lineTo(0, o), c.closePath(), c.translate(a / 2, o / 2), c.scale(r.zoomX / this.scaleX / i, r.zoomY / this.scaleY / i), this._applyPatternGradientTransform(c, t), c.fillStyle = t.toLive(e), c.fill(), e.translate(-this.width / 2 - this.strokeWidth / 2, -this.height / 2 - this.strokeWidth / 2), e.scale(i * this.scaleX / r.zoomX, i * this.scaleY / r.zoomY), e.strokeStyle = (n = c.createPattern(s, `no-repeat`)) == null ? `` : n);
	}
	_findCenterFromElement() {
		return new N(this.left + this.width / 2, this.top + this.height / 2);
	}
	clone(e) {
		let t = this.toObject(e);
		return this.constructor.fromObject(t);
	}
	cloneAsImage(e) {
		let t = this.toCanvasElement(e);
		return new (M.getClass(`image`))(t);
	}
	toCanvasElement(e = {}) {
		let t = kt(this), n = this.group, r = this.shadow, i = Math.abs, a = e.enableRetinaScaling ? v() : 1, o = (e.multiplier || 1) * a, s = e.canvasProvider || ((e) => new yt(e, {
			enableRetinaScaling: !1,
			renderOnAddRemove: !1,
			skipOffscreen: !1
		}));
		delete this.group, e.withoutTransform && Ot(this), e.withoutShadow && (this.shadow = null), e.viewportTransform && Pt(this, this.getViewportTransform()), this.setCoords();
		let c = P(), l = this.getBoundingRect(), u = this.shadow, d = new N();
		if (u) {
			let e = u.blur, t = u.nonScaling ? new N(1, 1) : this.getObjectScaling();
			d.x = 2 * Math.round(i(u.offsetX) + e) * i(t.x), d.y = 2 * Math.round(i(u.offsetY) + e) * i(t.y);
		}
		let f = l.width + d.x, p = l.height + d.y;
		c.width = Math.ceil(f), c.height = Math.ceil(p);
		let m = s(c);
		e.format === `jpeg` && (m.backgroundColor = `#fff`), this.setPositionByOrigin(new N(m.width / 2, m.height / 2), E, E);
		let h = this.canvas;
		m._objects = [this], this.set(`canvas`, m), this.setCoords();
		let g = m.toCanvasElement(o || 1, e);
		return this.set(`canvas`, h), this.shadow = r, n && (this.group = n), this.set(t), this.setCoords(), m._objects = [], m.destroy(), g;
	}
	toDataURL(e = {}) {
		return Pe(this.toCanvasElement(e), e.format || `png`, e.quality || 1);
	}
	toBlob(e = {}) {
		return Fe(this.toCanvasElement(e), e.format || `png`, e.quality || 1);
	}
	isType(...e) {
		return e.includes(this.constructor.type) || e.includes(this.type);
	}
	complexity() {
		return 1;
	}
	toJSON() {
		return this.toObject();
	}
	rotate(e) {
		let { centeredRotation: t, originX: n, originY: r } = this;
		if (t) {
			let { x: e, y: t } = this.getRelativeCenterPoint();
			this.originX = E, this.originY = E, this.left = e, this.top = t;
		}
		if (this.set(`angle`, e), t) {
			let { x: e, y: t } = this.getPositionByOrigin(n, r);
			this.left = e, this.top = t, this.originX = n, this.originY = r;
		}
	}
	setOnGroup() {}
	_setupCompositeOperation(e) {
		this.globalCompositeOperation && (e.globalCompositeOperation = this.globalCompositeOperation);
	}
	dispose() {
		ye.cancelByTarget(this), this.off(), this._set(`canvas`, void 0), this._cacheCanvas && h().dispose(this._cacheCanvas), this._cacheCanvas = void 0, this._cacheContext = null;
	}
	animate(e, t) {
		return Object.entries(e).reduce((e, [n, r]) => (e[n] = this._animate(n, r, t), e), {});
	}
	_animate(e, t, n = {}) {
		let r = e.split(`.`), i = this.constructor.colorProperties.includes(r[r.length - 1]), { abort: a, startValue: o, onChange: s, onComplete: c } = n, l = {
			...n,
			target: this,
			startValue: o == null ? r.reduce((e, t) => e[t], this) : o,
			endValue: t,
			abort: a == null ? void 0 : a.bind(this),
			onChange: (e, t, n) => {
				r.reduce((t, n, i) => (i === r.length - 1 && (t[n] = e), t[n]), this), s && s(e, t, n);
			},
			onComplete: (e, t, n) => {
				this.setCoords(), c && c(e, t, n);
			}
		};
		return i ? Nr(l) : Mr(l);
	}
	isDescendantOf(e) {
		let { parent: t, group: n } = this;
		return t === e || n === e || !!t && t.isDescendantOf(e) || !!n && n !== t && n.isDescendantOf(e);
	}
	getAncestors() {
		let e = [], t = this;
		do
			t = t.parent, t && e.push(t);
		while (t);
		return e;
	}
	findCommonAncestors(e) {
		if (this === e) return {
			fork: [],
			otherFork: [],
			common: [this, ...this.getAncestors()]
		};
		let t = this.getAncestors(), n = e.getAncestors();
		if (t.length === 0 && n.length > 0 && this === n[n.length - 1]) return {
			fork: [],
			otherFork: [e, ...n.slice(0, n.length - 1)],
			common: [this]
		};
		for (let r, i = 0; i < t.length; i++) {
			if (r = t[i], r === e) return {
				fork: [this, ...t.slice(0, i)],
				otherFork: [],
				common: t.slice(i)
			};
			for (let a = 0; a < n.length; a++) {
				if (this === n[a]) return {
					fork: [],
					otherFork: [e, ...n.slice(0, a)],
					common: [this, ...t]
				};
				if (r === n[a]) return {
					fork: [this, ...t.slice(0, i)],
					otherFork: [e, ...n.slice(0, a)],
					common: t.slice(i)
				};
			}
		}
		return {
			fork: [this, ...t],
			otherFork: [e, ...n],
			common: []
		};
	}
	hasCommonAncestors(e) {
		let t = this.findCommonAncestors(e);
		return t && !!t.common.length;
	}
	isInFrontOf(e) {
		if (this === e) return;
		let t = this.findCommonAncestors(e);
		if (t.fork.includes(e)) return !0;
		if (t.otherFork.includes(this)) return !1;
		let n = t.common[0] || this.canvas;
		if (!n) return;
		let r = t.fork.pop(), i = t.otherFork.pop(), a = n._objects.indexOf(r), o = n._objects.indexOf(i);
		return a > -1 && a > o;
	}
	toObject(t = []) {
		let n = t.concat(e.customProperties, this.constructor.customProperties || []), r, i = o.NUM_FRACTION_DIGITS, { clipPath: a, fill: s, stroke: c, shadow: l, strokeDashArray: u, left: d, top: f, originX: p, originY: m, width: h, height: g, strokeWidth: _, strokeLineCap: v, strokeDashOffset: y, strokeLineJoin: x, strokeUniform: S, strokeMiterLimit: C, scaleX: w, scaleY: ee, angle: T, flipX: E, flipY: D, opacity: O, visible: k, backgroundColor: te, fillRule: ne, paintFirst: re, globalCompositeOperation: ie, skewX: ae, skewY: oe } = this;
		a && !a.excludeFromExport && (r = a.toObject(n.concat(`inverted`, `absolutePositioned`)));
		let A = (e) => B(e, i), se = {
			...et(this, n),
			type: this.constructor.type,
			version: b,
			originX: p,
			originY: m,
			left: A(d),
			top: A(f),
			width: A(h),
			height: A(g),
			fill: rt(s) ? s.toObject() : s,
			stroke: rt(c) ? c.toObject() : c,
			strokeWidth: A(_),
			strokeDashArray: u && u.concat(),
			strokeLineCap: v,
			strokeDashOffset: y,
			strokeLineJoin: x,
			strokeUniform: S,
			strokeMiterLimit: A(C),
			scaleX: A(w),
			scaleY: A(ee),
			angle: A(T),
			flipX: E,
			flipY: D,
			opacity: A(O),
			shadow: l && l.toObject(),
			visible: k,
			backgroundColor: te,
			fillRule: ne,
			paintFirst: re,
			globalCompositeOperation: ie,
			skewX: A(ae),
			skewY: A(oe),
			...r ? { clipPath: r } : null
		};
		return this.includeDefaultValues ? se : this._removeDefaultValues(se);
	}
	toDatalessObject(e) {
		return this.toObject(e);
	}
	_removeDefaultValues(e) {
		let t = this.constructor.getDefaults(), n = Object.keys(t).length > 0 ? t : Object.getPrototypeOf(this);
		return tt(e, (e, t) => {
			if (t === `left` || t === `top` || t === `type`) return !0;
			let r = n[t];
			return e !== r && !(Array.isArray(e) && Array.isArray(r) && e.length === 0 && r.length === 0);
		});
	}
	toString() {
		return `#<${this.constructor.type}>`;
	}
	static _fromObject({ type: e, ...t }, { extraParam: n, ...r } = {}) {
		return $e(t, r).then((e) => n ? (delete e[n], new this(t[n], e)) : new this(e));
	}
	static fromObject(e, t) {
		return this._fromObject(e, t);
	}
};
i(Ir, `stateProperties`, Hn), i(Ir, `cacheProperties`, Un), i(Ir, `ownDefaults`, Wn), i(Ir, `type`, `FabricObject`), i(Ir, `colorProperties`, [
	j,
	he,
	`backgroundColor`
]), i(Ir, `customProperties`, []), M.setClass(Ir), M.setClass(Ir, `object`);
var Lr = (e, t) => {
	var n;
	let { transform: { target: r } } = t;
	(n = r.canvas) == null || n.fire(`object:${e}`, {
		...t,
		target: r
	}), r.fire(e, t);
};
var Rr = (e, t, n) => (r, i, a, o) => {
	let s = t(r, i, a, o);
	return s && Lr(e, {
		...Qt(r, i, a, o),
		...n
	}), s;
};
function zr(e) {
	return (t, n, r, i) => {
		let { target: a, originX: o, originY: s } = n, c = a.getPositionByOrigin(o, s), l = e(t, n, r, i);
		return a.setPositionByOrigin(c, n.originX, n.originY), l;
	};
}
var Br = (e, t, n, r) => (i, a, o, s) => {
	let c = en(a, a.originX, a.originY, o, s)[n], l = W(a[t]);
	if (l === 0 || l > 0 && c < 0 || l < 0 && c > 0) {
		let { target: t } = a, n = t.strokeWidth / (t.strokeUniform ? t[r] : 1), i = Yt(a) ? 2 : 1, o = t[e], s = Math.abs(c * i / t[r]) - n;
		return t.set(e, Math.max(s, 1)), o !== t[e];
	}
	return !1;
};
var Vr = Br(`width`, `originX`, `x`, `scaleX`);
var Hr = Br(`height`, `originY`, `y`, `scaleY`);
var Ur = Rr(se, zr(Vr));
var Wr = Rr(se, zr(Hr));
function Gr(e, t, n, r, i) {
	e.save();
	let { stroke: a, xSize: o, ySize: s, opName: c } = this.commonRenderProps(e, t, n, i, r), l = o;
	o > s ? e.scale(1, s / o) : s > o && (l = s, e.scale(o / s, 1)), e.beginPath(), e.arc(0, 0, l / 2, 0, w, !1), e[c](), a && e.stroke(), e.restore();
}
function Kr(e, t, n, r, i) {
	e.save();
	let { stroke: a, xSize: o, ySize: s, opName: c } = this.commonRenderProps(e, t, n, i, r), l = o / 2, u = s / 2;
	e[`${c}Rect`](-l, -u, o, s), a && e.strokeRect(-l, -u, o, s), e.restore();
}
var q = class {
	constructor(e) {
		i(this, `visible`, !0), i(this, `actionName`, ue), i(this, `angle`, 0), i(this, `x`, 0), i(this, `y`, 0), i(this, `offsetX`, 0), i(this, `offsetY`, 0), i(this, `sizeX`, 0), i(this, `sizeY`, 0), i(this, `touchSizeX`, 0), i(this, `touchSizeY`, 0), i(this, `cursorStyle`, `crosshair`), i(this, `withConnection`, !1), Object.assign(this, e);
	}
	getTransformAnchorPoint() {
		var e;
		return (e = this.transformAnchorPoint) == null ? new N(.5 - this.x, .5 - this.y) : e;
	}
	shouldActivate(e, t, n, { tl: r, tr: i, br: a, bl: o }) {
		var s;
		return ((s = t.canvas) == null ? void 0 : s.getActiveObject()) === t && t.isControlVisible(e) && Pr.isPointInPolygon(n, [
			r,
			i,
			a,
			o
		]);
	}
	getActionHandler(e, t, n) {
		return this.actionHandler;
	}
	getMouseDownHandler(e, t, n) {
		return this.mouseDownHandler;
	}
	getMouseUpHandler(e, t, n) {
		return this.mouseUpHandler;
	}
	cursorStyleHandler(e, t, n, r) {
		return t.cursorStyle;
	}
	getActionName(e, t, n) {
		return t.actionName;
	}
	getVisibility(e, t) {
		var n, r;
		return (n = (r = e._controlsVisibility) == null ? void 0 : r[t]) == null ? this.visible : n;
	}
	setVisibility(e, t, n) {
		this.visible = e;
	}
	positionHandler(e, t, n, r) {
		return new N(this.x * e.x + this.offsetX, this.y * e.y + this.offsetY).transform(t);
	}
	calcCornerCoords(e, t, n, r, i, a) {
		let o = Re([
			Ue(n, r),
			We({ angle: e }),
			Ge((i ? this.touchSizeX : this.sizeX) || t, (i ? this.touchSizeY : this.sizeY) || t)
		]);
		return {
			tl: new N(-.5, -.5).transform(o),
			tr: new N(.5, -.5).transform(o),
			br: new N(.5, .5).transform(o),
			bl: new N(-.5, .5).transform(o)
		};
	}
	commonRenderProps(e, t, n, r, i = {}) {
		let { cornerSize: a, cornerColor: o, transparentCorners: s, cornerStrokeColor: c } = i, l = a || r.cornerSize, u = this.sizeX || l, d = this.sizeY || l, f = s === void 0 ? r.transparentCorners : s, p = f ? he : j, m = c || r.cornerStrokeColor, h = !f && !!m;
		return e.fillStyle = o || r.cornerColor || ``, e.strokeStyle = m || ``, e.translate(t, n), e.rotate(I(r.getTotalAngle())), {
			stroke: h,
			xSize: u,
			ySize: d,
			transparentCorners: f,
			opName: p
		};
	}
	render(e, t, n, r, i) {
		((r = r || {}).cornerStyle || i.cornerStyle) === `circle` ? Gr.call(this, e, t, n, r, i) : Kr.call(this, e, t, n, r, i);
	}
};
var qr = (e, t, n) => n.lockRotation ? Jt : t.cursorStyle;
var Jr = Rr(ae, zr((e, { target: t, ex: n, ey: r, theta: i, originX: a, originY: o }, s, c) => {
	let l = t.getPositionByOrigin(a, o);
	if (Zt(t, `lockRotation`)) return !1;
	let u = Math.atan2(r - l.y, n - l.x), d = Ie(Math.atan2(c - l.y, s - l.x) - u + i);
	if (t.snapAngle && t.snapAngle > 0) {
		let e = t.snapAngle, n = t.snapThreshold || e, r = Math.ceil(d / e) * e, i = Math.floor(d / e) * e;
		Math.abs(d - i) < n ? d = i : Math.abs(d - r) < n && (d = r);
	}
	d < 0 && (d = 360 + d), d %= 360;
	let f = t.angle !== d;
	return t.angle = d, f;
}));
function Yr(e, t) {
	let n = t.canvas, r = e[n.uniScaleKey];
	return n.uniformScaling && !r || !n.uniformScaling && r;
}
function Xr(e, t, n) {
	let r = Zt(e, `lockScalingX`), i = Zt(e, `lockScalingY`);
	if (r && i || !t && (r || i) && n || r && t === `x` || i && t === `y`) return !0;
	let { width: a, height: o, strokeWidth: s } = e;
	return a === 0 && s === 0 && t !== `y` || o === 0 && s === 0 && t !== `x`;
}
var Zr = [
	`e`,
	`se`,
	`s`,
	`sw`,
	`w`,
	`nw`,
	`n`,
	`ne`,
	`e`
];
var Qr = (e, t, n, r) => {
	let i = Yr(e, n);
	return Xr(n, t.x !== 0 && t.y === 0 ? `x` : t.x === 0 && t.y !== 0 ? `y` : ``, i) ? Jt : `${Zr[$t(n, 0, r)]}-resize`;
};
function $r(e, t, n, r, i = {}) {
	let a = t.target, o = i.by, s = Yr(e, a), c, l, u, d, f, p;
	if (Xr(a, o, s)) return !1;
	if (t.gestureScale) l = t.scaleX * t.gestureScale, u = t.scaleY * t.gestureScale;
	else {
		if (c = en(t, t.originX, t.originY, n, r), f = o === `y` ? 1 : Math.sign(c.x || t.signX || 1), p = o === `x` ? 1 : Math.sign(c.y || t.signY || 1), t.signX || (t.signX = f), t.signY || (t.signY = p), Zt(a, `lockScalingFlip`) && (t.signX !== f || t.signY !== p)) return !1;
		if (d = a._getTransformedDimensions(), s && !o) {
			let e = Math.abs(c.x) + Math.abs(c.y), { original: n } = t, r = e / (Math.abs(d.x * n.scaleX / a.scaleX) + Math.abs(d.y * n.scaleY / a.scaleY));
			l = n.scaleX * r, u = n.scaleY * r;
		} else l = Math.abs(c.x * a.scaleX / d.x), u = Math.abs(c.y * a.scaleY / d.y);
		Yt(t) && (l *= 2, u *= 2), t.signX !== f && o !== `y` && (t.originX = Xt(t.originX), l *= -1, t.signX = f), t.signY !== p && o !== `x` && (t.originY = Xt(t.originY), u *= -1, t.signY = p);
	}
	let m = a.scaleX, h = a.scaleY;
	return o ? (o === `x` && a.set(`scaleX`, l), o === `y` && a.set(`scaleY`, u)) : (!Zt(a, `lockScalingX`) && a.set(`scaleX`, l), !Zt(a, `lockScalingY`) && a.set(`scaleY`, u)), m !== a.scaleX || h !== a.scaleY;
}
var ei = Rr(ie, zr((e, t, n, r) => $r(e, t, n, r)));
var ti = Rr(ie, zr((e, t, n, r) => $r(e, t, n, r, { by: `x` })));
var ni = Rr(ie, zr((e, t, n, r) => $r(e, t, n, r, { by: `y` })));
var ri = {
	x: {
		counterAxis: `y`,
		scale: de,
		skew: pe,
		lockSkewing: `lockSkewingX`,
		origin: `originX`,
		flip: `flipX`
	},
	y: {
		counterAxis: `x`,
		scale: fe,
		skew: me,
		lockSkewing: `lockSkewingY`,
		origin: `originY`,
		flip: `flipY`
	}
};
var ii = [
	`ns`,
	`nesw`,
	`ew`,
	`nwse`
];
var ai = (e, t, n, r) => t.x !== 0 && Zt(n, `lockSkewingY`) || t.y !== 0 && Zt(n, `lockSkewingX`) ? Jt : `${ii[$t(n, 0, r) % 4]}-resize`;
function oi(e, t, n, r, i) {
	let { target: a } = n, { counterAxis: o, origin: s, lockSkewing: c, skew: l, flip: u } = ri[e];
	if (Zt(a, c)) return !1;
	let { origin: d, flip: f } = ri[o], p = W(n[d]) * (a[f] ? -1 : 1), m = -Math.sign(p) * (a[u] ? -1 : 1), h = -(a[l] === 0 && en(n, `center`, `center`, r, i)[e] > 0 || a[l] > 0 ? 1 : -1) * m * .5 + .5;
	return Rr(A, zr((t, n, r, i) => function(e, { target: t, ex: n, ey: r, skewingSide: i, ...a }, o) {
		let { skew: s } = ri[e], c = o.subtract(new N(n, r)).divide(new N(t.scaleX, t.scaleY))[e], l = t[s], u = a[s], d = Math.tan(I(u)), f = e === `y` ? t._getTransformedDimensions({
			scaleX: 1,
			scaleY: 1,
			skewX: 0
		}).x : t._getTransformedDimensions({
			scaleX: 1,
			scaleY: 1
		}).y, p = 2 * c * i / Math.max(f, 1) + d, m = Ie(Math.atan(p));
		t.set(s, m);
		let h = l !== t[s];
		if (h && e === `y`) {
			let { skewX: e, scaleX: n } = t, r = t._getTransformedDimensions({ skewY: l }), i = t._getTransformedDimensions(), a = e === 0 ? 1 : r.x / i.x;
			a !== 1 && t.set(`scaleX`, a * n);
		}
		return h;
	}(e, n, new N(r, i))))(t, {
		...n,
		[s]: h,
		skewingSide: m
	}, r, i);
}
var si = (e, t, n, r) => oi(`x`, e, t, n, r);
var ci = (e, t, n, r) => oi(`y`, e, t, n, r);
function li(e, t) {
	return e[t.canvas.altActionKey];
}
var ui = (e, t, n) => {
	let r = li(e, n);
	return t.x === 0 ? r ? pe : fe : t.y === 0 ? r ? me : de : ``;
};
var di = (e, t, n, r) => li(e, n) ? ai(0, t, n, r) : Qr(e, t, n, r);
var fi = (e, t, n, r) => li(e, t.target) ? ci(e, t, n, r) : ti(e, t, n, r);
var pi = (e, t, n, r) => li(e, t.target) ? si(e, t, n, r) : ni(e, t, n, r);
var mi = () => ({
	ml: new q({
		x: -.5,
		y: 0,
		cursorStyleHandler: di,
		actionHandler: fi,
		getActionName: ui
	}),
	mr: new q({
		x: .5,
		y: 0,
		cursorStyleHandler: di,
		actionHandler: fi,
		getActionName: ui
	}),
	mb: new q({
		x: 0,
		y: .5,
		cursorStyleHandler: di,
		actionHandler: pi,
		getActionName: ui
	}),
	mt: new q({
		x: 0,
		y: -.5,
		cursorStyleHandler: di,
		actionHandler: pi,
		getActionName: ui
	}),
	tl: new q({
		x: -.5,
		y: -.5,
		cursorStyleHandler: Qr,
		actionHandler: ei
	}),
	tr: new q({
		x: .5,
		y: -.5,
		cursorStyleHandler: Qr,
		actionHandler: ei
	}),
	bl: new q({
		x: -.5,
		y: .5,
		cursorStyleHandler: Qr,
		actionHandler: ei
	}),
	br: new q({
		x: .5,
		y: .5,
		cursorStyleHandler: Qr,
		actionHandler: ei
	}),
	mtr: new q({
		x: 0,
		y: -.5,
		actionHandler: Jr,
		cursorStyleHandler: qr,
		offsetY: -40,
		withConnection: !0,
		actionName: oe
	})
});
var hi = () => ({
	mr: new q({
		x: .5,
		y: 0,
		actionHandler: Ur,
		cursorStyleHandler: di,
		actionName: se
	}),
	ml: new q({
		x: -.5,
		y: 0,
		actionHandler: Ur,
		cursorStyleHandler: di,
		actionName: se
	})
});
var gi = () => ({
	...mi(),
	...hi()
});
var _i = class e extends Ir {
	static getDefaults() {
		return {
			...super.getDefaults(),
			...e.ownDefaults
		};
	}
	constructor(t) {
		super(), Object.assign(this, this.constructor.createControls(), e.ownDefaults), this.setOptions(t);
	}
	static createControls() {
		return { controls: mi() };
	}
	_updateCacheCanvas() {
		let e = this.canvas;
		if (this.noScaleCache && e && e._currentTransform) {
			let t = e._currentTransform, n = t.target, r = t.action;
			if (this === n && r && r.startsWith(`scale`)) return !1;
		}
		return super._updateCacheCanvas();
	}
	getActiveControl() {
		let e = this.__corner;
		return e ? {
			key: e,
			control: this.controls[e],
			coord: this.oCoords[e]
		} : void 0;
	}
	findControl(e, t = !1) {
		if (!this.hasControls || !this.canvas) return;
		this.__corner = void 0;
		let n = Object.entries(this.oCoords);
		for (let r = n.length - 1; r >= 0; r--) {
			let [i, a] = n[r], o = this.controls[i];
			if (o.shouldActivate(i, this, e, t ? a.touchCorner : a.corner)) return this.__corner = i, {
				key: i,
				control: o,
				coord: this.oCoords[i]
			};
		}
	}
	calcOCoords() {
		let e = this.getViewportTransform(), t = Be(e), n = Ve(e), r = this.getCenterPoint(), i = z(z(e, z(Ue(r.x, r.y), We({ angle: this.getTotalAngle() - (this.group && this.flipX ? 180 : 0) }))), [
			1 / t,
			0,
			0,
			1 / n,
			0,
			0
		]), a = this.group ? He(this.calcTransformMatrix()) : void 0;
		a && (a.scaleX = Math.abs(a.scaleX), a.scaleY = Math.abs(a.scaleY));
		let o = this._calculateCurrentDimensions(a), s = {};
		return this.forEachControl((e, t) => {
			let n = e.positionHandler(o, i, this, e);
			s[t] = Object.assign(n, this._calcCornerCoords(e, n));
		}), s;
	}
	_calcCornerCoords(e, t) {
		let n = this.getTotalAngle();
		return {
			corner: e.calcCornerCoords(n, this.cornerSize, t.x, t.y, !1, this),
			touchCorner: e.calcCornerCoords(n, this.touchCornerSize, t.x, t.y, !0, this)
		};
	}
	setCoords() {
		super.setCoords(), this.canvas && (this.oCoords = this.calcOCoords());
	}
	forEachControl(e) {
		for (let t in this.controls) e(this.controls[t], t, this);
	}
	drawSelectionBackground(e) {
		if (!this.selectionBackgroundColor || this.canvas && this.canvas._activeObject !== this) return;
		e.save();
		let t = this.getRelativeCenterPoint(), n = this._calculateCurrentDimensions(), r = this.getViewportTransform();
		e.translate(t.x, t.y), e.scale(1 / r[0], 1 / r[3]), e.rotate(I(this.angle)), e.fillStyle = this.selectionBackgroundColor, e.fillRect(-n.x / 2, -n.y / 2, n.x, n.y), e.restore();
	}
	strokeBorders(e, t) {
		e.strokeRect(-t.x / 2, -t.y / 2, t.x, t.y);
	}
	_drawBorders(e, t, n = {}) {
		let r = {
			hasControls: this.hasControls,
			borderColor: this.borderColor,
			borderDashArray: this.borderDashArray,
			...n
		};
		e.save(), e.strokeStyle = r.borderColor, this._setLineDash(e, r.borderDashArray), this.strokeBorders(e, t), r.hasControls && this.drawControlsConnectingLines(e, t), e.restore();
	}
	_renderControls(e, t = {}) {
		let { hasBorders: n, hasControls: r } = this, i = {
			hasBorders: n,
			hasControls: r,
			...t
		}, a = this.getViewportTransform(), o = i.hasBorders, s = i.hasControls, c = He(z(a, this.calcTransformMatrix()));
		e.save(), e.translate(c.translateX, c.translateY), e.lineWidth = this.borderScaleFactor, this.group === this.parent && (e.globalAlpha = this.isMoving ? this.borderOpacityWhenMoving : 1), this.flipX && (c.angle -= 180);
		let l = ze(a);
		e.rotate(this.group ? I(c.angle) : I(this.angle) + l), o && this.drawBorders(e, c, t), s && this.drawControls(e, t), e.restore();
	}
	drawBorders(e, t, n) {
		let r;
		if (n && n.forActiveSelection || this.group) {
			let e = At(this.width, this.height, Ye(t)), n = this.isStrokeAccountedForInDimensions() ? we : (this.strokeUniform ? new N().scalarAdd(this.canvas ? this.canvas.getZoom() : 1) : new N(t.scaleX, t.scaleY)).scalarMultiply(this.strokeWidth);
			r = e.add(n).scalarAdd(this.borderScaleFactor).scalarAdd(2 * this.padding);
		} else r = this._calculateCurrentDimensions().scalarAdd(this.borderScaleFactor);
		this._drawBorders(e, r, n);
	}
	drawControlsConnectingLines(e, t) {
		let n = !1;
		e.beginPath(), this.forEachControl((r, i) => {
			r.withConnection && r.getVisibility(this, i) && (n = !0, e.moveTo(r.x * t.x, r.y * t.y), e.lineTo(r.x * t.x + r.offsetX, r.y * t.y + r.offsetY));
		}), n && e.stroke();
	}
	drawControls(e, t = {}) {
		e.save();
		let n = this.getCanvasRetinaScaling(), { cornerStrokeColor: r, cornerDashArray: i, cornerColor: a } = this, o = {
			cornerStrokeColor: r,
			cornerDashArray: i,
			cornerColor: a,
			...t
		};
		e.setTransform(n, 0, 0, n, 0, 0), e.strokeStyle = e.fillStyle = o.cornerColor, this.transparentCorners || (e.strokeStyle = o.cornerStrokeColor), this._setLineDash(e, o.cornerDashArray), this.forEachControl((t, n) => {
			if (t.getVisibility(this, n)) {
				let r = this.oCoords[n];
				t.render(e, r.x, r.y, o, this);
			}
		}), e.restore();
	}
	isControlVisible(e) {
		return this.controls[e] && this.controls[e].getVisibility(this, e);
	}
	setControlVisible(e, t) {
		this._controlsVisibility || (this._controlsVisibility = {}), this._controlsVisibility[e] = t;
	}
	setControlsVisibility(e = {}) {
		Object.entries(e).forEach(([e, t]) => this.setControlVisible(e, t));
	}
	clearContextTop(e) {
		if (!this.canvas) return;
		let t = this.canvas.contextTop;
		if (!t) return;
		let n = this.canvas.viewportTransform;
		t.save(), t.transform(n[0], n[1], n[2], n[3], n[4], n[5]), this.transform(t);
		let r = this.width + 4, i = this.height + 4;
		return t.clearRect(-r / 2, -i / 2, r, i), e || t.restore(), t;
	}
	onDeselect(e) {
		return !1;
	}
	onSelect(e) {
		return !1;
	}
	shouldStartDragging(e) {
		return !1;
	}
	onDragStart(e) {
		return !1;
	}
	canDrop(e) {
		return !1;
	}
	renderDragSourceEffect(e) {}
	renderDropTargetEffect(e) {}
};
function vi(e, t) {
	return t.forEach((t) => {
		Object.getOwnPropertyNames(t.prototype).forEach((n) => {
			n !== `constructor` && Object.defineProperty(e.prototype, n, Object.getOwnPropertyDescriptor(t.prototype, n) || Object.create(null));
		});
	}), e;
}
i(_i, `ownDefaults`, {
	noScaleCache: !0,
	lockMovementX: !1,
	lockMovementY: !1,
	lockRotation: !1,
	lockScalingX: !1,
	lockScalingY: !1,
	lockSkewingX: !1,
	lockSkewingY: !1,
	lockScalingFlip: !1,
	cornerSize: 13,
	touchCornerSize: 24,
	transparentCorners: !0,
	cornerColor: `rgb(178,204,255)`,
	cornerStrokeColor: ``,
	cornerStyle: `rect`,
	cornerDashArray: null,
	hasControls: !0,
	borderColor: `rgb(178,204,255)`,
	borderDashArray: null,
	borderOpacityWhenMoving: .4,
	borderScaleFactor: 1,
	hasBorders: !0,
	selectionBackgroundColor: ``,
	selectable: !0,
	evented: !0,
	perPixelTargetFind: !1,
	activeOn: `down`,
	hoverCursor: null,
	moveCursor: null
});
var J = class extends _i {};
vi(J, [gn]), M.setClass(J), M.setClass(J, `object`);
var yi = (e, t, n, r) => {
	let i = 2 * (r = Math.round(r)) + 1, { data: a } = e.getImageData(t - r, n - r, i, i);
	for (let e = 3; e < a.length; e += 4) if (a[e] > 0) return !1;
	return !0;
};
var bi = class {
	constructor(e) {
		this.options = e, this.strokeProjectionMagnitude = this.options.strokeWidth / 2, this.scale = new N(this.options.scaleX, this.options.scaleY), this.strokeUniformScalar = this.options.strokeUniform ? new N(1 / this.options.scaleX, 1 / this.options.scaleY) : new N(1, 1);
	}
	createSideVector(e, t) {
		let n = zt(e, t);
		return this.options.strokeUniform ? n.multiply(this.scale) : n;
	}
	projectOrthogonally(e, t, n) {
		return this.applySkew(e.add(this.calcOrthogonalProjection(e, t, n)));
	}
	isSkewed() {
		return this.options.skewX !== 0 || this.options.skewY !== 0;
	}
	applySkew(e) {
		let t = new N(e);
		return t.y += t.x * Math.tan(I(this.options.skewY)), t.x += t.y * Math.tan(I(this.options.skewX)), t;
	}
	scaleUnitVector(e, t) {
		return e.multiply(this.strokeUniformScalar).scalarMultiply(t);
	}
};
var xi = new N();
var Si = class e extends bi {
	static getOrthogonalRotationFactor(e, t) {
		let n = t ? Vt(e, t) : Ht(e);
		return Math.abs(n) < S ? -1 : 1;
	}
	constructor(e, t, n, r) {
		super(r), i(this, `AB`, void 0), i(this, `AC`, void 0), i(this, `alpha`, void 0), i(this, `bisector`, void 0), this.A = new N(e), this.B = new N(t), this.C = new N(n), this.AB = this.createSideVector(this.A, this.B), this.AC = this.createSideVector(this.A, this.C), this.alpha = Vt(this.AB, this.AC), this.bisector = Ut(Rt(this.AB.eq(xi) ? this.AC : this.AB, this.alpha / 2));
	}
	calcOrthogonalProjection(t, n, r = this.strokeProjectionMagnitude) {
		let i = Wt(this.createSideVector(t, n)), a = e.getOrthogonalRotationFactor(i, this.bisector);
		return this.scaleUnitVector(i, r * a);
	}
	projectBevel() {
		let e = [];
		return (this.alpha % w === 0 ? [this.B] : [this.B, this.C]).forEach((t) => {
			e.push(this.projectOrthogonally(this.A, t)), e.push(this.projectOrthogonally(this.A, t, -this.strokeProjectionMagnitude));
		}), e;
	}
	projectMiter() {
		let e = [], t = Math.abs(this.alpha), n = 1 / Math.sin(t / 2), r = this.scaleUnitVector(this.bisector, -this.strokeProjectionMagnitude * n), i = this.options.strokeUniform ? Bt(this.scaleUnitVector(this.bisector, this.options.strokeMiterLimit)) : this.options.strokeMiterLimit;
		return Bt(r) / this.strokeProjectionMagnitude <= i && e.push(this.applySkew(this.A.add(r))), e.push(...this.projectBevel()), e;
	}
	projectRoundNoSkew(t, n) {
		let r = [], i = new N(e.getOrthogonalRotationFactor(this.bisector), e.getOrthogonalRotationFactor(new N(this.bisector.y, this.bisector.x)));
		return [new N(1, 0).scalarMultiply(this.strokeProjectionMagnitude).multiply(this.strokeUniformScalar).multiply(i), new N(0, 1).scalarMultiply(this.strokeProjectionMagnitude).multiply(this.strokeUniformScalar).multiply(i)].forEach((e) => {
			qt(e, t, n) && r.push(this.A.add(e));
		}), r;
	}
	projectRoundWithSkew(e, t) {
		let n = [], { skewX: r, skewY: i, scaleX: a, scaleY: o, strokeUniform: s } = this.options, c = new N(Math.tan(I(r)), Math.tan(I(i))), l = this.strokeProjectionMagnitude, u = s ? l / o / Math.sqrt(1 / o ** 2 + 1 / a ** 2 * c.y ** 2) : l / Math.sqrt(1 + c.y ** 2), d = new N(Math.sqrt(Math.max(l ** 2 - u ** 2, 0)), u), f = s ? l / Math.sqrt(1 + c.x ** 2 * (1 / o) ** 2 / (1 / a + 1 / a * c.x * c.y) ** 2) : l / Math.sqrt(1 + c.x ** 2 / (1 + c.x * c.y) ** 2), p = new N(f, Math.sqrt(Math.max(l ** 2 - f ** 2, 0)));
		return [
			p,
			p.scalarMultiply(-1),
			d,
			d.scalarMultiply(-1)
		].map((e) => this.applySkew(s ? e.multiply(this.strokeUniformScalar) : e)).forEach((r) => {
			qt(r, e, t) && n.push(this.applySkew(this.A).add(r));
		}), n;
	}
	projectRound() {
		let e = [];
		e.push(...this.projectBevel());
		let t = this.alpha % w === 0, n = this.applySkew(this.A), r = e[t ? 0 : 2].subtract(n), i = e[+!!t].subtract(n), a = Gt(r, t ? this.applySkew(this.AB.scalarMultiply(-1)) : this.applySkew(this.bisector.multiply(this.strokeUniformScalar).scalarMultiply(-1))) > 0, o = a ? r : i, s = a ? i : r;
		return this.isSkewed() ? e.push(...this.projectRoundWithSkew(o, s)) : e.push(...this.projectRoundNoSkew(o, s)), e;
	}
	projectPoints() {
		switch (this.options.strokeLineJoin) {
			case `miter`: return this.projectMiter();
			case `round`: return this.projectRound();
			default: return this.projectBevel();
		}
	}
	project() {
		return this.projectPoints().map((e) => ({
			originPoint: this.A,
			projectedPoint: e,
			angle: this.alpha,
			bisector: this.bisector
		}));
	}
};
var Ci = class extends bi {
	constructor(e, t, n) {
		super(n), this.A = new N(e), this.T = new N(t);
	}
	calcOrthogonalProjection(e, t, n = this.strokeProjectionMagnitude) {
		let r = this.createSideVector(e, t);
		return this.scaleUnitVector(Wt(r), n);
	}
	projectButt() {
		return [this.projectOrthogonally(this.A, this.T, this.strokeProjectionMagnitude), this.projectOrthogonally(this.A, this.T, -this.strokeProjectionMagnitude)];
	}
	projectRound() {
		let e = [];
		if (!this.isSkewed() && this.A.eq(this.T)) {
			let t = new N(1, 1).scalarMultiply(this.strokeProjectionMagnitude).multiply(this.strokeUniformScalar);
			e.push(this.applySkew(this.A.add(t)), this.applySkew(this.A.subtract(t)));
		} else e.push(...new Si(this.A, this.T, this.T, this.options).projectRound());
		return e;
	}
	projectSquare() {
		let e = [];
		if (this.A.eq(this.T)) {
			let t = new N(1, 1).scalarMultiply(this.strokeProjectionMagnitude).multiply(this.strokeUniformScalar);
			e.push(this.A.add(t), this.A.subtract(t));
		} else {
			let t = this.calcOrthogonalProjection(this.A, this.T, this.strokeProjectionMagnitude), n = this.scaleUnitVector(Ut(this.createSideVector(this.A, this.T)), -this.strokeProjectionMagnitude), r = this.A.add(n);
			e.push(r.add(t), r.subtract(t));
		}
		return e.map((e) => this.applySkew(e));
	}
	projectPoints() {
		switch (this.options.strokeLineCap) {
			case `round`: return this.projectRound();
			case `square`: return this.projectSquare();
			default: return this.projectButt();
		}
	}
	project() {
		return this.projectPoints().map((e) => ({
			originPoint: this.A,
			projectedPoint: e
		}));
	}
};
var wi = (e, t, n = !1) => {
	let r = [];
	if (e.length === 0) return r;
	let i = e.reduce((e, t) => (e[e.length - 1].eq(t) || e.push(new N(t)), e), [new N(e[0])]);
	if (i.length === 1) n = !0;
	else if (!n) {
		let e = i[0], t = ((e, t) => {
			for (let n = e.length - 1; n >= 0; n--) if (t(e[n], n, e)) return n;
			return -1;
		})(i, (t) => !t.eq(e));
		i.splice(t + 1);
	}
	return i.forEach((e, i, a) => {
		let o, s;
		i === 0 ? (s = a[1], o = n ? e : a[a.length - 1]) : i === a.length - 1 ? (o = a[i - 1], s = n ? e : a[0]) : (o = a[i - 1], s = a[i + 1]), n && a.length === 1 ? r.push(...new Ci(e, e, t).project()) : !n || i !== 0 && i !== a.length - 1 ? r.push(...new Si(e, o, s, t).project()) : r.push(...new Ci(e, i === 0 ? s : o, t).project());
	}), r;
};
var Ti = (e) => {
	let t = {};
	return Object.keys(e).forEach((n) => {
		t[n] = {}, Object.keys(e[n]).forEach((r) => {
			t[n][r] = { ...e[n][r] };
		});
	}), t;
};
var Ei = (e, t, n = !1) => e.fill !== t.fill || e.stroke !== t.stroke || e.strokeWidth !== t.strokeWidth || e.fontSize !== t.fontSize || e.fontFamily !== t.fontFamily || e.fontWeight !== t.fontWeight || e.fontStyle !== t.fontStyle || e.textDecorationThickness !== t.textDecorationThickness || e.textDecorationColor !== t.textDecorationColor || e.textBackgroundColor !== t.textBackgroundColor || e.deltaY !== t.deltaY || n && (e.overline !== t.overline || e.underline !== t.underline || e.linethrough !== t.linethrough);
var Di = (e, t) => {
	let n = t.split(`
`), r = [], i = -1, a = {};
	e = Ti(e);
	for (let t = 0; t < n.length; t++) {
		let o = gt(n[t]);
		if (e[t]) for (let n = 0; n < o.length; n++) {
			i++;
			let o = e[t][n];
			o && Object.keys(o).length > 0 && (Ei(a, o, !0) ? r.push({
				start: i,
				end: i + 1,
				style: o
			}) : r[r.length - 1].end++), a = o || {};
		}
		else i += o.length, a = {};
	}
	return r;
};
var Oi = (e, t) => {
	if (!Array.isArray(e)) return Ti(e);
	let n = t.split(ne), r = {}, i = -1, a = 0;
	for (let t = 0; t < n.length; t++) {
		let o = gt(n[t]);
		for (let n = 0; n < o.length; n++) i++, e[a] && e[a].start <= i && i < e[a].end && (r[t] = r[t] || {}, r[t][n] = { ...e[a].style }, i === e[a].end - 1 && a++);
	}
	return r;
};
var ki = [
	`display`,
	`transform`,
	j,
	`fill-opacity`,
	`fill-rule`,
	`opacity`,
	he,
	`stroke-dasharray`,
	`stroke-linecap`,
	`stroke-dashoffset`,
	`stroke-linejoin`,
	`stroke-miterlimit`,
	`stroke-opacity`,
	`stroke-width`,
	`id`,
	`paint-order`,
	`vector-effect`,
	`instantiated_by_use`,
	`clip-path`
];
function Ai(e, t) {
	let n = e.nodeName, r = e.getAttribute(`class`), i = e.getAttribute(`id`), a = `(?![a-zA-Z\\-]+)`, o;
	if (o = RegExp(`^` + n, `i`), t = t.replace(o, ``), i && t.length && (o = RegExp(`#` + i + a, `i`), t = t.replace(o, ``)), r && t.length) {
		let e = r.split(` `);
		for (let n = e.length; n--;) o = RegExp(`\\.` + e[n] + a, `i`), t = t.replace(o, ``);
	}
	return t.length === 0;
}
function ji(e, t) {
	let n = !0, r = Ai(e, t.pop());
	return r && t.length && (n = function(e, t) {
		let n, r = !0;
		for (; e.parentElement && e.parentElement.nodeType === 1 && t.length;) r && (n = t.pop()), r = Ai(e = e.parentElement, n);
		return t.length === 0;
	}(e, t)), r && n && t.length === 0;
}
function Mi(e, t = {}) {
	let n = {};
	for (let r in t) ji(e, r.split(` `)) && (n = {
		...n,
		...t[r]
	});
	return n;
}
var Ni = (e) => {
	var t;
	return (t = jn[e]) == null ? e : t;
};
var Pi = RegExp(`(${Dn})`, `gi`);
var Y = `(${Dn})`;
var Fi = String.raw`(skewX)\(${Y}\)`;
var Ii = String.raw`(skewY)\(${Y}\)`;
var Li = String.raw`(rotate)\(${Y}(?: ${Y} ${Y})?\)`;
var Ri = String.raw`(scale)\(${Y}(?: ${Y})?\)`;
var zi = String.raw`(translate)\(${Y}(?: ${Y})?\)`;
var Bi = `(?:${String.raw`(matrix)\(${Y} ${Y} ${Y} ${Y} ${Y} ${Y}\)`}|${zi}|${Li}|${Ri}|${Fi}|${Ii})`;
var Vi = `(?:${Bi}*)`;
var Hi = String.raw`^\s*(?:${Vi}?)\s*$`;
var Ui = new RegExp(Hi);
var Wi = new RegExp(Bi);
var Gi = new RegExp(Bi, `g`);
function Ki(e) {
	let t = [];
	if (!(e = ((e) => on(e.replace(Pi, ` $1 `).replace(/,/gi, ` `)))(e).replace(/\s*([()])\s*/gi, `$1`)) || e && !Ui.test(e)) return [...T];
	for (let n of e.matchAll(Gi)) {
		let e = Wi.exec(n[0]);
		if (!e) continue;
		let r = T, [, i, ...a] = e.filter((e) => !!e), [o, s, c, l, u, d] = a.map((e) => parseFloat(e));
		switch (i) {
			case `translate`:
				r = Ue(o, s);
				break;
			case oe:
				r = We({ angle: o }, {
					x: s,
					y: c
				});
				break;
			case ue:
				r = Ge(o, s);
				break;
			case pe:
				r = qe(o);
				break;
			case me:
				r = Je(o);
				break;
			case `matrix`: r = [
				o,
				s,
				c,
				l,
				u,
				d
			];
		}
		t.push(r);
	}
	return Re(t);
}
function qi(e, t, n, r) {
	let i = Array.isArray(t), a, o = t;
	if (e !== `fill` && e !== `stroke` || t !== `none`) {
		if (e === `strokeUniform`) return t === `non-scaling-stroke`;
		if (e === `strokeDashArray`) o = t === `none` ? null : t.replace(/,/g, ` `).split(/\s+/).map(parseFloat);
		else if (e === `transformMatrix`) o = n && n.transformMatrix ? z(n.transformMatrix, Ki(t)) : Ki(t);
		else if (e === `visible`) o = t !== `none` && t !== `hidden`, n && !1 === n.visible && (o = !1);
		else if (e === `opacity`) o = parseFloat(t), n && n.opacity !== void 0 && (o *= n.opacity);
		else if (e === `textAnchor`) o = t === `start` ? D : t === `end` ? k : E;
		else if (e === `charSpacing` || e === `textDecorationThickness`) a = K(t, r) / r * 1e3;
		else if (e === `paintFirst`) {
			let e = t.indexOf(j), n = t.indexOf(he);
			o = j, (e > -1 && n > -1 && n < e || e === -1 && n > -1) && (o = he);
		} else {
			if (e === `href` || e === `xlink:href` || e === `font` || e === `id`) return t;
			if (e === `imageSmoothing`) return t === `optimizeQuality`;
			a = i ? t.map(K) : K(t, r);
		}
	} else o = ``;
	return !i && isNaN(a) ? o : a;
}
function Ji(e, t) {
	e.replace(/;\s*$/, ``).split(`;`).forEach((e) => {
		if (!e) return;
		let [n, r] = e.split(`:`);
		t[n.trim().toLowerCase()] = r.trim();
	});
}
function Yi(e) {
	let t = {}, n = e.getAttribute(`style`);
	return n && (typeof n == `string` ? Ji(n, t) : function(e, t) {
		Object.entries(e).forEach(([e, n]) => {
			n !== void 0 && (t[e.toLowerCase()] = n);
		});
	}(n, t)), t;
}
var Xi = {
	stroke: `strokeOpacity`,
	fill: `fillOpacity`
};
function Zi(e, t, n) {
	if (!e) return {};
	let r, i = {}, a = 16;
	e.parentNode && In.test(e.parentNode.nodeName) && (i = Zi(e.parentElement, t, n), i.fontSize && (r = a = K(i.fontSize)));
	let o = {
		...t.reduce((t, n) => {
			let r = e.getAttribute(n);
			return r && (t[n] = r), t;
		}, {}),
		...Mi(e, n),
		...Yi(e)
	};
	o[`clip-path`] && e.setAttribute(Nn, o[Nn]), o[`font-size`] && (r = K(o[Mn], a), o[Mn] = `${r}`);
	let s = {};
	for (let e in o) {
		let t = Ni(e);
		s[t] = qi(t, o[e], i, r);
	}
	s && s.font && function(e, t) {
		let n = e.match(An);
		if (!n) return;
		let r = n[1], i = n[3], a = n[4], o = n[5], s = n[6];
		r && (t.fontStyle = r), i && (t.fontWeight = isNaN(parseFloat(i)) ? i : parseFloat(i)), a && (t.fontSize = K(a)), s && (t.fontFamily = s), o && (t.lineHeight = o === `normal` ? 1 : o);
	}(s.font, s);
	let c = {
		...i,
		...s
	};
	return In.test(e.nodeName) ? c : function(e) {
		let t = J.getDefaults();
		return Object.entries(Xi).forEach(([n, r]) => {
			if (e[r] === void 0 || e[n] === ``) return;
			if (e[n] === void 0) {
				if (!t[n]) return;
				e[n] = t[n];
			}
			if (e[n].indexOf(`url(`) === 0) return;
			let i = new G(e[n]);
			e[n] = i.setAlpha(B(i.getAlpha() * e[r], 2)).toRgba();
		}), e;
	}(c);
}
var Qi = [`rx`, `ry`];
var $i = class e extends J {
	static getDefaults() {
		return {
			...super.getDefaults(),
			...e.ownDefaults
		};
	}
	constructor(t) {
		super(), Object.assign(this, e.ownDefaults), this.setOptions(t), this._initRxRy();
	}
	_initRxRy() {
		let { rx: e, ry: t } = this;
		e && !t ? this.ry = e : t && !e && (this.rx = t);
	}
	_render(e) {
		let { width: t, height: n } = this, r = -t / 2, i = -n / 2, a = this.rx ? Math.min(this.rx, t / 2) : 0, o = this.ry ? Math.min(this.ry, n / 2) : 0, s = a !== 0 || o !== 0;
		e.beginPath(), e.moveTo(r + a, i), e.lineTo(r + t - a, i), s && e.bezierCurveTo(r + t - .4477152502 * a, i, r + t, i + .4477152502 * o, r + t, i + o), e.lineTo(r + t, i + n - o), s && e.bezierCurveTo(r + t, i + n - .4477152502 * o, r + t - .4477152502 * a, i + n, r + t - a, i + n), e.lineTo(r + a, i + n), s && e.bezierCurveTo(r + .4477152502 * a, i + n, r, i + n - .4477152502 * o, r, i + n - o), e.lineTo(r, i + o), s && e.bezierCurveTo(r, i + .4477152502 * o, r + .4477152502 * a, i, r + a, i), e.closePath(), this._renderPaintInOrder(e);
	}
	toObject(e = []) {
		return super.toObject([...Qi, ...e]);
	}
	_toSVG() {
		let { width: e, height: t, rx: n, ry: r } = this;
		return [
			`<rect `,
			`COMMON_PARTS`,
			`x="${-e / 2}" y="${-t / 2}" rx="${U(n)}" ry="${U(r)}" width="${U(e)}" height="${U(t)}" />\n`
		];
	}
	static async fromElement(e, t, n) {
		let { left: r = 0, top: i = 0, width: a = 0, height: o = 0, visible: s = !0, ...c } = Zi(e, this.ATTRIBUTE_NAMES, n);
		return new this({
			...t,
			...c,
			left: r,
			top: i,
			width: a,
			height: o,
			visible: !!(s && a && o)
		});
	}
};
i($i, `type`, `Rect`), i($i, `cacheProperties`, [...Un, ...Qi]), i($i, `ownDefaults`, {
	rx: 0,
	ry: 0
}), i($i, `ATTRIBUTE_NAMES`, [
	...ki,
	`x`,
	`y`,
	`rx`,
	`ry`,
	`width`,
	`height`
]), M.setClass($i), M.setSVGClass($i);
var ea = `initialization`;
var ta = `added`;
var na = (e, t) => {
	let { strokeUniform: n, strokeWidth: r, width: i, height: a, group: o } = t, s = o && o !== e ? jt(o.calcTransformMatrix(), e.calcTransformMatrix()) : null, c = s ? t.getRelativeCenterPoint().transform(s) : t.getRelativeCenterPoint(), l = !t.isStrokeAccountedForInDimensions(), u = n && l ? Nt(new N(r, r), void 0, e.calcTransformMatrix()) : we, d = !n && l ? r : 0, f = At(i + d, a + d, Re([s, t.calcOwnMatrix()], !0)).add(u).scalarDivide(2);
	return [c.subtract(f), c.add(f)];
};
var ra = class {
	calcLayoutResult(e, t) {
		if (this.shouldPerformLayout(e)) return this.calcBoundingBox(t, e);
	}
	shouldPerformLayout({ type: e, prevStrategy: t, strategy: n }) {
		return e === `initialization` || e === `imperative` || !!t && n !== t;
	}
	shouldLayoutClipPath({ type: e, target: { clipPath: t } }) {
		return e !== `initialization` && t && !t.absolutePositioned;
	}
	getInitialSize(e, t) {
		return t.size;
	}
	calcBoundingBox(e, t) {
		let { type: n, target: r } = t;
		if (n === `imperative` && t.overrides) return t.overrides;
		if (e.length === 0) return;
		let { left: i, top: a, width: o, height: s } = wt(e.map((e) => na(r, e)).reduce((e, t) => e.concat(t), [])), c = new N(o, s), l = new N(i, a).add(c.scalarDivide(2));
		if (n === `initialization`) {
			let e = this.getInitialSize(t, {
				size: c,
				center: l
			});
			return {
				center: l,
				relativeCorrection: new N(0, 0),
				size: e
			};
		}
		return {
			center: l.transform(r.calcOwnMatrix()),
			size: c
		};
	}
};
i(ra, `type`, `strategy`);
var ia = class extends ra {
	shouldPerformLayout(e) {
		return !0;
	}
};
i(ia, `type`, `fit-content`), M.setClass(ia);
var aa = `layoutManager`;
var oa = class {
	constructor(e = new ia()) {
		i(this, `strategy`, void 0), this.strategy = e, this._subscriptions = /* @__PURE__ */ new Map();
	}
	performLayout(e) {
		let t = {
			bubbles: !0,
			strategy: this.strategy,
			...e,
			prevStrategy: this._prevLayoutStrategy,
			stopPropagation() {
				this.bubbles = !1;
			}
		};
		this.onBeforeLayout(t);
		let n = this.getLayoutResult(t);
		n && this.commitLayout(t, n), this.onAfterLayout(t, n), this._prevLayoutStrategy = t.strategy;
	}
	attachHandlers(e, t) {
		let { target: n } = t;
		return [
			ge,
			re,
			se,
			ae,
			ie,
			A,
			le,
			ce,
			`modifyPath`
		].map((t) => e.on(t, (e) => this.performLayout(t === `modified` ? {
			type: `object_modified`,
			trigger: t,
			e,
			target: n
		} : {
			type: `object_modifying`,
			trigger: t,
			e,
			target: n
		})));
	}
	subscribe(e, t) {
		this.unsubscribe(e, t);
		let n = this.attachHandlers(e, t);
		this._subscriptions.set(e, n);
	}
	unsubscribe(e, t) {
		(this._subscriptions.get(e) || []).forEach((e) => e()), this._subscriptions.delete(e);
	}
	unsubscribeTargets(e) {
		e.targets.forEach((t) => this.unsubscribe(t, e));
	}
	subscribeTargets(e) {
		e.targets.forEach((t) => this.subscribe(t, e));
	}
	onBeforeLayout(e) {
		let { target: t, type: n } = e, { canvas: r } = t;
		if (n === `initialization` || n === `added` ? this.subscribeTargets(e) : n === `removed` && this.unsubscribeTargets(e), t.fire(`layout:before`, { context: e }), r && r.fire(`object:layout:before`, {
			target: t,
			context: e
		}), n === `imperative` && e.deep) {
			let { strategy: n, ...r } = e;
			t.forEachObject((e) => e.layoutManager && e.layoutManager.performLayout({
				...r,
				bubbles: !1,
				target: e
			}));
		}
	}
	getLayoutResult(e) {
		let { target: t, strategy: n, type: r } = e, i = n.calcLayoutResult(e, t.getObjects());
		if (!i) return;
		let a = r === `initialization` ? new N() : t.getRelativeCenterPoint(), { center: o, correction: s = new N(), relativeCorrection: c = new N() } = i;
		return {
			result: i,
			prevCenter: a,
			nextCenter: o,
			offset: a.subtract(o).add(s).transform(r === `initialization` ? T : R(t.calcOwnMatrix()), !0).add(c)
		};
	}
	commitLayout(e, t) {
		let { target: n } = e, { result: { size: r }, nextCenter: i } = t;
		var a, o;
		n.set({
			width: r.x,
			height: r.y
		}), this.layoutObjects(e, t), e.type === `initialization` ? n.set({
			left: (a = e.x) == null ? i.x + r.x * W(n.originX) : a,
			top: (o = e.y) == null ? i.y + r.y * W(n.originY) : o
		}) : (n.setPositionByOrigin(i, E, E), n.setCoords(), n.set(`dirty`, !0));
	}
	layoutObjects(e, t) {
		let { target: n } = e;
		n.forEachObject((r) => {
			r.group === n && this.layoutObject(e, t, r);
		}), e.strategy.shouldLayoutClipPath(e) && this.layoutObject(e, t, n.clipPath);
	}
	layoutObject(e, { offset: t }, n) {
		n.set({
			left: n.left + t.x,
			top: n.top + t.y
		});
	}
	onAfterLayout(e, t) {
		let { target: n, strategy: r, bubbles: i, prevStrategy: a, ...o } = e, { canvas: s } = n;
		n.fire(`layout:after`, {
			context: e,
			result: t
		}), s && s.fire(`object:layout:after`, {
			context: e,
			result: t,
			target: n
		});
		let c = n.parent;
		i && c != null && c.layoutManager && ((o.path || (o.path = [])).push(n), c.layoutManager.performLayout({
			...o,
			target: c
		})), n.set(`dirty`, !0);
	}
	dispose() {
		let { _subscriptions: e } = this;
		e.forEach((e) => e.forEach((e) => e())), e.clear();
	}
	toObject() {
		return {
			type: aa,
			strategy: this.strategy.constructor.type
		};
	}
	toJSON() {
		return this.toObject();
	}
};
M.setClass(oa, aa);
var sa = class extends oa {
	performLayout() {}
};
var ca = class e extends Ee(J) {
	static getDefaults() {
		return {
			...super.getDefaults(),
			...e.ownDefaults
		};
	}
	constructor(t = [], n = {}) {
		super(), i(this, `_activeObjects`, []), i(this, `__objectSelectionTracker`, void 0), i(this, `__objectSelectionDisposer`, void 0), Object.assign(this, e.ownDefaults), this.setOptions(n), this.groupInit(t, n);
	}
	groupInit(e, t) {
		var n;
		this._objects = [...e], this.__objectSelectionTracker = this.__objectSelectionMonitor.bind(this, !0), this.__objectSelectionDisposer = this.__objectSelectionMonitor.bind(this, !1), this.forEachObject((e) => {
			this.enterGroup(e, !1);
		}), this.layoutManager = (n = t.layoutManager) == null ? new oa() : n, this.layoutManager.performLayout({
			type: ea,
			target: this,
			targets: [...e],
			x: t.left,
			y: t.top
		});
	}
	canEnterGroup(e) {
		return e === this || this.isDescendantOf(e) ? (s(`error`, `Group: circular object trees are not supported, this call has no effect`), !1) : this._objects.indexOf(e) === -1 || (s(`error`, `Group: duplicate objects are not supported inside group, this call has no effect`), !1);
	}
	_filterObjectsBeforeEnteringGroup(e) {
		return e.filter((e, t, n) => this.canEnterGroup(e) && n.indexOf(e) === t);
	}
	add(...e) {
		let t = this._filterObjectsBeforeEnteringGroup(e), n = super.add(...t);
		return this._onAfterObjectsChange(ta, t), n;
	}
	insertAt(e, ...t) {
		let n = this._filterObjectsBeforeEnteringGroup(t), r = super.insertAt(e, ...n);
		return this._onAfterObjectsChange(ta, n), r;
	}
	remove(...e) {
		let t = super.remove(...e);
		return this._onAfterObjectsChange(`removed`, t), t;
	}
	_onObjectAdded(e) {
		this.enterGroup(e, !0), this.fire(`object:added`, { target: e }), e.fire(`added`, { target: this });
	}
	_onObjectRemoved(e, t) {
		this.exitGroup(e, t), this.fire(`object:removed`, { target: e }), e.fire(`removed`, { target: this });
	}
	_onAfterObjectsChange(e, t) {
		this.layoutManager.performLayout({
			type: e,
			targets: t,
			target: this
		});
	}
	_onStackOrderChanged() {
		this._set(`dirty`, !0);
	}
	_set(e, t) {
		let n = this[e];
		return super._set(e, t), e === `canvas` && n !== t && (this._objects || []).forEach((n) => {
			n._set(e, t);
		}), this;
	}
	_shouldSetNestedCoords() {
		return this.subTargetCheck;
	}
	removeAll() {
		return this._activeObjects = [], this.remove(...this._objects);
	}
	__objectSelectionMonitor(e, { target: t }) {
		let n = this._activeObjects;
		if (e) n.push(t), this._set(`dirty`, !0);
		else if (n.length > 0) {
			let e = n.indexOf(t);
			e > -1 && (n.splice(e, 1), this._set(`dirty`, !0));
		}
	}
	_watchObject(e, t) {
		e && this._watchObject(!1, t), e ? (t.on(`selected`, this.__objectSelectionTracker), t.on(`deselected`, this.__objectSelectionDisposer)) : (t.off(`selected`, this.__objectSelectionTracker), t.off(`deselected`, this.__objectSelectionDisposer));
	}
	enterGroup(e, t) {
		e.group && e.group.remove(e), e._set(`parent`, this), this._enterGroup(e, t);
	}
	_enterGroup(e, t) {
		t && Dt(e, z(R(this.calcTransformMatrix()), e.calcTransformMatrix())), this._shouldSetNestedCoords() && e.setCoords(), e._set(`group`, this), e._set(`canvas`, this.canvas), this._watchObject(!0, e);
		let n = this.canvas && this.canvas.getActiveObject && this.canvas.getActiveObject();
		n && (n === e || e.isDescendantOf(n)) && this._activeObjects.push(e);
	}
	exitGroup(e, t) {
		this._exitGroup(e, t), e._set(`parent`, void 0), e._set(`canvas`, void 0);
	}
	_exitGroup(e, t) {
		e._set(`group`, void 0), t || (Dt(e, z(this.calcTransformMatrix(), e.calcTransformMatrix())), e.setCoords()), this._watchObject(!1, e);
		let n = this._activeObjects.length > 0 ? this._activeObjects.indexOf(e) : -1;
		n > -1 && this._activeObjects.splice(n, 1);
	}
	shouldCache() {
		let e = J.prototype.shouldCache.call(this);
		if (e) {
			for (let e = 0; e < this._objects.length; e++) if (this._objects[e].willDrawShadow()) return this.ownCaching = !1, !1;
		}
		return e;
	}
	willDrawShadow() {
		if (super.willDrawShadow()) return !0;
		for (let e = 0; e < this._objects.length; e++) if (this._objects[e].willDrawShadow()) return !0;
		return !1;
	}
	isOnACache() {
		return this.ownCaching || !!this.parent && this.parent.isOnACache();
	}
	drawObject(e, t, n) {
		this._renderBackground(e);
		for (let t = 0; t < this._objects.length; t++) {
			var r;
			let n = this._objects[t];
			(r = this.canvas) != null && r.preserveObjectStacking && n.group !== this ? (e.save(), e.transform(...R(this.calcTransformMatrix())), n.render(e), e.restore()) : n.group === this && n.render(e);
		}
		this._drawClipPath(e, this.clipPath, n);
	}
	setCoords() {
		super.setCoords(), this._shouldSetNestedCoords() && this.forEachObject((e) => e.setCoords());
	}
	triggerLayout(e = {}) {
		this.layoutManager.performLayout({
			target: this,
			type: `imperative`,
			...e
		});
	}
	render(e) {
		this._transformDone = !0, super.render(e), this._transformDone = !1;
	}
	__serializeObjects(e, t) {
		let n = this.includeDefaultValues;
		return this._objects.filter(function(e) {
			return !e.excludeFromExport;
		}).map(function(r) {
			let i = r.includeDefaultValues;
			r.includeDefaultValues = n;
			let a = r[e || `toObject`](t);
			return r.includeDefaultValues = i, a;
		});
	}
	toObject(e = []) {
		let t = this.layoutManager.toObject();
		return {
			...super.toObject([
				`subTargetCheck`,
				`interactive`,
				...e
			]),
			...t.strategy !== `fit-content` || this.includeDefaultValues ? { layoutManager: t } : {},
			objects: this.__serializeObjects(`toObject`, e)
		};
	}
	toString() {
		return `#<Group: (${this.complexity()})>`;
	}
	dispose() {
		this.layoutManager.unsubscribeTargets({
			targets: this.getObjects(),
			target: this
		}), this._activeObjects = [], this.forEachObject((e) => {
			this._watchObject(!1, e), e.dispose();
		}), super.dispose();
	}
	_createSVGBgRect(e) {
		if (!this.backgroundColor) return ``;
		let t = $i.prototype._toSVG.call(this), n = t.indexOf(`COMMON_PARTS`);
		t[n] = `for="group" `;
		let r = t.join(``);
		return e ? e(r) : r;
	}
	_toSVG(e) {
		let t = [
			`<g `,
			`COMMON_PARTS`,
			` >
`
		], n = this._createSVGBgRect(e);
		n && t.push(`		`, n);
		for (let n = 0; n < this._objects.length; n++) t.push(`		`, this._objects[n].toSVG(e));
		return t.push(`</g>
`), t;
	}
	getSvgStyles() {
		let e = this.opacity !== void 0 && this.opacity !== 1 ? `opacity: ${U(this.opacity)};` : ``, t = this.visible ? `` : ` visibility: hidden;`;
		return [
			e,
			this.getSvgFilter(),
			t
		].join(``);
	}
	toClipPathSVG(e) {
		let t = [], n = this._createSVGBgRect(e);
		n && t.push(`	`, n);
		for (let n = 0; n < this._objects.length; n++) t.push(`	`, this._objects[n].toClipPathSVG(e));
		return this._createBaseClipPathSVGMarkup(t, { reviver: e });
	}
	static fromObject({ type: e, objects: t = [], layoutManager: n, ...r }, i) {
		return Promise.all([Qe(t, i), $e(r, i)]).then(([e, t]) => {
			let i = new this(e, {
				...r,
				...t,
				layoutManager: new sa()
			});
			return i.layoutManager = n ? new (M.getClass(n.type))(new (M.getClass(n.strategy))()) : new oa(), i.layoutManager.subscribeTargets({
				type: ea,
				target: i,
				targets: i.getObjects()
			}), i.setCoords(), i;
		});
	}
};
i(ca, `type`, `Group`), i(ca, `ownDefaults`, {
	strokeWidth: 0,
	subTargetCheck: !1,
	interactive: !1
}), M.setClass(ca);
var la = (e, t) => e && e.length === 1 ? e[0] : new ca(e, t);
var ua = (e, t) => Math.min(t.width / e.width, t.height / e.height);
var da = (e, t) => Math.max(t.width / e.width, t.height / e.height);
var fa = `\\s*,?\\s*`;
var pa = `${fa}(${Dn})`;
var ma = `${pa}${pa}${pa}${fa}([01])${fa}([01])${pa}${pa}`;
var ha = {
	m: `l`,
	M: `L`
};
var ga = (e, t, n, r, i, a, o, s, c, l, u) => {
	let d = Se(e), f = Ce(e), p = Se(t), m = Ce(t), h = n * i * p - r * a * m + o, g = r * i * p + n * a * m + s;
	return [
		`C`,
		l + c * (-n * i * f - r * a * d),
		u + c * (-r * i * f + n * a * d),
		h + c * (n * i * m + r * a * p),
		g + c * (r * i * m - n * a * p),
		h,
		g
	];
};
var _a = (e, t, n, r) => {
	let i = Math.atan2(t, e), a = Math.atan2(r, n);
	return a >= i ? a - i : 2 * Math.PI - (i - a);
};
function va(e, t, n, r, i, a, s, c) {
	let l;
	if (o.cachesBoundsOfCurve && (l = [...arguments].join(), y.boundsOfCurveCache[l])) return y.boundsOfCurveCache[l];
	let u = Math.sqrt, d = Math.abs, f = [], p = [[0, 0], [0, 0]], m = 6 * e - 12 * n + 6 * i, h = -3 * e + 9 * n - 9 * i + 3 * s, g = 3 * n - 3 * e;
	for (let e = 0; e < 2; ++e) {
		if (e > 0 && (m = 6 * t - 12 * r + 6 * a, h = -3 * t + 9 * r - 9 * a + 3 * c, g = 3 * r - 3 * t), d(h) < 1e-12) {
			if (d(m) < 1e-12) continue;
			let e = -g / m;
			0 < e && e < 1 && f.push(e);
			continue;
		}
		let n = m * m - 4 * g * h;
		if (n < 0) continue;
		let i = u(n), o = (-m + i) / (2 * h);
		0 < o && o < 1 && f.push(o);
		let s = (-m - i) / (2 * h);
		0 < s && s < 1 && f.push(s);
	}
	let _ = f.length, v = _, b = Sa(e, t, n, r, i, a, s, c);
	for (; _--;) {
		let { x: e, y: t } = b(f[_]);
		p[0][_] = e, p[1][_] = t;
	}
	p[0][v] = e, p[1][v] = t, p[0][v + 1] = s, p[1][v + 1] = c;
	let x = [new N(Math.min(...p[0]), Math.min(...p[1])), new N(Math.max(...p[0]), Math.max(...p[1]))];
	return o.cachesBoundsOfCurve && (y.boundsOfCurveCache[l] = x), x;
}
var ya = (e, t, [n, r, i, a, o, s, c, l]) => {
	let u = ((e, t, n, r, i, a, o) => {
		if (n === 0 || r === 0) return [];
		let s = 0, c = 0, l = 0, u = Math.PI, d = o * ee, f = Ce(d), p = Se(d), m = .5 * (-p * e - f * t), h = .5 * (-p * t + f * e), g = n ** 2, _ = r ** 2, v = h ** 2, y = m ** 2, b = g * _ - g * v - _ * y, x = Math.abs(n), S = Math.abs(r);
		if (b < 0) {
			let e = Math.sqrt(1 - b / (g * _));
			x *= e, S *= e;
		} else l = (i === a ? -1 : 1) * Math.sqrt(b / (g * v + _ * y));
		let C = l * x * h / S, w = -l * S * m / x, T = p * C - f * w + .5 * e, E = f * C + p * w + .5 * t, D = _a(1, 0, (m - C) / x, (h - w) / S), O = _a((m - C) / x, (h - w) / S, (-m - C) / x, (-h - w) / S);
		a === 0 && O > 0 ? O -= 2 * u : a === 1 && O < 0 && (O += 2 * u);
		let k = Math.ceil(Math.abs(O / u * 2)), te = [], ne = O / k, re = 8 / 3 * Math.sin(ne / 4) * Math.sin(ne / 4) / Math.sin(ne / 2), ie = D + ne;
		for (let e = 0; e < k; e++) te[e] = ga(D, ie, p, f, x, S, T, E, re, s, c), s = te[e][5], c = te[e][6], D = ie, ie += ne;
		return te;
	})(c - e, l - t, r, i, o, s, a);
	for (let n = 0, r = u.length; n < r; n++) u[n][1] += e, u[n][2] += t, u[n][3] += e, u[n][4] += t, u[n][5] += e, u[n][6] += t;
	return u;
};
var ba = (e) => {
	let t = 0, n = 0, r = 0, i = 0, a = [], o, s = 0, c = 0;
	for (let l of e) {
		let e = [...l], u;
		switch (e[0]) {
			case `l`: e[1] += t, e[2] += n;
			case `L`:
				t = e[1], n = e[2], u = [
					`L`,
					t,
					n
				];
				break;
			case `h`: e[1] += t;
			case `H`:
				t = e[1], u = [
					`L`,
					t,
					n
				];
				break;
			case `v`: e[1] += n;
			case `V`:
				n = e[1], u = [
					`L`,
					t,
					n
				];
				break;
			case `m`: e[1] += t, e[2] += n;
			case `M`:
				t = e[1], n = e[2], r = e[1], i = e[2], u = [
					`M`,
					t,
					n
				];
				break;
			case `c`: e[1] += t, e[2] += n, e[3] += t, e[4] += n, e[5] += t, e[6] += n;
			case `C`:
				s = e[3], c = e[4], t = e[5], n = e[6], u = [
					`C`,
					e[1],
					e[2],
					s,
					c,
					t,
					n
				];
				break;
			case `s`: e[1] += t, e[2] += n, e[3] += t, e[4] += n;
			case `S`:
				o === `C` ? (s = 2 * t - s, c = 2 * n - c) : (s = t, c = n), t = e[3], n = e[4], u = [
					`C`,
					s,
					c,
					e[1],
					e[2],
					t,
					n
				], s = u[3], c = u[4];
				break;
			case `q`: e[1] += t, e[2] += n, e[3] += t, e[4] += n;
			case `Q`:
				s = e[1], c = e[2], t = e[3], n = e[4], u = [
					`Q`,
					s,
					c,
					t,
					n
				];
				break;
			case `t`: e[1] += t, e[2] += n;
			case `T`:
				o === `Q` ? (s = 2 * t - s, c = 2 * n - c) : (s = t, c = n), t = e[1], n = e[2], u = [
					`Q`,
					s,
					c,
					t,
					n
				];
				break;
			case `a`: e[6] += t, e[7] += n;
			case `A`:
				ya(t, n, e).forEach((e) => a.push(e)), t = e[6], n = e[7];
				break;
			case `z`:
			case `Z`: t = r, n = i, u = [`Z`];
		}
		u ? (a.push(u), o = u[0]) : o = ``;
	}
	return a;
};
var xa = (e, t, n, r) => Math.sqrt((n - e) ** 2 + (r - t) ** 2);
var Sa = (e, t, n, r, i, a, o, s) => (c) => {
	let l = c ** 3, u = ((e) => 3 * e ** 2 * (1 - e))(c), d = ((e) => 3 * e * (1 - e) ** 2)(c), f = ((e) => (1 - e) ** 3)(c);
	return new N(o * l + i * u + n * d + e * f, s * l + a * u + r * d + t * f);
};
var Ca = (e) => e ** 2;
var wa = (e) => 2 * e * (1 - e);
var Ta = (e) => (1 - e) ** 2;
var Ea = (e, t, n, r, i, a, o, s) => (c) => {
	let l = Ca(c), u = wa(c), d = Ta(c), f = 3 * (d * (n - e) + u * (i - n) + l * (o - i)), p = 3 * (d * (r - t) + u * (a - r) + l * (s - a));
	return Math.atan2(p, f);
};
var Da = (e, t, n, r, i, a) => (o) => {
	let s = Ca(o), c = wa(o), l = Ta(o);
	return new N(i * s + n * c + e * l, a * s + r * c + t * l);
};
var Oa = (e, t, n, r, i, a) => (o) => {
	let s = 1 - o, c = 2 * (s * (n - e) + o * (i - n)), l = 2 * (s * (r - t) + o * (a - r));
	return Math.atan2(l, c);
};
var ka = (e, t, n) => {
	let r = new N(t, n), i = 0;
	for (let t = 1; t <= 100; t += 1) {
		let n = e(t / 100);
		i += xa(r.x, r.y, n.x, n.y), r = n;
	}
	return i;
};
var Aa = (e, t) => {
	let n, r = 0, i = 0, a = {
		x: e.x,
		y: e.y
	}, o = { ...a }, s = .01, c = 0, l = e.iterator, u = e.angleFinder;
	for (; i < t && s > 1e-4;) o = l(r), c = r, n = xa(a.x, a.y, o.x, o.y), n + i > t ? (r -= s, s /= 2) : (a = o, r += s, i += n);
	return {
		...o,
		angle: u(c)
	};
};
var ja = (e) => {
	let t, n, r = 0, i = 0, a = 0, o = 0, s = 0, c = [];
	for (let l of e) {
		let e = {
			x: i,
			y: a,
			command: l[0],
			length: 0
		};
		switch (l[0]) {
			case `M`:
				n = e, n.x = o = i = l[1], n.y = s = a = l[2];
				break;
			case `L`:
				n = e, n.length = xa(i, a, l[1], l[2]), i = l[1], a = l[2];
				break;
			case `C`:
				t = Sa(i, a, l[1], l[2], l[3], l[4], l[5], l[6]), n = e, n.iterator = t, n.angleFinder = Ea(i, a, l[1], l[2], l[3], l[4], l[5], l[6]), n.length = ka(t, i, a), i = l[5], a = l[6];
				break;
			case `Q`:
				t = Da(i, a, l[1], l[2], l[3], l[4]), n = e, n.iterator = t, n.angleFinder = Oa(i, a, l[1], l[2], l[3], l[4]), n.length = ka(t, i, a), i = l[3], a = l[4];
				break;
			case `Z`: n = e, n.destX = o, n.destY = s, n.length = xa(i, a, o, s), i = o, a = s;
		}
		r += n.length, c.push(n);
	}
	return c.push({
		length: r,
		x: i,
		y: a
	}), c;
};
var Ma = (e, t, n = ja(e)) => {
	let r = 0;
	for (; t - n[r].length > 0 && r < n.length - 2;) t -= n[r].length, r++;
	let i = n[r], a = t / i.length, o = e[r];
	switch (i.command) {
		case `M`: return {
			x: i.x,
			y: i.y,
			angle: 0
		};
		case `Z`: return {
			...new N(i.x, i.y).lerp(new N(i.destX, i.destY), a),
			angle: Math.atan2(i.destY - i.y, i.destX - i.x)
		};
		case `L`: return {
			...new N(i.x, i.y).lerp(new N(o[1], o[2]), a),
			angle: Math.atan2(o[2] - i.y, o[1] - i.x)
		};
		case `C`:
		case `Q`: return Aa(i, t);
	}
};
var Na = RegExp(`[mzlhvcsqta][^mzlhvcsqta]*`, `gi`);
var Pa = new RegExp(ma, `g`);
var Fa = new RegExp(Dn, `gi`);
var Ia = {
	m: 2,
	l: 2,
	h: 1,
	v: 1,
	c: 6,
	s: 4,
	q: 4,
	t: 2,
	a: 7
};
var La = (e) => {
	var t;
	let n = [], r = (t = e.match(Na)) == null ? [] : t;
	for (let e of r) {
		let t = e[0];
		if (t === `z` || t === `Z`) {
			n.push([t]);
			continue;
		}
		let r = Ia[t.toLowerCase()], i = [];
		if (t === `a` || t === `A`) {
			let t;
			for (Pa.lastIndex = 0; t = Pa.exec(e);) i.push(...t.slice(1));
		} else i = e.match(Fa) || [];
		for (let e = 0; e < i.length; e += r) {
			let a = Array(r), o = ha[t];
			a[0] = e > 0 && o ? o : t;
			for (let t = 0; t < r; t++) a[t + 1] = parseFloat(i[e + t]);
			n.push(a);
		}
	}
	return n;
};
var Ra = (e, t = 0) => {
	let n = new N(e[0]), r = new N(e[1]), i = 1, a = 0, o = [], s = e.length, c = s > 2, l;
	for (c && (i = e[2].x < r.x ? -1 : e[2].x === r.x ? 0 : 1, a = e[2].y < r.y ? -1 : e[2].y === r.y ? 0 : 1), o.push([
		`M`,
		n.x - i * t,
		n.y - a * t
	]), l = 1; l < s; l++) {
		if (!n.eq(r)) {
			let e = n.midPointFrom(r);
			o.push([
				`Q`,
				n.x,
				n.y,
				e.x,
				e.y
			]);
		}
		n = e[l], l + 1 < e.length && (r = e[l + 1]);
	}
	return c && (i = n.x > e[l - 2].x ? 1 : n.x === e[l - 2].x ? 0 : -1, a = n.y > e[l - 2].y ? 1 : n.y === e[l - 2].y ? 0 : -1), o.push([
		`L`,
		n.x + i * t,
		n.y + a * t
	]), o;
};
var za = (e, t, n) => (n && (t = z(t, [
	1,
	0,
	0,
	1,
	-n.x,
	-n.y
])), e.map((e) => {
	let n = [...e];
	for (let r = 1; r < e.length - 1; r += 2) {
		let { x: i, y: a } = L({
			x: e[r],
			y: e[r + 1]
		}, t);
		n[r] = i, n[r + 1] = a;
	}
	return n;
}));
var Ba = (e, t) => {
	let n = 2 * Math.PI / e, r = -S;
	e % 2 == 0 && (r += n / 2);
	let i = Array(e + 1);
	for (let a = 0; a < e; a++) {
		let e = a * n + r, { x: o, y: s } = new N(Se(e), Ce(e)).scalarMultiply(t);
		i[a] = [
			a === 0 ? `M` : `L`,
			o,
			s
		];
	}
	return i[e] = [`Z`], i;
};
var Va = (e, t) => e.map((e) => e.map((e, n) => n === 0 || t === void 0 ? e : B(e, t)).join(` `)).join(` `);
var Ha = (e, t) => {
	var n;
	let r = e, i = t;
	r.inverted && !i.inverted && (r = t, i = e), Pt(i, (n = i.group) == null ? void 0 : n.calcTransformMatrix(), r.calcTransformMatrix());
	let a = r.inverted && i.inverted;
	return a && (r.inverted = i.inverted = !1), new ca([r], {
		clipPath: i,
		inverted: a
	});
};
var Ua = (e, t) => Math.floor(Math.random() * (t - e + 1)) + e;
var Wa = (e, t) => {
	let n = e._findCenterFromElement();
	e.transformMatrix && (((e) => {
		if (e.transformMatrix) {
			let { scaleX: t, scaleY: n, angle: r, skewX: i } = He(e.transformMatrix);
			e.flipX = !1, e.flipY = !1, e.set(de, t), e.set(fe, n), e.angle = r, e.skewX = i, e.skewY = 0;
		}
	})(e), n = n.transform(e.transformMatrix)), delete e.transformMatrix, t && (e.scaleX *= t.scaleX, e.scaleY *= t.scaleY, e.cropX = t.cropX, e.cropY = t.cropY, n.x += t.offsetLeft, n.y += t.offsetTop, e.width = t.width, e.height = t.height), e.setPositionByOrigin(n, E, E);
};
t({
	addTransformToObject: () => Et,
	animate: () => Mr,
	animateColor: () => Nr,
	applyTransformToObject: () => Dt,
	calcAngleBetweenVectors: () => Vt,
	calcDimensionsMatrix: () => Ye,
	calcPlaneChangeMatrix: () => jt,
	calcVectorRotation: () => Ht,
	cancelAnimFrame: () => ke,
	capValue: () => Vn,
	composeMatrix: () => Xe,
	copyCanvasElement: () => Ne,
	cos: () => Se,
	createCanvasElement: () => P,
	createImage: () => Me,
	createRotateMatrix: () => We,
	createScaleMatrix: () => Ge,
	createSkewXMatrix: () => qe,
	createSkewYMatrix: () => Je,
	createTranslateMatrix: () => Ue,
	createVector: () => zt,
	crossProduct: () => Gt,
	degreesToRadians: () => I,
	dotProduct: () => Kt,
	ease: () => Gn,
	enlivenObjectEnlivables: () => $e,
	enlivenObjects: () => Qe,
	findScaleToCover: () => da,
	findScaleToFit: () => ua,
	getBoundsOfCurve: () => va,
	getOrthonormalVector: () => Wt,
	getPathSegmentsInfo: () => ja,
	getPointOnPath: () => Ma,
	getPointer: () => xt,
	getRandomInt: () => Ua,
	getRegularPolygonPath: () => Ba,
	getSmoothPathFromPoints: () => Ra,
	getSvgAttributes: () => pn,
	getUnitVector: () => Ut,
	groupSVGElements: () => la,
	hasStyleChanged: () => Ei,
	invertTransform: () => R,
	isBetweenVectors: () => qt,
	isIdentityMatrix: () => Le,
	isTouchEvent: () => St,
	isTransparent: () => yi,
	joinPath: () => Va,
	loadImage: () => Ze,
	magnitude: () => Bt,
	makeBoundingBoxFromPoints: () => wt,
	makePathSimpler: () => ba,
	matrixToSVG: () => nt,
	mergeClipPaths: () => Ha,
	multiplyTransformMatrices: () => z,
	multiplyTransformMatrixArray: () => Re,
	parsePath: () => La,
	parsePreserveAspectRatioAttribute: () => mn,
	parseUnit: () => K,
	pick: () => et,
	projectStrokeOnPoints: () => wi,
	qrDecompose: () => He,
	radiansToDegrees: () => Ie,
	removeFromArray: () => xe,
	removeTransformFromObject: () => Tt,
	removeTransformMatrixForSvgParsing: () => Wa,
	requestAnimFrame: () => Oe,
	resetObjectTransform: () => Ot,
	rotateVector: () => Rt,
	saveObjectTransform: () => kt,
	sendObjectToPlane: () => Pt,
	sendPointToPlane: () => Mt,
	sendVectorToPlane: () => Nt,
	sin: () => Ce,
	sizeAfterTransform: () => At,
	string: () => pt,
	stylesFromArray: () => Oi,
	stylesToArray: () => Di,
	toBlob: () => Fe,
	toDataURL: () => Pe,
	toFixed: () => B,
	transformPath: () => za,
	transformPoint: () => L
});
function Ka(e, t) {
	let n = e.style;
	n && Object.entries(t).forEach(([e, t]) => n.setProperty(e, t));
}
var qa = class extends dt {
	constructor(e, { allowTouchScrolling: t = !1, containerClass: n = `` } = {}) {
		super(e), i(this, `upper`, void 0), i(this, `container`, void 0);
		let { el: r } = this.lower, a = this.createUpperCanvas();
		this.upper = {
			el: a,
			ctx: a.getContext(`2d`)
		}, this.applyCanvasStyle(r, { allowTouchScrolling: t }), this.applyCanvasStyle(a, {
			allowTouchScrolling: t,
			styles: {
				position: `absolute`,
				left: `0`,
				top: `0`
			}
		});
		let o = this.createContainerElement();
		o.classList.add(n), r.parentNode && r.parentNode.replaceChild(o, r), o.append(r, a), this.container = o;
	}
	createUpperCanvas() {
		let { el: e } = this.lower, t = P();
		return t.className = e.className, t.classList.remove(`lower-canvas`), t.classList.add(`upper-canvas`), t.setAttribute(`data-fabric`, `top`), t.style.cssText = e.style.cssText, t.setAttribute(`draggable`, `true`), t;
	}
	createContainerElement() {
		let e = g().createElement(`div`);
		return e.setAttribute(`data-fabric`, `wrapper`), Ka(e, { position: `relative` }), ut(e), e;
	}
	applyCanvasStyle(e, t) {
		let { styles: n, allowTouchScrolling: r } = t;
		Ka(e, {
			...n,
			"touch-action": r ? `manipulation` : te
		}), ut(e);
	}
	setDimensions(e, t) {
		super.setDimensions(e, t);
		let { el: n, ctx: r } = this.upper;
		ct(n, r, e, t);
	}
	setCSSDimensions(e) {
		super.setCSSDimensions(e), lt(this.upper.el, e), lt(this.container, e);
	}
	cleanupDOM(e) {
		let t = this.container, { el: n } = this.lower, { el: r } = this.upper;
		super.cleanupDOM(e), t.removeChild(r), t.removeChild(n), t.parentNode && t.parentNode.replaceChild(n, t);
	}
	dispose() {
		super.dispose(), h().dispose(this.upper.el), delete this.upper, delete this.container;
	}
};
var Ja = (e, t, n, r) => {
	let { target: i, offsetX: a, offsetY: o } = t, s = n - a, c = r - o, l = !Zt(i, `lockMovementX`) && i.left !== s, u = !Zt(i, `lockMovementY`) && i.top !== c;
	return l && i.set(`left`, s), u && i.set(`top`, c), (l || u) && Lr(re, Qt(e, t, n, r)), l || u;
};
var Ya = ce;
var Xa = (e) => function(t, n, r) {
	let { points: i, pathOffset: a } = r;
	return new N(i[e]).subtract(a).transform(z(r.getViewportTransform(), r.calcTransformMatrix()));
};
var Za = (e, t, n, r) => {
	let { target: i, pointIndex: a } = t, o = i, s = Mt(new N(n, r), void 0, o.calcOwnMatrix());
	return o.points[a] = s.add(o.pathOffset), o.setDimensions(), o.set(`dirty`, !0), !0;
};
var Qa = (e, t) => function(n, r, i, a) {
	let o = r.target, s = new N(o.points[(e > 0 ? e : o.points.length) - 1]), c = s.subtract(o.pathOffset).transform(o.calcOwnMatrix()), l = t(n, {
		...r,
		pointIndex: e
	}, i, a), u = s.subtract(o.pathOffset).transform(o.calcOwnMatrix()).subtract(c);
	return o.left -= u.x, o.top -= u.y, l;
};
var $a = (e) => Rr(Ya, Qa(e, Za));
function eo(e, t = {}) {
	let n = {};
	for (let r = 0; r < (typeof e == `number` ? e : e.points.length); r++) n[`p${r}`] = new q({
		actionName: Ya,
		positionHandler: Xa(r),
		actionHandler: $a(r),
		...t
	});
	return n;
}
var to = (e, t, n) => {
	let { path: r, pathOffset: i } = e, a = r[t];
	return new N(a[n] - i.x, a[n + 1] - i.y).transform(z(e.getViewportTransform(), e.calcTransformMatrix()));
};
function no(e, t, n) {
	let { commandIndex: r, pointIndex: i } = this;
	return to(n, r, i);
}
function ro(e, t, n, r) {
	let { target: i } = t, { commandIndex: a, pointIndex: o } = this, s = ((e, t, n, r, i) => {
		let { path: a, pathOffset: o } = e, s = a[(r > 0 ? r : a.length) - 1], c = new N(s[i], s[i + 1]), l = c.subtract(o).transform(e.calcOwnMatrix()), u = Mt(new N(t, n), void 0, e.calcOwnMatrix());
		a[r][i] = u.x + o.x, a[r][i + 1] = u.y + o.y, e.setDimensions();
		let d = c.subtract(e.pathOffset).transform(e.calcOwnMatrix()).subtract(l);
		return e.left -= d.x, e.top -= d.y, e.set(`dirty`, !0), !0;
	})(i, n, r, a, o);
	return s && Lr(this.actionName, {
		...Qt(e, t, n, r),
		commandIndex: a,
		pointIndex: o
	}), s;
}
var io = class extends q {
	constructor(e) {
		super(e);
	}
	render(e, t, n, r, i) {
		let a = {
			...r,
			cornerColor: this.controlFill,
			cornerStrokeColor: this.controlStroke,
			transparentCorners: !this.controlFill
		};
		super.render(e, t, n, a, i);
	}
};
var ao = class extends io {
	constructor(e) {
		super(e);
	}
	render(e, t, n, r, i) {
		let { path: a } = i, { commandIndex: o, pointIndex: s, connectToCommandIndex: c, connectToPointIndex: l } = this;
		e.save(), e.strokeStyle = this.controlStroke, this.connectionDashArray && e.setLineDash(this.connectionDashArray);
		let [u] = a[o], d = to(i, c, l);
		if (u === `Q`) {
			let r = to(i, o, s + 2);
			e.moveTo(r.x, r.y), e.lineTo(t, n);
		} else e.moveTo(t, n);
		e.lineTo(d.x, d.y), e.stroke(), e.restore(), super.render(e, t, n, r, i);
	}
};
var oo = (e, t, n, r, i, a) => new (n ? ao : io)({
	commandIndex: e,
	pointIndex: t,
	actionName: `modifyPath`,
	positionHandler: no,
	actionHandler: ro,
	connectToCommandIndex: i,
	connectToPointIndex: a,
	...r,
	...n ? r.controlPointStyle : r.pointStyle
});
function so(e, t = {}) {
	let n = {}, r = `M`;
	return e.path.forEach((e, i) => {
		let a = e[0];
		switch (a !== `Z` && (n[`c_${i}_${a}`] = oo(i, e.length - 2, !1, t)), a) {
			case `C`:
				n[`c_${i}_C_CP_1`] = oo(i, 1, !0, t, i - 1, ((e) => e === `C` ? 5 : e === `Q` ? 3 : 1)(r)), n[`c_${i}_C_CP_2`] = oo(i, 3, !0, t, i, 5);
				break;
			case `Q`: n[`c_${i}_Q_CP_1`] = oo(i, 1, !0, t, i, 3);
		}
		r = a;
	}), n;
}
t({
	changeHeight: () => Wr,
	changeObjectHeight: () => Hr,
	changeObjectWidth: () => Vr,
	changeWidth: () => Ur,
	createObjectDefaultControls: () => mi,
	createPathControls: () => so,
	createPolyActionHandler: () => $a,
	createPolyControls: () => eo,
	createPolyPositionHandler: () => Xa,
	createResizeControls: () => hi,
	createTextboxDefaultControls: () => gi,
	dragHandler: () => Ja,
	factoryPolyActionHandler: () => Qa,
	getLocalPoint: () => en,
	polyActionHandler: () => Za,
	renderCircleControl: () => Gr,
	renderSquareControl: () => Kr,
	rotationStyleHandler: () => qr,
	rotationWithSnapping: () => Jr,
	scaleCursorStyleHandler: () => Qr,
	scaleOrSkewActionName: () => ui,
	scaleSkewCursorStyleHandler: () => di,
	scalingEqually: () => ei,
	scalingX: () => ti,
	scalingXOrSkewingY: () => fi,
	scalingY: () => ni,
	scalingYOrSkewingX: () => pi,
	skewCursorStyleHandler: () => ai,
	skewHandlerX: () => si,
	skewHandlerY: () => ci,
	wrapWithFireEvent: () => Rr,
	wrapWithFixedAnchor: () => zr
});
var lo = class e extends yt {
	constructor(...e) {
		super(...e), i(this, `_hoveredTargets`, []), i(this, `_currentTransform`, null), i(this, `_groupSelector`, null), i(this, `contextTopDirty`, !1);
	}
	static getDefaults() {
		return {
			...super.getDefaults(),
			...e.ownDefaults
		};
	}
	get upperCanvasEl() {
		var e;
		return (e = this.elements.upper) == null ? void 0 : e.el;
	}
	get contextTop() {
		var e;
		return (e = this.elements.upper) == null ? void 0 : e.ctx;
	}
	get wrapperEl() {
		return this.elements.container;
	}
	initElements(e) {
		this.elements = new qa(e, {
			allowTouchScrolling: this.allowTouchScrolling,
			containerClass: this.containerClass
		}), this._createCacheCanvas();
	}
	_onObjectAdded(e) {
		this._objectsToRender = void 0, super._onObjectAdded(e);
	}
	_onObjectRemoved(e) {
		this._objectsToRender = void 0, e === this._activeObject && (this.fire(`before:selection:cleared`, { deselected: [e] }), this._discardActiveObject(), this.fire(`selection:cleared`, { deselected: [e] }), e.fire(`deselected`, { target: e })), e === this._hoveredTarget && (this._hoveredTarget = void 0, this._hoveredTargets = []), super._onObjectRemoved(e);
	}
	_onStackOrderChanged() {
		this._objectsToRender = void 0, super._onStackOrderChanged();
	}
	_chooseObjectsToRender() {
		let e = this._activeObject;
		return !this.preserveObjectStacking && e ? this._objects.filter((t) => !t.group && t !== e).concat(e) : this._objects;
	}
	renderAll() {
		this.cancelRequestedRender(), this.destroyed || (!this.contextTopDirty || this._groupSelector || this.isDrawingMode || (this.clearContext(this.contextTop), this.contextTopDirty = !1), this.hasLostContext && (this.renderTopLayer(this.contextTop), this.hasLostContext = !1), !this._objectsToRender && (this._objectsToRender = this._chooseObjectsToRender()), this.renderCanvas(this.getContext(), this._objectsToRender));
	}
	renderTopLayer(e) {
		e.save(), this.isDrawingMode && this._isCurrentlyDrawing && (this.freeDrawingBrush && this.freeDrawingBrush._render(), this.contextTopDirty = !0), this.selection && this._groupSelector && (this._drawSelection(e), this.contextTopDirty = !0), e.restore();
	}
	renderTop() {
		let e = this.contextTop;
		this.clearContext(e), this.renderTopLayer(e), this.fire(`after:render`, { ctx: e });
	}
	setTargetFindTolerance(e) {
		e = Math.round(e), this.targetFindTolerance = e;
		let t = this.getRetinaScaling(), n = Math.ceil((2 * e + 1) * t);
		this.pixelFindCanvasEl.width = this.pixelFindCanvasEl.height = n, this.pixelFindContext.scale(t, t);
	}
	isTargetTransparent(e, t, n) {
		let r = this.targetFindTolerance, i = this.pixelFindContext;
		this.clearContext(i), i.save(), i.translate(-t + r, -n + r), i.transform(...this.viewportTransform);
		let a = e.selectionBackgroundColor;
		e.selectionBackgroundColor = ``, e.render(i), e.selectionBackgroundColor = a, i.restore();
		let o = Math.round(r * this.getRetinaScaling());
		return yi(i, o, o, o);
	}
	_isSelectionKeyPressed(e) {
		let t = this.selectionKey;
		return !!t && (Array.isArray(t) ? !!t.find((t) => !!t && !0 === e[t]) : e[t]);
	}
	_shouldClearSelection(e, t) {
		let n = this.getActiveObjects(), r = this._activeObject;
		return !!(!t || t && r && n.length > 1 && n.indexOf(t) === -1 && r !== t && !this._isSelectionKeyPressed(e) || t && !t.evented || t && !t.selectable && r && r !== t);
	}
	_shouldCenterTransform(e, t, n) {
		if (!e) return;
		let r;
		return t === `scale` || t === `scaleX` || t === `scaleY` || t === `resizing` ? r = this.centeredScaling || e.centeredScaling : t === `rotate` && (r = this.centeredRotation || e.centeredRotation), r ? !n : n;
	}
	_getOriginFromCorner(e, t) {
		let n = t ? e.controls[t].getTransformAnchorPoint() : {
			x: e.originX,
			y: e.originY
		};
		return t ? ([
			`ml`,
			`tl`,
			`bl`
		].includes(t) ? n.x = k : [
			`mr`,
			`tr`,
			`br`
		].includes(t) && (n.x = D), [
			`tl`,
			`mt`,
			`tr`
		].includes(t) ? n.y = O : [
			`bl`,
			`mb`,
			`br`
		].includes(t) && (n.y = `top`), n) : n;
	}
	_setupCurrentTransform(e, t, n) {
		var r;
		let i = t.group ? Mt(this.getScenePoint(e), void 0, t.group.calcTransformMatrix()) : this.getScenePoint(e), { key: a = ``, control: o } = t.getActiveControl() || {}, s = n && o ? (r = o.getActionHandler(e, t, o)) == null ? void 0 : r.bind(o) : Ja, c = ((e, t, n, r) => {
			if (!t || !e) return `drag`;
			let i = r.controls[t];
			return i.getActionName(n, i, r);
		})(n, a, e, t), l = e[this.centeredKey], u = this._shouldCenterTransform(t, c, l) ? {
			x: E,
			y: E
		} : this._getOriginFromCorner(t, a), { scaleX: d, scaleY: f, skewX: p, skewY: m, left: h, top: g, angle: _, width: v, height: y, cropX: b, cropY: x } = t, S = {
			target: t,
			action: c,
			actionHandler: s,
			actionPerformed: !1,
			corner: a,
			scaleX: d,
			scaleY: f,
			skewX: p,
			skewY: m,
			offsetX: i.x - h,
			offsetY: i.y - g,
			originX: u.x,
			originY: u.y,
			ex: i.x,
			ey: i.y,
			lastX: i.x,
			lastY: i.y,
			theta: I(_),
			width: v,
			height: y,
			shiftKey: e.shiftKey,
			altKey: l,
			original: {
				...kt(t),
				originX: u.x,
				originY: u.y,
				cropX: b,
				cropY: x
			}
		};
		this._currentTransform = S, this.fire(`before:transform`, {
			e,
			transform: S
		});
	}
	setCursor(e) {
		this.upperCanvasEl.style.cursor = e;
	}
	_drawSelection(e) {
		let { x: t, y: n, deltaX: r, deltaY: i } = this._groupSelector, a = new N(t, n).transform(this.viewportTransform), o = new N(t + r, n + i).transform(this.viewportTransform), s = this.selectionLineWidth / 2, c = Math.min(a.x, o.x), l = Math.min(a.y, o.y), u = Math.max(a.x, o.x), d = Math.max(a.y, o.y);
		this.selectionColor && (e.fillStyle = this.selectionColor, e.fillRect(c, l, u - c, d - l)), this.selectionLineWidth && this.selectionBorderColor && (e.lineWidth = this.selectionLineWidth, e.strokeStyle = this.selectionBorderColor, c += s, l += s, u -= s, d -= s, J.prototype._setLineDash.call(this, e, this.selectionDashArray), e.strokeRect(c, l, u - c, d - l));
	}
	findTarget(e) {
		if (this._targetInfo) return this._targetInfo;
		if (this.skipTargetFind) return {
			subTargets: [],
			currentSubTargets: []
		};
		let t = this.getScenePoint(e), n = this._activeObject, r = this.getActiveObjects(), i = this.searchPossibleTargets(this._objects, t), { subTargets: a, container: o, target: s } = i, c = {
			...i,
			currentSubTargets: a,
			currentContainer: o,
			currentTarget: s
		};
		if (!n) return c;
		let l = {
			...this.searchPossibleTargets([n], t),
			currentSubTargets: a,
			currentContainer: o,
			currentTarget: s
		};
		return n.findControl(this.getViewportPoint(e), St(e)) ? {
			...l,
			target: n
		} : l.target && (r.length > 1 || !this.preserveObjectStacking || this.preserveObjectStacking && e[this.altSelectionKey]) ? l : c;
	}
	_pointIsInObjectSelectionArea(e, t) {
		let n = e.getCoords(), r = this.getZoom(), i = e.padding / r;
		if (i) {
			let [e, t, r, a] = n, o = Math.atan2(t.y - e.y, t.x - e.x), s = Se(o) * i, c = Ce(o) * i, l = s + c, u = s - c;
			n = [
				new N(e.x - u, e.y - l),
				new N(t.x + l, t.y - u),
				new N(r.x + u, r.y + l),
				new N(a.x - l, a.y + u)
			];
		}
		return Pr.isPointInPolygon(t, n);
	}
	_checkTarget(e, t) {
		if (e && e.visible && e.evented && this._pointIsInObjectSelectionArea(e, t)) {
			if (!this.perPixelTargetFind && !e.perPixelTargetFind || e.isEditing) return !0;
			{
				let n = t.transform(this.viewportTransform);
				if (!this.isTargetTransparent(e, n.x, n.y)) return !0;
			}
		}
		return !1;
	}
	_searchPossibleTargets(e, t, n) {
		let r = e.length;
		for (; r--;) {
			let i = e[r];
			if (this._checkTarget(i, t)) {
				if (Te(i) && i.subTargetCheck) {
					let { target: e } = this._searchPossibleTargets(i._objects, t, n);
					e && n.push(e);
				}
				return {
					target: i,
					subTargets: n
				};
			}
		}
		return { subTargets: [] };
	}
	searchPossibleTargets(e, t) {
		let n = this._searchPossibleTargets(e, t, []);
		n.container = n.target;
		let { container: r, subTargets: i } = n;
		if (r && Te(r) && r.interactive && i[0]) {
			for (let e = i.length - 1; e > 0; e--) {
				let t = i[e];
				if (!Te(t) || !t.interactive) return n.target = t, n;
			}
			return n.target = i[0], n;
		}
		return n;
	}
	getViewportPoint(e) {
		return this._viewportPoint ? this._viewportPoint : this._getPointerImpl(e, !0);
	}
	getScenePoint(e) {
		return this._scenePoint ? this._scenePoint : this._getPointerImpl(e);
	}
	_getPointerImpl(e, t = !1) {
		let n = this.upperCanvasEl, r = n.getBoundingClientRect(), i = xt(e), a = r.width || 0, o = r.height || 0;
		a && o || (`top` in r && `bottom` in r && (o = Math.abs(r.top - r.bottom)), `right` in r && `left` in r && (a = Math.abs(r.right - r.left))), this.calcOffset(), i.x -= this._offset.left, i.y -= this._offset.top, t || (i = Mt(i, void 0, this.viewportTransform));
		let s = this.getRetinaScaling();
		s !== 1 && (i.x /= s, i.y /= s);
		let c = a === 0 || o === 0 ? new N(1, 1) : new N(n.width / a, n.height / o);
		return i.multiply(c);
	}
	_setDimensionsImpl(e, t) {
		this._resetTransformEventData(), super._setDimensionsImpl(e, t), this._isCurrentlyDrawing && this.freeDrawingBrush && this.freeDrawingBrush._setBrushStyles(this.contextTop);
	}
	_createCacheCanvas() {
		this.pixelFindCanvasEl = P(), this.pixelFindContext = this.pixelFindCanvasEl.getContext(`2d`, { willReadFrequently: !0 }), this.setTargetFindTolerance(this.targetFindTolerance);
	}
	getTopContext() {
		return this.elements.upper.ctx;
	}
	getSelectionContext() {
		return this.elements.upper.ctx;
	}
	getSelectionElement() {
		return this.elements.upper.el;
	}
	getActiveObject() {
		return this._activeObject;
	}
	getActiveObjects() {
		let e = this._activeObject;
		return at(e) ? e.getObjects() : e ? [e] : [];
	}
	_fireSelectionEvents(e, t) {
		let n = !1, r = !1, i = this.getActiveObjects(), a = [], o = [];
		e.forEach((e) => {
			i.includes(e) || (n = !0, e.fire(`deselected`, {
				e: t,
				target: e
			}), o.push(e));
		}), i.forEach((r) => {
			e.includes(r) || (n = !0, r.fire(`selected`, {
				e: t,
				target: r
			}), a.push(r));
		}), e.length > 0 && i.length > 0 ? (r = !0, n && this.fire(`selection:updated`, {
			e: t,
			selected: a,
			deselected: o
		})) : i.length > 0 ? (r = !0, this.fire(`selection:created`, {
			e: t,
			selected: a
		})) : e.length > 0 && (r = !0, this.fire(`selection:cleared`, {
			e: t,
			deselected: o
		})), r && (this._objectsToRender = void 0);
	}
	setActiveObject(e, t) {
		let n = this.getActiveObjects(), r = this._setActiveObject(e, t);
		return this._fireSelectionEvents(n, t), r;
	}
	_setActiveObject(e, t) {
		let n = this._activeObject;
		return n !== e && !(!this._discardActiveObject(t, e) && this._activeObject) && !e.onSelect({ e: t }) && (this._activeObject = e, at(e) && n !== e && e.set(`canvas`, this), e.setCoords(), !0);
	}
	_discardActiveObject(e, t) {
		let n = this._activeObject;
		return !!n && !n.onDeselect({
			e,
			object: t
		}) && (this._currentTransform && this._currentTransform.target === n && this.endCurrentTransform(e), at(n) && n === this._hoveredTarget && (this._hoveredTarget = void 0), this._activeObject = void 0, !0);
	}
	discardActiveObject(e) {
		let t = this.getActiveObjects(), n = this.getActiveObject();
		t.length && this.fire(`before:selection:cleared`, {
			e,
			deselected: [n]
		});
		let r = this._discardActiveObject(e);
		return this._fireSelectionEvents(t, e), r;
	}
	endCurrentTransform(e) {
		let t = this._currentTransform;
		this._finalizeCurrentTransform(e), t && t.target && (t.target.isMoving = !1), this._currentTransform = null;
	}
	_finalizeCurrentTransform(e) {
		let t = this._currentTransform, n = t.target, r = {
			e,
			target: n,
			transform: t,
			action: t.action
		};
		n._scaling && (n._scaling = !1), n.setCoords(), t.actionPerformed && (this.fire(`object:modified`, r), n.fire(ge, r));
	}
	setViewportTransform(e) {
		super.setViewportTransform(e);
		let t = this._activeObject;
		t && t.setCoords();
	}
	destroy() {
		let e = this._activeObject;
		at(e) && (e.removeAll(), e.dispose()), delete this._activeObject, super.destroy(), this.pixelFindContext = null, this.pixelFindCanvasEl = void 0;
	}
	clear() {
		this.discardActiveObject(), this._activeObject = void 0, this.clearContext(this.contextTop), super.clear();
	}
	drawControls(e) {
		let t = this._activeObject;
		t && t._renderControls(e);
	}
	_toObject(e, t, n) {
		let r = this._realizeGroupTransformOnObject(e), i = super._toObject(e, t, n);
		return e.set(r), i;
	}
	_realizeGroupTransformOnObject(e) {
		let { group: t } = e;
		if (t && at(t) && this._activeObject === t) {
			let n = et(e, [
				`angle`,
				`flipX`,
				`flipY`,
				D,
				de,
				fe,
				pe,
				me,
				`top`
			]);
			return Et(e, t.calcOwnMatrix()), n;
		}
		return {};
	}
	_setSVGObject(e, t, n) {
		let r = this._realizeGroupTransformOnObject(t);
		super._setSVGObject(e, t, n), t.set(r);
	}
};
i(lo, `ownDefaults`, {
	uniformScaling: !0,
	uniScaleKey: `shiftKey`,
	centeredScaling: !1,
	centeredRotation: !1,
	centeredKey: `altKey`,
	altActionKey: `shiftKey`,
	selection: !0,
	selectionKey: `shiftKey`,
	selectionColor: `rgba(100, 100, 255, 0.3)`,
	selectionDashArray: [],
	selectionBorderColor: `rgba(255, 255, 255, 0.3)`,
	selectionLineWidth: 1,
	selectionFullyContained: !1,
	hoverCursor: `move`,
	moveCursor: `move`,
	defaultCursor: `default`,
	freeDrawingCursor: `crosshair`,
	notAllowedCursor: `not-allowed`,
	perPixelTargetFind: !1,
	targetFindTolerance: 0,
	skipTargetFind: !1,
	stopContextMenu: !0,
	fireRightClick: !0,
	fireMiddleClick: !0,
	enablePointerEvents: !1,
	containerClass: `canvas-container`,
	preserveObjectStacking: !0
});
var uo = class {
	constructor(e) {
		i(this, `targets`, []), i(this, `__disposer`, void 0);
		let t = () => {
			let { hiddenTextarea: t } = e.getActiveObject() || {};
			t && t.focus();
		}, n = e.upperCanvasEl;
		n.addEventListener(`click`, t), this.__disposer = () => n.removeEventListener(`click`, t);
	}
	exitTextEditing() {
		this.target = void 0, this.targets.forEach((e) => {
			e.isEditing && e.exitEditing();
		});
	}
	add(e) {
		this.targets.push(e);
	}
	remove(e) {
		this.unregister(e), xe(this.targets, e);
	}
	register(e) {
		this.target = e;
	}
	unregister(e) {
		e === this.target && (this.target = void 0);
	}
	onMouseMove(e) {
		var t;
		(t = this.target) != null && t.isEditing && this.target.updateSelectionOnMouseMove(e);
	}
	clear() {
		this.targets = [], this.target = void 0;
	}
	dispose() {
		this.clear(), this.__disposer(), delete this.__disposer;
	}
};
var X = { passive: !1 };
var fo = (e, t) => ({
	viewportPoint: e.getViewportPoint(t),
	scenePoint: e.getScenePoint(t)
});
var po = (e, ...t) => e.addEventListener(...t);
var Z = (e, ...t) => e.removeEventListener(...t);
var mo = {
	mouse: {
		in: `over`,
		out: `out`,
		targetIn: `mouseover`,
		targetOut: `mouseout`,
		canvasIn: `mouse:over`,
		canvasOut: `mouse:out`
	},
	drag: {
		in: `enter`,
		out: `leave`,
		targetIn: `dragenter`,
		targetOut: `dragleave`,
		canvasIn: `drag:enter`,
		canvasOut: `drag:leave`
	}
};
var ho = class extends lo {
	constructor(e, t = {}) {
		super(e, t), i(this, `_isClick`, void 0), i(this, `textEditingManager`, new uo(this)), [
			`_onMouseDown`,
			`_onTouchStart`,
			`_onMouseMove`,
			`_onMouseUp`,
			`_onTouchEnd`,
			`_onResize`,
			`_onMouseWheel`,
			`_onMouseOut`,
			`_onMouseEnter`,
			`_onContextMenu`,
			`_onClick`,
			`_onDragStart`,
			`_onDragEnd`,
			`_onDragProgress`,
			`_onDragOver`,
			`_onDragEnter`,
			`_onDragLeave`,
			`_onDrop`
		].forEach((e) => {
			this[e] = this[e].bind(this);
		}), this.addOrRemove(po);
	}
	_getEventPrefix() {
		return this.enablePointerEvents ? `pointer` : `mouse`;
	}
	addOrRemove(e, t = !1) {
		let n = this.upperCanvasEl, r = this._getEventPrefix();
		e(st(n), `resize`, this._onResize), e(n, r + `down`, this._onMouseDown), e(n, `${r}move`, this._onMouseMove, X), e(n, `${r}out`, this._onMouseOut), e(n, `${r}enter`, this._onMouseEnter), e(n, `wheel`, this._onMouseWheel, { passive: !1 }), e(n, `contextmenu`, this._onContextMenu), t || (e(n, `click`, this._onClick), e(n, `dblclick`, this._onClick)), e(n, `dragstart`, this._onDragStart), e(n, `dragend`, this._onDragEnd), e(n, `dragover`, this._onDragOver), e(n, `dragenter`, this._onDragEnter), e(n, `dragleave`, this._onDragLeave), e(n, `drop`, this._onDrop), this.enablePointerEvents || e(n, `touchstart`, this._onTouchStart, X);
	}
	removeListeners() {
		this.addOrRemove(Z);
		let e = this._getEventPrefix(), t = H(this.upperCanvasEl);
		Z(t, `${e}up`, this._onMouseUp), Z(t, `touchend`, this._onTouchEnd, X), Z(t, `${e}move`, this._onMouseMove, X), Z(t, `touchmove`, this._onMouseMove, X), clearTimeout(this._willAddMouseDown);
	}
	_onMouseWheel(e) {
		this._cacheTransformEventData(e), this._handleEvent(e, `wheel`), this._resetTransformEventData();
	}
	_onMouseOut(e) {
		let t = this._hoveredTarget, n = {
			e,
			...fo(this, e)
		};
		this.fire(`mouse:out`, {
			...n,
			target: t
		}), this._hoveredTarget = void 0, t && t.fire(`mouseout`, { ...n }), this._hoveredTargets.forEach((e) => {
			this.fire(`mouse:out`, {
				...n,
				target: e
			}), e && e.fire(`mouseout`, { ...n });
		}), this._hoveredTargets = [];
	}
	_onMouseEnter(e) {
		let { target: t } = this.findTarget(e);
		this._currentTransform || t || (this.fire(`mouse:over`, {
			e,
			...fo(this, e)
		}), this._hoveredTarget = void 0, this._hoveredTargets = []);
	}
	_onDragStart(e) {
		this._isClick = !1;
		let t = this.getActiveObject();
		if (t && t.onDragStart(e)) {
			this._dragSource = t;
			let n = {
				e,
				target: t
			};
			this.fire(`dragstart`, n), t.fire(`dragstart`, n), po(this.upperCanvasEl, `drag`, this._onDragProgress);
			return;
		}
		Ct(e);
	}
	_renderDragEffects(e, t, n) {
		let r = !1, i = this._dropTarget;
		i && i !== t && i !== n && (i.clearContextTop(), r = !0), t?.clearContextTop(), n !== t && n?.clearContextTop();
		let a = this.contextTop;
		a.save(), a.transform(...this.viewportTransform), t && (a.save(), t.transform(a), t.renderDragSourceEffect(e), a.restore(), r = !0), n && (a.save(), n.transform(a), n.renderDropTargetEffect(e), a.restore(), r = !0), a.restore(), r && (this.contextTopDirty = !0);
	}
	_onDragEnd(e) {
		let { currentSubTargets: t } = this.findTarget(e), n = !!e.dataTransfer && e.dataTransfer.dropEffect !== `none`, r = n ? this._activeObject : void 0, i = {
			e,
			target: this._dragSource,
			subTargets: t,
			dragSource: this._dragSource,
			didDrop: n,
			dropTarget: r
		};
		Z(this.upperCanvasEl, `drag`, this._onDragProgress), this.fire(`dragend`, i), this._dragSource && this._dragSource.fire(`dragend`, i), delete this._dragSource, this._onMouseUp(e);
	}
	_onDragProgress(e) {
		let t = {
			e,
			target: this._dragSource,
			dragSource: this._dragSource,
			dropTarget: this._draggedoverTarget
		};
		this.fire(`drag`, t), this._dragSource && this._dragSource.fire(`drag`, t);
	}
	_onDragOver(e) {
		let t = `dragover`, { currentContainer: n, currentSubTargets: r } = this.findTarget(e), i = this._dragSource, a = {
			e,
			target: n,
			subTargets: r,
			dragSource: i,
			canDrop: !1,
			dropTarget: void 0
		}, o;
		this.fire(t, a), this._fireEnterLeaveEvents(e, n, a), n && (n.canDrop(e) && (o = n), n.fire(t, a));
		for (let n = 0; n < r.length; n++) {
			let i = r[n];
			i.canDrop(e) && (o = i), i.fire(t, a);
		}
		this._renderDragEffects(e, i, o), this._dropTarget = o;
	}
	_onDragEnter(e) {
		let { currentContainer: t, currentSubTargets: n } = this.findTarget(e), r = {
			e,
			target: t,
			subTargets: n,
			dragSource: this._dragSource
		};
		this.fire(`dragenter`, r), this._fireEnterLeaveEvents(e, t, r);
	}
	_onDragLeave(e) {
		let { currentSubTargets: t } = this.findTarget(e), n = {
			e,
			target: this._draggedoverTarget,
			subTargets: t,
			dragSource: this._dragSource
		};
		this.fire(`dragleave`, n), this._fireEnterLeaveEvents(e, void 0, n), this._renderDragEffects(e, this._dragSource), this._dropTarget = void 0, this._hoveredTargets = [];
	}
	_onDrop(e) {
		let { currentContainer: t, currentSubTargets: n } = this.findTarget(e), r = this._basicEventHandler(`drop:before`, {
			e,
			target: t,
			subTargets: n,
			dragSource: this._dragSource,
			...fo(this, e)
		});
		r.didDrop = !1, r.dropTarget = void 0, this._basicEventHandler(`drop`, r), this.fire(`drop:after`, r);
	}
	_onContextMenu(e) {
		let { target: t, subTargets: n } = this.findTarget(e), r = this._basicEventHandler(`contextmenu:before`, {
			e,
			target: t,
			subTargets: n
		});
		return this.stopContextMenu && Ct(e), this._basicEventHandler(`contextmenu`, r), !1;
	}
	_onClick(e) {
		let t = e.detail;
		t > 3 || t < 2 || (this._cacheTransformEventData(e), t == 2 && e.type === `dblclick` && this._handleEvent(e, `dblclick`), t == 3 && this._handleEvent(e, `tripleclick`), this._resetTransformEventData());
	}
	fireEventFromPointerEvent(e, t, n, r = {}) {
		this._cacheTransformEventData(e);
		let { target: i, subTargets: a } = this.findTarget(e), o = {
			e,
			target: i,
			subTargets: a,
			...fo(this, e),
			transform: this._currentTransform,
			...r
		};
		this.fire(t, o), i && i.fire(n, o);
		for (let e = 0; e < a.length; e++) a[e] !== i && a[e].fire(n, o);
		this._resetTransformEventData();
	}
	getPointerId(e) {
		let t = e.changedTouches;
		return t ? t[0] && t[0].identifier : this.enablePointerEvents ? e.pointerId : -1;
	}
	_isMainEvent(e) {
		return !0 === e.isPrimary || !1 !== e.isPrimary && (e.type === `touchend` && e.touches.length === 0 || !e.changedTouches || e.changedTouches[0].identifier === this.mainTouchId);
	}
	_onTouchStart(e) {
		this._cacheTransformEventData(e);
		let t = !this.allowTouchScrolling, n = this._activeObject;
		this.mainTouchId === void 0 && (this.mainTouchId = this.getPointerId(e)), this.__onMouseDown(e);
		let { target: r } = this.findTarget(e);
		(this.isDrawingMode || n && r === n) && (t = !0), t && e.preventDefault();
		let i = this.upperCanvasEl, a = this._getEventPrefix(), o = H(i);
		po(o, `touchend`, this._onTouchEnd, X), t && po(o, `touchmove`, this._onMouseMove, X), Z(i, `${a}down`, this._onMouseDown), this._resetTransformEventData();
	}
	_onMouseDown(e) {
		this._cacheTransformEventData(e), this.__onMouseDown(e);
		let t = this.upperCanvasEl, n = this._getEventPrefix();
		Z(t, `${n}move`, this._onMouseMove, X);
		let r = H(t);
		po(r, `${n}up`, this._onMouseUp), po(r, `${n}move`, this._onMouseMove, X), this._resetTransformEventData();
	}
	_onTouchEnd(e) {
		if (e.touches.length > 0) return;
		this._cacheTransformEventData(e), this.__onMouseUp(e), this._resetTransformEventData(), delete this.mainTouchId;
		let t = this._getEventPrefix(), n = H(this.upperCanvasEl);
		Z(n, `touchend`, this._onTouchEnd, X), Z(n, `touchmove`, this._onMouseMove, X), this._willAddMouseDown && clearTimeout(this._willAddMouseDown), this._willAddMouseDown = setTimeout(() => {
			po(this.upperCanvasEl, `${t}down`, this._onMouseDown), this._willAddMouseDown = 0;
		}, 400);
	}
	_onMouseUp(e) {
		this._cacheTransformEventData(e), this.__onMouseUp(e);
		let t = this.upperCanvasEl, n = this._getEventPrefix();
		if (this._isMainEvent(e)) {
			let e = H(this.upperCanvasEl);
			Z(e, `${n}up`, this._onMouseUp), Z(e, `${n}move`, this._onMouseMove, X), po(t, `${n}move`, this._onMouseMove, X);
		}
		this._resetTransformEventData();
	}
	_onMouseMove(e) {
		this._cacheTransformEventData(e);
		let t = this.getActiveObject();
		!this.allowTouchScrolling && (!t || !t.shouldStartDragging(e)) && e.preventDefault && e.preventDefault(), this.__onMouseMove(e), this._resetTransformEventData();
	}
	_onResize() {
		this.calcOffset(), this._resetTransformEventData();
	}
	_shouldRender(e) {
		let t = this.getActiveObject();
		return !!t != !!e || t && e && t !== e;
	}
	__onMouseUp(e) {
		var t;
		this._handleEvent(e, `up:before`);
		let n = this._currentTransform, r = this._isClick, { target: i } = this.findTarget(e), { button: a } = e;
		if (a) return void ((this.fireMiddleClick && a === 1 || this.fireRightClick && a === 2) && this._handleEvent(e, `up`));
		if (this.isDrawingMode && this._isCurrentlyDrawing) return void this._onMouseUpInDrawingMode(e);
		if (!this._isMainEvent(e)) return;
		let o, s, c = !1;
		if (n && (this._finalizeCurrentTransform(e), c = n.actionPerformed), !r) {
			let t = i === this._activeObject;
			this.handleSelection(e), c || (c = this._shouldRender(i) || !t && i === this._activeObject);
		}
		if (i) {
			let { key: t, control: r } = i.findControl(this.getViewportPoint(e), St(e)) || {};
			if (s = t, i.selectable && i !== this._activeObject && i.activeOn === `up`) this.setActiveObject(i, e), c = !0;
			else if (r) {
				let t = r.getMouseUpHandler(e, i, r);
				t && (o = this.getScenePoint(e), t.call(r, e, n, o.x, o.y));
			}
			i.isMoving = !1;
		}
		if (n && (n.target !== i || n.corner !== s)) {
			let t = n.target && n.target.controls[n.corner], r = t && t.getMouseUpHandler(e, n.target, t);
			o = o || this.getScenePoint(e), r && r.call(t, e, n, o.x, o.y);
		}
		this._setCursorFromEvent(e, i), this._handleEvent(e, `up`), this._groupSelector = null, this._currentTransform = null, i && (i.__corner = void 0), c ? this.requestRenderAll() : r || (t = this._activeObject) != null && t.isEditing || this.renderTop();
	}
	_basicEventHandler(e, t) {
		let { target: n, subTargets: r = [] } = t;
		this.fire(e, t), n && n.fire(e, t);
		for (let i = 0; i < r.length; i++) r[i] !== n && r[i].fire(e, t);
		return t;
	}
	_handleEvent(e, t, n) {
		let { target: r, subTargets: i } = this.findTarget(e), a = {
			e,
			target: r,
			subTargets: i,
			...fo(this, e),
			transform: this._currentTransform,
			...t === `down:before` || t === `down` ? n : {}
		};
		t !== `up:before` && t !== `up` || (a.isClick = this._isClick), this.fire(`mouse:${t}`, a), r && r.fire(`mouse${t}`, a);
		for (let e = 0; e < i.length; e++) i[e] !== r && i[e].fire(`mouse${t}`, a);
	}
	_onMouseDownInDrawingMode(e) {
		this._isCurrentlyDrawing = !0, this.getActiveObject() && (this.discardActiveObject(e), this.requestRenderAll());
		let t = this.getScenePoint(e);
		this.freeDrawingBrush && this.freeDrawingBrush.onMouseDown(t, {
			e,
			pointer: t
		}), this._handleEvent(e, `down`, { alreadySelected: !1 });
	}
	_onMouseMoveInDrawingMode(e) {
		if (this._isCurrentlyDrawing) {
			let t = this.getScenePoint(e);
			this.freeDrawingBrush && this.freeDrawingBrush.onMouseMove(t, {
				e,
				pointer: t
			});
		}
		this.setCursor(this.freeDrawingCursor), this._handleEvent(e, `move`);
	}
	_onMouseUpInDrawingMode(e) {
		let t = this.getScenePoint(e);
		this.freeDrawingBrush ? this._isCurrentlyDrawing = !!this.freeDrawingBrush.onMouseUp({
			e,
			pointer: t
		}) : this._isCurrentlyDrawing = !1, this._handleEvent(e, `up`);
	}
	__onMouseDown(e) {
		this._isClick = !0, this._handleEvent(e, `down:before`);
		let { target: t } = this.findTarget(e), n = !!t && t === this._activeObject, { button: r } = e;
		if (r) return void ((this.fireMiddleClick && r === 1 || this.fireRightClick && r === 2) && this._handleEvent(e, `down`, { alreadySelected: n }));
		if (this.isDrawingMode) return void this._onMouseDownInDrawingMode(e);
		if (!this._isMainEvent(e) || this._currentTransform) return;
		let i = this._shouldRender(t), a = !1;
		if (this.handleMultiSelection(e, t) ? (t = this._activeObject, a = !0, i = !0) : this._shouldClearSelection(e, t) && this.discardActiveObject(e), this.selection && (!t || !t.selectable && !t.isEditing && t !== this._activeObject)) {
			let t = this.getScenePoint(e);
			this._groupSelector = {
				x: t.x,
				y: t.y,
				deltaY: 0,
				deltaX: 0
			};
		}
		if (n = !!t && t === this._activeObject, t) {
			t.selectable && t.activeOn === `down` && this.setActiveObject(t, e);
			let r = t.findControl(this.getViewportPoint(e), St(e));
			if (t === this._activeObject && (r || !a)) {
				this._setupCurrentTransform(e, t, n);
				let i = r ? r.control : void 0, a = this.getScenePoint(e), o = i && i.getMouseDownHandler(e, t, i);
				o && o.call(i, e, this._currentTransform, a.x, a.y);
			}
		}
		i && (this._objectsToRender = void 0), this._handleEvent(e, `down`, { alreadySelected: n }), i && this.requestRenderAll();
	}
	_resetTransformEventData() {
		this._targetInfo = this._viewportPoint = this._scenePoint = void 0;
	}
	_cacheTransformEventData(e) {
		this._resetTransformEventData(), this._viewportPoint = this.getViewportPoint(e), this._scenePoint = Mt(this._viewportPoint, void 0, this.viewportTransform), this._targetInfo = this.findTarget(e), this._currentTransform && (this._targetInfo.target = this._currentTransform.target);
	}
	__onMouseMove(e) {
		if (this._isClick = !1, this._handleEvent(e, `move:before`), this.isDrawingMode) return void this._onMouseMoveInDrawingMode(e);
		if (!this._isMainEvent(e)) return;
		let t = this._groupSelector;
		if (t) {
			let n = this.getScenePoint(e);
			t.deltaX = n.x - t.x, t.deltaY = n.y - t.y, this.renderTop();
		} else if (this._currentTransform) this._transformObject(e);
		else {
			let { target: t } = this.findTarget(e);
			this._setCursorFromEvent(e, t), this._fireOverOutEvents(e, t);
		}
		this.textEditingManager.onMouseMove(e), this._handleEvent(e, `move`);
	}
	_fireOverOutEvents(e, t) {
		let { _hoveredTarget: n, _hoveredTargets: r } = this, { subTargets: i, currentTarget: a } = this.findTarget(e), o = Math.max(r.length, i.length);
		this.fireSyntheticInOutEvents(`mouse`, {
			e,
			target: t,
			oldTarget: n,
			actualTarget: a,
			oldActualTarget: this._hoveredActualTarget,
			fireCanvas: !0
		});
		for (let a = 0; a < o; a++) i[a] === t || r[a] && r[a] === n || this.fireSyntheticInOutEvents(`mouse`, {
			e,
			target: i[a],
			oldTarget: r[a]
		});
		this._hoveredActualTarget = a, this._hoveredTarget = t, this._hoveredTargets = i;
	}
	_fireEnterLeaveEvents(e, t, n) {
		let r = this._draggedoverTarget, i = this._hoveredTargets, { subTargets: a } = this.findTarget(e), o = Math.max(i.length, a.length);
		this.fireSyntheticInOutEvents(`drag`, {
			...n,
			target: t,
			oldTarget: r,
			fireCanvas: !0
		});
		for (let e = 0; e < o; e++) this.fireSyntheticInOutEvents(`drag`, {
			...n,
			target: a[e],
			oldTarget: i[e]
		});
		this._draggedoverTarget = t;
	}
	fireSyntheticInOutEvents(e, { target: t, oldTarget: n, actualTarget: r, oldActualTarget: i, fireCanvas: a, e: o, ...s }) {
		let { targetIn: c, targetOut: l, canvasIn: u, canvasOut: d } = mo[e], f = n !== t, p = i !== r, m = t && f, h = r && p, g = n && f, _ = i && p, v = {
			...s,
			e: o,
			...fo(this, o)
		}, y = {
			...v,
			target: n,
			nextTarget: t,
			actualTarget: i,
			nextActualTarget: r
		};
		(g || _) && a && this.fire(d, y), g && n.fire(l, y), _ && n !== i && i.fire(l, y);
		let b = {
			...v,
			target: t,
			previousTarget: n,
			actualTarget: r,
			previousActualTarget: i
		};
		(m || h) && a && this.fire(u, b), m && t.fire(c, b), h && r !== t && r.fire(c, b);
	}
	_transformObject(e) {
		let t = this.getScenePoint(e), n = this._currentTransform, r = n.target, i = r.group ? Mt(t, void 0, r.group.calcTransformMatrix()) : t;
		n.shiftKey = e.shiftKey, n.altKey = !!this.centeredKey && e[this.centeredKey], this._performTransformAction(e, n, i), n.actionPerformed && this.requestRenderAll();
	}
	_performTransformAction(e, t, n) {
		let { action: r, actionHandler: i, target: a } = t, o = !!i && i(e, t, n.x, n.y);
		o && a.setCoords(), r === `drag` && o && (t.target.isMoving = !0, this.setCursor(t.target.moveCursor || this.moveCursor)), t.actionPerformed = t.actionPerformed || o;
	}
	_setCursorFromEvent(e, t) {
		if (!t) return void this.setCursor(this.defaultCursor);
		let n = t.hoverCursor || this.hoverCursor, r = at(this._activeObject) ? this._activeObject : null, i = (!r || t.group !== r) && t.findControl(this.getViewportPoint(e));
		if (i) {
			let { control: n, coord: r } = i;
			this.setCursor(n.cursorStyleHandler(e, n, t, r));
		} else {
			if (t.subTargetCheck) {
				let { subTargets: t } = this.findTarget(e);
				t.concat().reverse().forEach((e) => {
					n = e.hoverCursor || n;
				});
			}
			this.setCursor(n);
		}
	}
	handleMultiSelection(e, t) {
		let n = this._activeObject, r = at(n);
		if (n && this._isSelectionKeyPressed(e) && this.selection && t && t.selectable && (n !== t || r) && (r || !t.isDescendantOf(n) && !n.isDescendantOf(t)) && !t.onSelect({ e }) && !n.getActiveControl()) {
			if (r) {
				let r = n.getObjects(), i = [];
				if (t === n) {
					let n = this.getScenePoint(e), a = this.searchPossibleTargets(r, n);
					if (a.target ? (t = a.target, i = a.subTargets) : (a = this.searchPossibleTargets(this._objects, n), t = a.target, i = a.subTargets), !t || !t.selectable) return !1;
				}
				t.group === n ? (n.remove(t), this._hoveredTarget = t, this._hoveredTargets = i, n.size() === 1 && this._setActiveObject(n.item(0), e)) : (n.multiSelectAdd(t), this._hoveredTarget = n, this._hoveredTargets = i), this._fireSelectionEvents(r, e);
			} else {
				n.isEditing && n.exitEditing();
				let r = new (M.getClass(`ActiveSelection`))([], { canvas: this });
				r.multiSelectAdd(n, t), this._hoveredTarget = r, this._setActiveObject(r, e), this._fireSelectionEvents([n], e);
			}
			return !0;
		}
		return !1;
	}
	handleSelection(e) {
		if (!this.selection || !this._groupSelector) return !1;
		let { x: t, y: n, deltaX: r, deltaY: i } = this._groupSelector, a = new N(t, n), o = a.add(new N(r, i)), s = a.min(o), c = a.max(o).subtract(s), l = this.collectObjects({
			left: s.x,
			top: s.y,
			width: c.x,
			height: c.y
		}, { includeIntersecting: !this.selectionFullyContained }), u = a.eq(o) ? l[0] ? [l[0]] : [] : l.length > 1 ? l.filter((t) => !t.onSelect({ e })).reverse() : l;
		if (u.length === 1) this.setActiveObject(u[0], e);
		else if (u.length > 1) {
			let t = M.getClass(`ActiveSelection`);
			this.setActiveObject(new t(u, { canvas: this }), e);
		}
		return this._groupSelector = null, !0;
	}
	toCanvasElement(e = 1, t) {
		let { upper: n } = this.elements;
		n.ctx = void 0;
		let r = super.toCanvasElement(e, t);
		return n.ctx = n.el.getContext(`2d`), r;
	}
	clear() {
		this.textEditingManager.clear(), super.clear();
	}
	destroy() {
		this.removeListeners(), this.textEditingManager.dispose(), super.destroy();
	}
};
var go = {
	x1: 0,
	y1: 0,
	x2: 0,
	y2: 0
};
var _o = {
	...go,
	r1: 0,
	r2: 0
};
var vo = (e, t) => isNaN(e) && typeof t == `number` ? t : e;
function yo(e) {
	return e && /%$/.test(e) && Number.isFinite(parseFloat(e));
}
function bo(e, t) {
	return Vn(0, vo(typeof e == `number` ? e : typeof e == `string` ? parseFloat(e) / (yo(e) ? 100 : 1) : NaN, t), 1);
}
var xo = /\s*;\s*/;
var So = /\s*:\s*/;
function Co(e, t) {
	let n, r, i = e.getAttribute(`style`);
	if (i) {
		let e = i.split(xo);
		e[e.length - 1] === `` && e.pop();
		for (let t = e.length; t--;) {
			let [i, a] = e[t].split(So).map((e) => e.trim());
			i === `stop-color` ? n = a : i === `stop-opacity` && (r = a);
		}
	}
	n = n || e.getAttribute(`stop-color`) || `rgb(0,0,0)`, r = vo(parseFloat(r || e.getAttribute(`stop-opacity`) || ``), 1);
	let a = new G(n);
	return a.setAlpha(a.getAlpha() * r * t), {
		offset: bo(e.getAttribute(`offset`), 0),
		color: a.toRgba()
	};
}
function wo(e, t) {
	let n = [], r = e.getElementsByTagName(`stop`), i = bo(t, 1);
	for (let e = r.length; e--;) n.push(Co(r[e], i));
	return n;
}
function To(e) {
	return e.nodeName === `linearGradient` || e.nodeName === `LINEARGRADIENT` ? `linear` : `radial`;
}
function Eo(e) {
	return e.getAttribute(`gradientUnits`) === `userSpaceOnUse` ? `pixels` : `percentage`;
}
function Do(e, t) {
	return e.getAttribute(t);
}
function Oo(e, t) {
	return function(e, { width: t, height: n, gradientUnits: r }) {
		let i;
		return Object.entries(e).reduce((e, [a, o]) => {
			if (o === `Infinity`) i = 1;
			else if (o === `-Infinity`) i = 0;
			else {
				let e = typeof o == `string`;
				i = e ? parseFloat(o) : o, e && yo(o) && (i *= .01, r === `pixels` && (a !== `x1` && a !== `x2` && a !== `r2` || (i *= t), a !== `y1` && a !== `y2` || (i *= n)));
			}
			return e[a] = i, e;
		}, {});
	}(To(e) === `linear` ? function(e) {
		return {
			x1: Do(e, `x1`) || 0,
			y1: Do(e, `y1`) || 0,
			x2: Do(e, `x2`) || `100%`,
			y2: Do(e, `y2`) || 0
		};
	}(e) : function(e) {
		return {
			x1: Do(e, `fx`) || Do(e, `cx`) || `50%`,
			y1: Do(e, `fy`) || Do(e, `cy`) || `50%`,
			r1: 0,
			x2: Do(e, `cx`) || `50%`,
			y2: Do(e, `cy`) || `50%`,
			r2: Do(e, `r`) || `50%`
		};
	}(e), {
		...t,
		gradientUnits: Eo(e)
	});
}
var ko = class {
	constructor(e) {
		let { type: t = `linear`, gradientUnits: n = `pixels`, coords: r = {}, colorStops: i = [], offsetX: a = 0, offsetY: o = 0, gradientTransform: s, id: c } = e || {};
		Object.assign(this, {
			type: t,
			gradientUnits: n,
			coords: {
				...t === `radial` ? _o : go,
				...r
			},
			colorStops: i,
			offsetX: a,
			offsetY: o,
			gradientTransform: s,
			id: c ? `${c}_${je()}` : je()
		});
	}
	addColorStop(e) {
		for (let t in e) this.colorStops.push({
			offset: parseFloat(t),
			color: e[t]
		});
		return this;
	}
	toObject(e) {
		return {
			...et(this, e),
			type: this.type,
			coords: { ...this.coords },
			colorStops: this.colorStops.map((e) => ({ ...e })),
			offsetX: this.offsetX,
			offsetY: this.offsetY,
			gradientUnits: this.gradientUnits,
			gradientTransform: this.gradientTransform ? [...this.gradientTransform] : void 0
		};
	}
	toSVG(e, { additionalTransform: t } = {}) {
		let n = [], r = this.gradientTransform ? this.gradientTransform.concat() : T.concat(), i = this.gradientUnits === `pixels` ? `userSpaceOnUse` : `objectBoundingBox`, a = this.colorStops.map((e) => ({ ...e })).sort((e, t) => e.offset - t.offset), o = -this.offsetX, s = -this.offsetY;
		var c;
		i === `objectBoundingBox` ? (o /= e.width, s /= e.height) : (o += e.width / 2, s += e.height / 2), (c = e) && typeof c._renderPathCommands == `function` && this.gradientUnits !== `percentage` && (o -= e.pathOffset.x, s -= e.pathOffset.y), r[4] -= o, r[5] -= s;
		let l = [
			`id="SVGID_${U(String(this.id))}"`,
			`gradientUnits="${i}"`,
			`gradientTransform="${t ? t + ` ` : ``}${nt(r)}"`,
			``
		].join(` `), u = (e) => parseFloat(String(e));
		if (this.type === `linear`) {
			let { x1: e, y1: t, x2: r, y2: i } = this.coords, a = u(e), o = u(t), s = u(r), c = u(i);
			n.push(`<linearGradient `, l, ` x1="`, a, `" y1="`, o, `" x2="`, s, `" y2="`, c, `">
`);
		} else if (this.type === `radial`) {
			let { x1: e, y1: t, x2: r, y2: i, r1: o, r2: s } = this.coords, c = u(e), d = u(t), f = u(r), p = u(i), m = u(o), h = u(s), g = m > h;
			n.push(`<radialGradient `, l, ` cx="`, g ? c : f, `" cy="`, g ? d : p, `" r="`, g ? m : h, `" fx="`, g ? f : c, `" fy="`, g ? p : d, `">
`), g && (a.reverse(), a.forEach((e) => {
				e.offset = 1 - e.offset;
			}));
			let _ = Math.min(m, h);
			if (_ > 0) {
				let e = _ / Math.max(m, h);
				a.forEach((t) => {
					t.offset += e * (1 - t.offset);
				});
			}
		}
		return a.forEach(({ color: e, offset: t }) => {
			let r = String(e), i = nn(r) ? r : new G(r).toRgba();
			n.push(`<stop offset="${100 * t}%" style="stop-color:${U(i)};"/>\n`);
		}), n.push(this.type === `linear` ? `</linearGradient>` : `</radialGradient>`, `
`), n.join(``);
	}
	toLive(e) {
		let { x1: t, y1: n, x2: r, y2: i, r1: a, r2: o } = this.coords, s = this.type === `linear` ? e.createLinearGradient(t, n, r, i) : e.createRadialGradient(t, n, a, r, i, o);
		return this.colorStops.forEach(({ color: e, offset: t }) => {
			s.addColorStop(t, e);
		}), s;
	}
	static async fromObject(e) {
		let { colorStops: t, gradientTransform: n } = e;
		return new this({
			...e,
			colorStops: t ? t.map((e) => ({ ...e })) : void 0,
			gradientTransform: n ? [...n] : void 0
		});
	}
	static fromElement(e, t, n) {
		let r = Eo(e), i = t._findCenterFromElement();
		return new this({
			id: e.getAttribute(`id`) || void 0,
			type: To(e),
			coords: Oo(e, {
				width: n.viewBoxWidth || n.width,
				height: n.viewBoxHeight || n.height
			}),
			colorStops: wo(e, n.opacity),
			gradientUnits: r,
			gradientTransform: Ki(e.getAttribute(`gradientTransform`) || ``),
			...r === `pixels` ? {
				offsetX: t.width / 2 - i.x,
				offsetY: t.height / 2 - i.y
			} : {
				offsetX: 0,
				offsetY: 0
			}
		});
	}
};
i(ko, `type`, `Gradient`), M.setClass(ko, `gradient`), M.setClass(ko, `linear`), M.setClass(ko, `radial`);
var Ao = class {
	get type() {
		return `pattern`;
	}
	set type(e) {
		s(`warn`, `Setting type has no effect`, e);
	}
	constructor(e) {
		i(this, `repeat`, `repeat`), i(this, `offsetX`, 0), i(this, `offsetY`, 0), i(this, `crossOrigin`, ``), this.id = je(), Object.assign(this, e);
	}
	isImageSource() {
		return !!this.source && typeof this.source.src == `string`;
	}
	isCanvasSource() {
		return !!this.source && !!this.source.toDataURL;
	}
	sourceToString() {
		return this.isImageSource() ? this.source.src : this.isCanvasSource() ? this.source.toDataURL() : ``;
	}
	toLive(e) {
		return this.source && (!this.isImageSource() || this.source.complete && this.source.naturalWidth !== 0 && this.source.naturalHeight !== 0) ? e.createPattern(this.source, this.repeat) : null;
	}
	toObject(e = []) {
		let { repeat: t, crossOrigin: n } = this;
		return {
			...et(this, e),
			type: `pattern`,
			source: this.sourceToString(),
			repeat: t,
			crossOrigin: n,
			offsetX: B(this.offsetX, o.NUM_FRACTION_DIGITS),
			offsetY: B(this.offsetY, o.NUM_FRACTION_DIGITS),
			patternTransform: this.patternTransform ? [...this.patternTransform] : null
		};
	}
	toSVG({ width: e, height: t }) {
		let { source: n, repeat: r, id: i } = this, a = vo(this.offsetX / e, 0), o = vo(this.offsetY / t, 0), s = r === `repeat-y` || r === `no-repeat` ? 1 + Math.abs(a || 0) : vo(n.width / e, 0), c = r === `repeat-x` || r === `no-repeat` ? 1 + Math.abs(o || 0) : vo(n.height / t, 0);
		return [
			`<pattern id="SVGID_${U(i)}" x="${a}" y="${o}" width="${s}" height="${c}">`,
			`<image x="0" y="0" width="${n.width}" height="${n.height}" xlink:href="${U(this.sourceToString())}"></image>`,
			`</pattern>`,
			``
		].join(`
`);
	}
	static async fromObject({ type: e, source: t, patternTransform: n, ...r }, i) {
		let a = await Ze(t, {
			...i,
			crossOrigin: r.crossOrigin
		});
		return new this({
			...r,
			patternTransform: n && n.slice(0),
			source: a
		});
	}
};
i(Ao, `type`, `Pattern`), M.setClass(Ao), M.setClass(Ao, `pattern`);
var jo = class {
	constructor(e) {
		i(this, `color`, `rgb(0, 0, 0)`), i(this, `width`, 1), i(this, `shadow`, null), i(this, `strokeLineCap`, `round`), i(this, `strokeLineJoin`, `round`), i(this, `strokeMiterLimit`, 10), i(this, `strokeDashArray`, null), i(this, `limitedToCanvasSize`, !1), this.canvas = e;
	}
	_setBrushStyles(e) {
		e.strokeStyle = this.color, e.lineWidth = this.width, e.lineCap = this.strokeLineCap, e.miterLimit = this.strokeMiterLimit, e.lineJoin = this.strokeLineJoin, e.setLineDash(this.strokeDashArray || []);
	}
	_saveAndTransform(e) {
		let t = this.canvas.viewportTransform;
		e.save(), e.transform(t[0], t[1], t[2], t[3], t[4], t[5]);
	}
	needsFullRender() {
		return new G(this.color).getAlpha() < 1 || !!this.shadow;
	}
	_setShadow() {
		if (!this.shadow || !this.canvas) return;
		let e = this.canvas, t = this.shadow, n = e.contextTop, r = e.getZoom() * e.getRetinaScaling();
		n.shadowColor = t.color, n.shadowBlur = t.blur * r, n.shadowOffsetX = t.offsetX * r, n.shadowOffsetY = t.offsetY * r;
	}
	_resetShadow() {
		let e = this.canvas.contextTop;
		e.shadowColor = ``, e.shadowBlur = e.shadowOffsetX = e.shadowOffsetY = 0;
	}
	_isOutSideCanvas(e) {
		return e.x < 0 || e.x > this.canvas.getWidth() || e.y < 0 || e.y > this.canvas.getHeight();
	}
};
var Mo = class e extends J {
	constructor(t, { path: n, left: r, top: i, ...a } = {}) {
		super(), Object.assign(this, e.ownDefaults), this.setOptions(a), this._setPath(t || [], !0), typeof r == `number` && this.set(`left`, r), typeof i == `number` && this.set(`top`, i);
	}
	_setPath(e, t) {
		this.path = ba(Array.isArray(e) ? e : La(e)), this.setBoundingBox(t);
	}
	_findCenterFromElement() {
		let e = this._calcBoundsFromPath();
		return new N(e.left + e.width / 2, e.top + e.height / 2);
	}
	_renderPathCommands(e) {
		let t = -this.pathOffset.x, n = -this.pathOffset.y;
		e.beginPath();
		for (let r of this.path) switch (r[0]) {
			case `L`:
				e.lineTo(r[1] + t, r[2] + n);
				break;
			case `M`:
				e.moveTo(r[1] + t, r[2] + n);
				break;
			case `C`:
				e.bezierCurveTo(r[1] + t, r[2] + n, r[3] + t, r[4] + n, r[5] + t, r[6] + n);
				break;
			case `Q`:
				e.quadraticCurveTo(r[1] + t, r[2] + n, r[3] + t, r[4] + n);
				break;
			case `Z`: e.closePath();
		}
	}
	_render(e) {
		this._renderPathCommands(e), this._renderPaintInOrder(e);
	}
	toString() {
		return `#<Path (${this.complexity()}): { "top": ${this.top}, "left": ${this.left} }>`;
	}
	toObject(e = []) {
		return {
			...super.toObject(e),
			path: this.path.map((e) => e.slice())
		};
	}
	toDatalessObject(e = []) {
		let t = this.toObject(e);
		return this.sourcePath && (delete t.path, t.sourcePath = this.sourcePath), t;
	}
	_toSVG() {
		return [
			`<path `,
			`COMMON_PARTS`,
			`d="${Va(this.path, o.NUM_FRACTION_DIGITS)}" stroke-linecap="round" />\n`
		];
	}
	_getOffsetTransform() {
		let e = o.NUM_FRACTION_DIGITS;
		return ` translate(${B(-this.pathOffset.x, e)}, ${B(-this.pathOffset.y, e)})`;
	}
	toClipPathSVG(e) {
		let t = this._getOffsetTransform();
		return `	` + this._createBaseClipPathSVGMarkup(this._toSVG(), {
			reviver: e,
			additionalTransform: t
		});
	}
	toSVG(e) {
		let t = this._getOffsetTransform();
		return this._createBaseSVGMarkup(this._toSVG(), {
			reviver: e,
			additionalTransform: t
		});
	}
	complexity() {
		return this.path.length;
	}
	setDimensions() {
		this.setBoundingBox();
	}
	setBoundingBox(e) {
		let { width: t, height: n, pathOffset: r } = this._calcDimensions();
		this.set({
			width: t,
			height: n,
			pathOffset: r
		}), e && this.setPositionByOrigin(r, `center`, `center`);
	}
	_calcBoundsFromPath() {
		let e = [], t = 0, n = 0, r = 0, i = 0;
		for (let a of this.path) switch (a[0]) {
			case `L`:
				r = a[1], i = a[2], e.push({
					x: t,
					y: n
				}, {
					x: r,
					y: i
				});
				break;
			case `M`:
				r = a[1], i = a[2], t = r, n = i;
				break;
			case `C`:
				e.push(...va(r, i, a[1], a[2], a[3], a[4], a[5], a[6])), r = a[5], i = a[6];
				break;
			case `Q`:
				e.push(...va(r, i, a[1], a[2], a[1], a[2], a[3], a[4])), r = a[3], i = a[4];
				break;
			case `Z`: r = t, i = n;
		}
		return wt(e);
	}
	_calcDimensions() {
		let e = this._calcBoundsFromPath();
		return {
			...e,
			pathOffset: new N(e.left + e.width / 2, e.top + e.height / 2)
		};
	}
	static fromObject(e) {
		return this._fromObject(e, { extraParam: `path` });
	}
	static async fromElement(e, t, n) {
		let { d: r, ...i } = Zi(e, this.ATTRIBUTE_NAMES, n);
		return new this(r, {
			...i,
			...t,
			left: void 0,
			top: void 0
		});
	}
};
i(Mo, `type`, `Path`), i(Mo, `cacheProperties`, [
	...Un,
	`path`,
	`fillRule`
]), i(Mo, `ATTRIBUTE_NAMES`, [...ki, `d`]), M.setClass(Mo), M.setSVGClass(Mo);
var No = class e extends jo {
	constructor(e) {
		super(e), i(this, `decimate`, .4), i(this, `drawStraightLine`, !1), i(this, `straightLineKey`, `shiftKey`), this._points = [], this._hasStraightLine = !1;
	}
	needsFullRender() {
		return super.needsFullRender() || this._hasStraightLine;
	}
	static drawSegment(e, t, n) {
		let r = t.midPointFrom(n);
		return e.quadraticCurveTo(t.x, t.y, r.x, r.y), r;
	}
	onMouseDown(e, { e: t }) {
		this.canvas._isMainEvent(t) && (this.drawStraightLine = !!this.straightLineKey && t[this.straightLineKey], this._prepareForDrawing(e), this._addPoint(e), this._render());
	}
	onMouseMove(t, { e: n }) {
		if (this.canvas._isMainEvent(n) && (this.drawStraightLine = !!this.straightLineKey && n[this.straightLineKey], (!0 !== this.limitedToCanvasSize || !this._isOutSideCanvas(t)) && this._addPoint(t) && this._points.length > 1)) if (this.needsFullRender()) this.canvas.clearContext(this.canvas.contextTop), this._render();
		else {
			let t = this._points, n = t.length, r = this.canvas.contextTop;
			this._saveAndTransform(r), this.oldEnd && (r.beginPath(), r.moveTo(this.oldEnd.x, this.oldEnd.y)), this.oldEnd = e.drawSegment(r, t[n - 2], t[n - 1]), r.stroke(), r.restore();
		}
	}
	onMouseUp({ e }) {
		return !this.canvas._isMainEvent(e) || (this.drawStraightLine = !1, this.oldEnd = void 0, this._finalizeAndAddPath(), !1);
	}
	_prepareForDrawing(e) {
		this._reset(), this._addPoint(e), this.canvas.contextTop.moveTo(e.x, e.y);
	}
	_addPoint(e) {
		return !(this._points.length > 1 && e.eq(this._points[this._points.length - 1])) && (this.drawStraightLine && this._points.length > 1 && (this._hasStraightLine = !0, this._points.pop()), this._points.push(e), !0);
	}
	_reset() {
		this._points = [], this._setBrushStyles(this.canvas.contextTop), this._setShadow(), this._hasStraightLine = !1;
	}
	_render(t = this.canvas.contextTop) {
		let n = this._points[0], r = this._points[1];
		if (this._saveAndTransform(t), t.beginPath(), this._points.length === 2 && n.x === r.x && n.y === r.y) {
			let e = this.width / 1e3;
			n.x -= e, r.x += e;
		}
		t.moveTo(n.x, n.y);
		for (let i = 1; i < this._points.length; i++) e.drawSegment(t, n, r), n = this._points[i], r = this._points[i + 1];
		t.lineTo(n.x, n.y), t.stroke(), t.restore();
	}
	convertPointsToSVGPath(e) {
		return Ra(e, this.width / 1e3);
	}
	createPath(e) {
		let t = new Mo(e, {
			fill: null,
			stroke: this.color,
			strokeWidth: this.width,
			strokeLineCap: this.strokeLineCap,
			strokeMiterLimit: this.strokeMiterLimit,
			strokeLineJoin: this.strokeLineJoin,
			strokeDashArray: this.strokeDashArray
		});
		return this.shadow && (this.shadow.affectStroke = !0, t.shadow = new Bn(this.shadow)), t;
	}
	decimatePoints(e, t) {
		if (e.length <= 2) return e;
		let n, r = e[0], i = (t / this.canvas.getZoom()) ** 2, a = e.length - 1, o = [r];
		for (let t = 1; t < a - 1; t++) n = (r.x - e[t].x) ** 2 + (r.y - e[t].y) ** 2, n >= i && (r = e[t], o.push(r));
		return o.push(e[a]), o;
	}
	_finalizeAndAddPath() {
		this.canvas.contextTop.closePath(), this.decimate && (this._points = this.decimatePoints(this._points, this.decimate));
		let e = this.convertPointsToSVGPath(this._points);
		if (function(e) {
			return Va(e) === `M 0 0 Q 0 0 0 0 L 0 0`;
		}(e)) return void this.canvas.requestRenderAll();
		let t = this.createPath(e);
		this.canvas.clearContext(this.canvas.contextTop), this.canvas.fire(`before:path:created`, { path: t }), this.canvas.add(t), this.canvas.requestRenderAll(), t.setCoords(), this._resetShadow(), this.canvas.fire(`path:created`, { path: t });
	}
};
var Po = [
	`radius`,
	`startAngle`,
	`endAngle`,
	`counterClockwise`
];
var Fo = class e extends J {
	static getDefaults() {
		return {
			...super.getDefaults(),
			...e.ownDefaults
		};
	}
	constructor(t) {
		super(), Object.assign(this, e.ownDefaults), this.setOptions(t);
	}
	_set(e, t) {
		return super._set(e, t), e === `radius` && this.setRadius(t), this;
	}
	_render(e) {
		e.beginPath(), e.arc(0, 0, this.radius, I(this.startAngle), I(this.endAngle), this.counterClockwise), this._renderPaintInOrder(e);
	}
	getRadiusX() {
		return this.get(`radius`) * this.get(de);
	}
	getRadiusY() {
		return this.get(`radius`) * this.get(fe);
	}
	setRadius(e) {
		this.radius = e, this.set({
			width: 2 * e,
			height: 2 * e
		});
	}
	toObject(e = []) {
		return super.toObject([...Po, ...e]);
	}
	_toSVG() {
		let { radius: e, startAngle: t, endAngle: n } = this, r = (n - t) % 360;
		if (r === 0) return [
			`<circle `,
			`COMMON_PARTS`,
			`cx="0" cy="0" `,
			`r="`,
			`${U(e)}`,
			`" />
`
		];
		{
			let i = I(t), a = I(n), o = Se(i) * e, s = Ce(i) * e, c = Se(a) * e, l = Ce(a) * e;
			return [
				`<path d="M ${o} ${s} A ${e} ${e} 0 ${+(r > 180)} ${+!this.counterClockwise} ${c} ${l}" `,
				`COMMON_PARTS`,
				` />
`
			];
		}
	}
	static async fromElement(e, t, n) {
		let { left: r = 0, top: i = 0, radius: a = 0, ...o } = Zi(e, this.ATTRIBUTE_NAMES, n);
		return new this({
			...o,
			radius: a,
			left: r - a,
			top: i - a
		});
	}
	static fromObject(e) {
		return super._fromObject(e);
	}
};
i(Fo, `type`, `Circle`), i(Fo, `cacheProperties`, [...Un, ...Po]), i(Fo, `ownDefaults`, {
	radius: 0,
	startAngle: 0,
	endAngle: 360,
	counterClockwise: !1
}), i(Fo, `ATTRIBUTE_NAMES`, [
	`cx`,
	`cy`,
	`r`,
	...ki
]), M.setClass(Fo), M.setSVGClass(Fo);
var zo = [
	`x1`,
	`x2`,
	`y1`,
	`y2`
];
var Bo = class e extends J {
	constructor([t, n, r, i] = [
		0,
		0,
		0,
		0
	], a = {}) {
		super(), Object.assign(this, e.ownDefaults), this.setOptions(a), this.x1 = t, this.x2 = r, this.y1 = n, this.y2 = i, this._setWidthHeight();
		let { left: o, top: s } = a;
		typeof o == `number` && this.set(`left`, o), typeof s == `number` && this.set(`top`, s);
	}
	_setWidthHeight() {
		let { x1: e, y1: t, x2: n, y2: r } = this;
		this.width = Math.abs(n - e), this.height = Math.abs(r - t);
		let { left: i, top: a, width: o, height: s } = wt([{
			x: e,
			y: t
		}, {
			x: n,
			y: r
		}]), c = new N(i + o / 2, a + s / 2);
		this.setPositionByOrigin(c, E, E);
	}
	_set(e, t) {
		return super._set(e, t), zo.includes(e) && this._setWidthHeight(), this;
	}
	_render(e) {
		e.beginPath();
		let t = this.calcLinePoints();
		e.moveTo(t.x1, t.y1), e.lineTo(t.x2, t.y2), e.lineWidth = this.strokeWidth;
		let n = e.strokeStyle;
		var r;
		V(this.stroke) ? e.strokeStyle = this.stroke.toLive(e) : e.strokeStyle = (r = this.stroke) == null ? e.fillStyle : r, this.stroke && this._renderStroke(e), e.strokeStyle = n;
	}
	_findCenterFromElement() {
		return new N((this.x1 + this.x2) / 2, (this.y1 + this.y2) / 2);
	}
	toObject(e = []) {
		return {
			...super.toObject(e),
			...this.calcLinePoints()
		};
	}
	_getNonTransformedDimensions() {
		let e = super._getNonTransformedDimensions();
		return this.strokeLineCap === `butt` && (this.width === 0 && (e.y -= this.strokeWidth), this.height === 0 && (e.x -= this.strokeWidth)), e;
	}
	calcLinePoints() {
		let { x1: e, x2: t, y1: n, y2: r, width: i, height: a } = this, o = e <= t ? -.5 : .5, s = n <= r ? -.5 : .5;
		return {
			x1: o * i,
			x2: o * -i,
			y1: s * a,
			y2: s * -a
		};
	}
	_toSVG() {
		let { x1: e, x2: t, y1: n, y2: r } = this.calcLinePoints();
		return [
			`<line `,
			`COMMON_PARTS`,
			`x1="${e}" y1="${n}" x2="${t}" y2="${r}" />\n`
		];
	}
	static async fromElement(e, t, n) {
		let { x1: r = 0, y1: i = 0, x2: a = 0, y2: o = 0, ...s } = Zi(e, this.ATTRIBUTE_NAMES, n);
		return new this([
			r,
			i,
			a,
			o
		], s);
	}
	static fromObject({ x1: e, y1: t, x2: n, y2: r, ...i }) {
		return this._fromObject({
			...i,
			points: [
				e,
				t,
				n,
				r
			]
		}, { extraParam: `points` });
	}
};
i(Bo, `type`, `Line`), i(Bo, `cacheProperties`, [...Un, ...zo]), i(Bo, `ATTRIBUTE_NAMES`, ki.concat(zo)), M.setClass(Bo), M.setSVGClass(Bo);
var Vo = class e extends J {
	static getDefaults() {
		return {
			...super.getDefaults(),
			...e.ownDefaults
		};
	}
	constructor(t) {
		super(), Object.assign(this, e.ownDefaults), this.setOptions(t);
	}
	_render(e) {
		let t = this.width / 2, n = this.height / 2;
		e.beginPath(), e.moveTo(-t, n), e.lineTo(0, -n), e.lineTo(t, n), e.closePath(), this._renderPaintInOrder(e);
	}
	_toSVG() {
		let e = this.width / 2, t = this.height / 2;
		return [
			`<polygon `,
			`COMMON_PARTS`,
			`points="`,
			`${-e} ${t},0 ${-t},${e} ${t}`,
			`" />`
		];
	}
};
i(Vo, `type`, `Triangle`), i(Vo, `ownDefaults`, {
	width: 100,
	height: 100
}), M.setClass(Vo), M.setSVGClass(Vo);
var Ho = [`rx`, `ry`];
var Uo = class e extends J {
	static getDefaults() {
		return {
			...super.getDefaults(),
			...e.ownDefaults
		};
	}
	constructor(t) {
		super(), Object.assign(this, e.ownDefaults), this.setOptions(t);
	}
	_set(e, t) {
		switch (super._set(e, t), e) {
			case `rx`:
				this.rx = t, this.set(`width`, 2 * t);
				break;
			case `ry`: this.ry = t, this.set(`height`, 2 * t);
		}
		return this;
	}
	getRx() {
		return this.get(`rx`) * this.get(de);
	}
	getRy() {
		return this.get(`ry`) * this.get(fe);
	}
	toObject(e = []) {
		return super.toObject([...Ho, ...e]);
	}
	_toSVG() {
		return [
			`<ellipse `,
			`COMMON_PARTS`,
			`cx="0" cy="0" rx="${U(this.rx)}" ry="${U(this.ry)}" />\n`
		];
	}
	_render(e) {
		e.beginPath(), e.save(), e.transform(1, 0, 0, this.ry / this.rx, 0, 0), e.arc(0, 0, this.rx, 0, w, !1), e.restore(), this._renderPaintInOrder(e);
	}
	static async fromElement(e, t, n) {
		let r = Zi(e, this.ATTRIBUTE_NAMES, n);
		return r.left = (r.left || 0) - r.rx, r.top = (r.top || 0) - r.ry, new this(r);
	}
};
i(Uo, `type`, `Ellipse`), i(Uo, `cacheProperties`, [...Un, ...Ho]), i(Uo, `ownDefaults`, {
	rx: 0,
	ry: 0
}), i(Uo, `ATTRIBUTE_NAMES`, [
	...ki,
	`cx`,
	`cy`,
	`rx`,
	`ry`
]), M.setClass(Uo), M.setSVGClass(Uo);
var Wo = { exactBoundingBox: !1 };
var Go = class e extends J {
	static getDefaults() {
		return {
			...super.getDefaults(),
			...e.ownDefaults
		};
	}
	constructor(t = [], n = {}) {
		super(), i(this, `strokeDiff`, void 0), Object.assign(this, e.ownDefaults), this.setOptions(n), this.points = t;
		let { left: r, top: a } = n;
		this.initialized = !0, this.setBoundingBox(!0), typeof r == `number` && this.set(`left`, r), typeof a == `number` && this.set(`top`, a);
	}
	isOpen() {
		return !0;
	}
	_projectStrokeOnPoints(e) {
		return wi(this.points, e, this.isOpen());
	}
	_calcDimensions(e) {
		e = {
			scaleX: this.scaleX,
			scaleY: this.scaleY,
			skewX: this.skewX,
			skewY: this.skewY,
			strokeLineCap: this.strokeLineCap,
			strokeLineJoin: this.strokeLineJoin,
			strokeMiterLimit: this.strokeMiterLimit,
			strokeUniform: this.strokeUniform,
			strokeWidth: this.strokeWidth,
			...e || {}
		};
		let t = this.exactBoundingBox ? this._projectStrokeOnPoints(e).map((e) => e.projectedPoint) : this.points;
		if (t.length === 0) return {
			left: 0,
			top: 0,
			width: 0,
			height: 0,
			pathOffset: new N(),
			strokeOffset: new N(),
			strokeDiff: new N()
		};
		let n = wt(t), r = Ye({
			...e,
			scaleX: 1,
			scaleY: 1
		}), i = wt(this.points.map((e) => L(e, r, !0))), a = new N(this.scaleX, this.scaleY), o = n.left + n.width / 2, s = n.top + n.height / 2;
		return this.exactBoundingBox && (o -= s * Math.tan(I(this.skewX)), s -= o * Math.tan(I(this.skewY))), {
			...n,
			pathOffset: new N(o, s),
			strokeOffset: new N(i.left, i.top).subtract(new N(n.left, n.top)).multiply(a),
			strokeDiff: new N(n.width, n.height).subtract(new N(i.width, i.height)).multiply(a)
		};
	}
	_findCenterFromElement() {
		let e = wt(this.points);
		return new N(e.left + e.width / 2, e.top + e.height / 2);
	}
	setDimensions() {
		this.setBoundingBox();
	}
	setBoundingBox(e) {
		let { left: t, top: n, width: r, height: i, pathOffset: a, strokeOffset: o, strokeDiff: s } = this._calcDimensions();
		this.set({
			width: r,
			height: i,
			pathOffset: a,
			strokeOffset: o,
			strokeDiff: s
		}), e && this.setPositionByOrigin(new N(t + r / 2, n + i / 2), `center`, `center`);
	}
	isStrokeAccountedForInDimensions() {
		return this.exactBoundingBox;
	}
	_getNonTransformedDimensions() {
		return this.exactBoundingBox ? new N(this.width, this.height) : super._getNonTransformedDimensions();
	}
	_getTransformedDimensions(e = {}) {
		if (this.exactBoundingBox) {
			let a;
			if (Object.keys(e).some((e) => this.strokeUniform || this.constructor.layoutProperties.includes(e))) {
				var t, n;
				let { width: r, height: i } = this._calcDimensions(e);
				a = new N((t = e.width) == null ? r : t, (n = e.height) == null ? i : n);
			} else {
				var r, i;
				a = new N((r = e.width) == null ? this.width : r, (i = e.height) == null ? this.height : i);
			}
			return a.multiply(new N(e.scaleX || this.scaleX, e.scaleY || this.scaleY));
		}
		return super._getTransformedDimensions(e);
	}
	_set(e, t) {
		let n = this.initialized && this[e] !== t, r = super._set(e, t);
		return this.exactBoundingBox && n && ((e === `scaleX` || e === `scaleY`) && this.strokeUniform && this.constructor.layoutProperties.includes(`strokeUniform`) || this.constructor.layoutProperties.includes(e)) && this.setDimensions(), r;
	}
	toObject(e = []) {
		return {
			...super.toObject(e),
			points: this.points.map(({ x: e, y: t }) => ({
				x: e,
				y: t
			}))
		};
	}
	_toSVG() {
		let e = this.pathOffset.x, t = this.pathOffset.y, n = o.NUM_FRACTION_DIGITS, r = this.points.map(({ x: r, y: i }) => `${B(r - e, n)},${B(i - t, n)}`).join(` `);
		return [
			`<${U(this.constructor.type).toLowerCase()} `,
			`COMMON_PARTS`,
			`points="${r}" />\n`
		];
	}
	_render(e) {
		let t = this.points.length, n = this.pathOffset.x, r = this.pathOffset.y;
		if (t && !isNaN(this.points[t - 1].y)) {
			e.beginPath(), e.moveTo(this.points[0].x - n, this.points[0].y - r);
			for (let i = 0; i < t; i++) {
				let t = this.points[i];
				e.lineTo(t.x - n, t.y - r);
			}
			!this.isOpen() && e.closePath(), this._renderPaintInOrder(e);
		}
	}
	complexity() {
		return this.points.length;
	}
	static async fromElement(e, t, n) {
		let r = function(e) {
			if (!e) return [];
			let t = e.replace(/,/g, ` `).trim().split(/\s+/), n = [];
			for (let e = 0; e < t.length; e += 2) n.push({
				x: parseFloat(t[e]),
				y: parseFloat(t[e + 1])
			});
			return n;
		}(e.getAttribute(`points`)), { left: i, top: a, ...o } = Zi(e, this.ATTRIBUTE_NAMES, n);
		return new this(r, {
			...o,
			...t
		});
	}
	static fromObject(e) {
		return this._fromObject(e, { extraParam: `points` });
	}
};
i(Go, `ownDefaults`, Wo), i(Go, `type`, `Polyline`), i(Go, `layoutProperties`, [
	pe,
	me,
	`strokeLineCap`,
	`strokeLineJoin`,
	`strokeMiterLimit`,
	`strokeWidth`,
	`strokeUniform`,
	`points`
]), i(Go, `cacheProperties`, [...Un, `points`]), i(Go, `ATTRIBUTE_NAMES`, [...ki]), M.setClass(Go), M.setSVGClass(Go);
var Ko = class extends Go {
	isOpen() {
		return !1;
	}
};
i(Ko, `ownDefaults`, Wo), i(Ko, `type`, `Polygon`), M.setClass(Ko), M.setSVGClass(Ko);
var qo = class extends J {
	isEmptyStyles(e) {
		if (!this.styles || e !== void 0 && !this.styles[e]) return !0;
		let t = e === void 0 ? this.styles : { line: this.styles[e] };
		for (let e in t) for (let n in t[e]) for (let r in t[e][n]) return !1;
		return !0;
	}
	styleHas(e, t) {
		if (!this.styles || t !== void 0 && !this.styles[t]) return !1;
		let n = t === void 0 ? this.styles : { 0: this.styles[t] };
		for (let t in n) for (let r in n[t]) if (n[t][r][e] !== void 0) return !0;
		return !1;
	}
	cleanStyle(e) {
		if (!this.styles) return !1;
		let t = this.styles, n, r, i = 0, a = !0, o = 0;
		for (let o in t) {
			n = 0;
			for (let s in t[o]) {
				let c = t[o][s] || {};
				i++, c[e] === void 0 ? a = !1 : (r ? c[e] !== r && (a = !1) : r = c[e], c[e] === this[e] && delete c[e]), Object.keys(c).length === 0 ? delete t[o][s] : n++;
			}
			n === 0 && delete t[o];
		}
		for (let e = 0; e < this._textLines.length; e++) o += this._textLines[e].length;
		a && i === o && (this[e] = r, this.removeStyle(e));
	}
	removeStyle(e) {
		if (!this.styles) return;
		let t = this.styles, n, r, i;
		for (r in t) {
			for (i in n = t[r], n) delete n[i][e], Object.keys(n[i]).length === 0 && delete n[i];
			Object.keys(n).length === 0 && delete t[r];
		}
	}
	_extendStyles(e, t) {
		let { lineIndex: n, charIndex: r } = this.get2DCursorLocation(e);
		this._getLineStyle(n) || this._setLineStyle(n);
		let i = tt({
			...this._getStyleDeclaration(n, r),
			...t
		}, (e) => e !== void 0);
		this._setStyleDeclaration(n, r, i);
	}
	getSelectionStyles(e, t, n) {
		let r = [];
		for (let i = e; i < (t || e); i++) r.push(this.getStyleAtPosition(i, n));
		return r;
	}
	getStyleAtPosition(e, t) {
		let { lineIndex: n, charIndex: r } = this.get2DCursorLocation(e);
		return t ? this.getCompleteStyleDeclaration(n, r) : this._getStyleDeclaration(n, r);
	}
	setSelectionStyles(e, t, n) {
		for (let r = t; r < (n || t); r++) this._extendStyles(r, e);
		this._forceClearCache = !0;
	}
	_getStyleDeclaration(e, t) {
		var n;
		let r = this.styles && this.styles[e];
		return r && (n = r[t]) != null ? n : {};
	}
	getCompleteStyleDeclaration(e, t) {
		return {
			...et(this, this.constructor._styleProperties),
			...this._getStyleDeclaration(e, t)
		};
	}
	_setStyleDeclaration(e, t, n) {
		this.styles[e][t] = n;
	}
	_deleteStyleDeclaration(e, t) {
		delete this.styles[e][t];
	}
	_getLineStyle(e) {
		return !!this.styles[e];
	}
	_setLineStyle(e) {
		this.styles[e] = {};
	}
	_deleteLineStyle(e) {
		delete this.styles[e];
	}
};
i(qo, `_styleProperties`, wn);
var Jo = /  +/g;
var Yo = /"/g;
function Xo(e, t, n, r, i) {
	return `\t\t${((e, { left: t, top: n, width: r, height: i }, a = o.NUM_FRACTION_DIGITS) => {
		let s = hn(j, e, !1), [c, l, u, d] = [
			t,
			n,
			r,
			i
		].map((e) => B(e, a));
		return `<rect ${s} x="${c}" y="${l}" width="${u}" height="${d}"></rect>`;
	})(e, {
		left: t,
		top: n,
		width: r,
		height: i
	})}\n`;
}
var Zo;
var Q = class e extends qo {
	static getDefaults() {
		return {
			...super.getDefaults(),
			...e.ownDefaults
		};
	}
	constructor(t, n) {
		super(), i(this, `__charBounds`, []), Object.assign(this, e.ownDefaults), this.setOptions(n), this.styles || (this.styles = {}), this.text = t, this.initialized = !0, this.path && this.setPathInfo(), this.initDimensions(), this.setCoords();
	}
	setPathInfo() {
		let e = this.path;
		e && (e.segmentsInfo = ja(e.path));
	}
	_splitText() {
		let e = this._splitTextIntoLines(this.text);
		return this.textLines = e.lines, this._textLines = e.graphemeLines, this._unwrappedTextLines = e._unwrappedLines, this._text = e.graphemeText, e;
	}
	initDimensions() {
		this._splitText(), this._clearCache(), this.dirty = !0, this.path ? (this.width = this.path.width, this.height = this.path.height) : (this.width = this.calcTextWidth() || this.cursorWidth || this.MIN_TEXT_WIDTH, this.height = this.calcTextHeight()), this.textAlign.includes(`justify`) && this.enlargeSpaces();
	}
	enlargeSpaces() {
		let e, t, n, r, i, a, o;
		for (let s = 0, c = this._textLines.length; s < c; s++) if ((this.textAlign === `justify` || s !== c - 1 && !this.isEndOfWrapping(s)) && (r = 0, i = this._textLines[s], t = this.getLineWidth(s), t < this.width && (o = this.textLines[s].match(this._reSpacesAndTabs)))) {
			n = o.length, e = (this.width - t) / n;
			for (let t = 0; t <= i.length; t++) a = this.__charBounds[s][t], this._reSpaceAndTab.test(i[t]) ? (a.width += e, a.kernedWidth += e, a.left += r, r += e) : a.left += r;
		}
	}
	isEndOfWrapping(e) {
		return e === this._textLines.length - 1;
	}
	missingNewlineOffset(e) {
		return 1;
	}
	get2DCursorLocation(e, t) {
		let n = t ? this._unwrappedTextLines : this._textLines, r;
		for (r = 0; r < n.length; r++) {
			if (e <= n[r].length) return {
				lineIndex: r,
				charIndex: e
			};
			e -= n[r].length + this.missingNewlineOffset(r, t);
		}
		return {
			lineIndex: r - 1,
			charIndex: n[r - 1].length < e ? n[r - 1].length : e
		};
	}
	toString() {
		return `#<Text (${this.complexity()}): { "text": "${this.text}", "fontFamily": "${this.fontFamily}" }>`;
	}
	_getCacheCanvasDimensions() {
		let e = super._getCacheCanvasDimensions(), t = this.fontSize;
		return e.width += t * e.zoomX, e.height += t * e.zoomY, e;
	}
	_render(e) {
		let t = this.path;
		t && !t.isNotVisible() && t._render(e), this._setTextStyles(e), this._renderTextLinesBackground(e), this._renderTextDecoration(e, `underline`), this._renderText(e), this._renderTextDecoration(e, `overline`), this._renderTextDecoration(e, `linethrough`);
	}
	_renderText(e) {
		this.paintFirst === `stroke` ? (this._renderTextStroke(e), this._renderTextFill(e)) : (this._renderTextFill(e), this._renderTextStroke(e));
	}
	_setTextStyles(e, t, n) {
		if (e.textBaseline = `alphabetic`, this.path) switch (this.pathAlign) {
			case E:
				e.textBaseline = `middle`;
				break;
			case `ascender`:
				e.textBaseline = `top`;
				break;
			case `descender`: e.textBaseline = O;
		}
		e.font = this._getFontDeclaration(t, n);
	}
	calcTextWidth() {
		let e = this.getLineWidth(0);
		for (let t = 1, n = this._textLines.length; t < n; t++) {
			let n = this.getLineWidth(t);
			n > e && (e = n);
		}
		return e;
	}
	_renderTextLine(e, t, n, r, i, a) {
		this._renderChars(e, t, n, r, i, a);
	}
	_renderTextLinesBackground(e) {
		if (!this.textBackgroundColor && !this.styleHas(`textBackgroundColor`)) return;
		let t = e.fillStyle, n = this._getLeftOffset(), r = this._getTopOffset();
		for (let t = 0, i = this._textLines.length; t < i; t++) {
			let i = this.getHeightOfLine(t);
			if (!this.textBackgroundColor && !this.styleHas(`textBackgroundColor`, t)) {
				r += i;
				continue;
			}
			let a = this._textLines[t].length, o = this._getLineLeftOffset(t), s, c, l = 0, u = 0, d = this.getValueOfPropertyAt(t, 0, `textBackgroundColor`), f = this.getHeightOfLineImpl(t);
			for (let i = 0; i < a; i++) {
				let a = this.__charBounds[t][i];
				c = this.getValueOfPropertyAt(t, i, `textBackgroundColor`), this.path ? (e.save(), e.translate(a.renderLeft, a.renderTop), e.rotate(a.angle), e.fillStyle = c, c && e.fillRect(-a.width / 2, -f * (1 - this._fontSizeFraction), a.width, f), e.restore()) : c === d ? l += a.kernedWidth : (s = n + o + u, this.direction === `rtl` && (s = this.width - s - l), e.fillStyle = d, d && e.fillRect(s, r, l, f), u = a.left, l = a.width, d = c);
			}
			c && !this.path && (s = n + o + u, this.direction === `rtl` && (s = this.width - s - l), e.fillStyle = c, e.fillRect(s, r, l, f)), r += i;
		}
		e.fillStyle = t, this._removeShadow(e);
	}
	_measureChar(e, t, n, r) {
		let i = y.getFontCache(t), a = this._getFontDeclaration(t), o = n ? n + e : e, s = n && a === this._getFontDeclaration(r), c = t.fontSize / this.CACHE_FONT_SIZE, l, u, d, f;
		if (n && i.has(n) && (d = i.get(n)), i.has(e) && (f = l = i.get(e)), s && i.has(o) && (u = i.get(o), f = u - d), l === void 0 || d === void 0 || u === void 0) {
			let r = (Zo || (Zo = F({
				width: 0,
				height: 0
			}).getContext(`2d`)), Zo);
			this._setTextStyles(r, t, !0), l === void 0 && (f = l = r.measureText(e).width, i.set(e, l)), d === void 0 && s && n && (d = r.measureText(n).width, i.set(n, d)), s && u === void 0 && (u = r.measureText(o).width, i.set(o, u), f = u - d);
		}
		return {
			width: l * c,
			kernedWidth: f * c
		};
	}
	getHeightOfChar(e, t) {
		return this.getValueOfPropertyAt(e, t, `fontSize`);
	}
	measureLine(e) {
		let t = this._measureLine(e);
		return this.charSpacing !== 0 && (t.width -= this._getWidthOfCharSpacing()), t.width < 0 && (t.width = 0), t;
	}
	_measureLine(e) {
		let t, n, r = 0, i = this.pathSide === k, a = this.path, o = this._textLines[e], s = o.length, c = Array(s);
		this.__charBounds[e] = c;
		for (let i = 0; i < s; i++) {
			let a = o[i];
			n = this._getGraphemeBox(a, e, i, t), c[i] = n, r += n.kernedWidth, t = a;
		}
		if (c[s] = {
			left: n ? n.left + n.width : 0,
			width: 0,
			kernedWidth: 0,
			height: this.fontSize,
			deltaY: 0
		}, a && a.segmentsInfo) {
			let e = 0, t = a.segmentsInfo[a.segmentsInfo.length - 1].length;
			switch (this.textAlign) {
				case D:
					e = i ? t - r : 0;
					break;
				case E:
					e = (t - r) / 2;
					break;
				case k: e = i ? 0 : t - r;
			}
			e += this.pathStartOffset * (i ? -1 : 1);
			for (let r = i ? s - 1 : 0; i ? r >= 0 : r < s; i ? r-- : r++) n = c[r], e > t ? e %= t : e < 0 && (e += t), this._setGraphemeOnPath(e, n), e += n.kernedWidth;
		}
		return {
			width: r,
			numOfSpaces: 0
		};
	}
	_setGraphemeOnPath(e, t) {
		let n = e + t.kernedWidth / 2, r = this.path, i = Ma(r.path, n, r.segmentsInfo);
		t.renderLeft = i.x - r.pathOffset.x, t.renderTop = i.y - r.pathOffset.y, t.angle = i.angle + (this.pathSide === `right` ? Math.PI : 0);
	}
	_getGraphemeBox(e, t, n, r, i) {
		let a = this.getCompleteStyleDeclaration(t, n), o = r ? this.getCompleteStyleDeclaration(t, n - 1) : {}, s = this._measureChar(e, a, r, o), c, l = s.kernedWidth, u = s.width;
		this.charSpacing !== 0 && (c = this._getWidthOfCharSpacing(), u += c, l += c);
		let d = {
			width: u,
			left: 0,
			height: a.fontSize,
			kernedWidth: l,
			deltaY: a.deltaY
		};
		if (n > 0 && !i) {
			let e = this.__charBounds[t][n - 1];
			d.left = e.left + e.width + s.kernedWidth - s.width;
		}
		return d;
	}
	getHeightOfLineImpl(e) {
		let t = this.__lineHeights;
		if (t[e]) return t[e];
		let n = this.getHeightOfChar(e, 0);
		for (let t = 1, r = this._textLines[e].length; t < r; t++) n = Math.max(this.getHeightOfChar(e, t), n);
		return t[e] = n * this._fontSizeMult;
	}
	getHeightOfLine(e) {
		return this.getHeightOfLineImpl(e) * this.lineHeight;
	}
	calcTextHeight() {
		let e = 0;
		for (let t = 0, n = this._textLines.length; t < n; t++) e += t === n - 1 ? this.getHeightOfLineImpl(t) : this.getHeightOfLine(t);
		return e;
	}
	_getLeftOffset() {
		return this.direction === `ltr` ? -this.width / 2 : this.width / 2;
	}
	_getTopOffset() {
		return -this.height / 2;
	}
	_renderTextCommon(e, t) {
		e.save();
		let n = 0, r = this._getLeftOffset(), i = this._getTopOffset();
		for (let a = 0, o = this._textLines.length; a < o; a++) this._renderTextLine(t, e, this._textLines[a], r + this._getLineLeftOffset(a), i + n + this.getHeightOfLineImpl(a), a), n += this.getHeightOfLine(a);
		e.restore();
	}
	_renderTextFill(e) {
		(this.fill || this.styleHas(`fill`)) && this._renderTextCommon(e, `fillText`);
	}
	_renderTextStroke(e) {
		(this.stroke && this.strokeWidth !== 0 || !this.isEmptyStyles()) && (this.shadow && !this.shadow.affectStroke && this._removeShadow(e), e.save(), this._setLineDash(e, this.strokeDashArray), e.beginPath(), this._renderTextCommon(e, `strokeText`), e.closePath(), e.restore());
	}
	_renderChars(e, t, n, r, i, a) {
		let o = this.textAlign.includes(En), s = this.path, c = !o && this.charSpacing === 0 && this.isEmptyStyles(a) && !s, l = this.direction === `ltr`, u = this.direction === `ltr` ? 1 : -1, d = t.direction, f, p, m, h, g, _ = ``, v = 0;
		if (t.save(), d !== this.direction && (t.canvas.setAttribute(`dir`, l ? `ltr` : `rtl`), t.direction = l ? `ltr` : `rtl`, t.textAlign = l ? D : k), i -= this.getHeightOfLineImpl(a) * this._fontSizeFraction, c) return this._renderChar(e, t, a, 0, n.join(``), r, i), void t.restore();
		for (let c = 0, l = n.length - 1; c <= l; c++) h = c === l || this.charSpacing || s, _ += n[c], m = this.__charBounds[a][c], v === 0 ? (r += u * (m.kernedWidth - m.width), v += m.width) : v += m.kernedWidth, o && !h && this._reSpaceAndTab.test(n[c]) && (h = !0), h || (f = f || this.getCompleteStyleDeclaration(a, c), p = this.getCompleteStyleDeclaration(a, c + 1), h = Ei(f, p, !1)), h && (s ? (t.save(), t.translate(m.renderLeft, m.renderTop), t.rotate(m.angle), this._renderChar(e, t, a, c, _, -v / 2, 0), t.restore()) : (g = r, this._renderChar(e, t, a, c, _, g, i)), _ = ``, f = p, r += u * v, v = 0);
		t.restore();
	}
	_applyPatternGradientTransformText(e) {
		let t = this.width + this.strokeWidth, n = this.height + this.strokeWidth, r = F({
			width: t,
			height: n
		}), i = r.getContext(`2d`);
		return r.width = t, r.height = n, i.beginPath(), i.moveTo(0, 0), i.lineTo(t, 0), i.lineTo(t, n), i.lineTo(0, n), i.closePath(), i.translate(t / 2, n / 2), i.fillStyle = e.toLive(i), this._applyPatternGradientTransform(i, e), i.fill(), i.createPattern(r, `no-repeat`);
	}
	handleFiller(e, t, n) {
		let r, i;
		return V(n) ? n.gradientUnits === `percentage` || n.gradientTransform || n.patternTransform ? (r = -this.width / 2, i = -this.height / 2, e.translate(r, i), e[t] = this._applyPatternGradientTransformText(n), {
			offsetX: r,
			offsetY: i
		}) : (e[t] = n.toLive(e), this._applyPatternGradientTransform(e, n)) : (e[t] = n, {
			offsetX: 0,
			offsetY: 0
		});
	}
	_setStrokeStyles(e, { stroke: t, strokeWidth: n }) {
		return e.lineWidth = n, e.lineCap = this.strokeLineCap, e.lineDashOffset = this.strokeDashOffset, e.lineJoin = this.strokeLineJoin, e.miterLimit = this.strokeMiterLimit, this.handleFiller(e, `strokeStyle`, t);
	}
	_setFillStyles(e, { fill: t }) {
		return this.handleFiller(e, `fillStyle`, t);
	}
	_renderChar(e, t, n, r, i, a, o) {
		let s = this._getStyleDeclaration(n, r), c = this.getCompleteStyleDeclaration(n, r), l = e === `fillText` && c.fill, u = e === `strokeText` && c.stroke && c.strokeWidth;
		if (u || l) {
			if (t.save(), t.font = this._getFontDeclaration(c), s.textBackgroundColor && this._removeShadow(t), s.deltaY && (o += s.deltaY), l) {
				let e = this._setFillStyles(t, c);
				t.fillText(i, a - e.offsetX, o - e.offsetY);
			}
			if (u) {
				let e = this._setStrokeStyles(t, c);
				t.strokeText(i, a - e.offsetX, o - e.offsetY);
			}
			t.restore();
		}
	}
	setSuperscript(e, t) {
		this._setScript(e, t, this.superscript);
	}
	setSubscript(e, t) {
		this._setScript(e, t, this.subscript);
	}
	_setScript(e, t, n) {
		let r = this.get2DCursorLocation(e, !0), i = this.getValueOfPropertyAt(r.lineIndex, r.charIndex, `fontSize`), a = this.getValueOfPropertyAt(r.lineIndex, r.charIndex, `deltaY`), o = {
			fontSize: i * n.size,
			deltaY: a + i * n.baseline
		};
		this.setSelectionStyles(o, e, t);
	}
	_getLineLeftOffset(e) {
		let t = this.getLineWidth(e), n = this.width - t, r = this.textAlign, i = this.direction, a = this.isEndOfWrapping(e), o = 0;
		return r === `justify` || r === `justify-center` && !a || r === `justify-right` && !a || r === `justify-left` && !a ? 0 : (r === `center` && (o = n / 2), r === `right` && (o = n), r === `justify-center` && (o = n / 2), r === `justify-right` && (o = n), i === `rtl` && (r === `right` || r === `justify-right` ? o = 0 : r === `left` || r === `justify-left` ? o = -n : r !== `center` && r !== `justify-center` || (o = -n / 2)), o);
	}
	_clearCache() {
		this._forceClearCache = !1, this.__lineWidths = [], this.__lineHeights = [], this.__charBounds = [];
	}
	getLineWidth(e) {
		if (this.__lineWidths[e] !== void 0) return this.__lineWidths[e];
		let { width: t } = this.measureLine(e);
		return this.__lineWidths[e] = t, t;
	}
	_getWidthOfCharSpacing() {
		return this.charSpacing === 0 ? 0 : this.fontSize * this.charSpacing / 1e3;
	}
	getValueOfPropertyAt(e, t, n) {
		var r;
		return (r = this._getStyleDeclaration(e, t)[n]) == null ? this[n] : r;
	}
	_renderTextDecoration(e, t) {
		if (!this[t] && !this.styleHas(t)) return;
		let n = this._getTopOffset(), r = this._getLeftOffset(), i = this.path, a = this._getWidthOfCharSpacing(), o = t === `linethrough` ? .5 : +(t === `overline`), s = this.offsets[t];
		for (let c = 0, l = this._textLines.length; c < l; c++) {
			let l = this.getHeightOfLine(c);
			if (!this[t] && !this.styleHas(t, c)) {
				n += l;
				continue;
			}
			let u = this._textLines[c], d = l / this.lineHeight, f = this._getLineLeftOffset(c), p, m = 0, h = 0, g = this.getValueOfPropertyAt(c, 0, t), _ = this.getValueOfPropertyAt(c, 0, j), v = this.getValueOfPropertyAt(c, 0, `textDecorationColor`) || _, y = this.getValueOfPropertyAt(c, 0, vn), b = g, x = v, S = y, C = n + d * (1 - this._fontSizeFraction), w = this.getHeightOfChar(c, 0), ee = this.getValueOfPropertyAt(c, 0, `deltaY`);
			for (let n = 0, a = u.length; n < a; n++) {
				let a = this.__charBounds[c][n];
				b = this.getValueOfPropertyAt(c, n, t), p = this.getValueOfPropertyAt(c, n, j), x = this.getValueOfPropertyAt(c, n, `textDecorationColor`) || p, S = this.getValueOfPropertyAt(c, n, vn);
				let l = this.getHeightOfChar(c, n), u = this.getValueOfPropertyAt(c, n, `deltaY`);
				if (i && b && p) {
					let t = this.fontSize * S / 1e3;
					e.save(), e.fillStyle = x, e.translate(a.renderLeft, a.renderTop), e.rotate(a.angle), e.fillRect(-a.kernedWidth / 2, s * l + u - o * t, a.kernedWidth, t), e.restore();
				} else if ((b !== g || p !== _ || x !== v || l !== w || S !== y || u !== ee) && h > 0) {
					let t = this.fontSize * y / 1e3, n = r + f + m;
					this.direction === `rtl` && (n = this.width - n - h), g && v && y && (e.fillStyle = v, e.fillRect(n, C + s * w + ee - o * t, h, t)), m = a.left, h = a.width, g = b, v = x, y = S, _ = p, w = l, ee = u;
				} else h += a.kernedWidth;
			}
			let T = r + f + m;
			this.direction === `rtl` && (T = this.width - T - h), e.fillStyle = x;
			let E = this.fontSize * S / 1e3;
			b && x && S && e.fillRect(T, C + s * w + ee - o * E, h - a, E), n += l;
		}
		this._removeShadow(e);
	}
	_getFontDeclaration({ fontFamily: t = this.fontFamily, fontStyle: n = this.fontStyle, fontWeight: r = this.fontWeight, fontSize: i = this.fontSize } = {}, a) {
		let o = t.includes(`'`) || t.includes(`"`) || t.includes(`,`) || e.genericFonts.includes(t.toLowerCase()) ? t : `"${t}"`;
		return [
			n,
			r,
			`${a ? this.CACHE_FONT_SIZE : i}px`,
			o
		].join(` `);
	}
	render(e) {
		this.visible && (this.canvas && this.canvas.skipOffscreen && !this.group && !this.isOnScreen() || (this._forceClearCache && this.initDimensions(), super.render(e)));
	}
	graphemeSplit(e) {
		return gt(e);
	}
	_splitTextIntoLines(e) {
		let t = e.split(this._reNewline), n = Array(t.length), r = [`
`], i = [];
		for (let e = 0; e < t.length; e++) n[e] = this.graphemeSplit(t[e]), i = i.concat(n[e], r);
		return i.pop(), {
			_unwrappedLines: n,
			lines: t,
			graphemeText: i,
			graphemeLines: n
		};
	}
	toObject(e = []) {
		return {
			...super.toObject([...Cn, ...e]),
			styles: Di(this.styles, this.text),
			...this.path ? { path: this.path.toObject() } : {}
		};
	}
	set(e, t) {
		let { textLayoutProperties: n } = this.constructor;
		super.set(e, t);
		let r = !1, i = !1;
		if (typeof e == `object`) for (let t in e) t === `path` && this.setPathInfo(), r = r || n.includes(t), i = i || t === `path`;
		else r = n.includes(e), i = e === `path`;
		return i && this.setPathInfo(), r && this.initialized && (this.initDimensions(), this.setCoords()), this;
	}
	complexity() {
		return 1;
	}
	static async fromElement(t, n, r) {
		let i = Zi(t, e.ATTRIBUTE_NAMES, r), { textAnchor: a = D, textDecoration: o = ``, dx: s = 0, dy: c = 0, top: l = 0, left: u = 0, fontSize: d = 16, strokeWidth: f = 1, ...p } = {
			...n,
			...i
		}, m = new this(on(t.textContent || ``).trim(), {
			left: u + s,
			top: l + c,
			underline: o.includes(`underline`),
			overline: o.includes(`overline`),
			linethrough: o.includes(`line-through`),
			strokeWidth: 0,
			fontSize: d,
			...p
		}), h = m.getScaledHeight() / m.height, g = ((m.height + m.strokeWidth) * m.lineHeight - m.height) * h, _ = m.getScaledHeight() + g, v = 0;
		return a === `center` && (v = m.getScaledWidth() / 2), a === `right` && (v = m.getScaledWidth()), m.set({
			left: m.left - v,
			top: m.top - (_ - m.fontSize * (.07 + m._fontSizeFraction)) / m.lineHeight,
			strokeWidth: f
		}), m;
	}
	static fromObject(e) {
		return this._fromObject({
			...e,
			styles: Oi(e.styles || {}, e.text)
		}, { extraParam: `text` });
	}
};
i(Q, `textLayoutProperties`, Sn), i(Q, `cacheProperties`, [...Un, ...Cn]), i(Q, `ownDefaults`, Tn), i(Q, `type`, `Text`), i(Q, `genericFonts`, [
	`serif`,
	`sans-serif`,
	`monospace`,
	`cursive`,
	`fantasy`,
	`system-ui`,
	`ui-serif`,
	`ui-sans-serif`,
	`ui-monospace`,
	`ui-rounded`,
	`math`,
	`emoji`,
	`fangsong`
]), i(Q, `ATTRIBUTE_NAMES`, ki.concat(`x`, `y`, `dx`, `dy`, `font-family`, `font-style`, `font-weight`, `font-size`, `letter-spacing`, `text-decoration`, `text-decoration-thickness`, `text-decoration-color`, `text-anchor`)), vi(Q, [class extends gn {
	_toSVG() {
		let e = this._getSVGLeftTopOffsets(), t = this._getSVGTextAndBg(e.textTop, e.textLeft);
		return this._wrapSVGTextAndBg(t);
	}
	toSVG(e) {
		let t = this._createBaseSVGMarkup(this._toSVG(), {
			reviver: e,
			noStyle: !0,
			withShadow: !0
		}), n = this.path;
		return n ? t + n._createBaseSVGMarkup(n._toSVG(), {
			reviver: e,
			withShadow: !0,
			additionalTransform: nt(this.calcOwnMatrix())
		}) : t;
	}
	_getSVGLeftTopOffsets() {
		return {
			textLeft: -this.width / 2,
			textTop: -this.height / 2,
			lineTop: this.getHeightOfLine(0)
		};
	}
	_wrapSVGTextAndBg({ textBgRects: e, textSpans: t }) {
		let n = this.getSvgTextDecoration(this);
		return [
			e.join(``),
			`		<text xml:space="preserve" `,
			`font-family="${U(this.fontFamily.replace(Yo, `'`))}" `,
			`font-size="${U(this.fontSize)}" `,
			this.fontStyle ? `font-style="${U(this.fontStyle)}" ` : ``,
			this.fontWeight ? `font-weight="${U(this.fontWeight)}" ` : ``,
			n ? `text-decoration="${n}" ` : ``,
			this.direction === `rtl` ? `direction="rtl" ` : ``,
			`style="`,
			this.getSvgStyles(!0),
			`"`,
			this.addPaintOrder(),
			` >`,
			t.join(``),
			`</text>
`
		];
	}
	_getSVGTextAndBg(e, t) {
		let n = [], r = [], i, a = e;
		this.backgroundColor && r.push(Xo(this.backgroundColor, -this.width / 2, -this.height / 2, this.width, this.height));
		for (let e = 0, o = this._textLines.length; e < o; e++) i = this._getLineLeftOffset(e), this.direction === `rtl` && (i += this.width), (this.textBackgroundColor || this.styleHas(`textBackgroundColor`, e)) && this._setSVGTextLineBg(r, e, t + i, a), this._setSVGTextLineText(n, e, t + i, a), a += this.getHeightOfLine(e);
		return {
			textSpans: n,
			textBgRects: r
		};
	}
	_createTextCharSpan(e, t, n, r, i) {
		let a = o.NUM_FRACTION_DIGITS, s = this.getSvgSpanStyles(t, e !== e.trim() || !!e.match(Jo)), c = s ? `style="${s}"` : ``, l = t.deltaY, u = l ? ` dy="${B(l, a)}" ` : ``, { angle: d, renderLeft: f, renderTop: p, width: m } = i, h = ``;
		if (f !== void 0) {
			let e = m / 2;
			d && (h = ` rotate="${B(Ie(d), a)}"`);
			let t = We({ angle: Ie(d) });
			t[4] = f, t[5] = p;
			let i = new N(-e, 0).transform(t);
			n = i.x, r = i.y;
		}
		return `<tspan x="${B(n, a)}" y="${B(r, a)}" ${u}${h}${c}>${U(e)}</tspan>`;
	}
	_setSVGTextLineText(e, t, n, r) {
		let i = this.getHeightOfLine(t), a = this.textAlign.includes(En), o = this._textLines[t], s, c, l, u, d, f = ``, p = 0;
		r += i * (1 - this._fontSizeFraction) / this.lineHeight;
		for (let i = 0, m = o.length - 1; i <= m; i++) d = i === m || this.charSpacing || this.path, f += o[i], l = this.__charBounds[t][i], p === 0 ? (n += l.kernedWidth - l.width, p += l.width) : p += l.kernedWidth, a && !d && this._reSpaceAndTab.test(o[i]) && (d = !0), d || (s = s || this.getCompleteStyleDeclaration(t, i), c = this.getCompleteStyleDeclaration(t, i + 1), d = Ei(s, c, !0)), d && (u = this._getStyleDeclaration(t, i), e.push(this._createTextCharSpan(f, u, n, r, l)), f = ``, s = c, this.direction === `rtl` ? n -= p : n += p, p = 0);
	}
	_setSVGTextLineBg(e, t, n, r) {
		let i = this._textLines[t], a = this.getHeightOfLine(t) / this.lineHeight, o, s = 0, c = 0, l = this.getValueOfPropertyAt(t, 0, `textBackgroundColor`);
		for (let u = 0; u < i.length; u++) {
			let { left: i, width: d, kernedWidth: f } = this.__charBounds[t][u];
			o = this.getValueOfPropertyAt(t, u, `textBackgroundColor`), o === l ? s += f : (l && e.push(Xo(l, n + c, r, s, a)), c = i, s = d, l = o);
		}
		o && e.push(Xo(l, n + c, r, s, a));
	}
	getSvgStyles(e) {
		let t = nn(this.textDecorationColor) ? ` text-decoration-color: ${U(this[yn])};` : ``;
		return `${super.getSvgStyles(e)} text-decoration-thickness: ${B(this.textDecorationThickness * this.getObjectScaling().y / 10, o.NUM_FRACTION_DIGITS)}%;${t} white-space: pre;`;
	}
	getSvgSpanStyles(e, t) {
		let { fontFamily: n, strokeWidth: r, stroke: i, fill: a, fontSize: s, fontStyle: c, fontWeight: l, textDecorationThickness: u, textDecorationColor: d, linethrough: f, overline: p, underline: m } = e, h = this.getSvgTextDecoration({
			underline: m == null ? this.underline : m,
			overline: p == null ? this.overline : p,
			linethrough: f == null ? this.linethrough : f
		}), g = u || this.textDecorationThickness, _ = d || this.textDecorationColor, v = rn(r), y = an(n), b = rn(s), x = an(c), S = rn(l) || an(l), C = an(_);
		return [
			i ? hn(he, i) : ``,
			v ? `stroke-width: ${U(v)}; ` : ``,
			y ? `font-family: ${y.includes(`'`) || y.includes(`"`) ? U(y) : `'${U(y)}'`}; ` : ``,
			b ? `font-size: ${U(b)}px; ` : ``,
			x ? `font-style: ${U(x)}; ` : ``,
			S ? `font-weight: ${U(S)}; ` : ``,
			h ? `text-decoration: ${h}; text-decoration-thickness: ${B(g * this.getObjectScaling().y / 10, o.NUM_FRACTION_DIGITS)}%;${C ? ` text-decoration-color: ${U(C)};` : ``} ` : ``,
			a ? hn(j, a) : ``,
			t ? `white-space: pre; ` : ``
		].join(``);
	}
	getSvgTextDecoration(e) {
		return [
			`overline`,
			`underline`,
			`line-through`
		].filter((t) => e[t.replace(`-`, ``)]).join(` `);
	}
}]), M.setClass(Q), M.setSVGClass(Q);
var Qo = class {
	constructor(e) {
		i(this, `target`, void 0), i(this, `__mouseDownInPlace`, !1), i(this, `__dragStartFired`, !1), i(this, `__isDraggingOver`, !1), i(this, `__dragStartSelection`, void 0), i(this, `__dragImageDisposer`, void 0), i(this, `_dispose`, void 0), this.target = e;
		let t = [
			this.target.on(`dragenter`, this.dragEnterHandler.bind(this)),
			this.target.on(`dragover`, this.dragOverHandler.bind(this)),
			this.target.on(`dragleave`, this.dragLeaveHandler.bind(this)),
			this.target.on(`dragend`, this.dragEndHandler.bind(this)),
			this.target.on(`drop`, this.dropHandler.bind(this))
		];
		this._dispose = () => {
			t.forEach((e) => e()), this._dispose = void 0;
		};
	}
	isPointerOverSelection(e) {
		let t = this.target, n = t.getSelectionStartFromPointer(e);
		return t.isEditing && n >= t.selectionStart && n <= t.selectionEnd && t.selectionStart < t.selectionEnd;
	}
	start(e) {
		return this.__mouseDownInPlace = this.isPointerOverSelection(e);
	}
	isActive() {
		return this.__mouseDownInPlace;
	}
	end(e) {
		let t = this.isActive();
		return t && !this.__dragStartFired && (this.target.setCursorByClick(e), this.target.initDelayedCursor(!0)), this.__mouseDownInPlace = !1, this.__dragStartFired = !1, this.__isDraggingOver = !1, t;
	}
	getDragStartSelection() {
		return this.__dragStartSelection;
	}
	setDragImage(e, { selectionStart: t, selectionEnd: n }) {
		var r;
		let i = this.target, a = i.canvas, o = new N(i.flipX ? -1 : 1, i.flipY ? -1 : 1), s = i._getCursorBoundaries(t), c = new N(s.left + s.leftOffset, s.top + s.topOffset).multiply(o).transform(i.calcTransformMatrix()), l = a.getScenePoint(e).subtract(c), u = i.getCanvasRetinaScaling(), d = i.getBoundingRect(), f = c.subtract(new N(d.left, d.top)), p = a.viewportTransform, m = f.add(l).transform(p, !0), h = i.backgroundColor, g = Ti(i.styles);
		i.backgroundColor = ``;
		let _ = {
			stroke: `transparent`,
			fill: `transparent`,
			textBackgroundColor: `transparent`
		};
		i.setSelectionStyles(_, 0, t), i.setSelectionStyles(_, n, i.text.length), i.dirty = !0;
		let v = i.toCanvasElement({
			enableRetinaScaling: a.enableRetinaScaling,
			viewportTransform: !0
		});
		i.backgroundColor = h, i.styles = g, i.dirty = !0, Ka(v, {
			position: `fixed`,
			left: -v.width + `px`,
			border: te,
			width: v.width / u + `px`,
			height: v.height / u + `px`
		}), this.__dragImageDisposer && this.__dragImageDisposer(), this.__dragImageDisposer = () => {
			v.remove();
		}, H(e.target || this.target.hiddenTextarea).body.appendChild(v), (r = e.dataTransfer) == null || r.setDragImage(v, m.x, m.y);
	}
	onDragStart(e) {
		this.__dragStartFired = !0;
		let t = this.target, n = this.isActive();
		if (n && e.dataTransfer) {
			let n = this.__dragStartSelection = {
				selectionStart: t.selectionStart,
				selectionEnd: t.selectionEnd
			}, r = t._text.slice(n.selectionStart, n.selectionEnd).join(``), i = {
				text: t.text,
				value: r,
				...n
			};
			e.dataTransfer.setData(`text/plain`, r), e.dataTransfer.setData(`application/fabric`, JSON.stringify({
				value: r,
				styles: t.getSelectionStyles(n.selectionStart, n.selectionEnd, !0)
			})), e.dataTransfer.effectAllowed = `copyMove`, this.setDragImage(e, i);
		}
		return t.abortCursorAnimation(), n;
	}
	canDrop(e) {
		if (this.target.editable && !this.target.getActiveControl() && !e.defaultPrevented) {
			if (this.isActive() && this.__dragStartSelection) {
				let t = this.target.getSelectionStartFromPointer(e), n = this.__dragStartSelection;
				return t < n.selectionStart || t > n.selectionEnd;
			}
			return !0;
		}
		return !1;
	}
	targetCanDrop(e) {
		return this.target.canDrop(e);
	}
	dragEnterHandler({ e }) {
		let t = this.targetCanDrop(e);
		!this.__isDraggingOver && t && (this.__isDraggingOver = !0);
	}
	dragOverHandler(e) {
		let { e: t } = e, n = this.targetCanDrop(t);
		!this.__isDraggingOver && n ? this.__isDraggingOver = !0 : this.__isDraggingOver && !n && (this.__isDraggingOver = !1), this.__isDraggingOver && (t.preventDefault(), e.canDrop = !0, e.dropTarget = this.target);
	}
	dragLeaveHandler() {
		(this.__isDraggingOver || this.isActive()) && (this.__isDraggingOver = !1);
	}
	dropHandler(e) {
		var t;
		let { e: n } = e, r = n.defaultPrevented;
		this.__isDraggingOver = !1, n.preventDefault();
		let i = (t = n.dataTransfer) == null ? void 0 : t.getData(`text/plain`);
		if (i && !r) {
			let t = this.target, r = t.canvas, a = t.getSelectionStartFromPointer(n), { styles: o } = n.dataTransfer.types.includes(`application/fabric`) ? JSON.parse(n.dataTransfer.getData(`application/fabric`)) : {}, s = i[Math.max(0, i.length - 1)];
			if (this.__dragStartSelection) {
				let e = this.__dragStartSelection.selectionStart, n = this.__dragStartSelection.selectionEnd;
				a > e && a <= n ? a = e : a > n && (a -= n - e), t.removeChars(e, n), delete this.__dragStartSelection;
			}
			t._reNewline.test(s) && (t._reNewline.test(t._text[a]) || a === t._text.length) && (i = i.trimEnd()), e.didDrop = !0, e.dropTarget = t, t.insertChars(i, o, a), r.setActiveObject(t), t.enterEditing(n), t.selectionStart = Math.min(a + 0, t._text.length), t.selectionEnd = Math.min(t.selectionStart + i.length, t._text.length), t.hiddenTextarea.value = t.text, t._updateTextarea(), t.hiddenTextarea.focus(), t.fire(le, {
				index: a + 0,
				action: `drop`
			}), r.fire(`text:changed`, { target: t }), r.contextTopDirty = !0, r.requestRenderAll();
		}
	}
	dragEndHandler({ e }) {
		if (this.isActive() && this.__dragStartFired && this.__dragStartSelection) {
			var t;
			let n = this.target, r = this.target.canvas, { selectionStart: i, selectionEnd: a } = this.__dragStartSelection, o = ((t = e.dataTransfer) == null ? void 0 : t.dropEffect) || `none`;
			o === `none` ? (n.selectionStart = i, n.selectionEnd = a, n._updateTextarea(), n.hiddenTextarea.focus()) : (n.clearContextTop(), o === `move` && (n.removeChars(i, a), n.selectionStart = n.selectionEnd = i, n.hiddenTextarea && (n.hiddenTextarea.value = n.text), n._updateTextarea(), n.fire(le, {
				index: i,
				action: `dragend`
			}), r.fire(`text:changed`, { target: n }), r.requestRenderAll()), n.exitEditing());
		}
		this.__dragImageDisposer && this.__dragImageDisposer(), delete this.__dragImageDisposer, delete this.__dragStartSelection, this.__isDraggingOver = !1;
	}
	dispose() {
		this._dispose && this._dispose();
	}
};
var $o = /[ \n\.,;!\?\-]/;
var es = class extends Q {
	constructor(...e) {
		super(...e), i(this, `_currentCursorOpacity`, 1);
	}
	initBehavior() {
		this._tick = this._tick.bind(this), this._onTickComplete = this._onTickComplete.bind(this), this.updateSelectionOnMouseMove = this.updateSelectionOnMouseMove.bind(this);
	}
	onDeselect(e) {
		return this.isEditing && this.exitEditing(), this.selected = !1, super.onDeselect(e);
	}
	_animateCursor({ toValue: e, duration: t, delay: n, onComplete: r }) {
		return Mr({
			startValue: this._currentCursorOpacity,
			endValue: e,
			duration: t,
			delay: n,
			onComplete: r,
			abort: () => !this.canvas || this.selectionStart !== this.selectionEnd,
			onChange: (e) => {
				this._currentCursorOpacity = e, this.renderCursorOrSelection();
			}
		});
	}
	_tick(e) {
		this._currentTickState = this._animateCursor({
			toValue: 0,
			duration: this.cursorDuration / 2,
			delay: Math.max(e || 0, 100),
			onComplete: this._onTickComplete
		});
	}
	_onTickComplete() {
		var e;
		(e = this._currentTickCompleteState) == null || e.abort(), this._currentTickCompleteState = this._animateCursor({
			toValue: 1,
			duration: this.cursorDuration,
			onComplete: this._tick
		});
	}
	initDelayedCursor(e) {
		this.abortCursorAnimation(), this._tick(e ? 0 : this.cursorDelay);
	}
	abortCursorAnimation() {
		let e = !1;
		[this._currentTickState, this._currentTickCompleteState].forEach((t) => {
			t && !t.isDone() && (e = !0, t.abort());
		}), this._currentCursorOpacity = 1, e && this.clearContextTop();
	}
	restartCursorIfNeeded() {
		[this._currentTickState, this._currentTickCompleteState].some((e) => !e || e.isDone()) && this.initDelayedCursor();
	}
	selectAll() {
		return this.selectionStart = 0, this.selectionEnd = this._text.length, this._fireSelectionChanged(), this._updateTextarea(), this;
	}
	cmdAll() {
		this.selectAll(), this.renderCursorOrSelection();
	}
	getSelectedText() {
		return this._text.slice(this.selectionStart, this.selectionEnd).join(``);
	}
	findWordBoundaryLeft(e) {
		let t = 0, n = e - 1;
		if (this._reSpace.test(this._text[n])) for (; this._reSpace.test(this._text[n]);) t++, n--;
		for (; /\S/.test(this._text[n]) && n > -1;) t++, n--;
		return e - t;
	}
	findWordBoundaryRight(e) {
		let t = 0, n = e;
		if (this._reSpace.test(this._text[n])) for (; this._reSpace.test(this._text[n]);) t++, n++;
		for (; /\S/.test(this._text[n]) && n < this._text.length;) t++, n++;
		return e + t;
	}
	findLineBoundaryLeft(e) {
		let t = 0, n = e - 1;
		for (; !/\n/.test(this._text[n]) && n > -1;) t++, n--;
		return e - t;
	}
	findLineBoundaryRight(e) {
		let t = 0, n = e;
		for (; !/\n/.test(this._text[n]) && n < this._text.length;) t++, n++;
		return e + t;
	}
	searchWordBoundary(e, t) {
		let n = this._text, r = e > 0 && this._reSpace.test(n[e]) && (t === -1 || !ne.test(n[e - 1])) ? e - 1 : e, i = n[r];
		for (; r > 0 && r < n.length && !$o.test(i);) r += t, i = n[r];
		return t === -1 && $o.test(i) && r++, r;
	}
	selectWord(e) {
		var t;
		e = (t = e) == null ? this.selectionStart : t;
		let n = this.searchWordBoundary(e, -1), r = Math.max(n, this.searchWordBoundary(e, 1));
		this.selectionStart = n, this.selectionEnd = r, this._fireSelectionChanged(), this._updateTextarea(), this.renderCursorOrSelection();
	}
	selectLine(e) {
		var t;
		e = (t = e) == null ? this.selectionStart : t;
		let n = this.findLineBoundaryLeft(e), r = this.findLineBoundaryRight(e);
		this.selectionStart = n, this.selectionEnd = r, this._fireSelectionChanged(), this._updateTextarea();
	}
	enterEditing(e) {
		!this.isEditing && this.editable && (this.enterEditingImpl(), this.fire(`editing:entered`, e ? { e } : void 0), this._fireSelectionChanged(), this.canvas && (this.canvas.fire(`text:editing:entered`, {
			target: this,
			e
		}), this.canvas.requestRenderAll()));
	}
	enterEditingImpl() {
		this.canvas && (this.canvas.calcOffset(), this.canvas.textEditingManager.exitTextEditing()), this.isEditing = !0, this.initHiddenTextarea(), this.hiddenTextarea.focus(), this.hiddenTextarea.value = this.text, this._updateTextarea(), this._saveEditingProps(), this._setEditingProps(), this._textBeforeEdit = this.text, this._tick();
	}
	updateSelectionOnMouseMove(e) {
		if (this.getActiveControl()) return;
		let t = this.hiddenTextarea;
		H(t).activeElement !== t && t.focus();
		let n = this.getSelectionStartFromPointer(e), r = this.selectionStart, i = this.selectionEnd;
		(n === this.__selectionStartOnMouseDown && r !== i || r !== n && i !== n) && (n > this.__selectionStartOnMouseDown ? (this.selectionStart = this.__selectionStartOnMouseDown, this.selectionEnd = n) : (this.selectionStart = n, this.selectionEnd = this.__selectionStartOnMouseDown), this.selectionStart === r && this.selectionEnd === i || (this._fireSelectionChanged(), this._updateTextarea(), this.renderCursorOrSelection()));
	}
	_setEditingProps() {
		this.hoverCursor = `text`, this.canvas && (this.canvas.defaultCursor = this.canvas.moveCursor = `text`), this.borderColor = this.editingBorderColor, this.hasControls = this.selectable = !1, this.lockMovementX = this.lockMovementY = !0;
	}
	fromStringToGraphemeSelection(e, t, n) {
		let r = n.slice(0, e), i = this.graphemeSplit(r).length;
		if (e === t) return {
			selectionStart: i,
			selectionEnd: i
		};
		let a = n.slice(e, t);
		return {
			selectionStart: i,
			selectionEnd: i + this.graphemeSplit(a).length
		};
	}
	fromGraphemeToStringSelection(e, t, n) {
		let r = n.slice(0, e).join(``).length;
		return e === t ? {
			selectionStart: r,
			selectionEnd: r
		} : {
			selectionStart: r,
			selectionEnd: r + n.slice(e, t).join(``).length
		};
	}
	_updateTextarea() {
		if (this.cursorOffsetCache = {}, this.hiddenTextarea) {
			if (!this.inCompositionMode) {
				let e = this.fromGraphemeToStringSelection(this.selectionStart, this.selectionEnd, this._text);
				this.hiddenTextarea.selectionStart = e.selectionStart, this.hiddenTextarea.selectionEnd = e.selectionEnd;
			}
			this.updateTextareaPosition();
		}
	}
	updateFromTextArea() {
		let { hiddenTextarea: e, direction: t, textAlign: n, inCompositionMode: r } = this;
		if (!e) return;
		let i = n === `justify` ? t === `ltr` ? D : k : n.replace(`justify-`, ``), a = this.getPositionByOrigin(i, `top`);
		this.cursorOffsetCache = {}, this.text = e.value, this.set(`dirty`, !0), this.initDimensions(), this.setPositionByOrigin(a, i, `top`), this.setCoords();
		let o = this.fromStringToGraphemeSelection(e.selectionStart, e.selectionEnd, e.value);
		this.selectionEnd = this.selectionStart = o.selectionEnd, r || (this.selectionStart = o.selectionStart), this.updateTextareaPosition();
	}
	updateTextareaPosition() {
		if (this.selectionStart === this.selectionEnd) {
			let e = this._calcTextareaPosition();
			this.hiddenTextarea.style.left = e.left, this.hiddenTextarea.style.top = e.top;
		}
	}
	_calcTextareaPosition() {
		if (!this.canvas) return {
			left: `1px`,
			top: `1px`
		};
		let e = this.inCompositionMode ? this.compositionStart : this.selectionStart, t = this._getCursorBoundaries(e), n = this.get2DCursorLocation(e), r = n.lineIndex, i = n.charIndex, a = this.getValueOfPropertyAt(r, i, `fontSize`) * this.lineHeight, o = t.leftOffset, s = this.getCanvasRetinaScaling(), c = this.canvas.upperCanvasEl, l = c.width / s, u = c.height / s, d = l - a, f = u - a, p = new N(t.left + o, t.top + t.topOffset + a).transform(this.calcTransformMatrix()).transform(this.canvas.viewportTransform).multiply(new N(c.clientWidth / l, c.clientHeight / u));
		return p.x < 0 && (p.x = 0), p.x > d && (p.x = d), p.y < 0 && (p.y = 0), p.y > f && (p.y = f), p.x += this.canvas._offset.left, p.y += this.canvas._offset.top, {
			left: `${p.x}px`,
			top: `${p.y}px`,
			fontSize: `${a}px`,
			charHeight: a
		};
	}
	_saveEditingProps() {
		this._savedProps = {
			hasControls: this.hasControls,
			borderColor: this.borderColor,
			lockMovementX: this.lockMovementX,
			lockMovementY: this.lockMovementY,
			hoverCursor: this.hoverCursor,
			selectable: this.selectable,
			defaultCursor: this.canvas && this.canvas.defaultCursor,
			moveCursor: this.canvas && this.canvas.moveCursor
		};
	}
	_restoreEditingProps() {
		this._savedProps && (this.hoverCursor = this._savedProps.hoverCursor, this.hasControls = this._savedProps.hasControls, this.borderColor = this._savedProps.borderColor, this.selectable = this._savedProps.selectable, this.lockMovementX = this._savedProps.lockMovementX, this.lockMovementY = this._savedProps.lockMovementY, this.canvas && (this.canvas.defaultCursor = this._savedProps.defaultCursor || this.canvas.defaultCursor, this.canvas.moveCursor = this._savedProps.moveCursor || this.canvas.moveCursor), delete this._savedProps);
	}
	exitEditingImpl() {
		let e = this.hiddenTextarea;
		this.selected = !1, this.isEditing = !1, e && (e.blur && e.blur(), e.parentNode && e.parentNode.removeChild(e)), this.hiddenTextarea = null, this.abortCursorAnimation(), this.selectionStart !== this.selectionEnd && this.clearContextTop(), this.selectionEnd = this.selectionStart, this._restoreEditingProps(), this._forceClearCache && (this.initDimensions(), this.setCoords());
	}
	exitEditing() {
		let e = this._textBeforeEdit !== this.text;
		return this.exitEditingImpl(), this.fire(`editing:exited`), e && this.fire(`modified`), this.canvas && (this.canvas.fire(`text:editing:exited`, { target: this }), e && this.canvas.fire(`object:modified`, { target: this })), this;
	}
	_removeExtraneousStyles() {
		for (let e in this.styles) this._textLines[e] || delete this.styles[e];
	}
	removeStyleFromTo(e, t) {
		let { lineIndex: n, charIndex: r } = this.get2DCursorLocation(e, !0), { lineIndex: i, charIndex: a } = this.get2DCursorLocation(t, !0);
		if (n !== i) {
			if (this.styles[n]) for (let e = r; e < this._unwrappedTextLines[n].length; e++) delete this.styles[n][e];
			if (this.styles[i]) for (let e = a; e < this._unwrappedTextLines[i].length; e++) {
				let t = this.styles[i][e];
				t && (this.styles[n] || (this.styles[n] = {}), this.styles[n][r + e - a] = t);
			}
			for (let e = n + 1; e <= i; e++) delete this.styles[e];
			this.shiftLineStyles(i, n - i);
		} else if (this.styles[n]) {
			let e = this.styles[n], t = a - r;
			for (let t = r; t < a; t++) delete e[t];
			for (let r in this.styles[n]) {
				let n = parseInt(r, 10);
				n >= a && (e[n - t] = e[r], delete e[r]);
			}
		}
	}
	shiftLineStyles(e, t) {
		let n = Object.assign({}, this.styles);
		for (let r in this.styles) {
			let i = parseInt(r, 10);
			i > e && (this.styles[i + t] = n[i], n[i - t] || delete this.styles[i]);
		}
	}
	insertNewlineStyleObject(e, t, n, r) {
		let i = {}, a = this._unwrappedTextLines[e].length, o = a === t, s = !1;
		n || (n = 1), this.shiftLineStyles(e, n);
		let c = this.styles[e] ? this.styles[e][t === 0 ? t : t - 1] : void 0;
		for (let n in this.styles[e]) {
			let r = parseInt(n, 10);
			r >= t && (s = !0, i[r - t] = this.styles[e][n], o && t === 0 || delete this.styles[e][n]);
		}
		let l = !1;
		for (s && !o && (this.styles[e + n] = i, l = !0), (l || a > t) && n--; n > 0;) r && r[n - 1] ? this.styles[e + n] = { 0: { ...r[n - 1] } } : c ? this.styles[e + n] = { 0: { ...c } } : delete this.styles[e + n], n--;
		this._forceClearCache = !0;
	}
	insertCharStyleObject(e, t, n, r) {
		this.styles || (this.styles = {});
		let i = this.styles[e], a = i ? { ...i } : {};
		n || (n = 1);
		for (let e in a) {
			let r = parseInt(e, 10);
			r >= t && (i[r + n] = a[r], a[r - n] || delete i[r]);
		}
		if (this._forceClearCache = !0, r) {
			for (; n--;) Object.keys(r[n]).length && (this.styles[e] || (this.styles[e] = {}), this.styles[e][t + n] = { ...r[n] });
			return;
		}
		if (!i) return;
		let o = i[t ? t - 1 : 1];
		for (; o && n--;) this.styles[e][t + n] = { ...o };
	}
	insertNewStyleBlock(e, t, n) {
		let r = this.get2DCursorLocation(t, !0), i = [0], a, o = 0;
		for (let t = 0; t < e.length; t++) e[t] === `
` ? (o++, i[o] = 0) : i[o]++;
		for (i[0] > 0 && (this.insertCharStyleObject(r.lineIndex, r.charIndex, i[0], n), n = n && n.slice(i[0] + 1)), o && this.insertNewlineStyleObject(r.lineIndex, r.charIndex + i[0], o), a = 1; a < o; a++) i[a] > 0 ? this.insertCharStyleObject(r.lineIndex + a, 0, i[a], n) : n && this.styles[r.lineIndex + a] && n[0] && (this.styles[r.lineIndex + a][0] = n[0]), n = n && n.slice(i[a] + 1);
		i[a] > 0 && this.insertCharStyleObject(r.lineIndex + a, 0, i[a], n);
	}
	removeChars(e, t = e + 1) {
		this.removeStyleFromTo(e, t), this._text.splice(e, t - e), this.text = this._text.join(``), this.set(`dirty`, !0), this.initDimensions(), this.setCoords(), this._removeExtraneousStyles();
	}
	insertChars(e, t, n, r = n) {
		r > n && this.removeStyleFromTo(n, r);
		let i = this.graphemeSplit(e);
		this.insertNewStyleBlock(i, n, t), this._text = [
			...this._text.slice(0, n),
			...i,
			...this._text.slice(r)
		], this.text = this._text.join(``), this.set(`dirty`, !0), this.initDimensions(), this.setCoords(), this._removeExtraneousStyles();
	}
	setSelectionStartEndWithShift(e, t, n) {
		n <= e ? (t === e ? this._selectionDirection = D : this._selectionDirection === `right` && (this._selectionDirection = D, this.selectionEnd = e), this.selectionStart = n) : n > e && n < t ? this._selectionDirection === `right` ? this.selectionEnd = n : this.selectionStart = n : (t === e ? this._selectionDirection = k : this._selectionDirection === `left` && (this._selectionDirection = k, this.selectionStart = t), this.selectionEnd = n);
	}
};
var ts = class extends es {
	initHiddenTextarea() {
		let e = this.canvas && H(this.canvas.getElement()) || g(), t = e.createElement(`textarea`);
		Object.entries({
			autocapitalize: `off`,
			autocorrect: `off`,
			autocomplete: `off`,
			spellcheck: `false`,
			"data-fabric": `textarea`,
			wrap: `off`,
			name: `fabricTextarea`
		}).map(([e, n]) => t.setAttribute(e, n));
		let { top: n, left: r, fontSize: i } = this._calcTextareaPosition();
		t.style.cssText = `position: absolute; top: ${n}; left: ${r}; z-index: -999; opacity: 0; width: 1px; height: 1px; font-size: 1px; padding-top: ${i};`, (this.hiddenTextareaContainer || e.body).appendChild(t), Object.entries({
			blur: `blur`,
			keydown: `onKeyDown`,
			keyup: `onKeyUp`,
			input: `onInput`,
			copy: `copy`,
			cut: `copy`,
			paste: `paste`,
			compositionstart: `onCompositionStart`,
			compositionupdate: `onCompositionUpdate`,
			compositionend: `onCompositionEnd`
		}).map(([e, n]) => t.addEventListener(e, this[n].bind(this))), this.hiddenTextarea = t;
	}
	blur() {
		this.abortCursorAnimation();
	}
	onKeyDown(e) {
		if (!this.isEditing) return;
		let t = this.direction === `rtl` ? this.keysMapRtl : this.keysMap;
		if (e.keyCode in t) this[t[e.keyCode]](e);
		else {
			if (!(e.keyCode in this.ctrlKeysMapDown) || !e.ctrlKey && !e.metaKey) return;
			this[this.ctrlKeysMapDown[e.keyCode]](e);
		}
		e.stopImmediatePropagation(), e.preventDefault(), e.keyCode >= 33 && e.keyCode <= 40 ? (this.inCompositionMode = !1, this.clearContextTop(), this.renderCursorOrSelection()) : this.canvas && this.canvas.requestRenderAll();
	}
	onKeyUp(e) {
		!this.isEditing || this._copyDone || this.inCompositionMode ? this._copyDone = !1 : e.keyCode in this.ctrlKeysMapUp && (e.ctrlKey || e.metaKey) && (this[this.ctrlKeysMapUp[e.keyCode]](e), e.stopImmediatePropagation(), e.preventDefault(), this.canvas && this.canvas.requestRenderAll());
	}
	onInput(e) {
		let t = this.fromPaste, { value: n, selectionStart: r, selectionEnd: i } = this.hiddenTextarea;
		if (this.fromPaste = !1, e && e.stopPropagation(), !this.isEditing) return;
		let a = () => {
			this.updateFromTextArea(), this.fire(le), this.canvas && (this.canvas.fire(`text:changed`, { target: this }), this.canvas.requestRenderAll());
		};
		if (this.hiddenTextarea.value === ``) return this.styles = {}, void a();
		let s = this._splitTextIntoLines(n).graphemeText, c = this._text.length, l = s.length, u = this.selectionStart, d = this.selectionEnd, f = u !== d, p, m, g, _, v = l - c, y = this.fromStringToGraphemeSelection(r, i, n), b = u > y.selectionStart;
		f ? (m = this._text.slice(u, d), v += d - u) : l < c && (m = b ? this._text.slice(d + v, d) : this._text.slice(u, u - v));
		let x = s.slice(y.selectionEnd - v, y.selectionEnd);
		if (m && m.length && (x.length && (p = this.getSelectionStyles(u, u + 1, !1), p = x.map(() => p[0])), f ? (g = u, _ = d) : b ? (g = d - m.length, _ = d) : (g = d, _ = d + m.length), this.removeStyleFromTo(g, _)), x.length) {
			let { copyPasteData: e } = h();
			t && x.join(``) === e.copiedText && !o.disableStyleCopyPaste && (p = e.copiedTextStyle), this.insertNewStyleBlock(x, u, p);
		}
		a();
	}
	onCompositionStart() {
		this.inCompositionMode = !0;
	}
	onCompositionEnd() {
		this.inCompositionMode = !1;
	}
	onCompositionUpdate({ target: e }) {
		let { selectionStart: t, selectionEnd: n } = e;
		this.compositionStart = t, this.compositionEnd = n, this.updateTextareaPosition();
	}
	copy() {
		if (this.selectionStart === this.selectionEnd) return;
		let { copyPasteData: e } = h();
		e.copiedText = this.getSelectedText(), o.disableStyleCopyPaste ? e.copiedTextStyle = void 0 : e.copiedTextStyle = this.getSelectionStyles(this.selectionStart, this.selectionEnd, !0), this._copyDone = !0;
	}
	paste() {
		this.fromPaste = !0;
	}
	_getWidthBeforeCursor(e, t) {
		let n, r = this._getLineLeftOffset(e);
		return t > 0 && (n = this.__charBounds[e][t - 1], r += n.left + n.width), r;
	}
	getDownCursorOffset(e, t) {
		let n = this._getSelectionForOffset(e, t), r = this.get2DCursorLocation(n), i = r.lineIndex;
		if (i === this._textLines.length - 1 || e.metaKey || e.keyCode === 34) return this._text.length - n;
		let a = r.charIndex, o = this._getWidthBeforeCursor(i, a), s = this._getIndexOnLine(i + 1, o);
		return this._textLines[i].slice(a).length + s + 1 + this.missingNewlineOffset(i);
	}
	_getSelectionForOffset(e, t) {
		return e.shiftKey && this.selectionStart !== this.selectionEnd && t ? this.selectionEnd : this.selectionStart;
	}
	getUpCursorOffset(e, t) {
		let n = this._getSelectionForOffset(e, t), r = this.get2DCursorLocation(n), i = r.lineIndex;
		if (i === 0 || e.metaKey || e.keyCode === 33) return -n;
		let a = r.charIndex, o = this._getWidthBeforeCursor(i, a), s = this._getIndexOnLine(i - 1, o), c = this._textLines[i].slice(0, a), l = this.missingNewlineOffset(i - 1);
		return -this._textLines[i - 1].length + s - c.length + (1 - l);
	}
	_getIndexOnLine(e, t) {
		let n = this._textLines[e], r, i, a = this._getLineLeftOffset(e), o = 0;
		for (let s = 0, c = n.length; s < c; s++) if (r = this.__charBounds[e][s].width, a += r, a > t) {
			i = !0;
			let e = a - r, n = a, c = Math.abs(e - t);
			o = Math.abs(n - t) < c ? s : s - 1;
			break;
		}
		return i || (o = n.length - 1), o;
	}
	moveCursorDown(e) {
		this.selectionStart >= this._text.length && this.selectionEnd >= this._text.length || this._moveCursorUpOrDown(`Down`, e);
	}
	moveCursorUp(e) {
		this.selectionStart === 0 && this.selectionEnd === 0 || this._moveCursorUpOrDown(`Up`, e);
	}
	_moveCursorUpOrDown(e, t) {
		let n = this[`get${e}CursorOffset`](t, this._selectionDirection === k);
		if (t.shiftKey ? this.moveCursorWithShift(n) : this.moveCursorWithoutShift(n), n !== 0) {
			let e = this.text.length;
			this.selectionStart = Vn(0, this.selectionStart, e), this.selectionEnd = Vn(0, this.selectionEnd, e), this.abortCursorAnimation(), this.initDelayedCursor(), this._fireSelectionChanged(), this._updateTextarea();
		}
	}
	moveCursorWithShift(e) {
		let t = this._selectionDirection === `left` ? this.selectionStart + e : this.selectionEnd + e;
		return this.setSelectionStartEndWithShift(this.selectionStart, this.selectionEnd, t), e !== 0;
	}
	moveCursorWithoutShift(e) {
		return e < 0 ? (this.selectionStart += e, this.selectionEnd = this.selectionStart) : (this.selectionEnd += e, this.selectionStart = this.selectionEnd), e !== 0;
	}
	moveCursorLeft(e) {
		this.selectionStart === 0 && this.selectionEnd === 0 || this._moveCursorLeftOrRight(`Left`, e);
	}
	_move(e, t, n) {
		let r;
		if (e.altKey) r = this[`findWordBoundary${n}`](this[t]);
		else {
			if (!e.metaKey && e.keyCode !== 35 && e.keyCode !== 36) return this[t] += n === `Left` ? -1 : 1, !0;
			r = this[`findLineBoundary${n}`](this[t]);
		}
		return r !== void 0 && this[t] !== r && (this[t] = r, !0);
	}
	_moveLeft(e, t) {
		return this._move(e, t, `Left`);
	}
	_moveRight(e, t) {
		return this._move(e, t, `Right`);
	}
	moveCursorLeftWithoutShift(e) {
		let t = !0;
		return this._selectionDirection = D, this.selectionEnd === this.selectionStart && this.selectionStart !== 0 && (t = this._moveLeft(e, `selectionStart`)), this.selectionEnd = this.selectionStart, t;
	}
	moveCursorLeftWithShift(e) {
		return this._selectionDirection === `right` && this.selectionStart !== this.selectionEnd ? this._moveLeft(e, `selectionEnd`) : this.selectionStart === 0 ? void 0 : (this._selectionDirection = D, this._moveLeft(e, `selectionStart`));
	}
	moveCursorRight(e) {
		this.selectionStart >= this._text.length && this.selectionEnd >= this._text.length || this._moveCursorLeftOrRight(`Right`, e);
	}
	_moveCursorLeftOrRight(e, t) {
		let n = `moveCursor${e}${t.shiftKey ? `WithShift` : `WithoutShift`}`;
		this._currentCursorOpacity = 1, this[n](t) && (this.abortCursorAnimation(), this.initDelayedCursor(), this._fireSelectionChanged(), this._updateTextarea());
	}
	moveCursorRightWithShift(e) {
		return this._selectionDirection === `left` && this.selectionStart !== this.selectionEnd ? this._moveRight(e, `selectionStart`) : this.selectionEnd === this._text.length ? void 0 : (this._selectionDirection = k, this._moveRight(e, `selectionEnd`));
	}
	moveCursorRightWithoutShift(e) {
		let t = !0;
		return this._selectionDirection = k, this.selectionStart === this.selectionEnd ? (t = this._moveRight(e, `selectionStart`), this.selectionEnd = this.selectionStart) : this.selectionStart = this.selectionEnd, t;
	}
};
var ns = (e) => !!e.button;
var rs = class extends ts {
	constructor(...e) {
		super(...e), i(this, `draggableTextDelegate`, void 0);
	}
	initBehavior() {
		this.on(`mousedown`, this._mouseDownHandler), this.on(`mouseup`, this.mouseUpHandler), this.on(`mousedblclick`, this.doubleClickHandler), this.on(`mousetripleclick`, this.tripleClickHandler), this.draggableTextDelegate = new Qo(this), super.initBehavior();
	}
	shouldStartDragging() {
		return this.draggableTextDelegate.isActive();
	}
	onDragStart(e) {
		return this.draggableTextDelegate.onDragStart(e);
	}
	canDrop(e) {
		return this.draggableTextDelegate.canDrop(e);
	}
	doubleClickHandler(e) {
		this.isEditing && (this.selectWord(this.getSelectionStartFromPointer(e.e)), this.renderCursorOrSelection());
	}
	tripleClickHandler(e) {
		this.isEditing && (this.selectLine(this.getSelectionStartFromPointer(e.e)), this.renderCursorOrSelection());
	}
	_mouseDownHandler({ e, alreadySelected: t }) {
		this.canvas && this.editable && !ns(e) && !this.getActiveControl() && (this.draggableTextDelegate.start(e) || (this.canvas.textEditingManager.register(this), t && (this.inCompositionMode = !1, this.setCursorByClick(e)), this.isEditing && (this.__selectionStartOnMouseDown = this.selectionStart, this.selectionStart === this.selectionEnd && this.abortCursorAnimation(), this.renderCursorOrSelection()), this.selected || (this.selected = t || this.isEditing)));
	}
	mouseUpHandler({ e, transform: t }) {
		let n = this.draggableTextDelegate.end(e);
		if (this.canvas) {
			this.canvas.textEditingManager.unregister(this);
			let e = this.canvas._activeObject;
			if (e && e !== this) return;
		}
		!this.editable || this.group && !this.group.interactive || t && t.actionPerformed || ns(e) || n || this.selected && !this.getActiveControl() && (this.enterEditing(e), this.selectionStart === this.selectionEnd ? this.initDelayedCursor(!0) : this.renderCursorOrSelection());
	}
	setCursorByClick(e) {
		let t = this.getSelectionStartFromPointer(e), n = this.selectionStart, r = this.selectionEnd;
		e.shiftKey ? this.setSelectionStartEndWithShift(n, r, t) : (this.selectionStart = t, this.selectionEnd = t), this.isEditing && (this._fireSelectionChanged(), this._updateTextarea());
	}
	getSelectionStartFromPointer(e) {
		let t = this.canvas.getScenePoint(e).transform(R(this.calcTransformMatrix())).add(new N(-this._getLeftOffset(), -this._getTopOffset())), n = 0, r = 0, i = 0;
		for (let e = 0; e < this._textLines.length && n <= t.y; e++) n += this.getHeightOfLine(e), i = e, e > 0 && (r += this._textLines[e - 1].length + this.missingNewlineOffset(e - 1));
		let a = Math.abs(this._getLineLeftOffset(i)), o = this._textLines[i].length, s = this.__charBounds[i];
		for (let e = 0; e < o; e++) {
			let n = a + s[e].kernedWidth;
			if (t.x <= n) {
				Math.abs(t.x - n) <= Math.abs(t.x - a) && r++;
				break;
			}
			a = n, r++;
		}
		return Math.min(this.flipX ? o - r : r, this._text.length);
	}
};
var is = `moveCursorUp`;
var as = `moveCursorDown`;
var os = `moveCursorLeft`;
var ss = `moveCursorRight`;
var cs = `exitEditing`;
var ls = (e, t) => {
	let n = t.getRetinaScaling();
	e.setTransform(n, 0, 0, n, 0, 0);
	let r = t.viewportTransform;
	e.transform(r[0], r[1], r[2], r[3], r[4], r[5]);
};
var us = {
	selectionStart: 0,
	selectionEnd: 0,
	selectionColor: `rgba(17,119,255,0.3)`,
	isEditing: !1,
	editable: !0,
	editingBorderColor: `rgba(102,153,255,0.25)`,
	cursorWidth: 2,
	cursorColor: ``,
	cursorDelay: 1e3,
	cursorDuration: 600,
	caching: !0,
	hiddenTextareaContainer: null,
	keysMap: {
		9: cs,
		27: cs,
		33: is,
		34: as,
		35: ss,
		36: os,
		37: os,
		38: is,
		39: ss,
		40: as
	},
	keysMapRtl: {
		9: cs,
		27: cs,
		33: is,
		34: as,
		35: os,
		36: ss,
		37: ss,
		38: is,
		39: os,
		40: as
	},
	ctrlKeysMapDown: { 65: `cmdAll` },
	ctrlKeysMapUp: {
		67: `copy`,
		88: `cut`
	},
	_selectionDirection: null,
	_reSpace: /\s|\r?\n/,
	inCompositionMode: !1
};
var ds = class e extends rs {
	static getDefaults() {
		return {
			...super.getDefaults(),
			...e.ownDefaults
		};
	}
	get type() {
		let e = super.type;
		return e === `itext` ? `i-text` : e;
	}
	constructor(t, n) {
		super(t, {
			...e.ownDefaults,
			...n
		}), this.initBehavior();
	}
	_set(e, t) {
		return this.isEditing && this._savedProps && e in this._savedProps ? (this._savedProps[e] = t, this) : (e === `canvas` && (this.canvas instanceof ho && this.canvas.textEditingManager.remove(this), t instanceof ho && t.textEditingManager.add(this)), super._set(e, t));
	}
	setSelectionStart(e) {
		e = Math.max(e, 0), this._updateAndFire(`selectionStart`, e);
	}
	setSelectionEnd(e) {
		e = Math.min(e, this.text.length), this._updateAndFire(`selectionEnd`, e);
	}
	_updateAndFire(e, t) {
		this[e] !== t && (this._fireSelectionChanged(), this[e] = t), this._updateTextarea();
	}
	_fireSelectionChanged() {
		this.fire(`selection:changed`), this.canvas && this.canvas.fire(`text:selection:changed`, { target: this });
	}
	initDimensions() {
		this.isEditing && this.initDelayedCursor(), super.initDimensions();
	}
	getSelectionStyles(e = this.selectionStart || 0, t = this.selectionEnd, n) {
		return super.getSelectionStyles(e, t, n);
	}
	setSelectionStyles(e, t = this.selectionStart || 0, n = this.selectionEnd) {
		return super.setSelectionStyles(e, t, n);
	}
	get2DCursorLocation(e = this.selectionStart, t) {
		return super.get2DCursorLocation(e, t);
	}
	render(e) {
		super.render(e), this.cursorOffsetCache = {}, this.renderCursorOrSelection();
	}
	toCanvasElement(e) {
		let t = this.isEditing;
		this.isEditing = !1;
		let n = super.toCanvasElement(e);
		return this.isEditing = t, n;
	}
	renderCursorOrSelection() {
		if (!this.isEditing || !this.canvas) return;
		let e = this.clearContextTop(!0);
		if (!e) return;
		let t = this._getCursorBoundaries(), n = this.findAncestorsWithClipPath(), r = n.length > 0, i, a = e;
		if (r) {
			i = F(e.canvas), a = i.getContext(`2d`), ls(a, this.canvas);
			let t = this.calcTransformMatrix();
			a.transform(t[0], t[1], t[2], t[3], t[4], t[5]);
		}
		if (this.selectionStart !== this.selectionEnd || this.inCompositionMode ? this.renderSelection(a, t) : this.renderCursor(a, t), r) for (let t of n) {
			let n = t.clipPath, r = F(e.canvas), i = r.getContext(`2d`);
			if (ls(i, this.canvas), !n.absolutePositioned) {
				let e = t.calcTransformMatrix();
				i.transform(e[0], e[1], e[2], e[3], e[4], e[5]);
			}
			n.transform(i), n.drawObject(i, !0, {}), this.drawClipPathOnCache(a, n, r);
		}
		r && (e.setTransform(1, 0, 0, 1, 0, 0), e.drawImage(i, 0, 0)), this.canvas.contextTopDirty = !0, e.restore();
	}
	findAncestorsWithClipPath() {
		let e = [], t = this;
		for (; t;) t.clipPath && e.push(t), t = t.parent;
		return e;
	}
	_getCursorBoundaries(e = this.selectionStart, t) {
		let n = this._getLeftOffset(), r = this._getTopOffset(), i = this._getCursorBoundariesOffsets(e, t);
		return {
			left: n,
			top: r,
			leftOffset: i.left,
			topOffset: i.top
		};
	}
	_getCursorBoundariesOffsets(e, t) {
		return t ? this.__getCursorBoundariesOffsets(e) : this.cursorOffsetCache && `top` in this.cursorOffsetCache ? this.cursorOffsetCache : this.cursorOffsetCache = this.__getCursorBoundariesOffsets(e);
	}
	__getCursorBoundariesOffsets(e) {
		let t = 0, n = 0, { charIndex: r, lineIndex: i } = this.get2DCursorLocation(e), { textAlign: a, direction: o } = this;
		for (let e = 0; e < i; e++) t += this.getHeightOfLine(e);
		let s = this._getLineLeftOffset(i), c = this.__charBounds[i][r];
		c && (n = c.left), this.charSpacing !== 0 && r === this._textLines[i].length && (n -= this._getWidthOfCharSpacing());
		let l = s + (n > 0 ? n : 0);
		return o === `rtl` && (a === `right` || a === `justify` || a === `justify-right` ? l *= -1 : a === `left` || a === `justify-left` ? l = s - (n > 0 ? n : 0) : a !== `center` && a !== `justify-center` || (l = s - (n > 0 ? n : 0))), {
			top: t,
			left: l
		};
	}
	renderCursorAt(e) {
		this._renderCursor(this.canvas.contextTop, this._getCursorBoundaries(e, !0), e);
	}
	renderCursor(e, t) {
		this._renderCursor(e, t, this.selectionStart);
	}
	getCursorRenderingData(e = this.selectionStart, t = this._getCursorBoundaries(e)) {
		let n = this.get2DCursorLocation(e), r = n.lineIndex, i = n.charIndex > 0 ? n.charIndex - 1 : 0, a = this.getValueOfPropertyAt(r, i, `fontSize`), o = this.getObjectScaling().x * this.canvas.getZoom(), s = this.cursorWidth / o, c = this.getValueOfPropertyAt(r, i, `deltaY`), l = t.topOffset + (1 - this._fontSizeFraction) * this.getHeightOfLine(r) / this.lineHeight - a * (1 - this._fontSizeFraction);
		return {
			color: this.cursorColor || this.getValueOfPropertyAt(r, i, `fill`),
			opacity: this._currentCursorOpacity,
			left: t.left + t.leftOffset - s / 2,
			top: l + t.top + c,
			width: s,
			height: a
		};
	}
	_renderCursor(e, t, n) {
		let { color: r, opacity: i, left: a, top: o, width: s, height: c } = this.getCursorRenderingData(n, t);
		e.fillStyle = r, e.globalAlpha = i, e.fillRect(a, o, s, c);
	}
	renderSelection(e, t) {
		let n = {
			selectionStart: this.inCompositionMode ? this.hiddenTextarea.selectionStart : this.selectionStart,
			selectionEnd: this.inCompositionMode ? this.hiddenTextarea.selectionEnd : this.selectionEnd
		};
		this._renderSelection(e, n, t);
	}
	renderDragSourceEffect() {
		let e = this.draggableTextDelegate.getDragStartSelection();
		this._renderSelection(this.canvas.contextTop, e, this._getCursorBoundaries(e.selectionStart, !0));
	}
	renderDropTargetEffect(e) {
		let t = this.getSelectionStartFromPointer(e);
		this.renderCursorAt(t);
	}
	_renderSelection(e, t, n) {
		let { textAlign: r, direction: i } = this, a = t.selectionStart, o = t.selectionEnd, s = r.includes(En), c = this.get2DCursorLocation(a), l = this.get2DCursorLocation(o), u = c.lineIndex, d = l.lineIndex, f = c.charIndex < 0 ? 0 : c.charIndex, p = l.charIndex < 0 ? 0 : l.charIndex;
		for (let t = u; t <= d; t++) {
			let a = this._getLineLeftOffset(t) || 0, o = this.getHeightOfLine(t), c = 0, l = 0;
			if (t === u && (c = this.__charBounds[u][f].left), t >= u && t < d) l = s && !this.isEndOfWrapping(t) ? this.width : this.getLineWidth(t) || 5;
			else if (t === d) if (p === 0) l = this.__charBounds[d][p].left;
			else {
				let e = this._getWidthOfCharSpacing();
				l = this.__charBounds[d][p - 1].left + this.__charBounds[d][p - 1].width - e;
			}
			let m = o;
			(this.lineHeight < 1 || t === d && this.lineHeight > 1) && (o /= this.lineHeight);
			let h = n.left + a + c, g = o, _ = 0, v = l - c;
			this.inCompositionMode ? (e.fillStyle = this.compositionColor || `black`, g = 1, _ = o) : e.fillStyle = this.selectionColor, i === `rtl` && (r === `right` || r === `justify` || r === `justify-right` ? h = this.width - h - v : r === `left` || r === `justify-left` ? h = n.left + a - l : r !== `center` && r !== `justify-center` || (h = n.left + a - l)), e.fillRect(h, n.top + n.topOffset + _, v, g), n.topOffset += m;
		}
	}
	getCurrentCharFontSize() {
		let e = this._getCurrentCharIndex();
		return this.getValueOfPropertyAt(e.l, e.c, `fontSize`);
	}
	getCurrentCharColor() {
		let e = this._getCurrentCharIndex();
		return this.getValueOfPropertyAt(e.l, e.c, j);
	}
	_getCurrentCharIndex() {
		let e = this.get2DCursorLocation(this.selectionStart, !0), t = e.charIndex > 0 ? e.charIndex - 1 : 0;
		return {
			l: e.lineIndex,
			c: t
		};
	}
	dispose() {
		this.exitEditingImpl(), this.draggableTextDelegate.dispose(), super.dispose();
	}
};
i(ds, `ownDefaults`, us), i(ds, `type`, `IText`), M.setClass(ds), M.setClass(ds, `i-text`);
var fs = class e extends ds {
	static getDefaults() {
		return {
			...super.getDefaults(),
			...e.ownDefaults
		};
	}
	constructor(t, n) {
		super(t, {
			...e.ownDefaults,
			...n
		});
	}
	static createControls() {
		return { controls: gi() };
	}
	initDimensions() {
		this.initialized && (this.isEditing && this.initDelayedCursor(), this._clearCache(), this.dynamicMinWidth = 0, this._styleMap = this._generateStyleMap(this._splitText()), this.dynamicMinWidth > this.width && this._set(`width`, this.dynamicMinWidth), this.textAlign.includes(`justify`) && this.enlargeSpaces(), this.height = this.calcTextHeight());
	}
	_generateStyleMap(e) {
		let t = 0, n = 0, r = 0, i = {};
		for (let a = 0; a < e.graphemeLines.length; a++) e.graphemeText[r] === `
` && a > 0 ? (n = 0, r++, t++) : !this.splitByGrapheme && this._reSpaceAndTab.test(e.graphemeText[r]) && a > 0 && (n++, r++), i[a] = {
			line: t,
			offset: n
		}, r += e.graphemeLines[a].length, n += e.graphemeLines[a].length;
		return i;
	}
	styleHas(e, t) {
		if (this._styleMap && !this.isWrapping) {
			let e = this._styleMap[t];
			e && (t = e.line);
		}
		return super.styleHas(e, t);
	}
	isEmptyStyles(e) {
		if (!this.styles) return !0;
		let t, n, r = 0, i = !1, a = this._styleMap[e], o = this._styleMap[e + 1];
		a && (e = a.line, r = a.offset), o && (t = o.line, i = t === e, n = o.offset);
		let s = e === void 0 ? this.styles : { line: this.styles[e] };
		for (let e in s) for (let t in s[e]) {
			let a = parseInt(t, 10);
			if (a >= r && (!i || a < n)) for (let n in s[e][t]) return !1;
		}
		return !0;
	}
	_getStyleDeclaration(e, t) {
		if (this._styleMap && !this.isWrapping) {
			let n = this._styleMap[e];
			if (!n) return {};
			e = n.line, t = n.offset + t;
		}
		return super._getStyleDeclaration(e, t);
	}
	_setStyleDeclaration(e, t, n) {
		let r = this._styleMap[e];
		super._setStyleDeclaration(r.line, r.offset + t, n);
	}
	_deleteStyleDeclaration(e, t) {
		let n = this._styleMap[e];
		super._deleteStyleDeclaration(n.line, n.offset + t);
	}
	_getLineStyle(e) {
		let t = this._styleMap[e];
		return !!this.styles[t.line];
	}
	_setLineStyle(e) {
		let t = this._styleMap[e];
		super._setLineStyle(t.line);
	}
	_wrapText(e, t) {
		this.isWrapping = !0;
		let n = this.getGraphemeDataForRender(e), r = [];
		for (let e = 0; e < n.wordsData.length; e++) r.push(...this._wrapLine(e, t, n));
		return this.isWrapping = !1, r;
	}
	getGraphemeDataForRender(e) {
		let t = this.splitByGrapheme, n = t ? `` : ` `, r = 0;
		return {
			wordsData: e.map((e, i) => {
				let a = 0, o = t ? this.graphemeSplit(e) : this.wordSplit(e);
				return o.length === 0 ? [{
					word: [],
					width: 0
				}] : o.map((e) => {
					let o = t ? [e] : this.graphemeSplit(e), s = this._measureWord(o, i, a);
					return r = Math.max(s, r), a += o.length + n.length, {
						word: o,
						width: s
					};
				});
			}),
			largestWordWidth: r
		};
	}
	_measureWord(e, t, n = 0) {
		let r, i = 0;
		for (let a = 0, o = e.length; a < o; a++) i += this._getGraphemeBox(e[a], t, a + n, r, !0).kernedWidth, r = e[a];
		return i;
	}
	wordSplit(e) {
		return e.split(this._wordJoiners);
	}
	_wrapLine(e, t, { largestWordWidth: n, wordsData: r }, i = 0) {
		let a = this._getWidthOfCharSpacing(), o = this.splitByGrapheme, s = [], c = o ? `` : ` `, l = 0, u = [], d = 0, f = 0, p = !0;
		t -= i;
		let m = Math.max(t, n, this.dynamicMinWidth), h = r[e], g;
		for (g = 0; g < h.length; g++) {
			let { word: t, width: n } = h[g];
			d += t.length, l += f + n - a, l > m && !p ? (s.push(u), u = [], l = n, p = !0) : l += a, p || o || u.push(c), u = u.concat(t), f = o ? 0 : this._measureWord([c], e, d), d++, p = !1;
		}
		return g && s.push(u), n + i > this.dynamicMinWidth && (this.dynamicMinWidth = n - a + i), s;
	}
	isEndOfWrapping(e) {
		return !this._styleMap[e + 1] || this._styleMap[e + 1].line !== this._styleMap[e].line;
	}
	missingNewlineOffset(e, t) {
		return this.splitByGrapheme && !t ? +!!this.isEndOfWrapping(e) : 1;
	}
	_splitTextIntoLines(e) {
		let t = super._splitTextIntoLines(e), n = this._wrapText(t.lines, this.width), r = Array(n.length);
		for (let e = 0; e < n.length; e++) r[e] = n[e].join(``);
		return t.lines = r, t.graphemeLines = n, t;
	}
	getMinWidth() {
		return Math.max(this.minWidth, this.dynamicMinWidth);
	}
	_removeExtraneousStyles() {
		let e = /* @__PURE__ */ new Map();
		for (let t in this._styleMap) {
			let n = parseInt(t, 10);
			if (this._textLines[n]) {
				let n = this._styleMap[t].line;
				e.set(`${n}`, !0);
			}
		}
		for (let t in this.styles) e.has(t) || delete this.styles[t];
	}
	toObject(e = []) {
		return super.toObject([
			`minWidth`,
			`splitByGrapheme`,
			...e
		]);
	}
};
i(fs, `type`, `Textbox`), i(fs, `textLayoutProperties`, [...ds.textLayoutProperties, `width`]), i(fs, `ownDefaults`, {
	minWidth: 20,
	dynamicMinWidth: 2,
	lockScalingFlip: !0,
	noScaleCache: !1,
	_wordJoiners: /[ \t\r]/,
	splitByGrapheme: !1
}), M.setClass(fs);
var ps = class extends ra {
	shouldPerformLayout(e) {
		return !!e.target.clipPath && super.shouldPerformLayout(e);
	}
	shouldLayoutClipPath() {
		return !1;
	}
	calcLayoutResult(e, t) {
		let { target: n } = e, { clipPath: r, group: i } = n;
		if (!r || !this.shouldPerformLayout(e)) return;
		let { width: a, height: o } = wt(na(n, r)), s = new N(a, o);
		if (r.absolutePositioned) return {
			center: Mt(r.getRelativeCenterPoint(), void 0, i ? i.calcTransformMatrix() : void 0),
			size: s
		};
		{
			let i = r.getRelativeCenterPoint().transform(n.calcOwnMatrix(), !0);
			if (this.shouldPerformLayout(e)) {
				let { center: n = new N(), correction: r = new N() } = this.calcBoundingBox(t, e) || {};
				return {
					center: n.add(i),
					correction: r.subtract(i),
					size: s
				};
			}
			return {
				center: n.getRelativeCenterPoint().add(i),
				size: s
			};
		}
	}
};
i(ps, `type`, `clip-path`), M.setClass(ps);
var ms = class extends ra {
	getInitialSize({ target: e }, { size: t }) {
		return new N(e.width || t.x, e.height || t.y);
	}
};
i(ms, `type`, `fixed`), M.setClass(ms);
var hs = class extends oa {
	subscribeTargets(e) {
		let t = e.target;
		e.targets.reduce((e, t) => (t.parent && e.add(t.parent), e), /* @__PURE__ */ new Set()).forEach((e) => {
			e.layoutManager.subscribeTargets({
				target: e,
				targets: [t]
			});
		});
	}
	unsubscribeTargets(e) {
		let t = e.target, n = t.getObjects();
		e.targets.reduce((e, t) => (t.parent && e.add(t.parent), e), /* @__PURE__ */ new Set()).forEach((e) => {
			!n.some((t) => t.parent === e) && e.layoutManager.unsubscribeTargets({
				target: e,
				targets: [t]
			});
		});
	}
};
var gs = class e extends ca {
	static getDefaults() {
		return {
			...super.getDefaults(),
			...e.ownDefaults
		};
	}
	constructor(t = [], n = {}) {
		super(), Object.assign(this, e.ownDefaults), this.setOptions(n);
		let { left: r, top: i, layoutManager: a } = n;
		this.groupInit(t, {
			left: r,
			top: i,
			layoutManager: a == null ? new hs() : a
		});
	}
	_shouldSetNestedCoords() {
		return !0;
	}
	__objectSelectionMonitor() {}
	multiSelectAdd(...e) {
		this.multiSelectionStacking === `selection-order` ? this.add(...e) : e.forEach((e) => {
			let t = this._objects.findIndex((t) => t.isInFrontOf(e)), n = t === -1 ? this.size() : t;
			this.insertAt(n, e);
		});
	}
	canEnterGroup(e) {
		return this.getObjects().some((t) => t.isDescendantOf(e) || e.isDescendantOf(t)) ? (s(`error`, `ActiveSelection: circular object trees are not supported, this call has no effect`), !1) : super.canEnterGroup(e);
	}
	enterGroup(e, t) {
		e.parent && e.parent === e.group ? e.parent._exitGroup(e) : e.group && e.parent !== e.group && e.group.remove(e), this._enterGroup(e, t);
	}
	exitGroup(e, t) {
		this._exitGroup(e, t), e.parent && e.parent._enterGroup(e, !0);
	}
	_onAfterObjectsChange(e, t) {
		super._onAfterObjectsChange(e, t);
		let n = /* @__PURE__ */ new Set();
		t.forEach((e) => {
			let { parent: t } = e;
			t && n.add(t);
		}), e === `removed` ? n.forEach((e) => {
			e._onAfterObjectsChange(ta, t);
		}) : n.forEach((e) => {
			e._set(`dirty`, !0);
		});
	}
	onDeselect() {
		return this.removeAll(), !1;
	}
	toString() {
		return `#<ActiveSelection: (${this.complexity()})>`;
	}
	shouldCache() {
		return !1;
	}
	isOnACache() {
		return !1;
	}
	_renderControls(e, t, n) {
		e.save(), e.globalAlpha = this.isMoving ? this.borderOpacityWhenMoving : 1;
		let r = {
			hasControls: !1,
			...n,
			forActiveSelection: !0
		};
		for (let t = 0; t < this._objects.length; t++) this._objects[t]._renderControls(e, r);
		super._renderControls(e, t), e.restore();
	}
};
i(gs, `type`, `ActiveSelection`), i(gs, `ownDefaults`, { multiSelectionStacking: `canvas-stacking` }), M.setClass(gs), M.setClass(gs, `activeSelection`);
var _s = class {
	constructor() {
		i(this, `resources`, {});
	}
	applyFilters(e, t, n, r, i) {
		let a = i.getContext(`2d`, {
			willReadFrequently: !0,
			desynchronized: !0
		});
		if (!a) return;
		a.drawImage(t, 0, 0, n, r);
		let o = {
			sourceWidth: n,
			sourceHeight: r,
			imageData: a.getImageData(0, 0, n, r),
			originalEl: t,
			originalImageData: a.getImageData(0, 0, n, r),
			canvasEl: i,
			ctx: a,
			filterBackend: this
		};
		e.forEach((e) => {
			e.applyTo(o);
		});
		let { imageData: s } = o;
		return s.width === n && s.height === r || (i.width = s.width, i.height = s.height), a.putImageData(s, 0, 0), o;
	}
};
var vs = class {
	constructor({ tileSize: e = o.textureSize } = {}) {
		i(this, `aPosition`, new Float32Array([
			0,
			0,
			0,
			1,
			1,
			0,
			1,
			1
		])), i(this, `resources`, {}), this.tileSize = e, this.setupGLContext(e, e), this.captureGPUInfo();
	}
	setupGLContext(e, t) {
		this.dispose(), this.createWebGLCanvas(e, t);
	}
	createWebGLCanvas(e, t) {
		let n = F({
			width: e,
			height: t
		}), r = n.getContext(`webgl`, {
			alpha: !0,
			premultipliedAlpha: !1,
			depth: !1,
			stencil: !1,
			antialias: !1
		});
		r && (r.clearColor(0, 0, 0, 0), this.canvas = n, this.gl = r);
	}
	applyFilters(e, t, n, r, i, a) {
		let o = this.gl, s = i.getContext(`2d`);
		if (!o || !s) return;
		let c;
		a && (c = this.getCachedTexture(a, t));
		let l = {
			originalWidth: t.width || t.naturalWidth || 0,
			originalHeight: t.height || t.naturalHeight || 0,
			sourceWidth: n,
			sourceHeight: r,
			destinationWidth: n,
			destinationHeight: r,
			context: o,
			sourceTexture: this.createTexture(o, n, r, c ? void 0 : t),
			targetTexture: this.createTexture(o, n, r),
			originalTexture: c || this.createTexture(o, n, r, c ? void 0 : t),
			passes: e.length,
			webgl: !0,
			aPosition: this.aPosition,
			programCache: this.programCache,
			pass: 0,
			filterBackend: this,
			targetCanvas: i
		}, u = o.createFramebuffer();
		return o.bindFramebuffer(o.FRAMEBUFFER, u), e.forEach((e) => {
			e && e.applyTo(l);
		}), function(e) {
			let t = e.targetCanvas, n = t.width, r = t.height, i = e.destinationWidth, a = e.destinationHeight;
			n === i && r === a || (t.width = i, t.height = a);
		}(l), this.copyGLTo2D(o, l), o.bindTexture(o.TEXTURE_2D, null), o.deleteTexture(l.sourceTexture), o.deleteTexture(l.targetTexture), o.deleteFramebuffer(u), s.setTransform(1, 0, 0, 1, 0, 0), l;
	}
	dispose() {
		this.canvas && (this.canvas = null, this.gl = null), this.clearWebGLCaches();
	}
	clearWebGLCaches() {
		this.programCache = {}, this.textureCache = {};
	}
	createTexture(e, t, n, r, i) {
		let { NEAREST: a, TEXTURE_2D: o, RGBA: s, UNSIGNED_BYTE: c, CLAMP_TO_EDGE: l, TEXTURE_MAG_FILTER: u, TEXTURE_MIN_FILTER: d, TEXTURE_WRAP_S: f, TEXTURE_WRAP_T: p } = e, m = e.createTexture();
		return e.bindTexture(o, m), e.texParameteri(o, u, i || a), e.texParameteri(o, d, i || a), e.texParameteri(o, f, l), e.texParameteri(o, p, l), r ? e.texImage2D(o, 0, s, s, c, r) : e.texImage2D(o, 0, s, t, n, 0, s, c, null), m;
	}
	getCachedTexture(e, t, n) {
		let { textureCache: r } = this;
		if (r[e]) return r[e];
		{
			let i = this.createTexture(this.gl, t.width, t.height, t, n);
			return i && (r[e] = i), i;
		}
	}
	evictCachesForKey(e) {
		this.textureCache[e] && (this.gl.deleteTexture(this.textureCache[e]), delete this.textureCache[e]);
	}
	copyGLTo2D(e, t) {
		let n = e.canvas, r = t.targetCanvas, i = r.getContext(`2d`);
		if (!i) return;
		i.translate(0, r.height), i.scale(1, -1);
		let a = n.height - r.height;
		i.drawImage(n, 0, a, r.width, r.height, 0, 0, r.width, r.height);
	}
	copyGLTo2DPutImageData(e, t) {
		let n = t.targetCanvas.getContext(`2d`), r = t.destinationWidth, i = t.destinationHeight, a = r * i * 4;
		if (!n) return;
		let o = new Uint8Array(this.imageBuffer, 0, a), s = new Uint8ClampedArray(this.imageBuffer, 0, a);
		e.readPixels(0, 0, r, i, e.RGBA, e.UNSIGNED_BYTE, o);
		let c = new ImageData(s, r, i);
		n.putImageData(c, 0, 0);
	}
	captureGPUInfo() {
		if (this.gpuInfo) return this.gpuInfo;
		let e = this.gl, t = {
			renderer: ``,
			vendor: ``
		};
		if (!e) return t;
		let n = e.getExtension(`WEBGL_debug_renderer_info`);
		if (n) {
			let r = e.getParameter(n.UNMASKED_RENDERER_WEBGL), i = e.getParameter(n.UNMASKED_VENDOR_WEBGL);
			r && (t.renderer = r.toLowerCase()), i && (t.vendor = i.toLowerCase());
		}
		return this.gpuInfo = t, t;
	}
};
var ys;
function bs() {
	let { WebGLProbe: e } = h();
	return e.queryWebGL(P()), o.enableGLFiltering && e.isSupported(o.textureSize) ? new vs({ tileSize: o.textureSize }) : new _s();
}
function xs(e = !0) {
	return !ys && e && (ys = bs()), ys;
}
var Cs = [`cropX`, `cropY`];
var ws = class e extends J {
	static getDefaults() {
		return {
			...super.getDefaults(),
			...e.ownDefaults
		};
	}
	constructor(t, n) {
		super(), i(this, `_lastScaleX`, 1), i(this, `_lastScaleY`, 1), i(this, `_filterScalingX`, 1), i(this, `_filterScalingY`, 1), this.filters = [], Object.assign(this, e.ownDefaults), this.setOptions(n), this.cacheKey = `texture${je()}`, this.setElement(typeof t == `string` ? (this.canvas && H(this.canvas.getElement()) || g()).getElementById(t) : t, n);
	}
	getElement() {
		return this._element;
	}
	setElement(e, t = {}) {
		this.removeTexture(this.cacheKey), this.removeTexture(`${this.cacheKey}_filtered`), this._element = e, this._originalElement = e, this._setWidthHeight(t), this.filters.length !== 0 && this.applyFilters(), this.resizeFilter && this.applyResizeFilters();
	}
	removeTexture(e) {
		let t = xs(!1);
		t instanceof vs && t.evictCachesForKey(e);
	}
	dispose() {
		super.dispose(), this.removeTexture(this.cacheKey), this.removeTexture(`${this.cacheKey}_filtered`), this._cacheContext = null, [
			`_originalElement`,
			`_element`,
			`_filteredEl`,
			`_cacheCanvas`
		].forEach((e) => {
			let t = this[e];
			t && h().dispose(t), this[e] = void 0;
		});
	}
	getCrossOrigin() {
		return this._originalElement && (this._originalElement.crossOrigin || null);
	}
	getOriginalSize() {
		let e = this.getElement();
		return e ? {
			width: e.naturalWidth || e.width,
			height: e.naturalHeight || e.height
		} : {
			width: 0,
			height: 0
		};
	}
	_stroke(e) {
		if (!this.stroke || this.strokeWidth === 0) return;
		let t = this.width / 2, n = this.height / 2;
		e.beginPath(), e.moveTo(-t, -n), e.lineTo(t, -n), e.lineTo(t, n), e.lineTo(-t, n), e.lineTo(-t, -n), e.closePath();
	}
	toObject(e = []) {
		let t = [];
		return this.filters.forEach((e) => {
			e && t.push(e.toObject());
		}), {
			...super.toObject([...Cs, ...e]),
			src: this.getSrc(),
			crossOrigin: this.getCrossOrigin(),
			filters: t,
			...this.resizeFilter ? { resizeFilter: this.resizeFilter.toObject() } : {}
		};
	}
	hasCrop() {
		return !!this.cropX || !!this.cropY || this.width < this._element.width || this.height < this._element.height;
	}
	_toSVG() {
		let e = [], t = this._element, n = -this.width / 2, r = -this.height / 2, i = [], a = [], o = ``, s = ``;
		if (!t) return [];
		if (this.hasCrop()) {
			let e = je();
			i.push(`<clipPath id="imageCrop_` + e + `">
`, `	<rect x="` + n + `" y="` + r + `" width="` + U(this.width) + `" height="` + U(this.height) + `" />
`, `</clipPath>
`), o = ` clip-path="url(#imageCrop_` + e + `)" `;
		}
		if (this.imageSmoothing || (s = ` image-rendering="optimizeSpeed"`), e.push(`	<image `, `COMMON_PARTS`, `xlink:href="${U(this.getSrc(!0))}" x="${n - this.cropX}" y="${r - this.cropY}" width="${t.width || t.naturalWidth}" height="${t.height || t.naturalHeight}"${s}${o}></image>\n`), this.stroke || this.strokeDashArray) {
			let e = this.fill;
			this.fill = null, a = [`\t<rect x="${n}" y="${r}" width="${U(this.width)}" height="${U(this.height)}" style="${this.getSvgStyles()}" />\n`], this.fill = e;
		}
		return i = this.paintFirst === `fill` ? i.concat(e, a) : i.concat(a, e), i;
	}
	getSrc(e) {
		let t = e ? this._element : this._originalElement;
		return t ? t.toDataURL ? t.toDataURL() : this.srcFromAttribute ? t.getAttribute(`src`) || `` : t.src : this.src || ``;
	}
	getSvgSrc(e) {
		return this.getSrc(e);
	}
	setSrc(e, { crossOrigin: t, signal: n } = {}) {
		return Ze(e, {
			crossOrigin: t,
			signal: n
		}).then((e) => {
			t !== void 0 && this.set({ crossOrigin: t }), this.setElement(e);
		});
	}
	toString() {
		return `#<Image: { src: "${this.getSrc()}" }>`;
	}
	applyResizeFilters() {
		let e = this.resizeFilter, t = this.minimumScaleTrigger, n = this.getTotalObjectScaling(), r = n.x, i = n.y, a = this._filteredEl || this._originalElement;
		if (this.group && this.set(`dirty`, !0), !e || r > t && i > t) return this._element = a, this._filterScalingX = 1, this._filterScalingY = 1, this._lastScaleX = r, void (this._lastScaleY = i);
		let o = F(a), { width: s, height: c } = a;
		this._element = o, this._lastScaleX = e.scaleX = r, this._lastScaleY = e.scaleY = i, xs().applyFilters([e], a, s, c, this._element), this._filterScalingX = o.width / this._originalElement.width, this._filterScalingY = o.height / this._originalElement.height;
	}
	applyFilters(e = this.filters || []) {
		if (e = e.filter((e) => e && !e.isNeutralState()), this.set(`dirty`, !0), this.removeTexture(`${this.cacheKey}_filtered`), e.length === 0) return this._element = this._originalElement, this._filteredEl = void 0, this._filterScalingX = 1, void (this._filterScalingY = 1);
		let t = this._originalElement, n = t.naturalWidth || t.width, r = t.naturalHeight || t.height;
		if (this._element === this._originalElement) {
			let e = F({
				width: n,
				height: r
			});
			this._element = e, this._filteredEl = e;
		} else this._filteredEl && (this._element = this._filteredEl, this._filteredEl.getContext(`2d`).clearRect(0, 0, n, r), this._lastScaleX = 1, this._lastScaleY = 1);
		xs().applyFilters(e, this._originalElement, n, r, this._element, this.cacheKey), this._originalElement.width === this._element.width && this._originalElement.height === this._element.height || (this._filterScalingX = this._element.width / this._originalElement.width, this._filterScalingY = this._element.height / this._originalElement.height);
	}
	_render(e) {
		e.imageSmoothingEnabled = this.imageSmoothing, !0 !== this.isMoving && this.resizeFilter && this._needsResize() && this.applyResizeFilters(), this._stroke(e), this._renderPaintInOrder(e);
	}
	drawCacheOnCanvas(e) {
		e.imageSmoothingEnabled = this.imageSmoothing, super.drawCacheOnCanvas(e);
	}
	shouldCache() {
		return this.needsItsOwnCache();
	}
	_renderFill(e) {
		let t = this._element;
		if (!t) return;
		let n = this._filterScalingX, r = this._filterScalingY, i = this.width, a = this.height, o = Math.max(this.cropX, 0), s = Math.max(this.cropY, 0), c = t.naturalWidth || t.width, l = t.naturalHeight || t.height, u = o * n, d = s * r, f = Math.min(i * n, c - u), p = Math.min(a * r, l - d), m = -i / 2, h = -a / 2, g = Math.min(i, c / n - o), _ = Math.min(a, l / r - s);
		t && e.drawImage(t, u, d, f, p, m, h, g, _);
	}
	_needsResize() {
		let e = this.getTotalObjectScaling();
		return e.x !== this._lastScaleX || e.y !== this._lastScaleY;
	}
	_resetWidthHeight() {
		this.set(this.getOriginalSize());
	}
	_setWidthHeight({ width: e, height: t } = {}) {
		let n = this.getOriginalSize();
		this.width = e || n.width, this.height = t || n.height;
	}
	parsePreserveAspectRatioAttribute() {
		let e = mn(this.preserveAspectRatio || ``), t = this.width, n = this.height, r = {
			width: t,
			height: n
		}, i, a = this._element.width, o = this._element.height, s = 1, c = 1, l = 0, u = 0, d = 0, f = 0;
		return !e || e.alignX === `none` && e.alignY === `none` ? (s = t / a, c = n / o) : (e.meetOrSlice === `meet` && (s = c = ua(this._element, r), i = (t - a * s) / 2, e.alignX === `Min` && (l = -i), e.alignX === `Max` && (l = i), i = (n - o * c) / 2, e.alignY === `Min` && (u = -i), e.alignY === `Max` && (u = i)), e.meetOrSlice === `slice` && (s = c = da(this._element, r), i = a - t / s, e.alignX === `Mid` && (d = i / 2), e.alignX === `Max` && (d = i), i = o - n / c, e.alignY === `Mid` && (f = i / 2), e.alignY === `Max` && (f = i), a = t / s, o = n / c)), {
			width: a,
			height: o,
			scaleX: s,
			scaleY: c,
			offsetLeft: l,
			offsetTop: u,
			cropX: d,
			cropY: f
		};
	}
	static fromObject({ filters: e, resizeFilter: t, src: n, crossOrigin: r, type: i, ...a }, o) {
		return Promise.all([
			Ze(n, {
				...o,
				crossOrigin: r
			}),
			e && Qe(e, o),
			t ? Qe([t], o) : [],
			$e(a, o)
		]).then(([e, t = [], [r], i = {}]) => new this(e, {
			...a,
			src: n,
			filters: t,
			resizeFilter: r,
			...i
		}));
	}
	static fromURL(e, { crossOrigin: t = null, signal: n } = {}, r) {
		return Ze(e, {
			crossOrigin: t,
			signal: n
		}).then((e) => new this(e, r));
	}
	static async fromElement(e, t = {}, n) {
		let r = Zi(e, this.ATTRIBUTE_NAMES, n);
		return this.fromURL(r[`xlink:href`] || r.href, t, r).catch((e) => (s(`log`, `Unable to parse Image`, e), null));
	}
};
i(ws, `type`, `Image`), i(ws, `cacheProperties`, [...Un, ...Cs]), i(ws, `ownDefaults`, {
	strokeWidth: 0,
	srcFromAttribute: !1,
	minimumScaleTrigger: .5,
	cropX: 0,
	cropY: 0,
	imageSmoothing: !0
}), i(ws, `ATTRIBUTE_NAMES`, [
	...ki,
	`x`,
	`y`,
	`width`,
	`height`,
	`preserveAspectRatio`,
	`xlink:href`,
	`href`,
	`crossOrigin`,
	`image-rendering`
]), M.setClass(ws), M.setSVGClass(ws);
_n([
	`pattern`,
	`defs`,
	`symbol`,
	`metadata`,
	`clipPath`,
	`mask`,
	`desc`
]);
var zs = (e) => e.webgl !== void 0;
var Vs = `precision highp float`;
var Hs = `\n    ${Vs};\n    varying vec2 vTexCoord;\n    uniform sampler2D uTexture;\n    void main() {\n      gl_FragColor = texture2D(uTexture, vTexCoord);\n    }`;
var Us = new RegExp(Vs, `g`);
var $ = class {
	get type() {
		return this.constructor.type;
	}
	constructor({ type: e, ...t } = {}) {
		Object.assign(this, this.constructor.defaults, t);
	}
	getFragmentSource() {
		return Hs;
	}
	getVertexSource() {
		return `
    attribute vec2 aPosition;
    varying vec2 vTexCoord;
    void main() {
      vTexCoord = aPosition;
      gl_Position = vec4(aPosition * 2.0 - 1.0, 0.0, 1.0);
    }`;
	}
	createProgram(e, t = this.getFragmentSource(), n = this.getVertexSource()) {
		let { WebGLProbe: { GLPrecision: r = `highp` } } = h();
		r !== `highp` && (t = t.replace(Us, Vs.replace(`highp`, r)));
		let i = e.createShader(e.VERTEX_SHADER), a = e.createShader(e.FRAGMENT_SHADER), o = e.createProgram();
		if (!i || !a || !o) throw new c(`Vertex, fragment shader or program creation error`);
		if (e.shaderSource(i, n), e.compileShader(i), !e.getShaderParameter(i, e.COMPILE_STATUS)) throw new c(`Vertex shader compile error for ${this.type}: ${e.getShaderInfoLog(i)}`);
		if (e.shaderSource(a, t), e.compileShader(a), !e.getShaderParameter(a, e.COMPILE_STATUS)) throw new c(`Fragment shader compile error for ${this.type}: ${e.getShaderInfoLog(a)}`);
		if (e.attachShader(o, i), e.attachShader(o, a), e.linkProgram(o), !e.getProgramParameter(o, e.LINK_STATUS)) throw new c(`Shader link error for "${this.type}" ${e.getProgramInfoLog(o)}`);
		let s = this.getUniformLocations(e, o) || {};
		return s.uStepW = e.getUniformLocation(o, `uStepW`), s.uStepH = e.getUniformLocation(o, `uStepH`), {
			program: o,
			attributeLocations: this.getAttributeLocations(e, o),
			uniformLocations: s
		};
	}
	getAttributeLocations(e, t) {
		return { aPosition: e.getAttribLocation(t, `aPosition`) };
	}
	getUniformLocations(e, t) {
		let n = this.constructor.uniformLocations, r = {};
		for (let i = 0; i < n.length; i++) r[n[i]] = e.getUniformLocation(t, n[i]);
		return r;
	}
	sendAttributeData(e, t, n) {
		let r = t.aPosition, i = e.createBuffer();
		e.bindBuffer(e.ARRAY_BUFFER, i), e.enableVertexAttribArray(r), e.vertexAttribPointer(r, 2, e.FLOAT, !1, 0, 0), e.bufferData(e.ARRAY_BUFFER, n, e.STATIC_DRAW);
	}
	_setupFrameBuffer(e) {
		let t = e.context;
		if (e.passes > 1) {
			let n = e.destinationWidth, r = e.destinationHeight;
			e.sourceWidth === n && e.sourceHeight === r || (t.deleteTexture(e.targetTexture), e.targetTexture = e.filterBackend.createTexture(t, n, r)), t.framebufferTexture2D(t.FRAMEBUFFER, t.COLOR_ATTACHMENT0, t.TEXTURE_2D, e.targetTexture, 0);
		} else t.bindFramebuffer(t.FRAMEBUFFER, null), t.finish();
	}
	_swapTextures(e) {
		e.passes--, e.pass++;
		let t = e.targetTexture;
		e.targetTexture = e.sourceTexture, e.sourceTexture = t;
	}
	isNeutralState(e) {
		return !1;
	}
	applyTo(e) {
		zs(e) ? (this._setupFrameBuffer(e), this.applyToWebGL(e), this._swapTextures(e)) : this.applyTo2d(e);
	}
	applyTo2d(e) {}
	getCacheKey() {
		return this.type;
	}
	retrieveShader(e) {
		let t = this.getCacheKey();
		return e.programCache[t] || (e.programCache[t] = this.createProgram(e.context)), e.programCache[t];
	}
	applyToWebGL(e) {
		let t = e.context, n = this.retrieveShader(e);
		e.pass === 0 && e.originalTexture ? t.bindTexture(t.TEXTURE_2D, e.originalTexture) : t.bindTexture(t.TEXTURE_2D, e.sourceTexture), t.useProgram(n.program), this.sendAttributeData(t, n.attributeLocations, e.aPosition), t.uniform1f(n.uniformLocations.uStepW, 1 / e.sourceWidth), t.uniform1f(n.uniformLocations.uStepH, 1 / e.sourceHeight), this.sendUniformData(t, n.uniformLocations), t.viewport(0, 0, e.destinationWidth, e.destinationHeight), t.drawArrays(t.TRIANGLE_STRIP, 0, 4);
	}
	bindAdditionalTexture(e, t, n) {
		e.activeTexture(n), e.bindTexture(e.TEXTURE_2D, t), e.activeTexture(e.TEXTURE0);
	}
	unbindAdditionalTexture(e, t) {
		e.activeTexture(t), e.bindTexture(e.TEXTURE_2D, null), e.activeTexture(e.TEXTURE0);
	}
	sendUniformData(e, t) {}
	createHelpLayer(e) {
		if (!e.helpLayer) {
			let { sourceWidth: t, sourceHeight: n } = e;
			e.helpLayer = F({
				width: t,
				height: n
			});
		}
	}
	toObject() {
		let e = Object.keys(this.constructor.defaults || {});
		return {
			type: this.type,
			...e.reduce((e, t) => (e[t] = this[t], e), {})
		};
	}
	toJSON() {
		return this.toObject();
	}
	static async fromObject({ type: e, ...t }, n) {
		return new this(t);
	}
};
i($, `type`, `BaseFilter`), i($, `uniformLocations`, []);
var Ws = {
	multiply: `gl_FragColor.rgb *= uColor.rgb;
`,
	screen: `gl_FragColor.rgb = 1.0 - (1.0 - gl_FragColor.rgb) * (1.0 - uColor.rgb);
`,
	add: `gl_FragColor.rgb += uColor.rgb;
`,
	difference: `gl_FragColor.rgb = abs(gl_FragColor.rgb - uColor.rgb);
`,
	subtract: `gl_FragColor.rgb -= uColor.rgb;
`,
	lighten: `gl_FragColor.rgb = max(gl_FragColor.rgb, uColor.rgb);
`,
	darken: `gl_FragColor.rgb = min(gl_FragColor.rgb, uColor.rgb);
`,
	exclusion: `gl_FragColor.rgb += uColor.rgb - 2.0 * (uColor.rgb * gl_FragColor.rgb);
`,
	overlay: `
    if (uColor.r < 0.5) {
      gl_FragColor.r *= 2.0 * uColor.r;
    } else {
      gl_FragColor.r = 1.0 - 2.0 * (1.0 - gl_FragColor.r) * (1.0 - uColor.r);
    }
    if (uColor.g < 0.5) {
      gl_FragColor.g *= 2.0 * uColor.g;
    } else {
      gl_FragColor.g = 1.0 - 2.0 * (1.0 - gl_FragColor.g) * (1.0 - uColor.g);
    }
    if (uColor.b < 0.5) {
      gl_FragColor.b *= 2.0 * uColor.b;
    } else {
      gl_FragColor.b = 1.0 - 2.0 * (1.0 - gl_FragColor.b) * (1.0 - uColor.b);
    }
    `,
	tint: `
    gl_FragColor.rgb *= (1.0 - uColor.a);
    gl_FragColor.rgb += uColor.rgb;
    `
};
var Gs = class extends $ {
	getCacheKey() {
		return `${this.type}_${this.mode}`;
	}
	getFragmentSource() {
		return `\n      precision highp float;\n      uniform sampler2D uTexture;\n      uniform vec4 uColor;\n      varying vec2 vTexCoord;\n      void main() {\n        vec4 color = texture2D(uTexture, vTexCoord);\n        gl_FragColor = color;\n        if (color.a > 0.0) {\n          ${Ws[this.mode]}\n        }\n      }\n      `;
	}
	applyTo2d({ imageData: { data: e } }) {
		let t = new G(this.color).getSource(), n = this.alpha, r = t[0] * n, i = t[1] * n, a = t[2] * n, o = 1 - n;
		for (let t = 0; t < e.length; t += 4) {
			let n = e[t], s = e[t + 1], c = e[t + 2], l, u, d;
			switch (this.mode) {
				case `multiply`:
					l = n * r / 255, u = s * i / 255, d = c * a / 255;
					break;
				case `screen`:
					l = 255 - (255 - n) * (255 - r) / 255, u = 255 - (255 - s) * (255 - i) / 255, d = 255 - (255 - c) * (255 - a) / 255;
					break;
				case `add`:
					l = n + r, u = s + i, d = c + a;
					break;
				case `difference`:
					l = Math.abs(n - r), u = Math.abs(s - i), d = Math.abs(c - a);
					break;
				case `subtract`:
					l = n - r, u = s - i, d = c - a;
					break;
				case `darken`:
					l = Math.min(n, r), u = Math.min(s, i), d = Math.min(c, a);
					break;
				case `lighten`:
					l = Math.max(n, r), u = Math.max(s, i), d = Math.max(c, a);
					break;
				case `overlay`:
					l = r < 128 ? 2 * n * r / 255 : 255 - 2 * (255 - n) * (255 - r) / 255, u = i < 128 ? 2 * s * i / 255 : 255 - 2 * (255 - s) * (255 - i) / 255, d = a < 128 ? 2 * c * a / 255 : 255 - 2 * (255 - c) * (255 - a) / 255;
					break;
				case `exclusion`:
					l = r + n - 2 * r * n / 255, u = i + s - 2 * i * s / 255, d = a + c - 2 * a * c / 255;
					break;
				case `tint`: l = r + n * o, u = i + s * o, d = a + c * o;
			}
			e[t] = l, e[t + 1] = u, e[t + 2] = d;
		}
	}
	sendUniformData(e, t) {
		let n = new G(this.color).getSource();
		n[0] = this.alpha * n[0] / 255, n[1] = this.alpha * n[1] / 255, n[2] = this.alpha * n[2] / 255, n[3] = this.alpha, e.uniform4fv(t.uColor, n);
	}
};
i(Gs, `defaults`, {
	color: `#F95C63`,
	mode: `multiply`,
	alpha: 1
}), i(Gs, `type`, `BlendColor`), i(Gs, `uniformLocations`, [`uColor`]), M.setClass(Gs);
var Ks = {
	multiply: `
    precision highp float;
    uniform sampler2D uTexture;
    uniform sampler2D uImage;
    uniform vec4 uColor;
    varying vec2 vTexCoord;
    varying vec2 vTexCoord2;
    void main() {
      vec4 color = texture2D(uTexture, vTexCoord);
      vec4 color2 = texture2D(uImage, vTexCoord2);
      color.rgba *= color2.rgba;
      gl_FragColor = color;
    }
    `,
	mask: `
    precision highp float;
    uniform sampler2D uTexture;
    uniform sampler2D uImage;
    uniform vec4 uColor;
    varying vec2 vTexCoord;
    varying vec2 vTexCoord2;
    void main() {
      vec4 color = texture2D(uTexture, vTexCoord);
      vec4 color2 = texture2D(uImage, vTexCoord2);
      color.a = color2.a;
      gl_FragColor = color;
    }
    `
};
var qs = class extends $ {
	getCacheKey() {
		return `${this.type}_${this.mode}`;
	}
	getFragmentSource() {
		return Ks[this.mode];
	}
	getVertexSource() {
		return `
    attribute vec2 aPosition;
    varying vec2 vTexCoord;
    varying vec2 vTexCoord2;
    uniform mat3 uTransformMatrix;
    void main() {
      vTexCoord = aPosition;
      vTexCoord2 = (uTransformMatrix * vec3(aPosition, 1.0)).xy;
      gl_Position = vec4(aPosition * 2.0 - 1.0, 0.0, 1.0);
    }
    `;
	}
	applyToWebGL(e) {
		let t = e.context, n = this.createTexture(e.filterBackend, this.image);
		this.bindAdditionalTexture(t, n, t.TEXTURE1), super.applyToWebGL(e), this.unbindAdditionalTexture(t, t.TEXTURE1);
	}
	createTexture(e, t) {
		return e.getCachedTexture(t.cacheKey, t.getElement());
	}
	calculateMatrix() {
		let e = this.image, { width: t, height: n } = e.getElement();
		return [
			1 / e.scaleX,
			0,
			0,
			0,
			1 / e.scaleY,
			0,
			-e.left / t,
			-e.top / n,
			1
		];
	}
	applyTo2d({ imageData: { data: e, width: t, height: n }, filterBackend: { resources: r } }) {
		let i = this.image;
		r.blendImage || (r.blendImage = P());
		let a = r.blendImage, o = a.getContext(`2d`);
		a.width !== t || a.height !== n ? (a.width = t, a.height = n) : o.clearRect(0, 0, t, n), o.setTransform(i.scaleX, 0, 0, i.scaleY, i.left, i.top), o.drawImage(i.getElement(), 0, 0, t, n);
		let s = o.getImageData(0, 0, t, n).data;
		for (let t = 0; t < e.length; t += 4) {
			let n = e[t], r = e[t + 1], i = e[t + 2], a = e[t + 3], o = s[t], c = s[t + 1], l = s[t + 2], u = s[t + 3];
			switch (this.mode) {
				case `multiply`:
					e[t] = n * o / 255, e[t + 1] = r * c / 255, e[t + 2] = i * l / 255, e[t + 3] = a * u / 255;
					break;
				case `mask`: e[t + 3] = u;
			}
		}
	}
	sendUniformData(e, t) {
		let n = this.calculateMatrix();
		e.uniform1i(t.uImage, 1), e.uniformMatrix3fv(t.uTransformMatrix, !1, n);
	}
	toObject() {
		return {
			...super.toObject(),
			image: this.image && this.image.toObject()
		};
	}
	static async fromObject({ type: e, image: t, ...n }, r) {
		return ws.fromObject(t, r).then((e) => new this({
			...n,
			image: e
		}));
	}
};
i(qs, `type`, `BlendImage`), i(qs, `defaults`, {
	mode: `multiply`,
	alpha: 1
}), i(qs, `uniformLocations`, [`uTransformMatrix`, `uImage`]), M.setClass(qs);
var Js = class extends $ {
	getFragmentSource() {
		return `
    precision highp float;
    uniform sampler2D uTexture;
    uniform vec2 uDelta;
    varying vec2 vTexCoord;
    const float nSamples = 15.0;
    vec3 v3offset = vec3(12.9898, 78.233, 151.7182);
    float random(vec3 scale) {
      /* use the fragment position for a different seed per-pixel */
      return fract(sin(dot(gl_FragCoord.xyz, scale)) * 43758.5453);
    }
    void main() {
      vec4 color = vec4(0.0);
      float totalC = 0.0;
      float totalA = 0.0;
      float offset = random(v3offset);
      for (float t = -nSamples; t <= nSamples; t++) {
        float percent = (t + offset - 0.5) / nSamples;
        vec4 sample = texture2D(uTexture, vTexCoord + uDelta * percent);
        float weight = 1.0 - abs(percent);
        float alpha = weight * sample.a;
        color.rgb += sample.rgb * alpha;
        color.a += alpha;
        totalA += weight;
        totalC += alpha;
      }
      gl_FragColor.rgb = color.rgb / totalC;
      gl_FragColor.a = color.a / totalA;
    }
  `;
	}
	applyTo(e) {
		zs(e) ? (this.aspectRatio = e.sourceWidth / e.sourceHeight, e.passes++, this._setupFrameBuffer(e), this.horizontal = !0, this.applyToWebGL(e), this._swapTextures(e), this._setupFrameBuffer(e), this.horizontal = !1, this.applyToWebGL(e), this._swapTextures(e)) : this.applyTo2d(e);
	}
	applyTo2d({ imageData: { data: e, width: t, height: n } }) {
		this.aspectRatio = t / n, this.horizontal = !0;
		let r = this.getBlurValue() * t, i = new Uint8ClampedArray(e), a = 4 * t;
		for (let t = 0; t < e.length; t += 4) {
			let n = 0, o = 0, s = 0, c = 0, l = 0, u = t - t % a, d = u + a;
			for (let i = -14; i < 15; i++) {
				let a = i / 15, f = 4 * Math.floor(r * a), p = 1 - Math.abs(a), m = t + f;
				m < u ? m = u : m > d && (m = d);
				let h = e[m + 3] * p;
				n += e[m] * h, o += e[m + 1] * h, s += e[m + 2] * h, c += h, l += p;
			}
			i[t] = n / c, i[t + 1] = o / c, i[t + 2] = s / c, i[t + 3] = c / l;
		}
		this.horizontal = !1, r = this.getBlurValue() * n;
		for (let t = 0; t < i.length; t += 4) {
			let n = 0, o = 0, s = 0, c = 0, l = 0, u = t % a, d = i.length - a + u;
			for (let e = -14; e < 15; e++) {
				let f = e / 15, p = Math.floor(r * f) * a, m = 1 - Math.abs(f), h = t + p;
				h < u ? h = u : h > d && (h = d);
				let g = i[h + 3] * m;
				n += i[h] * g, o += i[h + 1] * g, s += i[h + 2] * g, c += g, l += m;
			}
			e[t] = n / c, e[t + 1] = o / c, e[t + 2] = s / c, e[t + 3] = c / l;
		}
	}
	sendUniformData(e, t) {
		let n = this.chooseRightDelta();
		e.uniform2fv(t.uDelta, n);
	}
	isNeutralState() {
		return this.blur === 0;
	}
	getBlurValue() {
		let e = 1, { horizontal: t, aspectRatio: n } = this;
		return t ? n > 1 && (e = 1 / n) : n < 1 && (e = n), e * this.blur * .12;
	}
	chooseRightDelta() {
		let e = this.getBlurValue();
		return this.horizontal ? [e, 0] : [0, e];
	}
};
i(Js, `type`, `Blur`), i(Js, `defaults`, { blur: 0 }), i(Js, `uniformLocations`, [`uDelta`]), M.setClass(Js);
var Ys = class extends $ {
	getFragmentSource() {
		return `
  precision highp float;
  uniform sampler2D uTexture;
  uniform float uBrightness;
  varying vec2 vTexCoord;
  void main() {
    vec4 color = texture2D(uTexture, vTexCoord);
    color.rgb += uBrightness;
    gl_FragColor = color;
  }
`;
	}
	applyTo2d({ imageData: { data: e } }) {
		let t = Math.round(255 * this.brightness);
		for (let n = 0; n < e.length; n += 4) e[n] += t, e[n + 1] += t, e[n + 2] += t;
	}
	isNeutralState() {
		return this.brightness === 0;
	}
	sendUniformData(e, t) {
		e.uniform1f(t.uBrightness, this.brightness);
	}
};
i(Ys, `type`, `Brightness`), i(Ys, `defaults`, { brightness: 0 }), i(Ys, `uniformLocations`, [`uBrightness`]), M.setClass(Ys);
var Xs = {
	matrix: [
		1,
		0,
		0,
		0,
		0,
		0,
		1,
		0,
		0,
		0,
		0,
		0,
		1,
		0,
		0,
		0,
		0,
		0,
		1,
		0
	],
	colorsOnly: !0
};
var Zs = class extends $ {
	getFragmentSource() {
		return `
  precision highp float;
  uniform sampler2D uTexture;
  varying vec2 vTexCoord;
  uniform mat4 uColorMatrix;
  uniform vec4 uConstants;
  void main() {
    vec4 color = texture2D(uTexture, vTexCoord);
    color *= uColorMatrix;
    color += uConstants;
    gl_FragColor = color;
  }`;
	}
	applyTo2d(e) {
		let t = e.imageData.data, n = this.matrix, r = this.colorsOnly;
		for (let e = 0; e < t.length; e += 4) {
			let i = t[e], a = t[e + 1], o = t[e + 2];
			if (t[e] = i * n[0] + a * n[1] + o * n[2] + 255 * n[4], t[e + 1] = i * n[5] + a * n[6] + o * n[7] + 255 * n[9], t[e + 2] = i * n[10] + a * n[11] + o * n[12] + 255 * n[14], !r) {
				let r = t[e + 3];
				t[e] += r * n[3], t[e + 1] += r * n[8], t[e + 2] += r * n[13], t[e + 3] = i * n[15] + a * n[16] + o * n[17] + r * n[18] + 255 * n[19];
			}
		}
	}
	sendUniformData(e, t) {
		let n = this.matrix, r = [
			n[0],
			n[1],
			n[2],
			n[3],
			n[5],
			n[6],
			n[7],
			n[8],
			n[10],
			n[11],
			n[12],
			n[13],
			n[15],
			n[16],
			n[17],
			n[18]
		], i = [
			n[4],
			n[9],
			n[14],
			n[19]
		];
		e.uniformMatrix4fv(t.uColorMatrix, !1, r), e.uniform4fv(t.uConstants, i);
	}
	toObject() {
		return {
			...super.toObject(),
			matrix: [...this.matrix]
		};
	}
};
function Qs(e, t) {
	var n;
	let r = (i(n = class extends Zs {
		toObject() {
			return {
				type: this.type,
				colorsOnly: this.colorsOnly
			};
		}
	}, `type`, e), i(n, `defaults`, {
		colorsOnly: !1,
		matrix: t
	}), n);
	return M.setClass(r, e), r;
}
i(Zs, `type`, `ColorMatrix`), i(Zs, `defaults`, Xs), i(Zs, `uniformLocations`, [`uColorMatrix`, `uConstants`]), M.setClass(Zs);
var $s = Qs(`Brownie`, [
	.5997,
	.34553,
	-.27082,
	0,
	.186,
	-.0377,
	.86095,
	.15059,
	0,
	-.1449,
	.24113,
	-.07441,
	.44972,
	0,
	-.02965,
	0,
	0,
	0,
	1,
	0
]);
var ec = Qs(`Vintage`, [
	.62793,
	.32021,
	-.03965,
	0,
	.03784,
	.02578,
	.64411,
	.03259,
	0,
	.02926,
	.0466,
	-.08512,
	.52416,
	0,
	.02023,
	0,
	0,
	0,
	1,
	0
]);
var tc = Qs(`Kodachrome`, [
	1.12855,
	-.39673,
	-.03992,
	0,
	.24991,
	-.16404,
	1.08352,
	-.05498,
	0,
	.09698,
	-.16786,
	-.56034,
	1.60148,
	0,
	.13972,
	0,
	0,
	0,
	1,
	0
]);
var nc = Qs(`Technicolor`, [
	1.91252,
	-.85453,
	-.09155,
	0,
	.04624,
	-.30878,
	1.76589,
	-.10601,
	0,
	-.27589,
	-.2311,
	-.75018,
	1.84759,
	0,
	.12137,
	0,
	0,
	0,
	1,
	0
]);
var rc = Qs(`Polaroid`, [
	1.438,
	-.062,
	-.062,
	0,
	0,
	-.122,
	1.378,
	-.122,
	0,
	0,
	-.016,
	-.016,
	1.483,
	0,
	0,
	0,
	0,
	0,
	1,
	0
]);
var ic = Qs(`Sepia`, [
	.393,
	.769,
	.189,
	0,
	0,
	.349,
	.686,
	.168,
	0,
	0,
	.272,
	.534,
	.131,
	0,
	0,
	0,
	0,
	0,
	1,
	0
]);
var ac = Qs(`BlackWhite`, [
	1.5,
	1.5,
	1.5,
	0,
	-1,
	1.5,
	1.5,
	1.5,
	0,
	-1,
	1.5,
	1.5,
	1.5,
	0,
	-1,
	0,
	0,
	0,
	1,
	0
]);
var oc = class extends $ {
	constructor(e = {}) {
		super(e), this.subFilters = e.subFilters || [];
	}
	applyTo(e) {
		zs(e) && (e.passes += this.subFilters.length - 1), this.subFilters.forEach((t) => {
			t.applyTo(e);
		});
	}
	toObject() {
		return {
			type: this.type,
			subFilters: this.subFilters.map((e) => e.toObject())
		};
	}
	isNeutralState() {
		return !this.subFilters.some((e) => !e.isNeutralState());
	}
	static fromObject(e, t) {
		return Promise.all((e.subFilters || []).map((e) => M.getClass(e.type).fromObject(e, t))).then((e) => new this({ subFilters: e }));
	}
};
i(oc, `type`, `Composed`), M.setClass(oc);
var sc = class extends $ {
	getFragmentSource() {
		return `
  precision highp float;
  uniform sampler2D uTexture;
  uniform float uContrast;
  varying vec2 vTexCoord;
  void main() {
    vec4 color = texture2D(uTexture, vTexCoord);
    float contrastF = 1.015 * (uContrast + 1.0) / (1.0 * (1.015 - uContrast));
    color.rgb = contrastF * (color.rgb - 0.5) + 0.5;
    gl_FragColor = color;
  }`;
	}
	isNeutralState() {
		return this.contrast === 0;
	}
	applyTo2d({ imageData: { data: e } }) {
		let t = Math.floor(255 * this.contrast), n = 259 * (t + 255) / (255 * (259 - t));
		for (let t = 0; t < e.length; t += 4) e[t] = n * (e[t] - 128) + 128, e[t + 1] = n * (e[t + 1] - 128) + 128, e[t + 2] = n * (e[t + 2] - 128) + 128;
	}
	sendUniformData(e, t) {
		e.uniform1f(t.uContrast, this.contrast);
	}
};
i(sc, `type`, `Contrast`), i(sc, `defaults`, { contrast: 0 }), i(sc, `uniformLocations`, [`uContrast`]), M.setClass(sc);
var cc = {
	Convolute_3_1: `
    precision highp float;
    uniform sampler2D uTexture;
    uniform float uMatrix[9];
    uniform float uStepW;
    uniform float uStepH;
    varying vec2 vTexCoord;
    void main() {
      vec4 color = vec4(0, 0, 0, 0);
      for (float h = 0.0; h < 3.0; h+=1.0) {
        for (float w = 0.0; w < 3.0; w+=1.0) {
          vec2 matrixPos = vec2(uStepW * (w - 1), uStepH * (h - 1));
          color += texture2D(uTexture, vTexCoord + matrixPos) * uMatrix[int(h * 3.0 + w)];
        }
      }
      gl_FragColor = color;
    }
    `,
	Convolute_3_0: `
    precision highp float;
    uniform sampler2D uTexture;
    uniform float uMatrix[9];
    uniform float uStepW;
    uniform float uStepH;
    varying vec2 vTexCoord;
    void main() {
      vec4 color = vec4(0, 0, 0, 1);
      for (float h = 0.0; h < 3.0; h+=1.0) {
        for (float w = 0.0; w < 3.0; w+=1.0) {
          vec2 matrixPos = vec2(uStepW * (w - 1.0), uStepH * (h - 1.0));
          color.rgb += texture2D(uTexture, vTexCoord + matrixPos).rgb * uMatrix[int(h * 3.0 + w)];
        }
      }
      float alpha = texture2D(uTexture, vTexCoord).a;
      gl_FragColor = color;
      gl_FragColor.a = alpha;
    }
    `,
	Convolute_5_1: `
    precision highp float;
    uniform sampler2D uTexture;
    uniform float uMatrix[25];
    uniform float uStepW;
    uniform float uStepH;
    varying vec2 vTexCoord;
    void main() {
      vec4 color = vec4(0, 0, 0, 0);
      for (float h = 0.0; h < 5.0; h+=1.0) {
        for (float w = 0.0; w < 5.0; w+=1.0) {
          vec2 matrixPos = vec2(uStepW * (w - 2.0), uStepH * (h - 2.0));
          color += texture2D(uTexture, vTexCoord + matrixPos) * uMatrix[int(h * 5.0 + w)];
        }
      }
      gl_FragColor = color;
    }
    `,
	Convolute_5_0: `
    precision highp float;
    uniform sampler2D uTexture;
    uniform float uMatrix[25];
    uniform float uStepW;
    uniform float uStepH;
    varying vec2 vTexCoord;
    void main() {
      vec4 color = vec4(0, 0, 0, 1);
      for (float h = 0.0; h < 5.0; h+=1.0) {
        for (float w = 0.0; w < 5.0; w+=1.0) {
          vec2 matrixPos = vec2(uStepW * (w - 2.0), uStepH * (h - 2.0));
          color.rgb += texture2D(uTexture, vTexCoord + matrixPos).rgb * uMatrix[int(h * 5.0 + w)];
        }
      }
      float alpha = texture2D(uTexture, vTexCoord).a;
      gl_FragColor = color;
      gl_FragColor.a = alpha;
    }
    `,
	Convolute_7_1: `
    precision highp float;
    uniform sampler2D uTexture;
    uniform float uMatrix[49];
    uniform float uStepW;
    uniform float uStepH;
    varying vec2 vTexCoord;
    void main() {
      vec4 color = vec4(0, 0, 0, 0);
      for (float h = 0.0; h < 7.0; h+=1.0) {
        for (float w = 0.0; w < 7.0; w+=1.0) {
          vec2 matrixPos = vec2(uStepW * (w - 3.0), uStepH * (h - 3.0));
          color += texture2D(uTexture, vTexCoord + matrixPos) * uMatrix[int(h * 7.0 + w)];
        }
      }
      gl_FragColor = color;
    }
    `,
	Convolute_7_0: `
    precision highp float;
    uniform sampler2D uTexture;
    uniform float uMatrix[49];
    uniform float uStepW;
    uniform float uStepH;
    varying vec2 vTexCoord;
    void main() {
      vec4 color = vec4(0, 0, 0, 1);
      for (float h = 0.0; h < 7.0; h+=1.0) {
        for (float w = 0.0; w < 7.0; w+=1.0) {
          vec2 matrixPos = vec2(uStepW * (w - 3.0), uStepH * (h - 3.0));
          color.rgb += texture2D(uTexture, vTexCoord + matrixPos).rgb * uMatrix[int(h * 7.0 + w)];
        }
      }
      float alpha = texture2D(uTexture, vTexCoord).a;
      gl_FragColor = color;
      gl_FragColor.a = alpha;
    }
    `,
	Convolute_9_1: `
    precision highp float;
    uniform sampler2D uTexture;
    uniform float uMatrix[81];
    uniform float uStepW;
    uniform float uStepH;
    varying vec2 vTexCoord;
    void main() {
      vec4 color = vec4(0, 0, 0, 0);
      for (float h = 0.0; h < 9.0; h+=1.0) {
        for (float w = 0.0; w < 9.0; w+=1.0) {
          vec2 matrixPos = vec2(uStepW * (w - 4.0), uStepH * (h - 4.0));
          color += texture2D(uTexture, vTexCoord + matrixPos) * uMatrix[int(h * 9.0 + w)];
        }
      }
      gl_FragColor = color;
    }
    `,
	Convolute_9_0: `
    precision highp float;
    uniform sampler2D uTexture;
    uniform float uMatrix[81];
    uniform float uStepW;
    uniform float uStepH;
    varying vec2 vTexCoord;
    void main() {
      vec4 color = vec4(0, 0, 0, 1);
      for (float h = 0.0; h < 9.0; h+=1.0) {
        for (float w = 0.0; w < 9.0; w+=1.0) {
          vec2 matrixPos = vec2(uStepW * (w - 4.0), uStepH * (h - 4.0));
          color.rgb += texture2D(uTexture, vTexCoord + matrixPos).rgb * uMatrix[int(h * 9.0 + w)];
        }
      }
      float alpha = texture2D(uTexture, vTexCoord).a;
      gl_FragColor = color;
      gl_FragColor.a = alpha;
    }
    `
};
var lc = class extends $ {
	getCacheKey() {
		return `${this.type}_${Math.sqrt(this.matrix.length)}_${+!!this.opaque}`;
	}
	getFragmentSource() {
		return cc[this.getCacheKey()];
	}
	applyTo2d(e) {
		let t = e.imageData, n = t.data, r = this.matrix, i = Math.round(Math.sqrt(r.length)), a = Math.floor(i / 2), o = t.width, s = t.height, c = e.ctx.createImageData(o, s), l = c.data, u = +!!this.opaque, d, f, p, m, h, g, _, v, y, b, x, S, C;
		for (x = 0; x < s; x++) for (b = 0; b < o; b++) {
			for (h = 4 * (x * o + b), d = 0, f = 0, p = 0, m = 0, C = 0; C < i; C++) for (S = 0; S < i; S++) _ = x + C - a, g = b + S - a, _ < 0 || _ >= s || g < 0 || g >= o || (v = 4 * (_ * o + g), y = r[C * i + S], d += n[v] * y, f += n[v + 1] * y, p += n[v + 2] * y, u || (m += n[v + 3] * y));
			l[h] = d, l[h + 1] = f, l[h + 2] = p, l[h + 3] = u ? n[h + 3] : m;
		}
		e.imageData = c;
	}
	sendUniformData(e, t) {
		e.uniform1fv(t.uMatrix, this.matrix);
	}
	toObject() {
		return {
			...super.toObject(),
			opaque: this.opaque,
			matrix: [...this.matrix]
		};
	}
};
i(lc, `type`, `Convolute`), i(lc, `defaults`, {
	opaque: !1,
	matrix: [
		0,
		0,
		0,
		0,
		1,
		0,
		0,
		0,
		0
	]
}), i(lc, `uniformLocations`, [
	`uMatrix`,
	`uOpaque`,
	`uHalfSize`,
	`uSize`
]), M.setClass(lc);
var uc = `Gamma`;
var dc = class extends $ {
	getFragmentSource() {
		return `
  precision highp float;
  uniform sampler2D uTexture;
  uniform vec3 uGamma;
  varying vec2 vTexCoord;
  void main() {
    vec4 color = texture2D(uTexture, vTexCoord);
    vec3 correction = (1.0 / uGamma);
    color.r = pow(color.r, correction.r);
    color.g = pow(color.g, correction.g);
    color.b = pow(color.b, correction.b);
    gl_FragColor = color;
    gl_FragColor.rgb *= color.a;
  }
`;
	}
	constructor(e = {}) {
		super(e), this.gamma = e.gamma || this.constructor.defaults.gamma.concat();
	}
	applyTo2d({ imageData: { data: e } }) {
		let t = this.gamma, n = 1 / t[0], r = 1 / t[1], i = 1 / t[2];
		this.rgbValues || (this.rgbValues = {
			r: /* @__PURE__ */ new Uint8Array(256),
			g: /* @__PURE__ */ new Uint8Array(256),
			b: /* @__PURE__ */ new Uint8Array(256)
		});
		let a = this.rgbValues;
		for (let e = 0; e < 256; e++) a.r[e] = 255 * (e / 255) ** n, a.g[e] = 255 * (e / 255) ** r, a.b[e] = 255 * (e / 255) ** i;
		for (let t = 0; t < e.length; t += 4) e[t] = a.r[e[t]], e[t + 1] = a.g[e[t + 1]], e[t + 2] = a.b[e[t + 2]];
	}
	sendUniformData(e, t) {
		e.uniform3fv(t.uGamma, this.gamma);
	}
	isNeutralState() {
		let { gamma: e } = this;
		return e[0] === 1 && e[1] === 1 && e[2] === 1;
	}
	toObject() {
		return {
			type: uc,
			gamma: this.gamma.concat()
		};
	}
};
i(dc, `type`, uc), i(dc, `defaults`, { gamma: [
	1,
	1,
	1
] }), i(dc, `uniformLocations`, [`uGamma`]), M.setClass(dc);
var fc = {
	average: `
    precision highp float;
    uniform sampler2D uTexture;
    varying vec2 vTexCoord;
    void main() {
      vec4 color = texture2D(uTexture, vTexCoord);
      float average = (color.r + color.b + color.g) / 3.0;
      gl_FragColor = vec4(average, average, average, color.a);
    }
    `,
	lightness: `
    precision highp float;
    uniform sampler2D uTexture;
    uniform int uMode;
    varying vec2 vTexCoord;
    void main() {
      vec4 col = texture2D(uTexture, vTexCoord);
      float average = (max(max(col.r, col.g),col.b) + min(min(col.r, col.g),col.b)) / 2.0;
      gl_FragColor = vec4(average, average, average, col.a);
    }
    `,
	luminosity: `
    precision highp float;
    uniform sampler2D uTexture;
    uniform int uMode;
    varying vec2 vTexCoord;
    void main() {
      vec4 col = texture2D(uTexture, vTexCoord);
      float average = 0.21 * col.r + 0.72 * col.g + 0.07 * col.b;
      gl_FragColor = vec4(average, average, average, col.a);
    }
    `
};
var pc = class extends $ {
	applyTo2d({ imageData: { data: e } }) {
		for (let t, n = 0; n < e.length; n += 4) {
			let r = e[n], i = e[n + 1], a = e[n + 2];
			switch (this.mode) {
				case `average`:
					t = (r + i + a) / 3;
					break;
				case `lightness`:
					t = (Math.min(r, i, a) + Math.max(r, i, a)) / 2;
					break;
				case `luminosity`: t = .21 * r + .72 * i + .07 * a;
			}
			e[n + 2] = e[n + 1] = e[n] = t;
		}
	}
	getCacheKey() {
		return `${this.type}_${this.mode}`;
	}
	getFragmentSource() {
		return fc[this.mode];
	}
	sendUniformData(e, t) {
		e.uniform1i(t.uMode, 1);
	}
	isNeutralState() {
		return !1;
	}
};
i(pc, `type`, `Grayscale`), i(pc, `defaults`, { mode: `average` }), i(pc, `uniformLocations`, [`uMode`]), M.setClass(pc);
var mc = {
	...Xs,
	rotation: 0
};
var hc = class extends Zs {
	calculateMatrix() {
		let e = this.rotation * Math.PI, t = Se(e), n = Ce(e), r = 1 / 3, i = Math.sqrt(r) * n, a = 1 - t;
		this.matrix = [
			t + a / 3,
			r * a - i,
			r * a + i,
			0,
			0,
			r * a + i,
			t + r * a,
			r * a - i,
			0,
			0,
			r * a - i,
			r * a + i,
			t + r * a,
			0,
			0,
			0,
			0,
			0,
			1,
			0
		];
	}
	isNeutralState() {
		return this.rotation === 0;
	}
	applyTo(e) {
		this.calculateMatrix(), super.applyTo(e);
	}
	toObject() {
		return {
			type: this.type,
			rotation: this.rotation
		};
	}
};
i(hc, `type`, `HueRotation`), i(hc, `defaults`, mc), M.setClass(hc);
var gc = class extends $ {
	applyTo2d({ imageData: { data: e } }) {
		for (let t = 0; t < e.length; t += 4) e[t] = 255 - e[t], e[t + 1] = 255 - e[t + 1], e[t + 2] = 255 - e[t + 2], this.alpha && (e[t + 3] = 255 - e[t + 3]);
	}
	getFragmentSource() {
		return `
  precision highp float;
  uniform sampler2D uTexture;
  uniform int uInvert;
  uniform int uAlpha;
  varying vec2 vTexCoord;
  void main() {
    vec4 color = texture2D(uTexture, vTexCoord);
    if (uInvert == 1) {
      if (uAlpha == 1) {
        gl_FragColor = vec4(1.0 - color.r,1.0 -color.g,1.0 -color.b,1.0 -color.a);
      } else {
        gl_FragColor = vec4(1.0 - color.r,1.0 -color.g,1.0 -color.b,color.a);
      }
    } else {
      gl_FragColor = color;
    }
  }
`;
	}
	isNeutralState() {
		return !this.invert;
	}
	sendUniformData(e, t) {
		e.uniform1i(t.uInvert, Number(this.invert)), e.uniform1i(t.uAlpha, Number(this.alpha));
	}
};
i(gc, `type`, `Invert`), i(gc, `defaults`, {
	alpha: !1,
	invert: !0
}), i(gc, `uniformLocations`, [`uInvert`, `uAlpha`]), M.setClass(gc);
var _c = class extends $ {
	getFragmentSource() {
		return `
  precision highp float;
  uniform sampler2D uTexture;
  uniform float uStepH;
  uniform float uNoise;
  uniform float uSeed;
  varying vec2 vTexCoord;
  float rand(vec2 co, float seed, float vScale) {
    return fract(sin(dot(co.xy * vScale ,vec2(12.9898 , 78.233))) * 43758.5453 * (seed + 0.01) / 2.0);
  }
  void main() {
    vec4 color = texture2D(uTexture, vTexCoord);
    color.rgb += (0.5 - rand(vTexCoord, uSeed, 0.1 / uStepH)) * uNoise;
    gl_FragColor = color;
  }
`;
	}
	applyTo2d({ imageData: { data: e } }) {
		let t = this.noise;
		for (let n = 0; n < e.length; n += 4) {
			let r = (.5 - Math.random()) * t;
			e[n] += r, e[n + 1] += r, e[n + 2] += r;
		}
	}
	sendUniformData(e, t) {
		e.uniform1f(t.uNoise, this.noise / 255), e.uniform1f(t.uSeed, Math.random());
	}
	isNeutralState() {
		return this.noise === 0;
	}
};
i(_c, `type`, `Noise`), i(_c, `defaults`, { noise: 0 }), i(_c, `uniformLocations`, [`uNoise`, `uSeed`]), M.setClass(_c);
var vc = class extends $ {
	applyTo2d({ imageData: { data: e, width: t, height: n } }) {
		for (let r = 0; r < n; r += this.blocksize) for (let i = 0; i < t; i += this.blocksize) {
			let a = 4 * r * t + 4 * i, o = e[a], s = e[a + 1], c = e[a + 2], l = e[a + 3];
			for (let a = r; a < Math.min(r + this.blocksize, n); a++) for (let n = i; n < Math.min(i + this.blocksize, t); n++) {
				let r = 4 * a * t + 4 * n;
				e[r] = o, e[r + 1] = s, e[r + 2] = c, e[r + 3] = l;
			}
		}
	}
	isNeutralState() {
		return this.blocksize === 1;
	}
	getFragmentSource() {
		return `
  precision highp float;
  uniform sampler2D uTexture;
  uniform float uBlocksize;
  uniform float uStepW;
  uniform float uStepH;
  varying vec2 vTexCoord;
  void main() {
    float blockW = uBlocksize * uStepW;
    float blockH = uBlocksize * uStepH;
    int posX = int(vTexCoord.x / blockW);
    int posY = int(vTexCoord.y / blockH);
    float fposX = float(posX);
    float fposY = float(posY);
    vec2 squareCoords = vec2(fposX * blockW, fposY * blockH);
    vec4 color = texture2D(uTexture, squareCoords);
    gl_FragColor = color;
  }
`;
	}
	sendUniformData(e, t) {
		e.uniform1f(t.uBlocksize, this.blocksize);
	}
};
i(vc, `type`, `Pixelate`), i(vc, `defaults`, { blocksize: 4 }), i(vc, `uniformLocations`, [`uBlocksize`]), M.setClass(vc);
var yc = class extends $ {
	getFragmentSource() {
		return `
precision highp float;
uniform sampler2D uTexture;
uniform vec4 uLow;
uniform vec4 uHigh;
varying vec2 vTexCoord;
void main() {
  gl_FragColor = texture2D(uTexture, vTexCoord);
  if(all(greaterThan(gl_FragColor.rgb,uLow.rgb)) && all(greaterThan(uHigh.rgb,gl_FragColor.rgb))) {
    gl_FragColor.a = 0.0;
  }
}
`;
	}
	applyTo2d({ imageData: { data: e } }) {
		let t = 255 * this.distance, n = new G(this.color).getSource(), r = [
			n[0] - t,
			n[1] - t,
			n[2] - t
		], i = [
			n[0] + t,
			n[1] + t,
			n[2] + t
		];
		for (let t = 0; t < e.length; t += 4) {
			let n = e[t], a = e[t + 1], o = e[t + 2];
			n > r[0] && a > r[1] && o > r[2] && n < i[0] && a < i[1] && o < i[2] && (e[t + 3] = 0);
		}
	}
	sendUniformData(e, t) {
		let n = new G(this.color).getSource(), r = this.distance, i = [
			0 + n[0] / 255 - r,
			0 + n[1] / 255 - r,
			0 + n[2] / 255 - r,
			1
		], a = [
			n[0] / 255 + r,
			n[1] / 255 + r,
			n[2] / 255 + r,
			1
		];
		e.uniform4fv(t.uLow, i), e.uniform4fv(t.uHigh, a);
	}
};
i(yc, `type`, `RemoveColor`), i(yc, `defaults`, {
	color: `#FFFFFF`,
	distance: .02,
	useAlpha: !1
}), i(yc, `uniformLocations`, [`uLow`, `uHigh`]), M.setClass(yc);
var bc = class extends $ {
	sendUniformData(e, t) {
		e.uniform2fv(t.uDelta, this.horizontal ? [1 / this.width, 0] : [0, 1 / this.height]), e.uniform1fv(t.uTaps, this.taps);
	}
	getFilterWindow() {
		let e = this.tempScale;
		return Math.ceil(this.lanczosLobes / e);
	}
	getCacheKey() {
		let e = this.getFilterWindow();
		return `${this.type}_${e}`;
	}
	getFragmentSource() {
		let e = this.getFilterWindow();
		return this.generateShader(e);
	}
	getTaps() {
		let e = this.lanczosCreate(this.lanczosLobes), t = this.tempScale, n = this.getFilterWindow(), r = Array(n);
		for (let i = 1; i <= n; i++) r[i - 1] = e(i * t);
		return r;
	}
	generateShader(e) {
		let t = Array(e);
		for (let n = 1; n <= e; n++) t[n - 1] = `${n}.0 * uDelta`;
		return `\n      precision highp float;\n      uniform sampler2D uTexture;\n      uniform vec2 uDelta;\n      varying vec2 vTexCoord;\n      uniform float uTaps[${e}];\n      void main() {\n        vec4 color = texture2D(uTexture, vTexCoord);\n        float sum = 1.0;\n        ${t.map((e, t) => `\n              color += texture2D(uTexture, vTexCoord + ${e}) * uTaps[${t}] + texture2D(uTexture, vTexCoord - ${e}) * uTaps[${t}];\n              sum += 2.0 * uTaps[${t}];\n            `).join(`
`)}\n        gl_FragColor = color / sum;\n      }\n    `;
	}
	applyToForWebgl(e) {
		e.passes++, this.width = e.sourceWidth, this.horizontal = !0, this.dW = Math.round(this.width * this.scaleX), this.dH = e.sourceHeight, this.tempScale = this.dW / this.width, this.taps = this.getTaps(), e.destinationWidth = this.dW, super.applyTo(e), e.sourceWidth = e.destinationWidth, this.height = e.sourceHeight, this.horizontal = !1, this.dH = Math.round(this.height * this.scaleY), this.tempScale = this.dH / this.height, this.taps = this.getTaps(), e.destinationHeight = this.dH, super.applyTo(e), e.sourceHeight = e.destinationHeight;
	}
	applyTo(e) {
		zs(e) ? this.applyToForWebgl(e) : this.applyTo2d(e);
	}
	isNeutralState() {
		return this.scaleX === 1 && this.scaleY === 1;
	}
	lanczosCreate(e) {
		return (t) => {
			if (t >= e || t <= -e) return 0;
			if (t < 1.1920929e-7 && t > -1.1920929e-7) return 1;
			let n = (t *= Math.PI) / e;
			return Math.sin(t) / t * Math.sin(n) / n;
		};
	}
	applyTo2d(e) {
		let t = e.imageData, n = this.scaleX, r = this.scaleY;
		this.rcpScaleX = 1 / n, this.rcpScaleY = 1 / r;
		let i = t.width, a = t.height, o = Math.round(i * n), s = Math.round(a * r), c;
		c = this.resizeType === `sliceHack` ? this.sliceByTwo(e, i, a, o, s) : this.resizeType === `hermite` ? this.hermiteFastResize(e, i, a, o, s) : this.resizeType === `bilinear` ? this.bilinearFiltering(e, i, a, o, s) : this.resizeType === `lanczos` ? this.lanczosResize(e, i, a, o, s) : new ImageData(o, s), e.imageData = c;
	}
	sliceByTwo(e, t, n, r, i) {
		let a = e.imageData, o = .5, s = !1, c = !1, l = t * o, u = n * o, d = e.filterBackend.resources, f = 0, p = 0, m = t, h = 0;
		d.sliceByTwo || (d.sliceByTwo = P());
		let g = d.sliceByTwo;
		(g.width < 1.5 * t || g.height < n) && (g.width = 1.5 * t, g.height = n);
		let _ = g.getContext(`2d`);
		for (_.clearRect(0, 0, 1.5 * t, n), _.putImageData(a, 0, 0), r = Math.floor(r), i = Math.floor(i); !s || !c;) t = l, n = u, r < Math.floor(l * o) ? l = Math.floor(l * o) : (l = r, s = !0), i < Math.floor(u * o) ? u = Math.floor(u * o) : (u = i, c = !0), _.drawImage(g, f, p, t, n, m, h, l, u), f = m, p = h, h += u;
		return _.getImageData(f, p, r, i);
	}
	lanczosResize(e, t, n, r, i) {
		let a = e.imageData.data, o = e.ctx.createImageData(r, i), s = o.data, c = this.lanczosCreate(this.lanczosLobes), l = this.rcpScaleX, u = this.rcpScaleY, d = 2 / this.rcpScaleX, f = 2 / this.rcpScaleY, p = Math.ceil(l * this.lanczosLobes / 2), m = Math.ceil(u * this.lanczosLobes / 2), h = {}, g = {
			x: 0,
			y: 0
		}, _ = {
			x: 0,
			y: 0
		};
		return function e(v) {
			let y, b, x, S, C, w, ee, T, E, D, O;
			for (g.x = (v + .5) * l, _.x = Math.floor(g.x), y = 0; y < i; y++) {
				for (g.y = (y + .5) * u, _.y = Math.floor(g.y), C = 0, w = 0, ee = 0, T = 0, E = 0, b = _.x - p; b <= _.x + p; b++) if (!(b < 0 || b >= t)) {
					D = Math.floor(1e3 * Math.abs(b - g.x)), h[D] || (h[D] = {});
					for (let e = _.y - m; e <= _.y + m; e++) e < 0 || e >= n || (O = Math.floor(1e3 * Math.abs(e - g.y)), h[D][O] || (h[D][O] = c(Math.sqrt((D * d) ** 2 + (O * f) ** 2) / 1e3)), x = h[D][O], x > 0 && (S = 4 * (e * t + b), C += x, w += x * a[S], ee += x * a[S + 1], T += x * a[S + 2], E += x * a[S + 3]));
				}
				S = 4 * (y * r + v), s[S] = w / C, s[S + 1] = ee / C, s[S + 2] = T / C, s[S + 3] = E / C;
			}
			return ++v < r ? e(v) : o;
		}(0);
	}
	bilinearFiltering(e, t, n, r, i) {
		let a, o, s, c, l, u, d, f, p, m, h, g, _, v = 0, y = this.rcpScaleX, b = this.rcpScaleY, x = 4 * (t - 1), S = e.imageData.data, C = e.ctx.createImageData(r, i), w = C.data;
		for (d = 0; d < i; d++) for (f = 0; f < r; f++) for (l = Math.floor(y * f), u = Math.floor(b * d), p = y * f - l, m = b * d - u, _ = 4 * (u * t + l), h = 0; h < 4; h++) a = S[_ + h], o = S[_ + 4 + h], s = S[_ + x + h], c = S[_ + x + 4 + h], g = a * (1 - p) * (1 - m) + o * p * (1 - m) + s * m * (1 - p) + c * p * m, w[v++] = g;
		return C;
	}
	hermiteFastResize(e, t, n, r, i) {
		let a = this.rcpScaleX, o = this.rcpScaleY, s = Math.ceil(a / 2), c = Math.ceil(o / 2), l = e.imageData.data, u = e.ctx.createImageData(r, i), d = u.data;
		for (let e = 0; e < i; e++) for (let n = 0; n < r; n++) {
			let i = 4 * (n + e * r), u, f = 0, p = 0, m = 0, h = 0, g = 0, _ = 0, v = (e + .5) * o;
			for (let r = Math.floor(e * o); r < (e + 1) * o; r++) {
				let e = Math.abs(v - (r + .5)) / c, i = (n + .5) * a, o = e * e;
				for (let e = Math.floor(n * a); e < (n + 1) * a; e++) {
					let n = Math.abs(i - (e + .5)) / s, a = Math.sqrt(o + n * n);
					a > 1 && a < -1 || (u = 2 * a * a * a - 3 * a * a + 1, u > 0 && (n = 4 * (e + r * t), _ += u * l[n + 3], p += u, l[n + 3] < 255 && (u = u * l[n + 3] / 250), m += u * l[n], h += u * l[n + 1], g += u * l[n + 2], f += u));
				}
			}
			d[i] = m / f, d[i + 1] = h / f, d[i + 2] = g / f, d[i + 3] = _ / p;
		}
		return u;
	}
};
i(bc, `type`, `Resize`), i(bc, `defaults`, {
	resizeType: `hermite`,
	scaleX: 1,
	scaleY: 1,
	lanczosLobes: 3
}), i(bc, `uniformLocations`, [`uDelta`, `uTaps`]), M.setClass(bc);
var xc = class extends $ {
	getFragmentSource() {
		return `
  precision highp float;
  uniform sampler2D uTexture;
  uniform float uSaturation;
  varying vec2 vTexCoord;
  void main() {
    vec4 color = texture2D(uTexture, vTexCoord);
    float rgMax = max(color.r, color.g);
    float rgbMax = max(rgMax, color.b);
    color.r += rgbMax != color.r ? (rgbMax - color.r) * uSaturation : 0.00;
    color.g += rgbMax != color.g ? (rgbMax - color.g) * uSaturation : 0.00;
    color.b += rgbMax != color.b ? (rgbMax - color.b) * uSaturation : 0.00;
    gl_FragColor = color;
  }
`;
	}
	applyTo2d({ imageData: { data: e } }) {
		let t = -this.saturation;
		for (let n = 0; n < e.length; n += 4) {
			let r = e[n], i = e[n + 1], a = e[n + 2], o = Math.max(r, i, a);
			e[n] += o === r ? 0 : (o - r) * t, e[n + 1] += o === i ? 0 : (o - i) * t, e[n + 2] += o === a ? 0 : (o - a) * t;
		}
	}
	sendUniformData(e, t) {
		e.uniform1f(t.uSaturation, -this.saturation);
	}
	isNeutralState() {
		return this.saturation === 0;
	}
};
i(xc, `type`, `Saturation`), i(xc, `defaults`, { saturation: 0 }), i(xc, `uniformLocations`, [`uSaturation`]), M.setClass(xc);
var Sc = class extends $ {
	getFragmentSource() {
		return `
  precision highp float;
  uniform sampler2D uTexture;
  uniform float uVibrance;
  varying vec2 vTexCoord;
  void main() {
    vec4 color = texture2D(uTexture, vTexCoord);
    float max = max(color.r, max(color.g, color.b));
    float avg = (color.r + color.g + color.b) / 3.0;
    float amt = (abs(max - avg) * 2.0) * uVibrance;
    color.r += max != color.r ? (max - color.r) * amt : 0.00;
    color.g += max != color.g ? (max - color.g) * amt : 0.00;
    color.b += max != color.b ? (max - color.b) * amt : 0.00;
    gl_FragColor = color;
  }
`;
	}
	applyTo2d({ imageData: { data: e } }) {
		let t = -this.vibrance;
		for (let n = 0; n < e.length; n += 4) {
			let r = e[n], i = e[n + 1], a = e[n + 2], o = Math.max(r, i, a), s = (r + i + a) / 3, c = 2 * Math.abs(o - s) / 255 * t;
			e[n] += o === r ? 0 : (o - r) * c, e[n + 1] += o === i ? 0 : (o - i) * c, e[n + 2] += o === a ? 0 : (o - a) * c;
		}
	}
	sendUniformData(e, t) {
		e.uniform1f(t.uVibrance, -this.vibrance);
	}
	isNeutralState() {
		return this.vibrance === 0;
	}
};
i(Sc, `type`, `Vibrance`), i(Sc, `defaults`, { vibrance: 0 }), i(Sc, `uniformLocations`, [`uVibrance`]), M.setClass(Sc);
t({
	BaseFilter: () => $,
	BlackWhite: () => ac,
	BlendColor: () => Gs,
	BlendImage: () => qs,
	Blur: () => Js,
	Brightness: () => Ys,
	Brownie: () => $s,
	ColorMatrix: () => Zs,
	Composed: () => oc,
	Contrast: () => sc,
	Convolute: () => lc,
	Gamma: () => dc,
	Grayscale: () => pc,
	HueRotation: () => hc,
	Invert: () => gc,
	Kodachrome: () => tc,
	Noise: () => _c,
	Pixelate: () => vc,
	Polaroid: () => rc,
	RemoveColor: () => yc,
	Resize: () => bc,
	Saturation: () => xc,
	Sepia: () => ic,
	Technicolor: () => nc,
	Vibrance: () => Sc,
	Vintage: () => ec
});
/*!
* Cropper.js v1.6.2
* https://fengyuanchen.github.io/cropperjs
*
* Copyright 2015-present Chen Fengyuan
* Released under the MIT license
*
* Date: 2024-04-21T07:43:05.335Z
*/
//#endregion
//#region node_modules/stackblur-canvas/dist/stackblur.mjs
var import_cropper = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(global, factory) {
		typeof exports === "object" && typeof module !== "undefined" ? module.exports = factory() : typeof define === "function" && define.amd ? define(factory) : (global = typeof globalThis !== "undefined" ? globalThis : global || self, global.Cropper = factory());
	})(exports, (function() {
		"use strict";
		function ownKeys(e, r) {
			var t = Object.keys(e);
			if (Object.getOwnPropertySymbols) {
				var o = Object.getOwnPropertySymbols(e);
				r && (o = o.filter(function(r) {
					return Object.getOwnPropertyDescriptor(e, r).enumerable;
				})), t.push.apply(t, o);
			}
			return t;
		}
		function _objectSpread2(e) {
			for (var r = 1; r < arguments.length; r++) {
				var t = null != arguments[r] ? arguments[r] : {};
				r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
					_defineProperty(e, r, t[r]);
				}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
					Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
				});
			}
			return e;
		}
		function _toPrimitive(t, r) {
			if ("object" != typeof t || !t) return t;
			var e = t[Symbol.toPrimitive];
			if (void 0 !== e) {
				var i = e.call(t, r || "default");
				if ("object" != typeof i) return i;
				throw new TypeError("@@toPrimitive must return a primitive value.");
			}
			return ("string" === r ? String : Number)(t);
		}
		function _toPropertyKey(t) {
			var i = _toPrimitive(t, "string");
			return "symbol" == typeof i ? i : i + "";
		}
		function _typeof(o) {
			"@babel/helpers - typeof";
			return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
				return typeof o;
			} : function(o) {
				return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
			}, _typeof(o);
		}
		function _classCallCheck(instance, Constructor) {
			if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
		}
		function _defineProperties(target, props) {
			for (var i = 0; i < props.length; i++) {
				var descriptor = props[i];
				descriptor.enumerable = descriptor.enumerable || false;
				descriptor.configurable = true;
				if ("value" in descriptor) descriptor.writable = true;
				Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor);
			}
		}
		function _createClass(Constructor, protoProps, staticProps) {
			if (protoProps) _defineProperties(Constructor.prototype, protoProps);
			if (staticProps) _defineProperties(Constructor, staticProps);
			Object.defineProperty(Constructor, "prototype", { writable: false });
			return Constructor;
		}
		function _defineProperty(obj, key, value) {
			key = _toPropertyKey(key);
			if (key in obj) Object.defineProperty(obj, key, {
				value,
				enumerable: true,
				configurable: true,
				writable: true
			});
			else obj[key] = value;
			return obj;
		}
		function _toConsumableArray(arr) {
			return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
		}
		function _arrayWithoutHoles(arr) {
			if (Array.isArray(arr)) return _arrayLikeToArray(arr);
		}
		function _iterableToArray(iter) {
			if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
		}
		function _unsupportedIterableToArray(o, minLen) {
			if (!o) return;
			if (typeof o === "string") return _arrayLikeToArray(o, minLen);
			var n = Object.prototype.toString.call(o).slice(8, -1);
			if (n === "Object" && o.constructor) n = o.constructor.name;
			if (n === "Map" || n === "Set") return Array.from(o);
			if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
		}
		function _arrayLikeToArray(arr, len) {
			if (len == null || len > arr.length) len = arr.length;
			for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
			return arr2;
		}
		function _nonIterableSpread() {
			throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
		}
		var IS_BROWSER = typeof window !== "undefined" && typeof window.document !== "undefined";
		var WINDOW = IS_BROWSER ? window : {};
		var IS_TOUCH_DEVICE = IS_BROWSER && WINDOW.document.documentElement ? "ontouchstart" in WINDOW.document.documentElement : false;
		var HAS_POINTER_EVENT = IS_BROWSER ? "PointerEvent" in WINDOW : false;
		var NAMESPACE = "cropper";
		var ACTION_ALL = "all";
		var ACTION_CROP = "crop";
		var ACTION_MOVE = "move";
		var ACTION_ZOOM = "zoom";
		var ACTION_EAST = "e";
		var ACTION_WEST = "w";
		var ACTION_SOUTH = "s";
		var ACTION_NORTH = "n";
		var ACTION_NORTH_EAST = "ne";
		var ACTION_NORTH_WEST = "nw";
		var ACTION_SOUTH_EAST = "se";
		var ACTION_SOUTH_WEST = "sw";
		var CLASS_CROP = "".concat(NAMESPACE, "-crop");
		var CLASS_DISABLED = "".concat(NAMESPACE, "-disabled");
		var CLASS_HIDDEN = "".concat(NAMESPACE, "-hidden");
		var CLASS_HIDE = "".concat(NAMESPACE, "-hide");
		var CLASS_INVISIBLE = "".concat(NAMESPACE, "-invisible");
		var CLASS_MODAL = "".concat(NAMESPACE, "-modal");
		var CLASS_MOVE = "".concat(NAMESPACE, "-move");
		var DATA_ACTION = "".concat(NAMESPACE, "Action");
		var DATA_PREVIEW = "".concat(NAMESPACE, "Preview");
		var DRAG_MODE_CROP = "crop";
		var DRAG_MODE_MOVE = "move";
		var DRAG_MODE_NONE = "none";
		var EVENT_CROP = "crop";
		var EVENT_CROP_END = "cropend";
		var EVENT_CROP_MOVE = "cropmove";
		var EVENT_CROP_START = "cropstart";
		var EVENT_DBLCLICK = "dblclick";
		var EVENT_TOUCH_START = IS_TOUCH_DEVICE ? "touchstart" : "mousedown";
		var EVENT_TOUCH_MOVE = IS_TOUCH_DEVICE ? "touchmove" : "mousemove";
		var EVENT_TOUCH_END = IS_TOUCH_DEVICE ? "touchend touchcancel" : "mouseup";
		var EVENT_POINTER_DOWN = HAS_POINTER_EVENT ? "pointerdown" : EVENT_TOUCH_START;
		var EVENT_POINTER_MOVE = HAS_POINTER_EVENT ? "pointermove" : EVENT_TOUCH_MOVE;
		var EVENT_POINTER_UP = HAS_POINTER_EVENT ? "pointerup pointercancel" : EVENT_TOUCH_END;
		var EVENT_READY = "ready";
		var EVENT_RESIZE = "resize";
		var EVENT_WHEEL = "wheel";
		var EVENT_ZOOM = "zoom";
		var MIME_TYPE_JPEG = "image/jpeg";
		var REGEXP_ACTIONS = /^e|w|s|n|se|sw|ne|nw|all|crop|move|zoom$/;
		var REGEXP_DATA_URL = /^data:/;
		var REGEXP_DATA_URL_JPEG = /^data:image\/jpeg;base64,/;
		var REGEXP_TAG_NAME = /^img|canvas$/i;
		var MIN_CONTAINER_WIDTH = 200;
		var MIN_CONTAINER_HEIGHT = 100;
		var DEFAULTS = {
			viewMode: 0,
			dragMode: DRAG_MODE_CROP,
			initialAspectRatio: NaN,
			aspectRatio: NaN,
			data: null,
			preview: "",
			responsive: true,
			restore: true,
			checkCrossOrigin: true,
			checkOrientation: true,
			modal: true,
			guides: true,
			center: true,
			highlight: true,
			background: true,
			autoCrop: true,
			autoCropArea: .8,
			movable: true,
			rotatable: true,
			scalable: true,
			zoomable: true,
			zoomOnTouch: true,
			zoomOnWheel: true,
			wheelZoomRatio: .1,
			cropBoxMovable: true,
			cropBoxResizable: true,
			toggleDragModeOnDblclick: true,
			minCanvasWidth: 0,
			minCanvasHeight: 0,
			minCropBoxWidth: 0,
			minCropBoxHeight: 0,
			minContainerWidth: MIN_CONTAINER_WIDTH,
			minContainerHeight: MIN_CONTAINER_HEIGHT,
			ready: null,
			cropstart: null,
			cropmove: null,
			cropend: null,
			crop: null,
			zoom: null
		};
		var TEMPLATE = "<div class=\"cropper-container\" touch-action=\"none\"><div class=\"cropper-wrap-box\"><div class=\"cropper-canvas\"></div></div><div class=\"cropper-drag-box\"></div><div class=\"cropper-crop-box\"><span class=\"cropper-view-box\"></span><span class=\"cropper-dashed dashed-h\"></span><span class=\"cropper-dashed dashed-v\"></span><span class=\"cropper-center\"></span><span class=\"cropper-face\"></span><span class=\"cropper-line line-e\" data-cropper-action=\"e\"></span><span class=\"cropper-line line-n\" data-cropper-action=\"n\"></span><span class=\"cropper-line line-w\" data-cropper-action=\"w\"></span><span class=\"cropper-line line-s\" data-cropper-action=\"s\"></span><span class=\"cropper-point point-e\" data-cropper-action=\"e\"></span><span class=\"cropper-point point-n\" data-cropper-action=\"n\"></span><span class=\"cropper-point point-w\" data-cropper-action=\"w\"></span><span class=\"cropper-point point-s\" data-cropper-action=\"s\"></span><span class=\"cropper-point point-ne\" data-cropper-action=\"ne\"></span><span class=\"cropper-point point-nw\" data-cropper-action=\"nw\"></span><span class=\"cropper-point point-sw\" data-cropper-action=\"sw\"></span><span class=\"cropper-point point-se\" data-cropper-action=\"se\"></span></div></div>";
		/**
		* Check if the given value is not a number.
		*/
		var isNaN = Number.isNaN || WINDOW.isNaN;
		/**
		* Check if the given value is a number.
		* @param {*} value - The value to check.
		* @returns {boolean} Returns `true` if the given value is a number, else `false`.
		*/
		function isNumber(value) {
			return typeof value === "number" && !isNaN(value);
		}
		/**
		* Check if the given value is a positive number.
		* @param {*} value - The value to check.
		* @returns {boolean} Returns `true` if the given value is a positive number, else `false`.
		*/
		var isPositiveNumber = function isPositiveNumber(value) {
			return value > 0 && value < Infinity;
		};
		/**
		* Check if the given value is undefined.
		* @param {*} value - The value to check.
		* @returns {boolean} Returns `true` if the given value is undefined, else `false`.
		*/
		function isUndefined(value) {
			return typeof value === "undefined";
		}
		/**
		* Check if the given value is an object.
		* @param {*} value - The value to check.
		* @returns {boolean} Returns `true` if the given value is an object, else `false`.
		*/
		function isObject(value) {
			return _typeof(value) === "object" && value !== null;
		}
		var hasOwnProperty = Object.prototype.hasOwnProperty;
		/**
		* Check if the given value is a plain object.
		* @param {*} value - The value to check.
		* @returns {boolean} Returns `true` if the given value is a plain object, else `false`.
		*/
		function isPlainObject(value) {
			if (!isObject(value)) return false;
			try {
				var _constructor = value.constructor;
				var prototype = _constructor.prototype;
				return _constructor && prototype && hasOwnProperty.call(prototype, "isPrototypeOf");
			} catch (error) {
				return false;
			}
		}
		/**
		* Check if the given value is a function.
		* @param {*} value - The value to check.
		* @returns {boolean} Returns `true` if the given value is a function, else `false`.
		*/
		function isFunction(value) {
			return typeof value === "function";
		}
		var slice = Array.prototype.slice;
		/**
		* Convert array-like or iterable object to an array.
		* @param {*} value - The value to convert.
		* @returns {Array} Returns a new array.
		*/
		function toArray(value) {
			return Array.from ? Array.from(value) : slice.call(value);
		}
		/**
		* Iterate the given data.
		* @param {*} data - The data to iterate.
		* @param {Function} callback - The process function for each element.
		* @returns {*} The original data.
		*/
		function forEach(data, callback) {
			if (data && isFunction(callback)) {
				if (Array.isArray(data) || isNumber(data.length)) toArray(data).forEach(function(value, key) {
					callback.call(data, value, key, data);
				});
				else if (isObject(data)) Object.keys(data).forEach(function(key) {
					callback.call(data, data[key], key, data);
				});
			}
			return data;
		}
		/**
		* Extend the given object.
		* @param {*} target - The target object to extend.
		* @param {*} args - The rest objects for merging to the target object.
		* @returns {Object} The extended object.
		*/
		var assign = Object.assign || function assign(target) {
			for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) args[_key - 1] = arguments[_key];
			if (isObject(target) && args.length > 0) args.forEach(function(arg) {
				if (isObject(arg)) Object.keys(arg).forEach(function(key) {
					target[key] = arg[key];
				});
			});
			return target;
		};
		var REGEXP_DECIMALS = /\.\d*(?:0|9){12}\d*$/;
		/**
		* Normalize decimal number.
		* Check out {@link https://0.30000000000000004.com/}
		* @param {number} value - The value to normalize.
		* @param {number} [times=100000000000] - The times for normalizing.
		* @returns {number} Returns the normalized number.
		*/
		function normalizeDecimalNumber(value) {
			var times = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 1e11;
			return REGEXP_DECIMALS.test(value) ? Math.round(value * times) / times : value;
		}
		var REGEXP_SUFFIX = /^width|height|left|top|marginLeft|marginTop$/;
		/**
		* Apply styles to the given element.
		* @param {Element} element - The target element.
		* @param {Object} styles - The styles for applying.
		*/
		function setStyle(element, styles) {
			var style = element.style;
			forEach(styles, function(value, property) {
				if (REGEXP_SUFFIX.test(property) && isNumber(value)) value = "".concat(value, "px");
				style[property] = value;
			});
		}
		/**
		* Check if the given element has a special class.
		* @param {Element} element - The element to check.
		* @param {string} value - The class to search.
		* @returns {boolean} Returns `true` if the special class was found.
		*/
		function hasClass(element, value) {
			return element.classList ? element.classList.contains(value) : element.className.indexOf(value) > -1;
		}
		/**
		* Add classes to the given element.
		* @param {Element} element - The target element.
		* @param {string} value - The classes to be added.
		*/
		function addClass(element, value) {
			if (!value) return;
			if (isNumber(element.length)) {
				forEach(element, function(elem) {
					addClass(elem, value);
				});
				return;
			}
			if (element.classList) {
				element.classList.add(value);
				return;
			}
			var className = element.className.trim();
			if (!className) element.className = value;
			else if (className.indexOf(value) < 0) element.className = "".concat(className, " ").concat(value);
		}
		/**
		* Remove classes from the given element.
		* @param {Element} element - The target element.
		* @param {string} value - The classes to be removed.
		*/
		function removeClass(element, value) {
			if (!value) return;
			if (isNumber(element.length)) {
				forEach(element, function(elem) {
					removeClass(elem, value);
				});
				return;
			}
			if (element.classList) {
				element.classList.remove(value);
				return;
			}
			if (element.className.indexOf(value) >= 0) element.className = element.className.replace(value, "");
		}
		/**
		* Add or remove classes from the given element.
		* @param {Element} element - The target element.
		* @param {string} value - The classes to be toggled.
		* @param {boolean} added - Add only.
		*/
		function toggleClass(element, value, added) {
			if (!value) return;
			if (isNumber(element.length)) {
				forEach(element, function(elem) {
					toggleClass(elem, value, added);
				});
				return;
			}
			if (added) addClass(element, value);
			else removeClass(element, value);
		}
		var REGEXP_CAMEL_CASE = /([a-z\d])([A-Z])/g;
		/**
		* Transform the given string from camelCase to kebab-case
		* @param {string} value - The value to transform.
		* @returns {string} The transformed value.
		*/
		function toParamCase(value) {
			return value.replace(REGEXP_CAMEL_CASE, "$1-$2").toLowerCase();
		}
		/**
		* Get data from the given element.
		* @param {Element} element - The target element.
		* @param {string} name - The data key to get.
		* @returns {string} The data value.
		*/
		function getData(element, name) {
			if (isObject(element[name])) return element[name];
			if (element.dataset) return element.dataset[name];
			return element.getAttribute("data-".concat(toParamCase(name)));
		}
		/**
		* Set data to the given element.
		* @param {Element} element - The target element.
		* @param {string} name - The data key to set.
		* @param {string} data - The data value.
		*/
		function setData(element, name, data) {
			if (isObject(data)) element[name] = data;
			else if (element.dataset) element.dataset[name] = data;
			else element.setAttribute("data-".concat(toParamCase(name)), data);
		}
		/**
		* Remove data from the given element.
		* @param {Element} element - The target element.
		* @param {string} name - The data key to remove.
		*/
		function removeData(element, name) {
			if (isObject(element[name])) try {
				delete element[name];
			} catch (error) {
				element[name] = void 0;
			}
			else if (element.dataset) try {
				delete element.dataset[name];
			} catch (error) {
				element.dataset[name] = void 0;
			}
			else element.removeAttribute("data-".concat(toParamCase(name)));
		}
		var REGEXP_SPACES = /\s\s*/;
		var onceSupported = function() {
			var supported = false;
			if (IS_BROWSER) {
				var once = false;
				var listener = function listener() {};
				var options = Object.defineProperty({}, "once", {
					get: function get() {
						supported = true;
						return once;
					},
					/**
					* This setter can fix a `TypeError` in strict mode
					* {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Errors/Getter_only}
					* @param {boolean} value - The value to set
					*/
					set: function set(value) {
						once = value;
					}
				});
				WINDOW.addEventListener("test", listener, options);
				WINDOW.removeEventListener("test", listener, options);
			}
			return supported;
		}();
		/**
		* Remove event listener from the target element.
		* @param {Element} element - The event target.
		* @param {string} type - The event type(s).
		* @param {Function} listener - The event listener.
		* @param {Object} options - The event options.
		*/
		function removeListener(element, type, listener) {
			var options = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {};
			var handler = listener;
			type.trim().split(REGEXP_SPACES).forEach(function(event) {
				if (!onceSupported) {
					var listeners = element.listeners;
					if (listeners && listeners[event] && listeners[event][listener]) {
						handler = listeners[event][listener];
						delete listeners[event][listener];
						if (Object.keys(listeners[event]).length === 0) delete listeners[event];
						if (Object.keys(listeners).length === 0) delete element.listeners;
					}
				}
				element.removeEventListener(event, handler, options);
			});
		}
		/**
		* Add event listener to the target element.
		* @param {Element} element - The event target.
		* @param {string} type - The event type(s).
		* @param {Function} listener - The event listener.
		* @param {Object} options - The event options.
		*/
		function addListener(element, type, listener) {
			var options = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {};
			var _handler = listener;
			type.trim().split(REGEXP_SPACES).forEach(function(event) {
				if (options.once && !onceSupported) {
					var _element$listeners = element.listeners, listeners = _element$listeners === void 0 ? {} : _element$listeners;
					_handler = function handler() {
						delete listeners[event][listener];
						element.removeEventListener(event, _handler, options);
						for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) args[_key2] = arguments[_key2];
						listener.apply(element, args);
					};
					if (!listeners[event]) listeners[event] = {};
					if (listeners[event][listener]) element.removeEventListener(event, listeners[event][listener], options);
					listeners[event][listener] = _handler;
					element.listeners = listeners;
				}
				element.addEventListener(event, _handler, options);
			});
		}
		/**
		* Dispatch event on the target element.
		* @param {Element} element - The event target.
		* @param {string} type - The event type(s).
		* @param {Object} data - The additional event data.
		* @returns {boolean} Indicate if the event is default prevented or not.
		*/
		function dispatchEvent(element, type, data) {
			var event;
			if (isFunction(Event) && isFunction(CustomEvent)) event = new CustomEvent(type, {
				detail: data,
				bubbles: true,
				cancelable: true
			});
			else {
				event = document.createEvent("CustomEvent");
				event.initCustomEvent(type, true, true, data);
			}
			return element.dispatchEvent(event);
		}
		/**
		* Get the offset base on the document.
		* @param {Element} element - The target element.
		* @returns {Object} The offset data.
		*/
		function getOffset(element) {
			var box = element.getBoundingClientRect();
			return {
				left: box.left + (window.pageXOffset - document.documentElement.clientLeft),
				top: box.top + (window.pageYOffset - document.documentElement.clientTop)
			};
		}
		var location = WINDOW.location;
		var REGEXP_ORIGINS = /^(\w+:)\/\/([^:/?#]*):?(\d*)/i;
		/**
		* Check if the given URL is a cross origin URL.
		* @param {string} url - The target URL.
		* @returns {boolean} Returns `true` if the given URL is a cross origin URL, else `false`.
		*/
		function isCrossOriginURL(url) {
			var parts = url.match(REGEXP_ORIGINS);
			return parts !== null && (parts[1] !== location.protocol || parts[2] !== location.hostname || parts[3] !== location.port);
		}
		/**
		* Add timestamp to the given URL.
		* @param {string} url - The target URL.
		* @returns {string} The result URL.
		*/
		function addTimestamp(url) {
			var timestamp = "timestamp=".concat((/* @__PURE__ */ new Date()).getTime());
			return url + (url.indexOf("?") === -1 ? "?" : "&") + timestamp;
		}
		/**
		* Get transforms base on the given object.
		* @param {Object} obj - The target object.
		* @returns {string} A string contains transform values.
		*/
		function getTransforms(_ref) {
			var rotate = _ref.rotate, scaleX = _ref.scaleX, scaleY = _ref.scaleY, translateX = _ref.translateX, translateY = _ref.translateY;
			var values = [];
			if (isNumber(translateX) && translateX !== 0) values.push("translateX(".concat(translateX, "px)"));
			if (isNumber(translateY) && translateY !== 0) values.push("translateY(".concat(translateY, "px)"));
			if (isNumber(rotate) && rotate !== 0) values.push("rotate(".concat(rotate, "deg)"));
			if (isNumber(scaleX) && scaleX !== 1) values.push("scaleX(".concat(scaleX, ")"));
			if (isNumber(scaleY) && scaleY !== 1) values.push("scaleY(".concat(scaleY, ")"));
			var transform = values.length ? values.join(" ") : "none";
			return {
				WebkitTransform: transform,
				msTransform: transform,
				transform
			};
		}
		/**
		* Get the max ratio of a group of pointers.
		* @param {string} pointers - The target pointers.
		* @returns {number} The result ratio.
		*/
		function getMaxZoomRatio(pointers) {
			var pointers2 = _objectSpread2({}, pointers);
			var maxRatio = 0;
			forEach(pointers, function(pointer, pointerId) {
				delete pointers2[pointerId];
				forEach(pointers2, function(pointer2) {
					var x1 = Math.abs(pointer.startX - pointer2.startX);
					var y1 = Math.abs(pointer.startY - pointer2.startY);
					var x2 = Math.abs(pointer.endX - pointer2.endX);
					var y2 = Math.abs(pointer.endY - pointer2.endY);
					var z1 = Math.sqrt(x1 * x1 + y1 * y1);
					var ratio = (Math.sqrt(x2 * x2 + y2 * y2) - z1) / z1;
					if (Math.abs(ratio) > Math.abs(maxRatio)) maxRatio = ratio;
				});
			});
			return maxRatio;
		}
		/**
		* Get a pointer from an event object.
		* @param {Object} event - The target event object.
		* @param {boolean} endOnly - Indicates if only returns the end point coordinate or not.
		* @returns {Object} The result pointer contains start and/or end point coordinates.
		*/
		function getPointer(_ref2, endOnly) {
			var pageX = _ref2.pageX, pageY = _ref2.pageY;
			var end = {
				endX: pageX,
				endY: pageY
			};
			return endOnly ? end : _objectSpread2({
				startX: pageX,
				startY: pageY
			}, end);
		}
		/**
		* Get the center point coordinate of a group of pointers.
		* @param {Object} pointers - The target pointers.
		* @returns {Object} The center point coordinate.
		*/
		function getPointersCenter(pointers) {
			var pageX = 0;
			var pageY = 0;
			var count = 0;
			forEach(pointers, function(_ref3) {
				var startX = _ref3.startX, startY = _ref3.startY;
				pageX += startX;
				pageY += startY;
				count += 1;
			});
			pageX /= count;
			pageY /= count;
			return {
				pageX,
				pageY
			};
		}
		/**
		* Get the max sizes in a rectangle under the given aspect ratio.
		* @param {Object} data - The original sizes.
		* @param {string} [type='contain'] - The adjust type.
		* @returns {Object} The result sizes.
		*/
		function getAdjustedSizes(_ref4) {
			var aspectRatio = _ref4.aspectRatio, height = _ref4.height, width = _ref4.width;
			var type = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "contain";
			var isValidWidth = isPositiveNumber(width);
			var isValidHeight = isPositiveNumber(height);
			if (isValidWidth && isValidHeight) {
				var adjustedWidth = height * aspectRatio;
				if (type === "contain" && adjustedWidth > width || type === "cover" && adjustedWidth < width) height = width / aspectRatio;
				else width = height * aspectRatio;
			} else if (isValidWidth) height = width / aspectRatio;
			else if (isValidHeight) width = height * aspectRatio;
			return {
				width,
				height
			};
		}
		/**
		* Get the new sizes of a rectangle after rotated.
		* @param {Object} data - The original sizes.
		* @returns {Object} The result sizes.
		*/
		function getRotatedSizes(_ref5) {
			var width = _ref5.width, height = _ref5.height, degree = _ref5.degree;
			degree = Math.abs(degree) % 180;
			if (degree === 90) return {
				width: height,
				height: width
			};
			var arc = degree % 90 * Math.PI / 180;
			var sinArc = Math.sin(arc);
			var cosArc = Math.cos(arc);
			var newWidth = width * cosArc + height * sinArc;
			var newHeight = width * sinArc + height * cosArc;
			return degree > 90 ? {
				width: newHeight,
				height: newWidth
			} : {
				width: newWidth,
				height: newHeight
			};
		}
		/**
		* Get a canvas which drew the given image.
		* @param {HTMLImageElement} image - The image for drawing.
		* @param {Object} imageData - The image data.
		* @param {Object} canvasData - The canvas data.
		* @param {Object} options - The options.
		* @returns {HTMLCanvasElement} The result canvas.
		*/
		function getSourceCanvas(image, _ref6, _ref7, _ref8) {
			var imageAspectRatio = _ref6.aspectRatio, imageNaturalWidth = _ref6.naturalWidth, imageNaturalHeight = _ref6.naturalHeight, _ref6$rotate = _ref6.rotate, rotate = _ref6$rotate === void 0 ? 0 : _ref6$rotate, _ref6$scaleX = _ref6.scaleX, scaleX = _ref6$scaleX === void 0 ? 1 : _ref6$scaleX, _ref6$scaleY = _ref6.scaleY, scaleY = _ref6$scaleY === void 0 ? 1 : _ref6$scaleY;
			var aspectRatio = _ref7.aspectRatio, naturalWidth = _ref7.naturalWidth, naturalHeight = _ref7.naturalHeight;
			var _ref8$fillColor = _ref8.fillColor, fillColor = _ref8$fillColor === void 0 ? "transparent" : _ref8$fillColor, _ref8$imageSmoothingE = _ref8.imageSmoothingEnabled, imageSmoothingEnabled = _ref8$imageSmoothingE === void 0 ? true : _ref8$imageSmoothingE, _ref8$imageSmoothingQ = _ref8.imageSmoothingQuality, imageSmoothingQuality = _ref8$imageSmoothingQ === void 0 ? "low" : _ref8$imageSmoothingQ, _ref8$maxWidth = _ref8.maxWidth, maxWidth = _ref8$maxWidth === void 0 ? Infinity : _ref8$maxWidth, _ref8$maxHeight = _ref8.maxHeight, maxHeight = _ref8$maxHeight === void 0 ? Infinity : _ref8$maxHeight, _ref8$minWidth = _ref8.minWidth, minWidth = _ref8$minWidth === void 0 ? 0 : _ref8$minWidth, _ref8$minHeight = _ref8.minHeight, minHeight = _ref8$minHeight === void 0 ? 0 : _ref8$minHeight;
			var canvas = document.createElement("canvas");
			var context = canvas.getContext("2d");
			var maxSizes = getAdjustedSizes({
				aspectRatio,
				width: maxWidth,
				height: maxHeight
			});
			var minSizes = getAdjustedSizes({
				aspectRatio,
				width: minWidth,
				height: minHeight
			}, "cover");
			var width = Math.min(maxSizes.width, Math.max(minSizes.width, naturalWidth));
			var height = Math.min(maxSizes.height, Math.max(minSizes.height, naturalHeight));
			var destMaxSizes = getAdjustedSizes({
				aspectRatio: imageAspectRatio,
				width: maxWidth,
				height: maxHeight
			});
			var destMinSizes = getAdjustedSizes({
				aspectRatio: imageAspectRatio,
				width: minWidth,
				height: minHeight
			}, "cover");
			var destWidth = Math.min(destMaxSizes.width, Math.max(destMinSizes.width, imageNaturalWidth));
			var destHeight = Math.min(destMaxSizes.height, Math.max(destMinSizes.height, imageNaturalHeight));
			var params = [
				-destWidth / 2,
				-destHeight / 2,
				destWidth,
				destHeight
			];
			canvas.width = normalizeDecimalNumber(width);
			canvas.height = normalizeDecimalNumber(height);
			context.fillStyle = fillColor;
			context.fillRect(0, 0, width, height);
			context.save();
			context.translate(width / 2, height / 2);
			context.rotate(rotate * Math.PI / 180);
			context.scale(scaleX, scaleY);
			context.imageSmoothingEnabled = imageSmoothingEnabled;
			context.imageSmoothingQuality = imageSmoothingQuality;
			context.drawImage.apply(context, [image].concat(_toConsumableArray(params.map(function(param) {
				return Math.floor(normalizeDecimalNumber(param));
			}))));
			context.restore();
			return canvas;
		}
		var fromCharCode = String.fromCharCode;
		/**
		* Get string from char code in data view.
		* @param {DataView} dataView - The data view for read.
		* @param {number} start - The start index.
		* @param {number} length - The read length.
		* @returns {string} The read result.
		*/
		function getStringFromCharCode(dataView, start, length) {
			var str = "";
			length += start;
			for (var i = start; i < length; i += 1) str += fromCharCode(dataView.getUint8(i));
			return str;
		}
		var REGEXP_DATA_URL_HEAD = /^data:.*,/;
		/**
		* Transform Data URL to array buffer.
		* @param {string} dataURL - The Data URL to transform.
		* @returns {ArrayBuffer} The result array buffer.
		*/
		function dataURLToArrayBuffer(dataURL) {
			var base64 = dataURL.replace(REGEXP_DATA_URL_HEAD, "");
			var binary = atob(base64);
			var arrayBuffer = new ArrayBuffer(binary.length);
			var uint8 = new Uint8Array(arrayBuffer);
			forEach(uint8, function(value, i) {
				uint8[i] = binary.charCodeAt(i);
			});
			return arrayBuffer;
		}
		/**
		* Transform array buffer to Data URL.
		* @param {ArrayBuffer} arrayBuffer - The array buffer to transform.
		* @param {string} mimeType - The mime type of the Data URL.
		* @returns {string} The result Data URL.
		*/
		function arrayBufferToDataURL(arrayBuffer, mimeType) {
			var chunks = [];
			var chunkSize = 8192;
			var uint8 = new Uint8Array(arrayBuffer);
			while (uint8.length > 0) {
				chunks.push(fromCharCode.apply(null, toArray(uint8.subarray(0, chunkSize))));
				uint8 = uint8.subarray(chunkSize);
			}
			return "data:".concat(mimeType, ";base64,").concat(btoa(chunks.join("")));
		}
		/**
		* Get orientation value from given array buffer.
		* @param {ArrayBuffer} arrayBuffer - The array buffer to read.
		* @returns {number} The read orientation value.
		*/
		function resetAndGetOrientation(arrayBuffer) {
			var dataView = new DataView(arrayBuffer);
			var orientation;
			try {
				var littleEndian;
				var app1Start;
				var ifdStart;
				if (dataView.getUint8(0) === 255 && dataView.getUint8(1) === 216) {
					var length = dataView.byteLength;
					var offset = 2;
					while (offset + 1 < length) {
						if (dataView.getUint8(offset) === 255 && dataView.getUint8(offset + 1) === 225) {
							app1Start = offset;
							break;
						}
						offset += 1;
					}
				}
				if (app1Start) {
					var exifIDCode = app1Start + 4;
					var tiffOffset = app1Start + 10;
					if (getStringFromCharCode(dataView, exifIDCode, 4) === "Exif") {
						var endianness = dataView.getUint16(tiffOffset);
						littleEndian = endianness === 18761;
						if (littleEndian || endianness === 19789) {
							if (dataView.getUint16(tiffOffset + 2, littleEndian) === 42) {
								var firstIFDOffset = dataView.getUint32(tiffOffset + 4, littleEndian);
								if (firstIFDOffset >= 8) ifdStart = tiffOffset + firstIFDOffset;
							}
						}
					}
				}
				if (ifdStart) {
					var _length = dataView.getUint16(ifdStart, littleEndian);
					var _offset;
					var i;
					for (i = 0; i < _length; i += 1) {
						_offset = ifdStart + i * 12 + 2;
						if (dataView.getUint16(_offset, littleEndian) === 274) {
							_offset += 8;
							orientation = dataView.getUint16(_offset, littleEndian);
							dataView.setUint16(_offset, 1, littleEndian);
							break;
						}
					}
				}
			} catch (error) {
				orientation = 1;
			}
			return orientation;
		}
		/**
		* Parse Exif Orientation value.
		* @param {number} orientation - The orientation to parse.
		* @returns {Object} The parsed result.
		*/
		function parseOrientation(orientation) {
			var rotate = 0;
			var scaleX = 1;
			var scaleY = 1;
			switch (orientation) {
				case 2:
					scaleX = -1;
					break;
				case 3:
					rotate = -180;
					break;
				case 4:
					scaleY = -1;
					break;
				case 5:
					rotate = 90;
					scaleY = -1;
					break;
				case 6:
					rotate = 90;
					break;
				case 7:
					rotate = 90;
					scaleX = -1;
					break;
				case 8: rotate = -90;
			}
			return {
				rotate,
				scaleX,
				scaleY
			};
		}
		var render = {
			render: function render() {
				this.initContainer();
				this.initCanvas();
				this.initCropBox();
				this.renderCanvas();
				if (this.cropped) this.renderCropBox();
			},
			initContainer: function initContainer() {
				var element = this.element, options = this.options, container = this.container, cropper = this.cropper;
				var minWidth = Number(options.minContainerWidth);
				var minHeight = Number(options.minContainerHeight);
				addClass(cropper, CLASS_HIDDEN);
				removeClass(element, CLASS_HIDDEN);
				var containerData = {
					width: Math.max(container.offsetWidth, minWidth >= 0 ? minWidth : MIN_CONTAINER_WIDTH),
					height: Math.max(container.offsetHeight, minHeight >= 0 ? minHeight : MIN_CONTAINER_HEIGHT)
				};
				this.containerData = containerData;
				setStyle(cropper, {
					width: containerData.width,
					height: containerData.height
				});
				addClass(element, CLASS_HIDDEN);
				removeClass(cropper, CLASS_HIDDEN);
			},
			initCanvas: function initCanvas() {
				var containerData = this.containerData, imageData = this.imageData;
				var viewMode = this.options.viewMode;
				var rotated = Math.abs(imageData.rotate) % 180 === 90;
				var naturalWidth = rotated ? imageData.naturalHeight : imageData.naturalWidth;
				var naturalHeight = rotated ? imageData.naturalWidth : imageData.naturalHeight;
				var aspectRatio = naturalWidth / naturalHeight;
				var canvasWidth = containerData.width;
				var canvasHeight = containerData.height;
				if (containerData.height * aspectRatio > containerData.width) {
					if (viewMode === 3) canvasWidth = containerData.height * aspectRatio;
					else canvasHeight = containerData.width / aspectRatio;
				} else if (viewMode === 3) canvasHeight = containerData.width / aspectRatio;
				else canvasWidth = containerData.height * aspectRatio;
				var canvasData = {
					aspectRatio,
					naturalWidth,
					naturalHeight,
					width: canvasWidth,
					height: canvasHeight
				};
				this.canvasData = canvasData;
				this.limited = viewMode === 1 || viewMode === 2;
				this.limitCanvas(true, true);
				canvasData.width = Math.min(Math.max(canvasData.width, canvasData.minWidth), canvasData.maxWidth);
				canvasData.height = Math.min(Math.max(canvasData.height, canvasData.minHeight), canvasData.maxHeight);
				canvasData.left = (containerData.width - canvasData.width) / 2;
				canvasData.top = (containerData.height - canvasData.height) / 2;
				canvasData.oldLeft = canvasData.left;
				canvasData.oldTop = canvasData.top;
				this.initialCanvasData = assign({}, canvasData);
			},
			limitCanvas: function limitCanvas(sizeLimited, positionLimited) {
				var options = this.options, containerData = this.containerData, canvasData = this.canvasData, cropBoxData = this.cropBoxData;
				var viewMode = options.viewMode;
				var aspectRatio = canvasData.aspectRatio;
				var cropped = this.cropped && cropBoxData;
				if (sizeLimited) {
					var minCanvasWidth = Number(options.minCanvasWidth) || 0;
					var minCanvasHeight = Number(options.minCanvasHeight) || 0;
					if (viewMode > 1) {
						minCanvasWidth = Math.max(minCanvasWidth, containerData.width);
						minCanvasHeight = Math.max(minCanvasHeight, containerData.height);
						if (viewMode === 3) {
							if (minCanvasHeight * aspectRatio > minCanvasWidth) minCanvasWidth = minCanvasHeight * aspectRatio;
							else minCanvasHeight = minCanvasWidth / aspectRatio;
						}
					} else if (viewMode > 0) {
						if (minCanvasWidth) minCanvasWidth = Math.max(minCanvasWidth, cropped ? cropBoxData.width : 0);
						else if (minCanvasHeight) minCanvasHeight = Math.max(minCanvasHeight, cropped ? cropBoxData.height : 0);
						else if (cropped) {
							minCanvasWidth = cropBoxData.width;
							minCanvasHeight = cropBoxData.height;
							if (minCanvasHeight * aspectRatio > minCanvasWidth) minCanvasWidth = minCanvasHeight * aspectRatio;
							else minCanvasHeight = minCanvasWidth / aspectRatio;
						}
					}
					var _getAdjustedSizes = getAdjustedSizes({
						aspectRatio,
						width: minCanvasWidth,
						height: minCanvasHeight
					});
					minCanvasWidth = _getAdjustedSizes.width;
					minCanvasHeight = _getAdjustedSizes.height;
					canvasData.minWidth = minCanvasWidth;
					canvasData.minHeight = minCanvasHeight;
					canvasData.maxWidth = Infinity;
					canvasData.maxHeight = Infinity;
				}
				if (positionLimited) {
					if (viewMode > (cropped ? 0 : 1)) {
						var newCanvasLeft = containerData.width - canvasData.width;
						var newCanvasTop = containerData.height - canvasData.height;
						canvasData.minLeft = Math.min(0, newCanvasLeft);
						canvasData.minTop = Math.min(0, newCanvasTop);
						canvasData.maxLeft = Math.max(0, newCanvasLeft);
						canvasData.maxTop = Math.max(0, newCanvasTop);
						if (cropped && this.limited) {
							canvasData.minLeft = Math.min(cropBoxData.left, cropBoxData.left + (cropBoxData.width - canvasData.width));
							canvasData.minTop = Math.min(cropBoxData.top, cropBoxData.top + (cropBoxData.height - canvasData.height));
							canvasData.maxLeft = cropBoxData.left;
							canvasData.maxTop = cropBoxData.top;
							if (viewMode === 2) {
								if (canvasData.width >= containerData.width) {
									canvasData.minLeft = Math.min(0, newCanvasLeft);
									canvasData.maxLeft = Math.max(0, newCanvasLeft);
								}
								if (canvasData.height >= containerData.height) {
									canvasData.minTop = Math.min(0, newCanvasTop);
									canvasData.maxTop = Math.max(0, newCanvasTop);
								}
							}
						}
					} else {
						canvasData.minLeft = -canvasData.width;
						canvasData.minTop = -canvasData.height;
						canvasData.maxLeft = containerData.width;
						canvasData.maxTop = containerData.height;
					}
				}
			},
			renderCanvas: function renderCanvas(changed, transformed) {
				var canvasData = this.canvasData, imageData = this.imageData;
				if (transformed) {
					var _getRotatedSizes = getRotatedSizes({
						width: imageData.naturalWidth * Math.abs(imageData.scaleX || 1),
						height: imageData.naturalHeight * Math.abs(imageData.scaleY || 1),
						degree: imageData.rotate || 0
					}), naturalWidth = _getRotatedSizes.width, naturalHeight = _getRotatedSizes.height;
					var width = canvasData.width * (naturalWidth / canvasData.naturalWidth);
					var height = canvasData.height * (naturalHeight / canvasData.naturalHeight);
					canvasData.left -= (width - canvasData.width) / 2;
					canvasData.top -= (height - canvasData.height) / 2;
					canvasData.width = width;
					canvasData.height = height;
					canvasData.aspectRatio = naturalWidth / naturalHeight;
					canvasData.naturalWidth = naturalWidth;
					canvasData.naturalHeight = naturalHeight;
					this.limitCanvas(true, false);
				}
				if (canvasData.width > canvasData.maxWidth || canvasData.width < canvasData.minWidth) canvasData.left = canvasData.oldLeft;
				if (canvasData.height > canvasData.maxHeight || canvasData.height < canvasData.minHeight) canvasData.top = canvasData.oldTop;
				canvasData.width = Math.min(Math.max(canvasData.width, canvasData.minWidth), canvasData.maxWidth);
				canvasData.height = Math.min(Math.max(canvasData.height, canvasData.minHeight), canvasData.maxHeight);
				this.limitCanvas(false, true);
				canvasData.left = Math.min(Math.max(canvasData.left, canvasData.minLeft), canvasData.maxLeft);
				canvasData.top = Math.min(Math.max(canvasData.top, canvasData.minTop), canvasData.maxTop);
				canvasData.oldLeft = canvasData.left;
				canvasData.oldTop = canvasData.top;
				setStyle(this.canvas, assign({
					width: canvasData.width,
					height: canvasData.height
				}, getTransforms({
					translateX: canvasData.left,
					translateY: canvasData.top
				})));
				this.renderImage(changed);
				if (this.cropped && this.limited) this.limitCropBox(true, true);
			},
			renderImage: function renderImage(changed) {
				var canvasData = this.canvasData, imageData = this.imageData;
				var width = imageData.naturalWidth * (canvasData.width / canvasData.naturalWidth);
				var height = imageData.naturalHeight * (canvasData.height / canvasData.naturalHeight);
				assign(imageData, {
					width,
					height,
					left: (canvasData.width - width) / 2,
					top: (canvasData.height - height) / 2
				});
				setStyle(this.image, assign({
					width: imageData.width,
					height: imageData.height
				}, getTransforms(assign({
					translateX: imageData.left,
					translateY: imageData.top
				}, imageData))));
				if (changed) this.output();
			},
			initCropBox: function initCropBox() {
				var options = this.options, canvasData = this.canvasData;
				var aspectRatio = options.aspectRatio || options.initialAspectRatio;
				var autoCropArea = Number(options.autoCropArea) || .8;
				var cropBoxData = {
					width: canvasData.width,
					height: canvasData.height
				};
				if (aspectRatio) {
					if (canvasData.height * aspectRatio > canvasData.width) cropBoxData.height = cropBoxData.width / aspectRatio;
					else cropBoxData.width = cropBoxData.height * aspectRatio;
				}
				this.cropBoxData = cropBoxData;
				this.limitCropBox(true, true);
				cropBoxData.width = Math.min(Math.max(cropBoxData.width, cropBoxData.minWidth), cropBoxData.maxWidth);
				cropBoxData.height = Math.min(Math.max(cropBoxData.height, cropBoxData.minHeight), cropBoxData.maxHeight);
				cropBoxData.width = Math.max(cropBoxData.minWidth, cropBoxData.width * autoCropArea);
				cropBoxData.height = Math.max(cropBoxData.minHeight, cropBoxData.height * autoCropArea);
				cropBoxData.left = canvasData.left + (canvasData.width - cropBoxData.width) / 2;
				cropBoxData.top = canvasData.top + (canvasData.height - cropBoxData.height) / 2;
				cropBoxData.oldLeft = cropBoxData.left;
				cropBoxData.oldTop = cropBoxData.top;
				this.initialCropBoxData = assign({}, cropBoxData);
			},
			limitCropBox: function limitCropBox(sizeLimited, positionLimited) {
				var options = this.options, containerData = this.containerData, canvasData = this.canvasData, cropBoxData = this.cropBoxData, limited = this.limited;
				var aspectRatio = options.aspectRatio;
				if (sizeLimited) {
					var minCropBoxWidth = Number(options.minCropBoxWidth) || 0;
					var minCropBoxHeight = Number(options.minCropBoxHeight) || 0;
					var maxCropBoxWidth = limited ? Math.min(containerData.width, canvasData.width, canvasData.width + canvasData.left, containerData.width - canvasData.left) : containerData.width;
					var maxCropBoxHeight = limited ? Math.min(containerData.height, canvasData.height, canvasData.height + canvasData.top, containerData.height - canvasData.top) : containerData.height;
					minCropBoxWidth = Math.min(minCropBoxWidth, containerData.width);
					minCropBoxHeight = Math.min(minCropBoxHeight, containerData.height);
					if (aspectRatio) {
						if (minCropBoxWidth && minCropBoxHeight) {
							if (minCropBoxHeight * aspectRatio > minCropBoxWidth) minCropBoxHeight = minCropBoxWidth / aspectRatio;
							else minCropBoxWidth = minCropBoxHeight * aspectRatio;
						} else if (minCropBoxWidth) minCropBoxHeight = minCropBoxWidth / aspectRatio;
						else if (minCropBoxHeight) minCropBoxWidth = minCropBoxHeight * aspectRatio;
						if (maxCropBoxHeight * aspectRatio > maxCropBoxWidth) maxCropBoxHeight = maxCropBoxWidth / aspectRatio;
						else maxCropBoxWidth = maxCropBoxHeight * aspectRatio;
					}
					cropBoxData.minWidth = Math.min(minCropBoxWidth, maxCropBoxWidth);
					cropBoxData.minHeight = Math.min(minCropBoxHeight, maxCropBoxHeight);
					cropBoxData.maxWidth = maxCropBoxWidth;
					cropBoxData.maxHeight = maxCropBoxHeight;
				}
				if (positionLimited) {
					if (limited) {
						cropBoxData.minLeft = Math.max(0, canvasData.left);
						cropBoxData.minTop = Math.max(0, canvasData.top);
						cropBoxData.maxLeft = Math.min(containerData.width, canvasData.left + canvasData.width) - cropBoxData.width;
						cropBoxData.maxTop = Math.min(containerData.height, canvasData.top + canvasData.height) - cropBoxData.height;
					} else {
						cropBoxData.minLeft = 0;
						cropBoxData.minTop = 0;
						cropBoxData.maxLeft = containerData.width - cropBoxData.width;
						cropBoxData.maxTop = containerData.height - cropBoxData.height;
					}
				}
			},
			renderCropBox: function renderCropBox() {
				var options = this.options, containerData = this.containerData, cropBoxData = this.cropBoxData;
				if (cropBoxData.width > cropBoxData.maxWidth || cropBoxData.width < cropBoxData.minWidth) cropBoxData.left = cropBoxData.oldLeft;
				if (cropBoxData.height > cropBoxData.maxHeight || cropBoxData.height < cropBoxData.minHeight) cropBoxData.top = cropBoxData.oldTop;
				cropBoxData.width = Math.min(Math.max(cropBoxData.width, cropBoxData.minWidth), cropBoxData.maxWidth);
				cropBoxData.height = Math.min(Math.max(cropBoxData.height, cropBoxData.minHeight), cropBoxData.maxHeight);
				this.limitCropBox(false, true);
				cropBoxData.left = Math.min(Math.max(cropBoxData.left, cropBoxData.minLeft), cropBoxData.maxLeft);
				cropBoxData.top = Math.min(Math.max(cropBoxData.top, cropBoxData.minTop), cropBoxData.maxTop);
				cropBoxData.oldLeft = cropBoxData.left;
				cropBoxData.oldTop = cropBoxData.top;
				if (options.movable && options.cropBoxMovable) setData(this.face, DATA_ACTION, cropBoxData.width >= containerData.width && cropBoxData.height >= containerData.height ? ACTION_MOVE : ACTION_ALL);
				setStyle(this.cropBox, assign({
					width: cropBoxData.width,
					height: cropBoxData.height
				}, getTransforms({
					translateX: cropBoxData.left,
					translateY: cropBoxData.top
				})));
				if (this.cropped && this.limited) this.limitCanvas(true, true);
				if (!this.disabled) this.output();
			},
			output: function output() {
				this.preview();
				dispatchEvent(this.element, EVENT_CROP, this.getData());
			}
		};
		var preview = {
			initPreview: function initPreview() {
				var element = this.element, crossOrigin = this.crossOrigin;
				var preview = this.options.preview;
				var url = crossOrigin ? this.crossOriginUrl : this.url;
				var alt = element.alt || "The image to preview";
				var image = document.createElement("img");
				if (crossOrigin) image.crossOrigin = crossOrigin;
				image.src = url;
				image.alt = alt;
				this.viewBox.appendChild(image);
				this.viewBoxImage = image;
				if (!preview) return;
				var previews = preview;
				if (typeof preview === "string") previews = element.ownerDocument.querySelectorAll(preview);
				else if (preview.querySelector) previews = [preview];
				this.previews = previews;
				forEach(previews, function(el) {
					var img = document.createElement("img");
					setData(el, DATA_PREVIEW, {
						width: el.offsetWidth,
						height: el.offsetHeight,
						html: el.innerHTML
					});
					if (crossOrigin) img.crossOrigin = crossOrigin;
					img.src = url;
					img.alt = alt;
					/**
					* Override img element styles
					* Add `display:block` to avoid margin top issue
					* Add `height:auto` to override `height` attribute on IE8
					* (Occur only when margin-top <= -height)
					*/
					img.style.cssText = "display:block;width:100%;height:auto;min-width:0!important;min-height:0!important;max-width:none!important;max-height:none!important;image-orientation:0deg!important;\"";
					el.innerHTML = "";
					el.appendChild(img);
				});
			},
			resetPreview: function resetPreview() {
				forEach(this.previews, function(element) {
					var data = getData(element, DATA_PREVIEW);
					setStyle(element, {
						width: data.width,
						height: data.height
					});
					element.innerHTML = data.html;
					removeData(element, DATA_PREVIEW);
				});
			},
			preview: function preview() {
				var imageData = this.imageData, canvasData = this.canvasData, cropBoxData = this.cropBoxData;
				var cropBoxWidth = cropBoxData.width, cropBoxHeight = cropBoxData.height;
				var width = imageData.width, height = imageData.height;
				var left = cropBoxData.left - canvasData.left - imageData.left;
				var top = cropBoxData.top - canvasData.top - imageData.top;
				if (!this.cropped || this.disabled) return;
				setStyle(this.viewBoxImage, assign({
					width,
					height
				}, getTransforms(assign({
					translateX: -left,
					translateY: -top
				}, imageData))));
				forEach(this.previews, function(element) {
					var data = getData(element, DATA_PREVIEW);
					var originalWidth = data.width;
					var originalHeight = data.height;
					var newWidth = originalWidth;
					var newHeight = originalHeight;
					var ratio = 1;
					if (cropBoxWidth) {
						ratio = originalWidth / cropBoxWidth;
						newHeight = cropBoxHeight * ratio;
					}
					if (cropBoxHeight && newHeight > originalHeight) {
						ratio = originalHeight / cropBoxHeight;
						newWidth = cropBoxWidth * ratio;
						newHeight = originalHeight;
					}
					setStyle(element, {
						width: newWidth,
						height: newHeight
					});
					setStyle(element.getElementsByTagName("img")[0], assign({
						width: width * ratio,
						height: height * ratio
					}, getTransforms(assign({
						translateX: -left * ratio,
						translateY: -top * ratio
					}, imageData))));
				});
			}
		};
		var events = {
			bind: function bind() {
				var element = this.element, options = this.options, cropper = this.cropper;
				if (isFunction(options.cropstart)) addListener(element, EVENT_CROP_START, options.cropstart);
				if (isFunction(options.cropmove)) addListener(element, EVENT_CROP_MOVE, options.cropmove);
				if (isFunction(options.cropend)) addListener(element, EVENT_CROP_END, options.cropend);
				if (isFunction(options.crop)) addListener(element, EVENT_CROP, options.crop);
				if (isFunction(options.zoom)) addListener(element, EVENT_ZOOM, options.zoom);
				addListener(cropper, EVENT_POINTER_DOWN, this.onCropStart = this.cropStart.bind(this));
				if (options.zoomable && options.zoomOnWheel) addListener(cropper, EVENT_WHEEL, this.onWheel = this.wheel.bind(this), {
					passive: false,
					capture: true
				});
				if (options.toggleDragModeOnDblclick) addListener(cropper, EVENT_DBLCLICK, this.onDblclick = this.dblclick.bind(this));
				addListener(element.ownerDocument, EVENT_POINTER_MOVE, this.onCropMove = this.cropMove.bind(this));
				addListener(element.ownerDocument, EVENT_POINTER_UP, this.onCropEnd = this.cropEnd.bind(this));
				if (options.responsive) addListener(window, EVENT_RESIZE, this.onResize = this.resize.bind(this));
			},
			unbind: function unbind() {
				var element = this.element, options = this.options, cropper = this.cropper;
				if (isFunction(options.cropstart)) removeListener(element, EVENT_CROP_START, options.cropstart);
				if (isFunction(options.cropmove)) removeListener(element, EVENT_CROP_MOVE, options.cropmove);
				if (isFunction(options.cropend)) removeListener(element, EVENT_CROP_END, options.cropend);
				if (isFunction(options.crop)) removeListener(element, EVENT_CROP, options.crop);
				if (isFunction(options.zoom)) removeListener(element, EVENT_ZOOM, options.zoom);
				removeListener(cropper, EVENT_POINTER_DOWN, this.onCropStart);
				if (options.zoomable && options.zoomOnWheel) removeListener(cropper, EVENT_WHEEL, this.onWheel, {
					passive: false,
					capture: true
				});
				if (options.toggleDragModeOnDblclick) removeListener(cropper, EVENT_DBLCLICK, this.onDblclick);
				removeListener(element.ownerDocument, EVENT_POINTER_MOVE, this.onCropMove);
				removeListener(element.ownerDocument, EVENT_POINTER_UP, this.onCropEnd);
				if (options.responsive) removeListener(window, EVENT_RESIZE, this.onResize);
			}
		};
		var handlers = {
			resize: function resize() {
				if (this.disabled) return;
				var options = this.options, container = this.container, containerData = this.containerData;
				var ratioX = container.offsetWidth / containerData.width;
				var ratioY = container.offsetHeight / containerData.height;
				var ratio = Math.abs(ratioX - 1) > Math.abs(ratioY - 1) ? ratioX : ratioY;
				if (ratio !== 1) {
					var canvasData;
					var cropBoxData;
					if (options.restore) {
						canvasData = this.getCanvasData();
						cropBoxData = this.getCropBoxData();
					}
					this.render();
					if (options.restore) {
						this.setCanvasData(forEach(canvasData, function(n, i) {
							canvasData[i] = n * ratio;
						}));
						this.setCropBoxData(forEach(cropBoxData, function(n, i) {
							cropBoxData[i] = n * ratio;
						}));
					}
				}
			},
			dblclick: function dblclick() {
				if (this.disabled || this.options.dragMode === DRAG_MODE_NONE) return;
				this.setDragMode(hasClass(this.dragBox, CLASS_CROP) ? DRAG_MODE_MOVE : DRAG_MODE_CROP);
			},
			wheel: function wheel(event) {
				var _this = this;
				var ratio = Number(this.options.wheelZoomRatio) || .1;
				var delta = 1;
				if (this.disabled) return;
				event.preventDefault();
				if (this.wheeling) return;
				this.wheeling = true;
				setTimeout(function() {
					_this.wheeling = false;
				}, 50);
				if (event.deltaY) delta = event.deltaY > 0 ? 1 : -1;
				else if (event.wheelDelta) delta = -event.wheelDelta / 120;
				else if (event.detail) delta = event.detail > 0 ? 1 : -1;
				this.zoom(-delta * ratio, event);
			},
			cropStart: function cropStart(event) {
				var buttons = event.buttons, button = event.button;
				if (this.disabled || (event.type === "mousedown" || event.type === "pointerdown" && event.pointerType === "mouse") && (isNumber(buttons) && buttons !== 1 || isNumber(button) && button !== 0 || event.ctrlKey)) return;
				var options = this.options, pointers = this.pointers;
				var action;
				if (event.changedTouches) forEach(event.changedTouches, function(touch) {
					pointers[touch.identifier] = getPointer(touch);
				});
				else pointers[event.pointerId || 0] = getPointer(event);
				if (Object.keys(pointers).length > 1 && options.zoomable && options.zoomOnTouch) action = ACTION_ZOOM;
				else action = getData(event.target, DATA_ACTION);
				if (!REGEXP_ACTIONS.test(action)) return;
				if (dispatchEvent(this.element, EVENT_CROP_START, {
					originalEvent: event,
					action
				}) === false) return;
				event.preventDefault();
				this.action = action;
				this.cropping = false;
				if (action === ACTION_CROP) {
					this.cropping = true;
					addClass(this.dragBox, CLASS_MODAL);
				}
			},
			cropMove: function cropMove(event) {
				var action = this.action;
				if (this.disabled || !action) return;
				var pointers = this.pointers;
				event.preventDefault();
				if (dispatchEvent(this.element, EVENT_CROP_MOVE, {
					originalEvent: event,
					action
				}) === false) return;
				if (event.changedTouches) forEach(event.changedTouches, function(touch) {
					assign(pointers[touch.identifier] || {}, getPointer(touch, true));
				});
				else assign(pointers[event.pointerId || 0] || {}, getPointer(event, true));
				this.change(event);
			},
			cropEnd: function cropEnd(event) {
				if (this.disabled) return;
				var action = this.action, pointers = this.pointers;
				if (event.changedTouches) forEach(event.changedTouches, function(touch) {
					delete pointers[touch.identifier];
				});
				else delete pointers[event.pointerId || 0];
				if (!action) return;
				event.preventDefault();
				if (!Object.keys(pointers).length) this.action = "";
				if (this.cropping) {
					this.cropping = false;
					toggleClass(this.dragBox, CLASS_MODAL, this.cropped && this.options.modal);
				}
				dispatchEvent(this.element, EVENT_CROP_END, {
					originalEvent: event,
					action
				});
			}
		};
		var change = { change: function change(event) {
			var options = this.options, canvasData = this.canvasData, containerData = this.containerData, cropBoxData = this.cropBoxData, pointers = this.pointers;
			var action = this.action;
			var aspectRatio = options.aspectRatio;
			var left = cropBoxData.left, top = cropBoxData.top, width = cropBoxData.width, height = cropBoxData.height;
			var right = left + width;
			var bottom = top + height;
			var minLeft = 0;
			var minTop = 0;
			var maxWidth = containerData.width;
			var maxHeight = containerData.height;
			var renderable = true;
			var offset;
			if (!aspectRatio && event.shiftKey) aspectRatio = width && height ? width / height : 1;
			if (this.limited) {
				minLeft = cropBoxData.minLeft;
				minTop = cropBoxData.minTop;
				maxWidth = minLeft + Math.min(containerData.width, canvasData.width, canvasData.left + canvasData.width);
				maxHeight = minTop + Math.min(containerData.height, canvasData.height, canvasData.top + canvasData.height);
			}
			var pointer = pointers[Object.keys(pointers)[0]];
			var range = {
				x: pointer.endX - pointer.startX,
				y: pointer.endY - pointer.startY
			};
			var check = function check(side) {
				switch (side) {
					case ACTION_EAST:
						if (right + range.x > maxWidth) range.x = maxWidth - right;
						break;
					case ACTION_WEST:
						if (left + range.x < minLeft) range.x = minLeft - left;
						break;
					case ACTION_NORTH:
						if (top + range.y < minTop) range.y = minTop - top;
						break;
					case ACTION_SOUTH: if (bottom + range.y > maxHeight) range.y = maxHeight - bottom;
				}
			};
			switch (action) {
				case ACTION_ALL:
					left += range.x;
					top += range.y;
					break;
				case ACTION_EAST:
					if (range.x >= 0 && (right >= maxWidth || aspectRatio && (top <= minTop || bottom >= maxHeight))) {
						renderable = false;
						break;
					}
					check(ACTION_EAST);
					width += range.x;
					if (width < 0) {
						action = ACTION_WEST;
						width = -width;
						left -= width;
					}
					if (aspectRatio) {
						height = width / aspectRatio;
						top += (cropBoxData.height - height) / 2;
					}
					break;
				case ACTION_NORTH:
					if (range.y <= 0 && (top <= minTop || aspectRatio && (left <= minLeft || right >= maxWidth))) {
						renderable = false;
						break;
					}
					check(ACTION_NORTH);
					height -= range.y;
					top += range.y;
					if (height < 0) {
						action = ACTION_SOUTH;
						height = -height;
						top -= height;
					}
					if (aspectRatio) {
						width = height * aspectRatio;
						left += (cropBoxData.width - width) / 2;
					}
					break;
				case ACTION_WEST:
					if (range.x <= 0 && (left <= minLeft || aspectRatio && (top <= minTop || bottom >= maxHeight))) {
						renderable = false;
						break;
					}
					check(ACTION_WEST);
					width -= range.x;
					left += range.x;
					if (width < 0) {
						action = ACTION_EAST;
						width = -width;
						left -= width;
					}
					if (aspectRatio) {
						height = width / aspectRatio;
						top += (cropBoxData.height - height) / 2;
					}
					break;
				case ACTION_SOUTH:
					if (range.y >= 0 && (bottom >= maxHeight || aspectRatio && (left <= minLeft || right >= maxWidth))) {
						renderable = false;
						break;
					}
					check(ACTION_SOUTH);
					height += range.y;
					if (height < 0) {
						action = ACTION_NORTH;
						height = -height;
						top -= height;
					}
					if (aspectRatio) {
						width = height * aspectRatio;
						left += (cropBoxData.width - width) / 2;
					}
					break;
				case ACTION_NORTH_EAST:
					if (aspectRatio) {
						if (range.y <= 0 && (top <= minTop || right >= maxWidth)) {
							renderable = false;
							break;
						}
						check(ACTION_NORTH);
						height -= range.y;
						top += range.y;
						width = height * aspectRatio;
					} else {
						check(ACTION_NORTH);
						check(ACTION_EAST);
						if (range.x >= 0) {
							if (right < maxWidth) width += range.x;
							else if (range.y <= 0 && top <= minTop) renderable = false;
						} else width += range.x;
						if (range.y <= 0) {
							if (top > minTop) {
								height -= range.y;
								top += range.y;
							}
						} else {
							height -= range.y;
							top += range.y;
						}
					}
					if (width < 0 && height < 0) {
						action = ACTION_SOUTH_WEST;
						height = -height;
						width = -width;
						top -= height;
						left -= width;
					} else if (width < 0) {
						action = ACTION_NORTH_WEST;
						width = -width;
						left -= width;
					} else if (height < 0) {
						action = ACTION_SOUTH_EAST;
						height = -height;
						top -= height;
					}
					break;
				case ACTION_NORTH_WEST:
					if (aspectRatio) {
						if (range.y <= 0 && (top <= minTop || left <= minLeft)) {
							renderable = false;
							break;
						}
						check(ACTION_NORTH);
						height -= range.y;
						top += range.y;
						width = height * aspectRatio;
						left += cropBoxData.width - width;
					} else {
						check(ACTION_NORTH);
						check(ACTION_WEST);
						if (range.x <= 0) {
							if (left > minLeft) {
								width -= range.x;
								left += range.x;
							} else if (range.y <= 0 && top <= minTop) renderable = false;
						} else {
							width -= range.x;
							left += range.x;
						}
						if (range.y <= 0) {
							if (top > minTop) {
								height -= range.y;
								top += range.y;
							}
						} else {
							height -= range.y;
							top += range.y;
						}
					}
					if (width < 0 && height < 0) {
						action = ACTION_SOUTH_EAST;
						height = -height;
						width = -width;
						top -= height;
						left -= width;
					} else if (width < 0) {
						action = ACTION_NORTH_EAST;
						width = -width;
						left -= width;
					} else if (height < 0) {
						action = ACTION_SOUTH_WEST;
						height = -height;
						top -= height;
					}
					break;
				case ACTION_SOUTH_WEST:
					if (aspectRatio) {
						if (range.x <= 0 && (left <= minLeft || bottom >= maxHeight)) {
							renderable = false;
							break;
						}
						check(ACTION_WEST);
						width -= range.x;
						left += range.x;
						height = width / aspectRatio;
					} else {
						check(ACTION_SOUTH);
						check(ACTION_WEST);
						if (range.x <= 0) {
							if (left > minLeft) {
								width -= range.x;
								left += range.x;
							} else if (range.y >= 0 && bottom >= maxHeight) renderable = false;
						} else {
							width -= range.x;
							left += range.x;
						}
						if (range.y >= 0) {
							if (bottom < maxHeight) height += range.y;
						} else height += range.y;
					}
					if (width < 0 && height < 0) {
						action = ACTION_NORTH_EAST;
						height = -height;
						width = -width;
						top -= height;
						left -= width;
					} else if (width < 0) {
						action = ACTION_SOUTH_EAST;
						width = -width;
						left -= width;
					} else if (height < 0) {
						action = ACTION_NORTH_WEST;
						height = -height;
						top -= height;
					}
					break;
				case ACTION_SOUTH_EAST:
					if (aspectRatio) {
						if (range.x >= 0 && (right >= maxWidth || bottom >= maxHeight)) {
							renderable = false;
							break;
						}
						check(ACTION_EAST);
						width += range.x;
						height = width / aspectRatio;
					} else {
						check(ACTION_SOUTH);
						check(ACTION_EAST);
						if (range.x >= 0) {
							if (right < maxWidth) width += range.x;
							else if (range.y >= 0 && bottom >= maxHeight) renderable = false;
						} else width += range.x;
						if (range.y >= 0) {
							if (bottom < maxHeight) height += range.y;
						} else height += range.y;
					}
					if (width < 0 && height < 0) {
						action = ACTION_NORTH_WEST;
						height = -height;
						width = -width;
						top -= height;
						left -= width;
					} else if (width < 0) {
						action = ACTION_SOUTH_WEST;
						width = -width;
						left -= width;
					} else if (height < 0) {
						action = ACTION_NORTH_EAST;
						height = -height;
						top -= height;
					}
					break;
				case ACTION_MOVE:
					this.move(range.x, range.y);
					renderable = false;
					break;
				case ACTION_ZOOM:
					this.zoom(getMaxZoomRatio(pointers), event);
					renderable = false;
					break;
				case ACTION_CROP:
					if (!range.x || !range.y) {
						renderable = false;
						break;
					}
					offset = getOffset(this.cropper);
					left = pointer.startX - offset.left;
					top = pointer.startY - offset.top;
					width = cropBoxData.minWidth;
					height = cropBoxData.minHeight;
					if (range.x > 0) action = range.y > 0 ? ACTION_SOUTH_EAST : ACTION_NORTH_EAST;
					else if (range.x < 0) {
						left -= width;
						action = range.y > 0 ? ACTION_SOUTH_WEST : ACTION_NORTH_WEST;
					}
					if (range.y < 0) top -= height;
					if (!this.cropped) {
						removeClass(this.cropBox, CLASS_HIDDEN);
						this.cropped = true;
						if (this.limited) this.limitCropBox(true, true);
					}
			}
			if (renderable) {
				cropBoxData.width = width;
				cropBoxData.height = height;
				cropBoxData.left = left;
				cropBoxData.top = top;
				this.action = action;
				this.renderCropBox();
			}
			forEach(pointers, function(p) {
				p.startX = p.endX;
				p.startY = p.endY;
			});
		} };
		var methods = {
			crop: function crop() {
				if (this.ready && !this.cropped && !this.disabled) {
					this.cropped = true;
					this.limitCropBox(true, true);
					if (this.options.modal) addClass(this.dragBox, CLASS_MODAL);
					removeClass(this.cropBox, CLASS_HIDDEN);
					this.setCropBoxData(this.initialCropBoxData);
				}
				return this;
			},
			reset: function reset() {
				if (this.ready && !this.disabled) {
					this.imageData = assign({}, this.initialImageData);
					this.canvasData = assign({}, this.initialCanvasData);
					this.cropBoxData = assign({}, this.initialCropBoxData);
					this.renderCanvas();
					if (this.cropped) this.renderCropBox();
				}
				return this;
			},
			clear: function clear() {
				if (this.cropped && !this.disabled) {
					assign(this.cropBoxData, {
						left: 0,
						top: 0,
						width: 0,
						height: 0
					});
					this.cropped = false;
					this.renderCropBox();
					this.limitCanvas(true, true);
					this.renderCanvas();
					removeClass(this.dragBox, CLASS_MODAL);
					addClass(this.cropBox, CLASS_HIDDEN);
				}
				return this;
			},
			/**
			* Replace the image's src and rebuild the cropper
			* @param {string} url - The new URL.
			* @param {boolean} [hasSameSize] - Indicate if the new image has the same size as the old one.
			* @returns {Cropper} this
			*/
			replace: function replace(url) {
				var hasSameSize = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
				if (!this.disabled && url) {
					if (this.isImg) this.element.src = url;
					if (hasSameSize) {
						this.url = url;
						this.image.src = url;
						if (this.ready) {
							this.viewBoxImage.src = url;
							forEach(this.previews, function(element) {
								element.getElementsByTagName("img")[0].src = url;
							});
						}
					} else {
						if (this.isImg) this.replaced = true;
						this.options.data = null;
						this.uncreate();
						this.load(url);
					}
				}
				return this;
			},
			enable: function enable() {
				if (this.ready && this.disabled) {
					this.disabled = false;
					removeClass(this.cropper, CLASS_DISABLED);
				}
				return this;
			},
			disable: function disable() {
				if (this.ready && !this.disabled) {
					this.disabled = true;
					addClass(this.cropper, CLASS_DISABLED);
				}
				return this;
			},
			/**
			* Destroy the cropper and remove the instance from the image
			* @returns {Cropper} this
			*/
			destroy: function destroy() {
				var element = this.element;
				if (!element[NAMESPACE]) return this;
				element[NAMESPACE] = void 0;
				if (this.isImg && this.replaced) element.src = this.originalUrl;
				this.uncreate();
				return this;
			},
			/**
			* Move the canvas with relative offsets
			* @param {number} offsetX - The relative offset distance on the x-axis.
			* @param {number} [offsetY=offsetX] - The relative offset distance on the y-axis.
			* @returns {Cropper} this
			*/
			move: function move(offsetX) {
				var offsetY = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : offsetX;
				var _this$canvasData = this.canvasData, left = _this$canvasData.left, top = _this$canvasData.top;
				return this.moveTo(isUndefined(offsetX) ? offsetX : left + Number(offsetX), isUndefined(offsetY) ? offsetY : top + Number(offsetY));
			},
			/**
			* Move the canvas to an absolute point
			* @param {number} x - The x-axis coordinate.
			* @param {number} [y=x] - The y-axis coordinate.
			* @returns {Cropper} this
			*/
			moveTo: function moveTo(x) {
				var y = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : x;
				var canvasData = this.canvasData;
				var changed = false;
				x = Number(x);
				y = Number(y);
				if (this.ready && !this.disabled && this.options.movable) {
					if (isNumber(x)) {
						canvasData.left = x;
						changed = true;
					}
					if (isNumber(y)) {
						canvasData.top = y;
						changed = true;
					}
					if (changed) this.renderCanvas(true);
				}
				return this;
			},
			/**
			* Zoom the canvas with a relative ratio
			* @param {number} ratio - The target ratio.
			* @param {Event} _originalEvent - The original event if any.
			* @returns {Cropper} this
			*/
			zoom: function zoom(ratio, _originalEvent) {
				var canvasData = this.canvasData;
				ratio = Number(ratio);
				if (ratio < 0) ratio = 1 / (1 - ratio);
				else ratio = 1 + ratio;
				return this.zoomTo(canvasData.width * ratio / canvasData.naturalWidth, null, _originalEvent);
			},
			/**
			* Zoom the canvas to an absolute ratio
			* @param {number} ratio - The target ratio.
			* @param {Object} pivot - The zoom pivot point coordinate.
			* @param {Event} _originalEvent - The original event if any.
			* @returns {Cropper} this
			*/
			zoomTo: function zoomTo(ratio, pivot, _originalEvent) {
				var options = this.options, canvasData = this.canvasData;
				var width = canvasData.width, height = canvasData.height, naturalWidth = canvasData.naturalWidth, naturalHeight = canvasData.naturalHeight;
				ratio = Number(ratio);
				if (ratio >= 0 && this.ready && !this.disabled && options.zoomable) {
					var newWidth = naturalWidth * ratio;
					var newHeight = naturalHeight * ratio;
					if (dispatchEvent(this.element, EVENT_ZOOM, {
						ratio,
						oldRatio: width / naturalWidth,
						originalEvent: _originalEvent
					}) === false) return this;
					if (_originalEvent) {
						var pointers = this.pointers;
						var offset = getOffset(this.cropper);
						var center = pointers && Object.keys(pointers).length ? getPointersCenter(pointers) : {
							pageX: _originalEvent.pageX,
							pageY: _originalEvent.pageY
						};
						canvasData.left -= (newWidth - width) * ((center.pageX - offset.left - canvasData.left) / width);
						canvasData.top -= (newHeight - height) * ((center.pageY - offset.top - canvasData.top) / height);
					} else if (isPlainObject(pivot) && isNumber(pivot.x) && isNumber(pivot.y)) {
						canvasData.left -= (newWidth - width) * ((pivot.x - canvasData.left) / width);
						canvasData.top -= (newHeight - height) * ((pivot.y - canvasData.top) / height);
					} else {
						canvasData.left -= (newWidth - width) / 2;
						canvasData.top -= (newHeight - height) / 2;
					}
					canvasData.width = newWidth;
					canvasData.height = newHeight;
					this.renderCanvas(true);
				}
				return this;
			},
			/**
			* Rotate the canvas with a relative degree
			* @param {number} degree - The rotate degree.
			* @returns {Cropper} this
			*/
			rotate: function rotate(degree) {
				return this.rotateTo((this.imageData.rotate || 0) + Number(degree));
			},
			/**
			* Rotate the canvas to an absolute degree
			* @param {number} degree - The rotate degree.
			* @returns {Cropper} this
			*/
			rotateTo: function rotateTo(degree) {
				degree = Number(degree);
				if (isNumber(degree) && this.ready && !this.disabled && this.options.rotatable) {
					this.imageData.rotate = degree % 360;
					this.renderCanvas(true, true);
				}
				return this;
			},
			/**
			* Scale the image on the x-axis.
			* @param {number} scaleX - The scale ratio on the x-axis.
			* @returns {Cropper} this
			*/
			scaleX: function scaleX(_scaleX) {
				var scaleY = this.imageData.scaleY;
				return this.scale(_scaleX, isNumber(scaleY) ? scaleY : 1);
			},
			/**
			* Scale the image on the y-axis.
			* @param {number} scaleY - The scale ratio on the y-axis.
			* @returns {Cropper} this
			*/
			scaleY: function scaleY(_scaleY) {
				var scaleX = this.imageData.scaleX;
				return this.scale(isNumber(scaleX) ? scaleX : 1, _scaleY);
			},
			/**
			* Scale the image
			* @param {number} scaleX - The scale ratio on the x-axis.
			* @param {number} [scaleY=scaleX] - The scale ratio on the y-axis.
			* @returns {Cropper} this
			*/
			scale: function scale(scaleX) {
				var scaleY = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : scaleX;
				var imageData = this.imageData;
				var transformed = false;
				scaleX = Number(scaleX);
				scaleY = Number(scaleY);
				if (this.ready && !this.disabled && this.options.scalable) {
					if (isNumber(scaleX)) {
						imageData.scaleX = scaleX;
						transformed = true;
					}
					if (isNumber(scaleY)) {
						imageData.scaleY = scaleY;
						transformed = true;
					}
					if (transformed) this.renderCanvas(true, true);
				}
				return this;
			},
			/**
			* Get the cropped area position and size data (base on the original image)
			* @param {boolean} [rounded=false] - Indicate if round the data values or not.
			* @returns {Object} The result cropped data.
			*/
			getData: function getData() {
				var rounded = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : false;
				var options = this.options, imageData = this.imageData, canvasData = this.canvasData, cropBoxData = this.cropBoxData;
				var data;
				if (this.ready && this.cropped) {
					data = {
						x: cropBoxData.left - canvasData.left,
						y: cropBoxData.top - canvasData.top,
						width: cropBoxData.width,
						height: cropBoxData.height
					};
					var ratio = imageData.width / imageData.naturalWidth;
					forEach(data, function(n, i) {
						data[i] = n / ratio;
					});
					if (rounded) {
						var bottom = Math.round(data.y + data.height);
						var right = Math.round(data.x + data.width);
						data.x = Math.round(data.x);
						data.y = Math.round(data.y);
						data.width = right - data.x;
						data.height = bottom - data.y;
					}
				} else data = {
					x: 0,
					y: 0,
					width: 0,
					height: 0
				};
				if (options.rotatable) data.rotate = imageData.rotate || 0;
				if (options.scalable) {
					data.scaleX = imageData.scaleX || 1;
					data.scaleY = imageData.scaleY || 1;
				}
				return data;
			},
			/**
			* Set the cropped area position and size with new data
			* @param {Object} data - The new data.
			* @returns {Cropper} this
			*/
			setData: function setData(data) {
				var options = this.options, imageData = this.imageData, canvasData = this.canvasData;
				var cropBoxData = {};
				if (this.ready && !this.disabled && isPlainObject(data)) {
					var transformed = false;
					if (options.rotatable) {
						if (isNumber(data.rotate) && data.rotate !== imageData.rotate) {
							imageData.rotate = data.rotate;
							transformed = true;
						}
					}
					if (options.scalable) {
						if (isNumber(data.scaleX) && data.scaleX !== imageData.scaleX) {
							imageData.scaleX = data.scaleX;
							transformed = true;
						}
						if (isNumber(data.scaleY) && data.scaleY !== imageData.scaleY) {
							imageData.scaleY = data.scaleY;
							transformed = true;
						}
					}
					if (transformed) this.renderCanvas(true, true);
					var ratio = imageData.width / imageData.naturalWidth;
					if (isNumber(data.x)) cropBoxData.left = data.x * ratio + canvasData.left;
					if (isNumber(data.y)) cropBoxData.top = data.y * ratio + canvasData.top;
					if (isNumber(data.width)) cropBoxData.width = data.width * ratio;
					if (isNumber(data.height)) cropBoxData.height = data.height * ratio;
					this.setCropBoxData(cropBoxData);
				}
				return this;
			},
			/**
			* Get the container size data.
			* @returns {Object} The result container data.
			*/
			getContainerData: function getContainerData() {
				return this.ready ? assign({}, this.containerData) : {};
			},
			/**
			* Get the image position and size data.
			* @returns {Object} The result image data.
			*/
			getImageData: function getImageData() {
				return this.sized ? assign({}, this.imageData) : {};
			},
			/**
			* Get the canvas position and size data.
			* @returns {Object} The result canvas data.
			*/
			getCanvasData: function getCanvasData() {
				var canvasData = this.canvasData;
				var data = {};
				if (this.ready) forEach([
					"left",
					"top",
					"width",
					"height",
					"naturalWidth",
					"naturalHeight"
				], function(n) {
					data[n] = canvasData[n];
				});
				return data;
			},
			/**
			* Set the canvas position and size with new data.
			* @param {Object} data - The new canvas data.
			* @returns {Cropper} this
			*/
			setCanvasData: function setCanvasData(data) {
				var canvasData = this.canvasData;
				var aspectRatio = canvasData.aspectRatio;
				if (this.ready && !this.disabled && isPlainObject(data)) {
					if (isNumber(data.left)) canvasData.left = data.left;
					if (isNumber(data.top)) canvasData.top = data.top;
					if (isNumber(data.width)) {
						canvasData.width = data.width;
						canvasData.height = data.width / aspectRatio;
					} else if (isNumber(data.height)) {
						canvasData.height = data.height;
						canvasData.width = data.height * aspectRatio;
					}
					this.renderCanvas(true);
				}
				return this;
			},
			/**
			* Get the crop box position and size data.
			* @returns {Object} The result crop box data.
			*/
			getCropBoxData: function getCropBoxData() {
				var cropBoxData = this.cropBoxData;
				var data;
				if (this.ready && this.cropped) data = {
					left: cropBoxData.left,
					top: cropBoxData.top,
					width: cropBoxData.width,
					height: cropBoxData.height
				};
				return data || {};
			},
			/**
			* Set the crop box position and size with new data.
			* @param {Object} data - The new crop box data.
			* @returns {Cropper} this
			*/
			setCropBoxData: function setCropBoxData(data) {
				var cropBoxData = this.cropBoxData;
				var aspectRatio = this.options.aspectRatio;
				var widthChanged;
				var heightChanged;
				if (this.ready && this.cropped && !this.disabled && isPlainObject(data)) {
					if (isNumber(data.left)) cropBoxData.left = data.left;
					if (isNumber(data.top)) cropBoxData.top = data.top;
					if (isNumber(data.width) && data.width !== cropBoxData.width) {
						widthChanged = true;
						cropBoxData.width = data.width;
					}
					if (isNumber(data.height) && data.height !== cropBoxData.height) {
						heightChanged = true;
						cropBoxData.height = data.height;
					}
					if (aspectRatio) {
						if (widthChanged) cropBoxData.height = cropBoxData.width / aspectRatio;
						else if (heightChanged) cropBoxData.width = cropBoxData.height * aspectRatio;
					}
					this.renderCropBox();
				}
				return this;
			},
			/**
			* Get a canvas drawn the cropped image.
			* @param {Object} [options={}] - The config options.
			* @returns {HTMLCanvasElement} - The result canvas.
			*/
			getCroppedCanvas: function getCroppedCanvas() {
				var options = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
				if (!this.ready || !window.HTMLCanvasElement) return null;
				var canvasData = this.canvasData;
				var source = getSourceCanvas(this.image, this.imageData, canvasData, options);
				if (!this.cropped) return source;
				var _this$getData = this.getData(options.rounded), initialX = _this$getData.x, initialY = _this$getData.y, initialWidth = _this$getData.width, initialHeight = _this$getData.height;
				var ratio = source.width / Math.floor(canvasData.naturalWidth);
				if (ratio !== 1) {
					initialX *= ratio;
					initialY *= ratio;
					initialWidth *= ratio;
					initialHeight *= ratio;
				}
				var aspectRatio = initialWidth / initialHeight;
				var maxSizes = getAdjustedSizes({
					aspectRatio,
					width: options.maxWidth || Infinity,
					height: options.maxHeight || Infinity
				});
				var minSizes = getAdjustedSizes({
					aspectRatio,
					width: options.minWidth || 0,
					height: options.minHeight || 0
				}, "cover");
				var _getAdjustedSizes = getAdjustedSizes({
					aspectRatio,
					width: options.width || (ratio !== 1 ? source.width : initialWidth),
					height: options.height || (ratio !== 1 ? source.height : initialHeight)
				}), width = _getAdjustedSizes.width, height = _getAdjustedSizes.height;
				width = Math.min(maxSizes.width, Math.max(minSizes.width, width));
				height = Math.min(maxSizes.height, Math.max(minSizes.height, height));
				var canvas = document.createElement("canvas");
				var context = canvas.getContext("2d");
				canvas.width = normalizeDecimalNumber(width);
				canvas.height = normalizeDecimalNumber(height);
				context.fillStyle = options.fillColor || "transparent";
				context.fillRect(0, 0, width, height);
				var _options$imageSmoothi = options.imageSmoothingEnabled, imageSmoothingEnabled = _options$imageSmoothi === void 0 ? true : _options$imageSmoothi, imageSmoothingQuality = options.imageSmoothingQuality;
				context.imageSmoothingEnabled = imageSmoothingEnabled;
				if (imageSmoothingQuality) context.imageSmoothingQuality = imageSmoothingQuality;
				var sourceWidth = source.width;
				var sourceHeight = source.height;
				var srcX = initialX;
				var srcY = initialY;
				var srcWidth;
				var srcHeight;
				var dstX;
				var dstY;
				var dstWidth;
				var dstHeight;
				if (srcX <= -initialWidth || srcX > sourceWidth) {
					srcX = 0;
					srcWidth = 0;
					dstX = 0;
					dstWidth = 0;
				} else if (srcX <= 0) {
					dstX = -srcX;
					srcX = 0;
					srcWidth = Math.min(sourceWidth, initialWidth + srcX);
					dstWidth = srcWidth;
				} else if (srcX <= sourceWidth) {
					dstX = 0;
					srcWidth = Math.min(initialWidth, sourceWidth - srcX);
					dstWidth = srcWidth;
				}
				if (srcWidth <= 0 || srcY <= -initialHeight || srcY > sourceHeight) {
					srcY = 0;
					srcHeight = 0;
					dstY = 0;
					dstHeight = 0;
				} else if (srcY <= 0) {
					dstY = -srcY;
					srcY = 0;
					srcHeight = Math.min(sourceHeight, initialHeight + srcY);
					dstHeight = srcHeight;
				} else if (srcY <= sourceHeight) {
					dstY = 0;
					srcHeight = Math.min(initialHeight, sourceHeight - srcY);
					dstHeight = srcHeight;
				}
				var params = [
					srcX,
					srcY,
					srcWidth,
					srcHeight
				];
				if (dstWidth > 0 && dstHeight > 0) {
					var scale = width / initialWidth;
					params.push(dstX * scale, dstY * scale, dstWidth * scale, dstHeight * scale);
				}
				context.drawImage.apply(context, [source].concat(_toConsumableArray(params.map(function(param) {
					return Math.floor(normalizeDecimalNumber(param));
				}))));
				return canvas;
			},
			/**
			* Change the aspect ratio of the crop box.
			* @param {number} aspectRatio - The new aspect ratio.
			* @returns {Cropper} this
			*/
			setAspectRatio: function setAspectRatio(aspectRatio) {
				var options = this.options;
				if (!this.disabled && !isUndefined(aspectRatio)) {
					options.aspectRatio = Math.max(0, aspectRatio) || NaN;
					if (this.ready) {
						this.initCropBox();
						if (this.cropped) this.renderCropBox();
					}
				}
				return this;
			},
			/**
			* Change the drag mode.
			* @param {string} mode - The new drag mode.
			* @returns {Cropper} this
			*/
			setDragMode: function setDragMode(mode) {
				var options = this.options, dragBox = this.dragBox, face = this.face;
				if (this.ready && !this.disabled) {
					var croppable = mode === DRAG_MODE_CROP;
					var movable = options.movable && mode === DRAG_MODE_MOVE;
					mode = croppable || movable ? mode : DRAG_MODE_NONE;
					options.dragMode = mode;
					setData(dragBox, DATA_ACTION, mode);
					toggleClass(dragBox, CLASS_CROP, croppable);
					toggleClass(dragBox, CLASS_MOVE, movable);
					if (!options.cropBoxMovable) {
						setData(face, DATA_ACTION, mode);
						toggleClass(face, CLASS_CROP, croppable);
						toggleClass(face, CLASS_MOVE, movable);
					}
				}
				return this;
			}
		};
		var AnotherCropper = WINDOW.Cropper;
		var Cropper = /*#__PURE__*/ function() {
			/**
			* Create a new Cropper.
			* @param {Element} element - The target element for cropping.
			* @param {Object} [options={}] - The configuration options.
			*/
			function Cropper(element) {
				var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
				_classCallCheck(this, Cropper);
				if (!element || !REGEXP_TAG_NAME.test(element.tagName)) throw new Error("The first argument is required and must be an <img> or <canvas> element.");
				this.element = element;
				this.options = assign({}, DEFAULTS, isPlainObject(options) && options);
				this.cropped = false;
				this.disabled = false;
				this.pointers = {};
				this.ready = false;
				this.reloading = false;
				this.replaced = false;
				this.sized = false;
				this.sizing = false;
				this.init();
			}
			return _createClass(Cropper, [
				{
					key: "init",
					value: function init() {
						var element = this.element;
						var tagName = element.tagName.toLowerCase();
						var url;
						if (element[NAMESPACE]) return;
						element[NAMESPACE] = this;
						if (tagName === "img") {
							this.isImg = true;
							url = element.getAttribute("src") || "";
							this.originalUrl = url;
							if (!url) return;
							url = element.src;
						} else if (tagName === "canvas" && window.HTMLCanvasElement) url = element.toDataURL();
						this.load(url);
					}
				},
				{
					key: "load",
					value: function load(url) {
						var _this = this;
						if (!url) return;
						this.url = url;
						this.imageData = {};
						var element = this.element, options = this.options;
						if (!options.rotatable && !options.scalable) options.checkOrientation = false;
						if (!options.checkOrientation || !window.ArrayBuffer) {
							this.clone();
							return;
						}
						if (REGEXP_DATA_URL.test(url)) {
							if (REGEXP_DATA_URL_JPEG.test(url)) this.read(dataURLToArrayBuffer(url));
							else this.clone();
							return;
						}
						var xhr = new XMLHttpRequest();
						var clone = this.clone.bind(this);
						this.reloading = true;
						this.xhr = xhr;
						xhr.onabort = clone;
						xhr.onerror = clone;
						xhr.ontimeout = clone;
						xhr.onprogress = function() {
							if (xhr.getResponseHeader("content-type") !== MIME_TYPE_JPEG) xhr.abort();
						};
						xhr.onload = function() {
							_this.read(xhr.response);
						};
						xhr.onloadend = function() {
							_this.reloading = false;
							_this.xhr = null;
						};
						if (options.checkCrossOrigin && isCrossOriginURL(url) && element.crossOrigin) url = addTimestamp(url);
						xhr.open("GET", url, true);
						xhr.responseType = "arraybuffer";
						xhr.withCredentials = element.crossOrigin === "use-credentials";
						xhr.send();
					}
				},
				{
					key: "read",
					value: function read(arrayBuffer) {
						var options = this.options, imageData = this.imageData;
						var orientation = resetAndGetOrientation(arrayBuffer);
						var rotate = 0;
						var scaleX = 1;
						var scaleY = 1;
						if (orientation > 1) {
							this.url = arrayBufferToDataURL(arrayBuffer, MIME_TYPE_JPEG);
							var _parseOrientation = parseOrientation(orientation);
							rotate = _parseOrientation.rotate;
							scaleX = _parseOrientation.scaleX;
							scaleY = _parseOrientation.scaleY;
						}
						if (options.rotatable) imageData.rotate = rotate;
						if (options.scalable) {
							imageData.scaleX = scaleX;
							imageData.scaleY = scaleY;
						}
						this.clone();
					}
				},
				{
					key: "clone",
					value: function clone() {
						var element = this.element, url = this.url;
						var crossOrigin = element.crossOrigin;
						var crossOriginUrl = url;
						if (this.options.checkCrossOrigin && isCrossOriginURL(url)) {
							if (!crossOrigin) crossOrigin = "anonymous";
							crossOriginUrl = addTimestamp(url);
						}
						this.crossOrigin = crossOrigin;
						this.crossOriginUrl = crossOriginUrl;
						var image = document.createElement("img");
						if (crossOrigin) image.crossOrigin = crossOrigin;
						image.src = crossOriginUrl || url;
						image.alt = element.alt || "The image to crop";
						this.image = image;
						image.onload = this.start.bind(this);
						image.onerror = this.stop.bind(this);
						addClass(image, CLASS_HIDE);
						element.parentNode.insertBefore(image, element.nextSibling);
					}
				},
				{
					key: "start",
					value: function start() {
						var _this2 = this;
						var image = this.image;
						image.onload = null;
						image.onerror = null;
						this.sizing = true;
						var isIOSWebKit = WINDOW.navigator && /(?:iPad|iPhone|iPod).*?AppleWebKit/i.test(WINDOW.navigator.userAgent);
						var done = function done(naturalWidth, naturalHeight) {
							assign(_this2.imageData, {
								naturalWidth,
								naturalHeight,
								aspectRatio: naturalWidth / naturalHeight
							});
							_this2.initialImageData = assign({}, _this2.imageData);
							_this2.sizing = false;
							_this2.sized = true;
							_this2.build();
						};
						if (image.naturalWidth && !isIOSWebKit) {
							done(image.naturalWidth, image.naturalHeight);
							return;
						}
						var sizingImage = document.createElement("img");
						var body = document.body || document.documentElement;
						this.sizingImage = sizingImage;
						sizingImage.onload = function() {
							done(sizingImage.width, sizingImage.height);
							if (!isIOSWebKit) body.removeChild(sizingImage);
						};
						sizingImage.src = image.src;
						if (!isIOSWebKit) {
							sizingImage.style.cssText = "left:0;max-height:none!important;max-width:none!important;min-height:0!important;min-width:0!important;opacity:0;position:absolute;top:0;z-index:-1;";
							body.appendChild(sizingImage);
						}
					}
				},
				{
					key: "stop",
					value: function stop() {
						var image = this.image;
						image.onload = null;
						image.onerror = null;
						image.parentNode.removeChild(image);
						this.image = null;
					}
				},
				{
					key: "build",
					value: function build() {
						if (!this.sized || this.ready) return;
						var element = this.element, options = this.options, image = this.image;
						var container = element.parentNode;
						var template = document.createElement("div");
						template.innerHTML = TEMPLATE;
						var cropper = template.querySelector(".".concat(NAMESPACE, "-container"));
						var canvas = cropper.querySelector(".".concat(NAMESPACE, "-canvas"));
						var dragBox = cropper.querySelector(".".concat(NAMESPACE, "-drag-box"));
						var cropBox = cropper.querySelector(".".concat(NAMESPACE, "-crop-box"));
						var face = cropBox.querySelector(".".concat(NAMESPACE, "-face"));
						this.container = container;
						this.cropper = cropper;
						this.canvas = canvas;
						this.dragBox = dragBox;
						this.cropBox = cropBox;
						this.viewBox = cropper.querySelector(".".concat(NAMESPACE, "-view-box"));
						this.face = face;
						canvas.appendChild(image);
						addClass(element, CLASS_HIDDEN);
						container.insertBefore(cropper, element.nextSibling);
						removeClass(image, CLASS_HIDE);
						this.initPreview();
						this.bind();
						options.initialAspectRatio = Math.max(0, options.initialAspectRatio) || NaN;
						options.aspectRatio = Math.max(0, options.aspectRatio) || NaN;
						options.viewMode = Math.max(0, Math.min(3, Math.round(options.viewMode))) || 0;
						addClass(cropBox, CLASS_HIDDEN);
						if (!options.guides) addClass(cropBox.getElementsByClassName("".concat(NAMESPACE, "-dashed")), CLASS_HIDDEN);
						if (!options.center) addClass(cropBox.getElementsByClassName("".concat(NAMESPACE, "-center")), CLASS_HIDDEN);
						if (options.background) addClass(cropper, "".concat(NAMESPACE, "-bg"));
						if (!options.highlight) addClass(face, CLASS_INVISIBLE);
						if (options.cropBoxMovable) {
							addClass(face, CLASS_MOVE);
							setData(face, DATA_ACTION, ACTION_ALL);
						}
						if (!options.cropBoxResizable) {
							addClass(cropBox.getElementsByClassName("".concat(NAMESPACE, "-line")), CLASS_HIDDEN);
							addClass(cropBox.getElementsByClassName("".concat(NAMESPACE, "-point")), CLASS_HIDDEN);
						}
						this.render();
						this.ready = true;
						this.setDragMode(options.dragMode);
						if (options.autoCrop) this.crop();
						this.setData(options.data);
						if (isFunction(options.ready)) addListener(element, EVENT_READY, options.ready, { once: true });
						dispatchEvent(element, EVENT_READY);
					}
				},
				{
					key: "unbuild",
					value: function unbuild() {
						if (!this.ready) return;
						this.ready = false;
						this.unbind();
						this.resetPreview();
						var parentNode = this.cropper.parentNode;
						if (parentNode) parentNode.removeChild(this.cropper);
						removeClass(this.element, CLASS_HIDDEN);
					}
				},
				{
					key: "uncreate",
					value: function uncreate() {
						if (this.ready) {
							this.unbuild();
							this.ready = false;
							this.cropped = false;
						} else if (this.sizing) {
							this.sizingImage.onload = null;
							this.sizing = false;
							this.sized = false;
						} else if (this.reloading) {
							this.xhr.onabort = null;
							this.xhr.abort();
						} else if (this.image) this.stop();
					}
				}
			], [{
				key: "noConflict",
				value: function noConflict() {
					window.Cropper = AnotherCropper;
					return Cropper;
				}
			}, {
				key: "setDefaults",
				value: function setDefaults(options) {
					assign(DEFAULTS, isPlainObject(options) && options);
				}
			}]);
		}();
		assign(Cropper.prototype, render, preview, events, handlers, change, methods);
		return Cropper;
	}));
})))(), 1);
function _classCallCheck(a, n) {
	if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
}
function _createClass(e, r, t) {
	return Object.defineProperty(e, "prototype", { writable: false }), e;
}
function _typeof(o) {
	"@babel/helpers - typeof";
	return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof(o);
}
/**
* StackBlur - a fast almost Gaussian Blur For Canvas
*
* In case you find this class useful - especially in commercial projects -
* I am not totally unhappy for a small donation to my PayPal account
* mario@quasimondo.de
*
* Or support me on flattr:
* {@link https://flattr.com/thing/72791/StackBlur-a-fast-almost-Gaussian-Blur-Effect-for-CanvasJavascript}.
*
* @module StackBlur
* @author Mario Klingemann
* Contact: mario@quasimondo.com
* Website: {@link http://www.quasimondo.com/StackBlurForCanvas/StackBlurDemo.html}
* Twitter: `@quasimondo`
* @copyright (c) 2010 Mario Klingemann
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/
var mulTable = [
	512,
	512,
	456,
	512,
	328,
	456,
	335,
	512,
	405,
	328,
	271,
	456,
	388,
	335,
	292,
	512,
	454,
	405,
	364,
	328,
	298,
	271,
	496,
	456,
	420,
	388,
	360,
	335,
	312,
	292,
	273,
	512,
	482,
	454,
	428,
	405,
	383,
	364,
	345,
	328,
	312,
	298,
	284,
	271,
	259,
	496,
	475,
	456,
	437,
	420,
	404,
	388,
	374,
	360,
	347,
	335,
	323,
	312,
	302,
	292,
	282,
	273,
	265,
	512,
	497,
	482,
	468,
	454,
	441,
	428,
	417,
	405,
	394,
	383,
	373,
	364,
	354,
	345,
	337,
	328,
	320,
	312,
	305,
	298,
	291,
	284,
	278,
	271,
	265,
	259,
	507,
	496,
	485,
	475,
	465,
	456,
	446,
	437,
	428,
	420,
	412,
	404,
	396,
	388,
	381,
	374,
	367,
	360,
	354,
	347,
	341,
	335,
	329,
	323,
	318,
	312,
	307,
	302,
	297,
	292,
	287,
	282,
	278,
	273,
	269,
	265,
	261,
	512,
	505,
	497,
	489,
	482,
	475,
	468,
	461,
	454,
	447,
	441,
	435,
	428,
	422,
	417,
	411,
	405,
	399,
	394,
	389,
	383,
	378,
	373,
	368,
	364,
	359,
	354,
	350,
	345,
	341,
	337,
	332,
	328,
	324,
	320,
	316,
	312,
	309,
	305,
	301,
	298,
	294,
	291,
	287,
	284,
	281,
	278,
	274,
	271,
	268,
	265,
	262,
	259,
	257,
	507,
	501,
	496,
	491,
	485,
	480,
	475,
	470,
	465,
	460,
	456,
	451,
	446,
	442,
	437,
	433,
	428,
	424,
	420,
	416,
	412,
	408,
	404,
	400,
	396,
	392,
	388,
	385,
	381,
	377,
	374,
	370,
	367,
	363,
	360,
	357,
	354,
	350,
	347,
	344,
	341,
	338,
	335,
	332,
	329,
	326,
	323,
	320,
	318,
	315,
	312,
	310,
	307,
	304,
	302,
	299,
	297,
	294,
	292,
	289,
	287,
	285,
	282,
	280,
	278,
	275,
	273,
	271,
	269,
	267,
	265,
	263,
	261,
	259
];
var shgTable = [
	9,
	11,
	12,
	13,
	13,
	14,
	14,
	15,
	15,
	15,
	15,
	16,
	16,
	16,
	16,
	17,
	17,
	17,
	17,
	17,
	17,
	17,
	18,
	18,
	18,
	18,
	18,
	18,
	18,
	18,
	18,
	19,
	19,
	19,
	19,
	19,
	19,
	19,
	19,
	19,
	19,
	19,
	19,
	19,
	19,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	20,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	21,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	22,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24
];
/**
* @param {string|HTMLCanvasElement} canvas
* @param {Integer} topX
* @param {Integer} topY
* @param {Integer} width
* @param {Integer} height
* @throws {Error|TypeError}
* @returns {ImageData} See {@link https://html.spec.whatwg.org/multipage/canvas.html#imagedata}
*/
function getImageDataFromCanvas(canvas, topX, topY, width, height) {
	if (typeof canvas === "string") canvas = document.getElementById(canvas);
	if (!canvas || _typeof(canvas) !== "object" || !("getContext" in canvas)) throw new TypeError("Expecting canvas with `getContext` method in processCanvasRGB(A) calls!");
	var context = canvas.getContext("2d");
	try {
		return context.getImageData(topX, topY, width, height);
	} catch (e) {
		throw new Error("unable to access image data: " + e);
	}
}
/**
* @param {HTMLCanvasElement} canvas
* @param {Integer} topX
* @param {Integer} topY
* @param {Integer} width
* @param {Integer} height
* @param {Float} radius
* @returns {undefined}
*/
function processCanvasRGBA(canvas, topX, topY, width, height, radius) {
	if (isNaN(radius) || radius < 1) return;
	radius |= 0;
	var imageData = getImageDataFromCanvas(canvas, topX, topY, width, height);
	imageData = processImageDataRGBA(imageData, topX, topY, width, height, radius);
	canvas.getContext("2d").putImageData(imageData, topX, topY);
}
/**
* @param {ImageData} imageData
* @param {Integer} topX
* @param {Integer} topY
* @param {Integer} width
* @param {Integer} height
* @param {Float} radius
* @returns {ImageData}
*/
function processImageDataRGBA(imageData, topX, topY, width, height, radius) {
	var pixels = imageData.data;
	var div = 2 * radius + 1;
	var widthMinus1 = width - 1;
	var heightMinus1 = height - 1;
	var radiusPlus1 = radius + 1;
	var sumFactor = radiusPlus1 * (radiusPlus1 + 1) / 2;
	var stackStart = new BlurStack();
	var stack = stackStart;
	var stackEnd;
	for (var i = 1; i < div; i++) {
		stack = stack.next = new BlurStack();
		if (i === radiusPlus1) stackEnd = stack;
	}
	stack.next = stackStart;
	var stackIn = null, stackOut = null, yw = 0, yi = 0;
	var mulSum = mulTable[radius];
	var shgSum = shgTable[radius];
	for (var y = 0; y < height; y++) {
		stack = stackStart;
		var pr = pixels[yi], pg = pixels[yi + 1], pb = pixels[yi + 2], pa = pixels[yi + 3];
		for (var _i = 0; _i < radiusPlus1; _i++) {
			stack.r = pr;
			stack.g = pg;
			stack.b = pb;
			stack.a = pa;
			stack = stack.next;
		}
		var rInSum = 0, gInSum = 0, bInSum = 0, aInSum = 0, rOutSum = radiusPlus1 * pr, gOutSum = radiusPlus1 * pg, bOutSum = radiusPlus1 * pb, aOutSum = radiusPlus1 * pa, rSum = sumFactor * pr, gSum = sumFactor * pg, bSum = sumFactor * pb, aSum = sumFactor * pa;
		for (var _i2 = 1; _i2 < radiusPlus1; _i2++) {
			var p = yi + (Math.min(widthMinus1, _i2) << 2);
			var r = pixels[p], g = pixels[p + 1], b = pixels[p + 2], a = pixels[p + 3];
			var rbs = radiusPlus1 - _i2;
			rSum += (stack.r = r) * rbs;
			gSum += (stack.g = g) * rbs;
			bSum += (stack.b = b) * rbs;
			aSum += (stack.a = a) * rbs;
			rInSum += r;
			gInSum += g;
			bInSum += b;
			aInSum += a;
			stack = stack.next;
		}
		stackIn = stackStart;
		stackOut = stackEnd;
		for (var x = 0; x < width; x++) {
			var paInitial = aSum * mulSum >>> shgSum;
			pixels[yi + 3] = paInitial;
			if (paInitial !== 0) {
				var _a = 255 / paInitial;
				pixels[yi] = (rSum * mulSum >>> shgSum) * _a;
				pixels[yi + 1] = (gSum * mulSum >>> shgSum) * _a;
				pixels[yi + 2] = (bSum * mulSum >>> shgSum) * _a;
			} else pixels[yi] = pixels[yi + 1] = pixels[yi + 2] = 0;
			rSum -= rOutSum;
			gSum -= gOutSum;
			bSum -= bOutSum;
			aSum -= aOutSum;
			rOutSum -= stackIn.r;
			gOutSum -= stackIn.g;
			bOutSum -= stackIn.b;
			aOutSum -= stackIn.a;
			var _p = x + radius + 1;
			_p = yw + Math.min(_p, widthMinus1) << 2;
			rInSum += stackIn.r = pixels[_p];
			gInSum += stackIn.g = pixels[_p + 1];
			bInSum += stackIn.b = pixels[_p + 2];
			aInSum += stackIn.a = pixels[_p + 3];
			rSum += rInSum;
			gSum += gInSum;
			bSum += bInSum;
			aSum += aInSum;
			stackIn = stackIn.next;
			var _stackOut = stackOut, _r = _stackOut.r, _g = _stackOut.g, _b = _stackOut.b, _a2 = _stackOut.a;
			rOutSum += _r;
			gOutSum += _g;
			bOutSum += _b;
			aOutSum += _a2;
			rInSum -= _r;
			gInSum -= _g;
			bInSum -= _b;
			aInSum -= _a2;
			stackOut = stackOut.next;
			yi += 4;
		}
		yw += width;
	}
	for (var _x = 0; _x < width; _x++) {
		yi = _x << 2;
		var _pr = pixels[yi], _pg = pixels[yi + 1], _pb = pixels[yi + 2], _pa = pixels[yi + 3], _rOutSum = radiusPlus1 * _pr, _gOutSum = radiusPlus1 * _pg, _bOutSum = radiusPlus1 * _pb, _aOutSum = radiusPlus1 * _pa, _rSum = sumFactor * _pr, _gSum = sumFactor * _pg, _bSum = sumFactor * _pb, _aSum = sumFactor * _pa;
		stack = stackStart;
		for (var _i3 = 0; _i3 < radiusPlus1; _i3++) {
			stack.r = _pr;
			stack.g = _pg;
			stack.b = _pb;
			stack.a = _pa;
			stack = stack.next;
		}
		var yp = width;
		var _gInSum = 0, _bInSum = 0, _aInSum = 0, _rInSum = 0;
		for (var _i4 = 1; _i4 <= radius; _i4++) {
			yi = yp + _x << 2;
			var _rbs = radiusPlus1 - _i4;
			_rSum += (stack.r = _pr = pixels[yi]) * _rbs;
			_gSum += (stack.g = _pg = pixels[yi + 1]) * _rbs;
			_bSum += (stack.b = _pb = pixels[yi + 2]) * _rbs;
			_aSum += (stack.a = _pa = pixels[yi + 3]) * _rbs;
			_rInSum += _pr;
			_gInSum += _pg;
			_bInSum += _pb;
			_aInSum += _pa;
			stack = stack.next;
			if (_i4 < heightMinus1) yp += width;
		}
		yi = _x;
		stackIn = stackStart;
		stackOut = stackEnd;
		for (var _y = 0; _y < height; _y++) {
			var _p2 = yi << 2;
			pixels[_p2 + 3] = _pa = _aSum * mulSum >>> shgSum;
			if (_pa > 0) {
				_pa = 255 / _pa;
				pixels[_p2] = (_rSum * mulSum >>> shgSum) * _pa;
				pixels[_p2 + 1] = (_gSum * mulSum >>> shgSum) * _pa;
				pixels[_p2 + 2] = (_bSum * mulSum >>> shgSum) * _pa;
			} else pixels[_p2] = pixels[_p2 + 1] = pixels[_p2 + 2] = 0;
			_rSum -= _rOutSum;
			_gSum -= _gOutSum;
			_bSum -= _bOutSum;
			_aSum -= _aOutSum;
			_rOutSum -= stackIn.r;
			_gOutSum -= stackIn.g;
			_bOutSum -= stackIn.b;
			_aOutSum -= stackIn.a;
			_p2 = _x + ((_p2 = _y + radiusPlus1) < heightMinus1 ? _p2 : heightMinus1) * width << 2;
			_rSum += _rInSum += stackIn.r = pixels[_p2];
			_gSum += _gInSum += stackIn.g = pixels[_p2 + 1];
			_bSum += _bInSum += stackIn.b = pixels[_p2 + 2];
			_aSum += _aInSum += stackIn.a = pixels[_p2 + 3];
			stackIn = stackIn.next;
			_rOutSum += _pr = stackOut.r;
			_gOutSum += _pg = stackOut.g;
			_bOutSum += _pb = stackOut.b;
			_aOutSum += _pa = stackOut.a;
			_rInSum -= _pr;
			_gInSum -= _pg;
			_bInSum -= _pb;
			_aInSum -= _pa;
			stackOut = stackOut.next;
			yi += width;
		}
	}
	return imageData;
}
/**
*
*/
var BlurStack = /*#__PURE__*/ _createClass(
	/**
	* Set properties.
	*/
	function BlurStack() {
		_classCallCheck(this, BlurStack);
		this.r = 0;
		this.g = 0;
		this.b = 0;
		this.a = 0;
		this.next = null;
	}
);
//#endregion
//#region src/editor/canvas-editor.ts
applyTheme();
watchTheme();
var shapeSvgs = {
	rectangle: "<rect x=\"3\" y=\"5\" width=\"18\" height=\"14\" rx=\"0\"/>",
	square: "<rect x=\"4\" y=\"4\" width=\"16\" height=\"16\" rx=\"0\"/>",
	circle: "<circle cx=\"12\" cy=\"12\" r=\"8\"/>",
	ellipse: "<ellipse cx=\"12\" cy=\"12\" rx=\"9\" ry=\"6\"/>",
	triangle: "<polygon points=\"12,3 21,21 3,21\"/>",
	polygon: "<polygon points=\"12,3 20.66,8 20.66,18 12,23 3.34,18 3.34,8\"/>"
};
var shapeLabels = {
	rectangle: "Rectangle (R)",
	square: "Square",
	circle: "Circle",
	ellipse: "Ellipse (E)",
	triangle: "Triangle",
	polygon: "Polygon (Hexagon)"
};
var canvas;
var currentTool = "select";
var currentShapeType = "rectangle";
var currentArrowType = "straight";
var currentBlurType = "glass";
var currentColor = "#EF4444";
var strokeWidth = 4;
var stepCounter = 1;
var drawStartX = 0;
var drawStartY = 0;
var isDrawing = false;
var tempShape = null;
var undoStack = [];
var redoStack = [];
var backgroundImage = null;
var fitScale = 1;
var imgNativeW = 0;
var imgNativeH = 0;
var dispW = 0;
var dispH = 0;
var cssZoom = 1;
var cropperInstance = null;
var isBeautified = false;
var isCropped = false;
var capturedPageUrl = "";
var DEFAULT_SHORTCUTS = {
	select: "v",
	arrow: "a",
	rectangle: "r",
	ellipse: "e",
	callout: "c",
	line: "l",
	freedraw: "p",
	text: "t",
	spotlight: "s",
	blur: "b",
	step: "n",
	crop: "x",
	highlight: "h",
	triangle: "",
	circle: "",
	square: "",
	polygon: ""
};
var activeShortcuts = { ...DEFAULT_SHORTCUTS };
var keyToTool = {};
function rebuildKeyToTool() {
	keyToTool = {};
	Object.keys(activeShortcuts).forEach((tool) => {
		keyToTool[activeShortcuts[tool]] = tool;
	});
}
rebuildKeyToTool();
async function loadShortcuts() {
	try {
		const custom = (await chrome.storage.sync.get("settings")).settings?.editorShortcuts;
		if (custom) {
			activeShortcuts = {
				...DEFAULT_SHORTCUTS,
				...custom
			};
			rebuildKeyToTool();
		}
	} catch {}
}
function applyShortcutLabels() {
	Object.keys(activeShortcuts).forEach((tool) => {
		const tip = document.querySelector(`[data-tool="${tool}"]`)?.querySelector(".tip");
		if (!tip) return;
		const key = activeShortcuts[tool].toUpperCase();
		tip.textContent = `${tip.textContent?.replace(/\s*\([A-Z0-9]\)$/, "").trim() ?? ""} (${key})`;
	});
}
var dimensionsEl = document.getElementById("dimensions");
var zoomEl = document.getElementById("zoom");
var toolNameEl = document.getElementById("toolName");
var toast = document.getElementById("toast");
async function init() {
	canvas = new ho(document.getElementById("editorCanvas"), {
		selection: true,
		preserveObjectStacking: true,
		enableRetinaScaling: true
	});
	window.canvas = canvas;
	window.__fabricCanvas = canvas;
	const rotateCursor = `url("data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><path fill="%23333" d="M16 4.5a11.5 11.5 0 0 1 8.35 3.65L21.5 11h9V2l-3.22 3.22A15 15 0 0 0 1.07 17h4.02A11.5 11.5 0 0 1 16 4.5zm0 23A11.5 11.5 0 0 1 7.65 23.85L10.5 21h-9v9l3.22-3.22A15 15 0 0 0 30.93 15h-4.02A11.5 11.5 0 0 1 16 27.5z"/></svg>") 16 16, crosshair`;
	try {
		const proto = J.prototype;
		if (proto.controls?.mtr) proto.controls.mtr.cursorStyle = rotateCursor;
	} catch {}
	canvas.on("object:added", (e) => {
		try {
			if (e.target?.controls?.mtr) e.target.controls.mtr.cursorStyle = rotateCursor;
		} catch {}
	});
	setupTools();
	setupDropdownMenus();
	setupTooltipPositioning();
	setupColorPicker();
	setupStrokeControl();
	setupExportButtons();
	await loadShortcuts();
	applyShortcutLabels();
	setupKeyboardShortcuts();
	setupCanvasEvents();
	try {
		const url = (await chrome.runtime.sendMessage({ type: "GET_CAPTURE_BLOB_URL" }))?.url ?? null;
		if (url && url.startsWith("data:image/")) await loadScreenshot(url);
		else showToast("No image available — please capture first");
	} catch {
		showToast("Could not load image from service worker");
	}
	try {
		const metaResp = await chrome.runtime.sendMessage({ type: "GET_LAST_CAPTURE" });
		if (metaResp?.result?.url) capturedPageUrl = metaResp.result.url;
	} catch {}
	saveState();
	maybeShowRateNudge();
}
async function maybeShowRateNudge() {
	if (!await claimPendingRateNudge() || document.getElementById("gf-rate-nudge")) return;
	const nudge = document.createElement("div");
	nudge.id = "gf-rate-nudge";
	nudge.innerHTML = `
    <div class="gf-rn-row">
      <div class="gf-rn-star">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
      </div>
      <div style="flex:1">
        <div class="gf-rn-title">Enjoying GoFully?</div>
        <div class="gf-rn-sub">A quick rating helps others discover the extension.</div>
      </div>
      <button class="gf-rn-close" id="gf-rn-close-btn">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
    <div class="gf-rn-actions">
      <button class="gf-rn-btn gf-rn-btn-primary" id="gf-rn-yes-btn">Yes, rate it</button>
      <button class="gf-rn-btn gf-rn-btn-secondary" id="gf-rn-no-btn">Not now</button>
    </div>
  `;
	document.body.appendChild(nudge);
	requestAnimationFrame(() => nudge.classList.add("show"));
	const dismiss = () => {
		nudge.classList.remove("show");
		setTimeout(() => nudge.remove(), 200);
	};
	document.getElementById("gf-rn-yes-btn").addEventListener("click", () => {
		markRatedYes().catch(() => {});
		dismiss();
	});
	document.getElementById("gf-rn-no-btn").addEventListener("click", () => {
		markDismissed().catch(() => {});
		dismiss();
	});
	document.getElementById("gf-rn-close-btn").addEventListener("click", () => {
		markDismissed().catch(() => {});
		dismiss();
	});
}
function openExportMenu() {
	const exportMenuBtn = document.getElementById("export-menu-btn");
	const exportDropMenu = document.getElementById("export-drop-menu");
	if (!exportDropMenu || !exportMenuBtn) return;
	const r = exportMenuBtn.getBoundingClientRect();
	exportDropMenu.style.right = `${window.innerWidth - r.right}px`;
	exportDropMenu.style.top = `${r.bottom + 6}px`;
	exportDropMenu.classList.add("show");
}
function positionToolDropdown(anchorEl, menu) {
	const r = anchorEl.getBoundingClientRect();
	menu.style.left = `${r.left}px`;
	menu.style.top = `${r.bottom + 6}px`;
}
function setupTooltipPositioning() {
	const shared = document.createElement("div");
	shared.id = "sharedTooltip";
	document.body.appendChild(shared);
	document.querySelectorAll(".tip").forEach((tip) => {
		const anchor = tip.parentElement;
		if (!anchor) return;
		anchor.addEventListener("mouseenter", () => {
			const r = anchor.getBoundingClientRect();
			shared.textContent = tip.textContent;
			shared.style.left = `${r.left + r.width / 2}px`;
			shared.style.top = `${r.bottom + 6}px`;
			shared.classList.add("show");
		});
		anchor.addEventListener("mouseleave", () => {
			shared.classList.remove("show");
		});
	});
}
function setupDropdownMenus() {
	const arrowExpand = document.getElementById("arrow-expand");
	const arrowWrapper = arrowExpand?.closest(".tool-dropdown-wrapper");
	const arrowMenu = document.getElementById("arrow-menu");
	const colorTrigger = document.getElementById("color-trigger");
	const colorGroup = document.getElementById("color-group");
	arrowExpand?.addEventListener("click", (e) => {
		e.stopPropagation();
		blurMenu?.classList.remove("show");
		shapeMenu?.classList.remove("show");
		exportDropMenu?.classList.remove("show");
		colorGroup?.classList.remove("show");
		if (arrowMenu && !arrowMenu.classList.contains("show") && arrowWrapper) positionToolDropdown(arrowWrapper, arrowMenu);
		arrowMenu?.classList.toggle("show");
	});
	const blurExpand = document.getElementById("blur-expand");
	const blurWrapper = blurExpand?.closest(".tool-dropdown-wrapper");
	const blurMenu = document.getElementById("blur-menu");
	blurExpand?.addEventListener("click", (e) => {
		e.stopPropagation();
		arrowMenu?.classList.remove("show");
		shapeMenu?.classList.remove("show");
		exportDropMenu?.classList.remove("show");
		colorGroup?.classList.remove("show");
		if (blurMenu && !blurMenu.classList.contains("show") && blurWrapper) positionToolDropdown(blurWrapper, blurMenu);
		blurMenu?.classList.toggle("show");
	});
	const shapeExpand = document.getElementById("shape-expand");
	const shapeWrapper = shapeExpand?.closest(".tool-dropdown-wrapper");
	const shapeMenu = document.getElementById("shape-menu");
	shapeExpand?.addEventListener("click", (e) => {
		e.stopPropagation();
		arrowMenu?.classList.remove("show");
		blurMenu?.classList.remove("show");
		exportDropMenu?.classList.remove("show");
		colorGroup?.classList.remove("show");
		if (shapeMenu && !shapeMenu.classList.contains("show") && shapeWrapper) positionToolDropdown(shapeWrapper, shapeMenu);
		shapeMenu?.classList.toggle("show");
	});
	const exportMenuBtn = document.getElementById("export-menu-btn");
	const exportDropMenu = document.getElementById("export-drop-menu");
	exportMenuBtn?.addEventListener("click", (e) => {
		e.stopPropagation();
		arrowMenu?.classList.remove("show");
		blurMenu?.classList.remove("show");
		shapeMenu?.classList.remove("show");
		colorGroup?.classList.remove("show");
		if (!exportDropMenu?.classList.contains("show")) openExportMenu();
		else exportDropMenu?.classList.remove("show");
	});
	exportDropMenu?.addEventListener("click", (e) => {
		if (!e.target.closest("#export-settings-panel")) exportDropMenu.classList.remove("show");
	});
	colorTrigger?.addEventListener("click", (e) => {
		e.stopPropagation();
		arrowMenu?.classList.remove("show");
		blurMenu?.classList.remove("show");
		shapeMenu?.classList.remove("show");
		exportDropMenu?.classList.remove("show");
		if (colorGroup && !colorGroup.classList.contains("show")) positionToolDropdown(colorTrigger, colorGroup);
		colorGroup?.classList.toggle("show");
	});
	document.addEventListener("click", () => {
		arrowMenu?.classList.remove("show");
		blurMenu?.classList.remove("show");
		shapeMenu?.classList.remove("show");
		colorGroup?.classList.remove("show");
		document.getElementById("export-drop-menu")?.classList.remove("show");
	});
	document.querySelectorAll("[data-shape-type]").forEach((item) => {
		item.addEventListener("click", (e) => {
			e.stopPropagation();
			document.querySelectorAll("[data-shape-type]").forEach((i) => i.classList.remove("active"));
			item.classList.add("active");
			const shapeType = item.dataset.shapeType;
			currentShapeType = shapeType;
			const mainBtn = document.getElementById("tool-shape");
			if (mainBtn) mainBtn.dataset.tool = shapeType;
			const iconEl = document.getElementById("shape-active-icon");
			if (iconEl && shapeSvgs[shapeType]) iconEl.innerHTML = shapeSvgs[shapeType];
			const tipEl = document.getElementById("shape-active-tip");
			if (tipEl && shapeLabels[shapeType]) tipEl.textContent = `Shape: ${shapeLabels[shapeType]}`;
			shapeMenu?.classList.remove("show");
			setTool(shapeType);
			showToast(`${shapeLabels[shapeType]} selected`);
		});
	});
	document.querySelectorAll("[data-arrow-type]").forEach((item) => {
		item.addEventListener("click", (e) => {
			e.stopPropagation();
			document.querySelectorAll("[data-arrow-type]").forEach((i) => i.classList.remove("active"));
			item.classList.add("active");
			currentArrowType = item.dataset.arrowType;
			arrowMenu?.classList.remove("show");
			setTool("arrow");
			showToast(currentArrowType === "curved" ? "Curved Arrow selected" : "Straight Arrow selected");
		});
	});
	document.querySelectorAll("[data-blur-type]").forEach((item) => {
		item.addEventListener("click", (e) => {
			e.stopPropagation();
			document.querySelectorAll("[data-blur-type]").forEach((i) => i.classList.remove("active"));
			item.classList.add("active");
			currentBlurType = item.dataset.blurType;
			blurMenu?.classList.remove("show");
			setTool("blur");
			showToast(currentBlurType === "pixel" ? "Pixelate mode selected" : currentBlurType === "redact" ? "Redact Blackout selected" : "Glass Blur selected");
		});
	});
}
function applyCleanShotStyle(obj) {
	try {
		obj.set({
			cornerColor: "#FFFFFF",
			cornerStrokeColor: "#1667F2",
			borderColor: "#1667F2",
			cornerStyle: "circle",
			cornerSize: 8,
			transparentCorners: false,
			borderScaleFactor: 1.5,
			padding: 6
		});
	} catch (e) {}
}
async function loadScreenshot(url, resetAnnotations = false) {
	if (!url.startsWith("data:image/")) {
		console.error("loadScreenshot: rejected non-image URL");
		showToast("Invalid image source");
		return;
	}
	try {
		const img = await ws.fromURL(url);
		const nw = img.width, nh = img.height;
		if (!nw || !nh) {
			console.error("Zero-size image");
			return;
		}
		imgNativeW = nw;
		imgNativeH = nh;
		const avW = window.innerWidth - 80;
		const avH = window.innerHeight - 48 - 28 - 80;
		fitScale = Math.max(.05, Math.min(1, avW / nw, avH / nh));
		cssZoom = 1;
		dispW = Math.round(nw * fitScale);
		dispH = Math.round(nh * fitScale);
		canvas.setDimensions({
			width: dispW,
			height: dispH
		});
		img.set({
			left: 0,
			top: 0,
			scaleX: fitScale,
			scaleY: fitScale,
			selectable: false,
			evented: false,
			erasable: false,
			originX: "left",
			originY: "top",
			objectCaching: false
		});
		if (resetAnnotations) canvas.clear();
		else if (backgroundImage) canvas.remove(backgroundImage);
		canvas.add(img);
		canvas.sendObjectToBack(img);
		canvas.renderAll();
		backgroundImage = img;
		dimensionsEl.textContent = `${nw} × ${nh} px`;
		zoomEl.textContent = "100%";
		const hdrZoomVal = document.getElementById("hdr-zoom-val");
		if (hdrZoomVal) hdrZoomVal.textContent = "100%";
		applyContainerZoom(1);
	} catch (e) {
		console.error("Failed to load screenshot:", e);
		showToast("Failed to load image");
	}
}
function applyContainerZoom(z) {
	cssZoom = z;
	canvas.setDimensions({
		width: Math.round(dispW * z),
		height: Math.round(dispH * z)
	});
	canvas.setZoom(z);
	canvas.renderAll();
}
function setupTools() {
	document.querySelectorAll(".tool-btn[data-tool]").forEach((btn) => {
		btn.addEventListener("click", () => setTool(btn.dataset.tool));
	});
}
function setTool(tool) {
	const textFmtGroup = document.getElementById("text-format-group");
	if (textFmtGroup) textFmtGroup.style.display = tool === "text" ? "" : "none";
	if (tool === "crop") {
		if (!backgroundImage) {
			showToast("No image to crop");
			return;
		}
		openCropModal();
		return;
	}
	if (cropperInstance) closeCropModal(false);
	if (isDrawing) {
		if (tempShape) {
			canvas.remove(tempShape);
			tempShape = null;
		}
		isDrawing = false;
	}
	currentTool = tool;
	const isShapeTool = [
		"rectangle",
		"square",
		"circle",
		"ellipse",
		"triangle",
		"polygon"
	].includes(tool);
	document.querySelectorAll(".tool-btn[data-tool]").forEach((btn) => {
		if (btn.id === "tool-shape") btn.classList.toggle("active", isShapeTool);
		else btn.classList.toggle("active", btn.dataset.tool === tool);
	});
	if (isShapeTool) {
		currentShapeType = tool;
		const mainBtn = document.getElementById("tool-shape");
		if (mainBtn) mainBtn.dataset.tool = tool;
		const iconEl = document.getElementById("shape-active-icon");
		if (iconEl && shapeSvgs[currentShapeType]) iconEl.innerHTML = shapeSvgs[currentShapeType];
		const tipEl = document.getElementById("shape-active-tip");
		if (tipEl && shapeLabels[currentShapeType]) tipEl.textContent = `Shape: ${shapeLabels[currentShapeType]}`;
		document.querySelectorAll("[data-shape-type]").forEach((i) => {
			i.classList.toggle("active", i.dataset.shapeType === tool);
		});
	}
	toolNameEl.textContent = {
		select: "Select & Transform",
		arrow: "CleanShot Arrow",
		rectangle: "Rectangle",
		square: "Square",
		circle: "Circle",
		ellipse: "Ellipse",
		triangle: "Triangle",
		polygon: "Polygon (Hexagon)",
		callout: "Callout Speech Bubble",
		line: "Straight Line",
		freedraw: "Pen / Marker",
		text: "Text Annotation",
		spotlight: "CleanShot Spotlight",
		blur: "Blur / Redaction",
		step: "Step Number Counter",
		crop: "Crop & Resize Image",
		highlight: "Highlighter"
	}[tool] || tool;
	const isSelect = tool === "select";
	canvas.getObjects().forEach((obj) => {
		if (obj === backgroundImage) return;
		obj.selectable = isSelect;
		obj.evented = isSelect;
	});
	if (!isSelect) canvas.discardActiveObject();
	canvas.selection = isSelect;
	if (tool === "freedraw") {
		if (!canvas.freeDrawingBrush) canvas.freeDrawingBrush = new No(canvas);
		canvas.freeDrawingBrush.color = currentColor;
		canvas.freeDrawingBrush.width = strokeWidth;
	}
	canvas.isDrawingMode = tool === "freedraw";
	canvas.defaultCursor = tool === "select" ? "default" : tool === "text" ? "text" : "crosshair";
	canvas.renderAll();
}
function finishAndSelect(obj) {
	setTool("select");
	canvas.setActiveObject(obj);
	canvas.renderAll();
}
function setupCanvasEvents() {
	canvas.on("mouse:wheel", (opt) => {
		const evt = opt.e;
		if (evt.ctrlKey || evt.metaKey) {
			evt.preventDefault();
			evt.stopPropagation();
			adjustZoom(evt.deltaY > 0 ? -.08 : .08);
		}
	});
	canvas.on("mouse:down", (e) => {
		if (currentTool === "select" || currentTool === "freedraw") return;
		if (currentTool === "step" && e.target) return;
		const pt = getScenePoint(e);
		drawStartX = pt.x;
		drawStartY = pt.y;
		isDrawing = true;
		if (currentTool === "text") {
			addText(pt.x, pt.y);
			isDrawing = false;
			return;
		}
		if (currentTool === "step") {
			addStepNumber(pt.x, pt.y);
			isDrawing = false;
			return;
		}
		const rawEvt = e?.e;
		const badge = document.getElementById("canvasDrawBadge");
		if (badge && rawEvt && typeof rawEvt.clientX === "number") {
			badge.style.display = "block";
			badge.style.left = `${rawEvt.clientX}px`;
			badge.style.top = `${rawEvt.clientY}px`;
			badge.textContent = "0 × 0 px";
		}
		tempShape = createShape(currentTool, pt.x, pt.y);
		if (tempShape) canvas.add(tempShape);
	});
	canvas.on("mouse:move", (e) => {
		if (!isDrawing || !tempShape) return;
		const pt = getScenePoint(e);
		updateShape(tempShape, currentTool, drawStartX, drawStartY, pt.x, pt.y);
		canvas.requestRenderAll();
		const rawEvt = e?.e;
		const badge = document.getElementById("canvasDrawBadge");
		if (badge && rawEvt && typeof rawEvt.clientX === "number") {
			badge.style.left = `${rawEvt.clientX}px`;
			badge.style.top = `${rawEvt.clientY}px`;
			badge.textContent = `${Math.round(Math.abs(pt.x - drawStartX) * (imgNativeW > 0 && dispW > 0 ? imgNativeW / dispW : 1))} × ${Math.round(Math.abs(pt.y - drawStartY) * (imgNativeH > 0 && dispH > 0 ? imgNativeH / dispH : 1))} px`;
		}
	});
	canvas.on("mouse:up", (e) => {
		const badge = document.getElementById("canvasDrawBadge");
		if (badge) badge.style.display = "none";
		if (!isDrawing) return;
		isDrawing = false;
		if (!tempShape) return;
		const pt = getScenePoint(e);
		updateShape(tempShape, currentTool, drawStartX, drawStartY, pt.x, pt.y);
		const w = Math.abs((tempShape.width || 0) * (tempShape.scaleX || 1));
		const h = Math.abs((tempShape.height || 0) * (tempShape.scaleY || 1));
		if (currentTool === "arrow") {
			finaliseArrow(tempShape);
			tempShape = null;
			return;
		}
		if (currentTool === "callout") {
			finaliseCallout(tempShape);
			tempShape = null;
			return;
		}
		if (currentTool === "spotlight") {
			finaliseSpotlight(tempShape);
			tempShape = null;
			return;
		}
		if (w < 4 && h < 4 && currentTool !== "line") {
			canvas.remove(tempShape);
			tempShape = null;
			return;
		}
		if (currentTool === "blur") {
			const shape = tempShape;
			tempShape = null;
			finaliseBlur(shape);
			return;
		}
		applyCleanShotStyle(tempShape);
		tempShape.setCoords();
		saveState();
		finishAndSelect(tempShape);
		tempShape = null;
	});
	canvas.on("path:created", (e) => {
		if (e.path) applyCleanShotStyle(e.path);
		saveState();
	});
	canvas.on("object:modified", saveState);
}
function createShape(tool, x, y) {
	const sw = Math.max(2, strokeWidth);
	switch (tool) {
		case "rectangle": return new $i({
			left: x,
			top: y,
			width: 0,
			height: 0,
			rx: 10,
			ry: 10,
			fill: "transparent",
			stroke: currentColor,
			strokeWidth: sw,
			strokeUniform: true,
			originX: "left",
			originY: "top",
			selectable: false,
			evented: false
		});
		case "ellipse": return new Uo({
			left: x,
			top: y,
			rx: 0,
			ry: 0,
			fill: "transparent",
			stroke: currentColor,
			strokeWidth: sw,
			strokeUniform: true,
			originX: "left",
			originY: "top",
			selectable: false,
			evented: false
		});
		case "line": return new Bo([
			x,
			y,
			x,
			y
		], {
			stroke: currentColor,
			strokeWidth: sw,
			strokeUniform: true,
			strokeLineCap: "round",
			selectable: false,
			evented: false
		});
		case "arrow": return new Bo([
			x,
			y,
			x,
			y
		], {
			stroke: currentColor,
			strokeWidth: sw,
			strokeUniform: true,
			strokeLineCap: "round",
			selectable: false,
			evented: false
		});
		case "callout": return new $i({
			left: x,
			top: y,
			width: 0,
			height: 0,
			rx: 12,
			ry: 12,
			fill: currentColor,
			stroke: "#FFFFFF",
			strokeWidth: 2,
			strokeUniform: true,
			originX: "left",
			originY: "top",
			selectable: false,
			evented: false
		});
		case "spotlight": return new $i({
			left: x,
			top: y,
			width: 0,
			height: 0,
			rx: 8,
			ry: 8,
			fill: "transparent",
			stroke: "#1667F2",
			strokeWidth: 2,
			strokeDashArray: [6, 4],
			originX: "left",
			originY: "top",
			selectable: false,
			evented: false
		});
		case "highlight": return new $i({
			left: x,
			top: y,
			width: 0,
			height: 0,
			fill: currentColor,
			opacity: .35,
			stroke: "transparent",
			originX: "left",
			originY: "top",
			selectable: false,
			evented: false
		});
		case "blur": return new $i({
			left: x,
			top: y,
			width: 0,
			height: 0,
			rx: 4,
			ry: 4,
			fill: "rgba(100,100,100,0.35)",
			stroke: "rgba(255,255,255,0.7)",
			strokeWidth: 1.5,
			strokeUniform: true,
			strokeDashArray: [5, 4],
			originX: "left",
			originY: "top",
			selectable: false,
			evented: false
		});
		case "square": return new $i({
			left: x,
			top: y,
			width: 0,
			height: 0,
			fill: "transparent",
			stroke: currentColor,
			strokeWidth: sw,
			strokeUniform: true,
			originX: "left",
			originY: "top",
			selectable: false,
			evented: false
		});
		case "circle": return new Fo({
			left: x,
			top: y,
			radius: 0,
			fill: "transparent",
			stroke: currentColor,
			strokeWidth: sw,
			strokeUniform: true,
			originX: "left",
			originY: "top",
			selectable: false,
			evented: false
		});
		case "triangle": return new Vo({
			left: x,
			top: y,
			width: 0,
			height: 0,
			fill: "transparent",
			stroke: currentColor,
			strokeWidth: sw,
			strokeUniform: true,
			originX: "left",
			originY: "top",
			selectable: false,
			evented: false
		});
		case "polygon": return new Ko(Array.from({ length: 6 }, () => ({
			x: 0,
			y: 0
		})), {
			left: x,
			top: y,
			fill: "transparent",
			stroke: currentColor,
			strokeWidth: sw,
			strokeUniform: true,
			originX: "left",
			originY: "top",
			selectable: false,
			evented: false
		});
		default: return null;
	}
}
function updateShape(shape, tool, x1, y1, x2, y2) {
	const left = Math.min(x1, x2);
	const top = Math.min(y1, y2);
	const width = Math.max(1, Math.abs(x2 - x1));
	const height = Math.max(1, Math.abs(y2 - y1));
	switch (tool) {
		case "rectangle":
		case "blur":
		case "crop":
		case "callout":
		case "spotlight":
		case "highlight":
			shape.set({
				originX: "left",
				originY: "top",
				left,
				top,
				width,
				height
			});
			break;
		case "square": {
			const side = Math.max(width, height);
			shape.set({
				originX: "left",
				originY: "top",
				left,
				top,
				width: side,
				height: side
			});
			break;
		}
		case "ellipse":
			shape.set({
				originX: "left",
				originY: "top",
				left,
				top,
				rx: width / 2,
				ry: height / 2
			});
			break;
		case "circle": {
			const r = Math.max(width, height) / 2;
			shape.set({
				originX: "left",
				originY: "top",
				left,
				top,
				radius: r
			});
			break;
		}
		case "triangle":
			shape.set({
				originX: "left",
				originY: "top",
				left,
				top,
				width,
				height
			});
			break;
		case "polygon": {
			const cx = width / 2;
			const cy = height / 2;
			const rx = width / 2;
			const ry = height / 2;
			shape.points = Array.from({ length: 6 }, (_, i) => {
				const angle = Math.PI / 3 * i - Math.PI / 2;
				return {
					x: cx + rx * Math.cos(angle),
					y: cy + ry * Math.sin(angle)
				};
			});
			shape.set({
				originX: "left",
				originY: "top",
				left,
				top
			});
			if (typeof shape.setDimensions === "function") shape.setDimensions();
			break;
		}
		case "line":
		case "arrow": shape.set({
			x1,
			y1,
			x2,
			y2
		});
	}
	shape.setCoords();
}
function finaliseArrow(line) {
	const [x1, y1, x2, y2] = [
		line.get("x1"),
		line.get("y1"),
		line.get("x2"),
		line.get("y2")
	];
	const dx = x2 - x1, dy = y2 - y1;
	if (Math.sqrt(dx * dx + dy * dy) < 6) {
		canvas.remove(line);
		return;
	}
	const sw = Math.max(2, strokeWidth);
	const hs = Math.max(sw * 3.5, 12);
	const angle = Math.atan2(dy, dx);
	const spread = Math.PI / 7;
	if (currentArrowType === "curved") {
		const midX = (x1 + x2) / 2;
		const midY = (y1 + y2) / 2;
		const perpX = -dy * .25;
		const perpY = dx * .25;
		const cpX = midX + perpX;
		const cpY = midY + perpY;
		const headAngle = Math.atan2(y2 - cpY, x2 - cpX);
		const group = new ca([new Mo(`M ${x1} ${y1} Q ${cpX} ${cpY} ${x2} ${y2}`, {
			fill: "transparent",
			stroke: currentColor,
			strokeWidth: sw,
			strokeUniform: true,
			strokeLineCap: "round",
			strokeLineJoin: "round",
			objectCaching: false
		}), new Mo(`M ${x2} ${y2} L ${x2 - hs * Math.cos(headAngle - spread)} ${y2 - hs * Math.sin(headAngle - spread)} Q ${x2 - hs * .7 * Math.cos(headAngle)} ${y2 - hs * .7 * Math.sin(headAngle)} ${x2 - hs * Math.cos(headAngle + spread)} ${y2 - hs * Math.sin(headAngle + spread)} Z`, {
			fill: currentColor,
			stroke: currentColor,
			strokeWidth: 1,
			strokeUniform: true,
			strokeLineJoin: "round",
			objectCaching: false
		})], {
			selectable: false,
			evented: false,
			objectCaching: false
		});
		applyCleanShotStyle(group);
		canvas.remove(line);
		canvas.add(group);
		group.setCoords();
		saveState();
		finishAndSelect(group);
		return;
	}
	const head = new Mo(`M ${x2} ${y2} L ${x2 - hs * Math.cos(angle - spread)} ${y2 - hs * Math.sin(angle - spread)} Q ${x2 - hs * .7 * Math.cos(angle)} ${y2 - hs * .7 * Math.sin(angle)} ${x2 - hs * Math.cos(angle + spread)} ${y2 - hs * Math.sin(angle + spread)} Z`, {
		fill: currentColor,
		stroke: currentColor,
		strokeWidth: 1,
		strokeUniform: true,
		strokeLineJoin: "round",
		objectCaching: false
	});
	const group = new ca([new Bo([
		x1,
		y1,
		x2,
		y2
	], {
		stroke: currentColor,
		strokeWidth: sw,
		strokeUniform: true,
		strokeLineCap: "round",
		objectCaching: false
	}), head], {
		selectable: false,
		evented: false,
		objectCaching: false
	});
	applyCleanShotStyle(group);
	canvas.remove(line);
	canvas.add(group);
	group.setCoords();
	saveState();
	finishAndSelect(group);
}
function finaliseCallout(rect) {
	const l = rect.left ?? 0;
	const t = rect.top ?? 0;
	const w = Math.max(60, (rect.width ?? 0) * (rect.scaleX ?? 1));
	const h = Math.max(36, (rect.height ?? 0) * (rect.scaleY ?? 1));
	canvas.remove(rect);
	const group = new ca([new $i({
		left: 0,
		top: 0,
		width: w,
		height: h,
		rx: 10,
		ry: 10,
		fill: currentColor,
		originX: "left",
		originY: "top"
	}), new ds("Note", {
		left: w / 2,
		top: h / 2,
		fontSize: Math.max(13, Math.min(18, h * .45)),
		fontFamily: "-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif",
		fontWeight: "bold",
		fill: "#FFFFFF",
		originX: "center",
		originY: "center"
	})], {
		left: l,
		top: t,
		selectable: false,
		evented: false
	});
	applyCleanShotStyle(group);
	canvas.add(group);
	group.setCoords();
	saveState();
	finishAndSelect(group);
}
function finaliseSpotlight(rect) {
	const l = Math.max(0, rect.left ?? 0);
	const t = Math.max(0, rect.top ?? 0);
	const w = (rect.width ?? 0) * (rect.scaleX ?? 1);
	const h = (rect.height ?? 0) * (rect.scaleY ?? 1);
	canvas.remove(rect);
	if (w < 10 || h < 10) return;
	const cW = canvas.width || dispW;
	const cH = canvas.height || dispH;
	const group = new ca([new Mo(`M 0 0 L ${cW} 0 L ${cW} ${cH} L 0 ${cH} Z M ${l} ${t} L ${l} ${t + h} L ${l + w} ${t + h} L ${l + w} ${t} Z`, {
		left: 0,
		top: 0,
		fill: "rgba(0, 0, 0, 0.60)",
		fillRule: "evenodd",
		selectable: false,
		evented: false,
		originX: "left",
		originY: "top"
	}), new $i({
		left: l,
		top: t,
		width: w,
		height: h,
		rx: 8,
		ry: 8,
		fill: "transparent",
		stroke: "#FFFFFF",
		strokeWidth: 2,
		selectable: false,
		evented: false,
		originX: "left",
		originY: "top"
	})], {
		left: 0,
		top: 0,
		selectable: false,
		evented: false,
		originX: "left",
		originY: "top"
	});
	applyCleanShotStyle(group);
	canvas.add(group);
	group.setCoords();
	saveState();
	finishAndSelect(group);
}
async function finaliseBlur(placeholder) {
	const l = placeholder.left ?? 0;
	const t = placeholder.top ?? 0;
	const w = (placeholder.width ?? 0) * (placeholder.scaleX ?? 1);
	const h = (placeholder.height ?? 0) * (placeholder.scaleY ?? 1);
	if (!backgroundImage || w < 2 || h < 2) {
		canvas.remove(placeholder);
		return;
	}
	const rx = Math.max(0, Math.round(l));
	const ry = Math.max(0, Math.round(t));
	const rw = Math.max(1, Math.min(Math.round(w), Math.round(dispW) - rx));
	const rh = Math.max(1, Math.min(Math.round(h), Math.round(dispH) - ry));
	if (currentBlurType === "redact") {
		canvas.remove(placeholder);
		const redactBox = new $i({
			left: rx,
			top: ry,
			width: rw,
			height: rh,
			fill: "#000000",
			rx: 3,
			ry: 3,
			selectable: false,
			evented: false,
			originX: "left",
			originY: "top"
		});
		applyCleanShotStyle(redactBox);
		canvas.add(redactBox);
		redactBox.setCoords();
		saveState();
		finishAndSelect(redactBox);
		return;
	}
	try {
		placeholder.visible = false;
		canvas.renderAll();
		const multiplier = 1 / (cssZoom || 1);
		const fullDataUrl = canvas.toDataURL({
			format: "png",
			quality: 1,
			multiplier
		});
		const src = new Image();
		src.src = fullDataUrl;
		await new Promise((r) => {
			src.onload = () => r();
		});
		const region = document.createElement("canvas");
		region.width = rw;
		region.height = rh;
		const ctx = region.getContext("2d");
		ctx.drawImage(src, rx, ry, rw, rh, 0, 0, rw, rh);
		if (currentBlurType === "pixel") {
			const pixelSize = Math.max(8, Math.round(Math.min(rw, rh) / 10));
			const offCanvas = document.createElement("canvas");
			const offW = Math.max(1, Math.floor(rw / pixelSize));
			const offH = Math.max(1, Math.floor(rh / pixelSize));
			offCanvas.width = offW;
			offCanvas.height = offH;
			const offCtx = offCanvas.getContext("2d");
			offCtx.imageSmoothingEnabled = false;
			offCtx.drawImage(region, 0, 0, offW, offH);
			ctx.imageSmoothingEnabled = false;
			ctx.clearRect(0, 0, rw, rh);
			ctx.drawImage(offCanvas, 0, 0, offW, offH, 0, 0, rw, rh);
		} else processCanvasRGBA(region, 0, 0, rw, rh, Math.max(16, Math.round(Math.min(rw, rh) / 4)));
		const img = await ws.fromURL(region.toDataURL("image/png"));
		img.set({
			left: rx,
			top: ry,
			originX: "left",
			originY: "top",
			selectable: false,
			evented: false
		});
		applyCleanShotStyle(img);
		canvas.remove(placeholder);
		canvas.add(img);
		img.setCoords();
		saveState();
		finishAndSelect(img);
	} catch (err) {
		console.error("Blur failed:", err);
		canvas.remove(placeholder);
		canvas.renderAll();
		showToast("Blur failed — try again");
	}
}
function openCropModal() {
	const modal = document.getElementById("cropModal");
	const img = document.getElementById("cropImg");
	const sizeEl = document.getElementById("cropSizeDisplay");
	const posEl = document.getElementById("cropPosDisplay");
	const multiplier = Math.max(1, 1 / fitScale);
	const savedCropZ = cssZoom;
	if (savedCropZ !== 1) applyContainerZoom(1);
	const dataUrl = canvas.toDataURL({
		format: "png",
		quality: 1,
		multiplier
	});
	if (savedCropZ !== 1) applyContainerZoom(savedCropZ);
	document.querySelectorAll(".tool-btn[data-tool]").forEach((b) => b.classList.remove("active"));
	document.querySelector(".tool-btn[data-tool='crop']")?.classList.add("active");
	modal.style.display = "flex";
	sizeEl.textContent = `${imgNativeW} × ${imgNativeH} px`;
	posEl.textContent = "";
	img.onload = () => {
		if (cropperInstance) {
			cropperInstance.destroy();
			cropperInstance = null;
		}
		cropperInstance = new import_cropper.default(img, {
			viewMode: 1,
			dragMode: "crop",
			guides: true,
			center: true,
			highlight: false,
			background: true,
			autoCrop: false,
			movable: false,
			rotatable: false,
			scalable: false,
			zoomable: false,
			zoomOnWheel: false,
			toggleDragModeOnDblclick: false,
			crop(event) {
				const { x, y, width, height } = event.detail;
				if (width > 1 && height > 1) {
					sizeEl.textContent = `${Math.round(width)} × ${Math.round(height)} px`;
					posEl.textContent = `${Math.round(x)}, ${Math.round(y)}`;
				}
			}
		});
		document.querySelectorAll(".ratio-btn").forEach((btn) => {
			btn.onclick = () => {
				document.querySelectorAll(".ratio-btn").forEach((b) => b.classList.remove("active"));
				btn.classList.add("active");
				const r = btn.dataset.ratio;
				cropperInstance?.setAspectRatio(r ? parseFloat(r) : NaN);
			};
		});
	};
	img.src = dataUrl;
}
function closeCropModal(andSelectTool = true) {
	if (cropperInstance) {
		cropperInstance.destroy();
		cropperInstance = null;
	}
	const modal = document.getElementById("cropModal");
	const img = document.getElementById("cropImg");
	modal.style.display = "none";
	img.src = "";
	document.querySelectorAll(".ratio-btn").forEach((b) => b.classList.remove("active"));
	document.querySelector(".ratio-btn[data-ratio=\"\"]")?.classList.add("active");
	if (andSelectTool) setTool("select");
}
function applyCropModal() {
	if (!cropperInstance) return;
	const data = cropperInstance.getData(true);
	if (!data.width || !data.height || data.width < 4 || data.height < 4) {
		document.getElementById("cropSizeDisplay").textContent = "Draw a selection first";
		return;
	}
	const croppedCanvas = cropperInstance.getCroppedCanvas({
		imageSmoothingEnabled: true,
		imageSmoothingQuality: "high"
	});
	if (!croppedCanvas) {
		showToast("Crop failed — try again");
		return;
	}
	const resultDataUrl = croppedCanvas.toDataURL("image/png");
	if (cropperInstance) {
		cropperInstance.destroy();
		cropperInstance = null;
	}
	const modal = document.getElementById("cropModal");
	const img = document.getElementById("cropImg");
	modal.style.display = "none";
	img.src = "";
	loadScreenshot(resultDataUrl, true).then(() => {
		isCropped = true;
		setTool("select");
		saveState();
		showToast("Cropped successfully");
	});
}
function nudgeCropBox(dx, dy) {
	if (!cropperInstance) return;
	const d = cropperInstance.getData();
	cropperInstance.setData({
		x: (d.x ?? 0) + dx,
		y: (d.y ?? 0) + dy
	});
}
function getScenePoint(e) {
	try {
		if (typeof canvas?.getScenePoint === "function" && (e?.e || e)) {
			const p = canvas.getScenePoint(e?.e || e);
			if (p && typeof p.x === "number" && !isNaN(p.x)) return {
				x: Math.max(0, Math.min(dispW || p.x, p.x)),
				y: Math.max(0, Math.min(dispH || p.y, p.y))
			};
		}
	} catch {}
	if (e?.scenePoint && typeof e.scenePoint.x === "number" && !isNaN(e.scenePoint.x)) return {
		x: Math.max(0, Math.min(dispW || e.scenePoint.x, e.scenePoint.x)),
		y: Math.max(0, Math.min(dispH || e.scenePoint.y, e.scenePoint.y))
	};
	const raw = e?.e || e;
	const upperCanvas = canvas?.upperCanvasEl || canvas?.getElement?.();
	if (raw && typeof raw.clientX === "number" && upperCanvas) {
		const rect = upperCanvas.getBoundingClientRect();
		if (rect.width > 0 && rect.height > 0) {
			const targetW = dispW || 1;
			const targetH = dispH || 1;
			const normX = (raw.clientX - rect.left) / rect.width;
			const normY = (raw.clientY - rect.top) / rect.height;
			return {
				x: Math.max(0, Math.min(targetW, normX * targetW)),
				y: Math.max(0, Math.min(targetH, normY * targetH))
			};
		}
	}
	return {
		x: 0,
		y: 0
	};
}
function addText(x, y) {
	const text = new ds("Redact confidential info", {
		left: x,
		top: y,
		fontSize: 26,
		fontFamily: "'Caveat', cursive, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
		fill: currentColor,
		fontWeight: "700",
		editable: true
	});
	applyCleanShotStyle(text);
	canvas.add(text);
	canvas.setActiveObject(text);
	text.enterEditing();
	text.selectAll();
	saveState();
}
function addStepNumber(x, y) {
	const r = 15;
	const group = new ca([new Fo({
		radius: r,
		fill: currentColor,
		originX: "center",
		originY: "center"
	}), new Q(String(stepCounter), {
		fontSize: 15,
		fontFamily: "-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif",
		fill: "#FFFFFF",
		fontWeight: "bold",
		originX: "center",
		originY: "center"
	})], {
		left: x - r,
		top: y - r,
		selectable: true,
		evented: true
	});
	applyCleanShotStyle(group);
	canvas.add(group);
	canvas.setActiveObject(group);
	stepCounter++;
	saveState();
}
function applyCurrentColor() {
	if (canvas.freeDrawingBrush) canvas.freeDrawingBrush.color = currentColor;
	const active = canvas.getActiveObject();
	if (active) {
		if (active.type === "i-text" || active.type === "text") active.set("fill", currentColor);
		else if (active.type === "group") active.getObjects().forEach((o) => {
			if (o.type === "circle" || o.type === "rect" || o.type === "path") o.set("fill", currentColor);
			if (o.type === "line") o.set("stroke", currentColor);
		});
		else {
			if (active.fill && active.fill !== "transparent") active.set("fill", currentColor);
			active.set("stroke", currentColor);
		}
		canvas.renderAll();
		saveState();
	}
}
function setupColorPicker() {
	const colorTrigger = document.getElementById("color-trigger");
	const syncColorTrigger = () => {
		if (colorTrigger) colorTrigger.style.background = currentColor;
	};
	syncColorTrigger();
	document.querySelectorAll(".color-swatch:not(.color-swatch-custom)").forEach((swatch) => {
		swatch.addEventListener("click", () => {
			document.querySelectorAll(".color-swatch").forEach((s) => s.classList.remove("active"));
			swatch.classList.add("active");
			currentColor = swatch.dataset.color;
			applyCurrentColor();
			syncColorTrigger();
		});
	});
	const customSwatch = document.getElementById("customColorSwatch");
	const customInput = document.getElementById("customColorInput");
	if (!customSwatch || !customInput) return;
	customInput.addEventListener("input", () => {
		currentColor = customInput.value;
		customSwatch.style.background = currentColor;
		document.querySelectorAll(".color-swatch").forEach((s) => s.classList.remove("active"));
		customSwatch.classList.add("active");
		applyCurrentColor();
		syncColorTrigger();
	});
}
function setupStrokeControl() {
	const slider = document.getElementById("strokeWidth");
	slider.addEventListener("input", () => {
		strokeWidth = parseInt(slider.value);
		if (canvas.freeDrawingBrush) canvas.freeDrawingBrush.width = strokeWidth;
		const active = canvas.getActiveObject();
		if (active && active.type !== "i-text") {
			if (active.type === "group") active.getObjects().forEach((o) => {
				if (o.type !== "i-text") o.set("strokeWidth", strokeWidth);
			});
			else active.set("strokeWidth", strokeWidth);
			canvas.renderAll();
			saveState();
		}
	});
}
function getAnnotToggle() {
	return document.getElementById("annot-toggle-check")?.checked ?? true;
}
function getResizeDims() {
	const wEl = document.getElementById("export-w");
	const hEl = document.getElementById("export-h");
	const w = parseInt(wEl?.value ?? "");
	const h = parseInt(hEl?.value ?? "");
	if (w > 0 && h > 0) return {
		w,
		h
	};
	return null;
}
async function exportToBlob() {
	const clean = !getAnnotToggle();
	const annotations = canvas.getObjects().filter((o) => o !== backgroundImage);
	const hasAnnotations = annotations.length > 0;
	const dims = getResizeDims() ?? getExportTargetSize();
	if (!(isBeautified || isCropped) && (clean || !hasAnnotations)) try {
		const dataUrl = (await chrome.runtime.sendMessage({ type: "GET_CAPTURE_BLOB_URL" }))?.url ?? null;
		if (dataUrl) {
			let blob = await dataUrlToBlob(dataUrl);
			if (dims) {
				const bitmap = await createImageBitmap(blob);
				const oc = new OffscreenCanvas(dims.w, dims.h);
				const ctx = oc.getContext("2d");
				ctx.imageSmoothingEnabled = true;
				ctx.imageSmoothingQuality = "high";
				ctx.drawImage(bitmap, 0, 0, dims.w, dims.h);
				blob = await oc.convertToBlob({ type: "image/png" });
			}
			return blob;
		}
	} catch (e) {
		console.warn("Direct capture blob bypass failed, falling back to Fabric:", e);
	}
	const savedZoom = cssZoom;
	const multiplier = getExportMultiplier();
	try {
		if (savedZoom !== 1) applyContainerZoom(1);
		if (clean && hasAnnotations) {
			annotations.forEach((o) => o.set("visible", false));
			canvas.renderAll();
		}
		let blob = await dataUrlToBlob(canvas.toDataURL({
			format: "png",
			quality: 1,
			multiplier,
			imageSmoothingEnabled: true,
			imageSmoothingQuality: "high"
		}));
		if (dims) {
			const bitmap = await createImageBitmap(blob);
			const oc = new OffscreenCanvas(dims.w, dims.h);
			const ctx = oc.getContext("2d");
			ctx.imageSmoothingEnabled = true;
			ctx.imageSmoothingQuality = "high";
			ctx.drawImage(bitmap, 0, 0, dims.w, dims.h);
			blob = await oc.convertToBlob({ type: "image/png" });
		}
		return blob;
	} finally {
		if (clean && hasAnnotations) annotations.forEach((o) => o.set("visible", true));
		if (savedZoom !== 1) applyContainerZoom(savedZoom);
		else canvas.renderAll();
	}
}
function setupExportButtons() {
	document.getElementById("export-settings-panel")?.addEventListener("click", (e) => e.stopPropagation());
	let aspectLocked = true;
	const lockBtn = document.getElementById("resize-lock-btn");
	const wInput = document.getElementById("export-w");
	const hInput = document.getElementById("export-h");
	lockBtn?.addEventListener("click", (e) => {
		e.stopPropagation();
		aspectLocked = !aspectLocked;
		lockBtn.classList.toggle("locked", aspectLocked);
		lockBtn.setAttribute("aria-pressed", String(aspectLocked));
		lockBtn.innerHTML = "<svg viewBox=\"0 0 24 24\" width=\"13\" height=\"13\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><rect x=\"4\" y=\"11\" width=\"16\" height=\"10\" rx=\"2\"/>" + (aspectLocked ? `<path d="M8 11V7a4 4 0 0 1 8 0v4"/>` : `<path d="M8 11V7a4 4 0 0 1 7.5-2"/>`) + `</svg><span class="tip">${aspectLocked ? "Aspect ratio locked" : "Aspect ratio unlocked"}</span>`;
	});
	wInput?.addEventListener("input", () => {
		if (!aspectLocked || !imgNativeW || !imgNativeH) return;
		const w = parseInt(wInput.value);
		if (w > 0) hInput.value = String(Math.round(w * imgNativeH / imgNativeW));
	});
	hInput?.addEventListener("input", () => {
		if (!aspectLocked || !imgNativeW || !imgNativeH) return;
		const h = parseInt(hInput.value);
		if (h > 0) wInput.value = String(Math.round(h * imgNativeW / imgNativeH));
	});
	function getExportFilename(ext) {
		const custom = document.getElementById("export-filename")?.value.trim();
		if (custom) {
			const clean = custom.replace(/[^a-zA-Z0-9._ -]/g, "").trim().replace(/\.+$/, "");
			if (clean) return `${clean}.${ext}`;
		}
		return `gofully-${Date.now()}.${ext}`;
	}
	document.getElementById("copy-btn").addEventListener("click", async () => {
		try {
			const blob = await exportToBlob();
			await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
			showToast("Copied to clipboard");
		} catch {
			showToast("Copy failed — try Save PNG instead");
		}
	});
	document.getElementById("save-btn").addEventListener("click", async () => {
		const blob = await exportToBlob();
		const url = URL.createObjectURL(blob);
		Object.assign(document.createElement("a"), {
			href: url,
			download: getExportFilename("png")
		}).click();
		setTimeout(() => URL.revokeObjectURL(url), 5e3);
		editorDirty = false;
		showToast("PNG saved");
	});
	document.getElementById("pdf-btn").addEventListener("click", async () => {
		try {
			const blob = await exportToBlob();
			const pdfBlob = await generatePDF(blob, "a4");
			const url = URL.createObjectURL(pdfBlob);
			Object.assign(document.createElement("a"), {
				href: url,
				download: getExportFilename("pdf")
			}).click();
			setTimeout(() => URL.revokeObjectURL(url), 5e3);
			editorDirty = false;
			showToast("PDF saved");
		} catch {
			showToast("PDF failed");
		}
	});
	document.getElementById("copy-selected-btn")?.addEventListener("click", async () => {
		const active = canvas.getActiveObject();
		if (!active) {
			showToast("Select an object first");
			return;
		}
		try {
			const tmpCanvas = document.createElement("canvas");
			const bounds = active.getBoundingRect();
			tmpCanvas.width = Math.ceil(bounds.width);
			tmpCanvas.height = Math.ceil(bounds.height);
			const ctx = tmpCanvas.getContext("2d");
			ctx.translate(-bounds.left, -bounds.top);
			active.render(ctx);
			tmpCanvas.toBlob(async (blob) => {
				if (!blob) return;
				await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
				showToast("Object copied");
			}, "image/png");
		} catch {
			showToast("Copy failed");
		}
	});
	const imageQualitySelect = document.getElementById("export-image-quality");
	const getExportQuality = () => (imageQualitySelect ? parseInt(imageQualitySelect.value) : 92) / 100;
	document.getElementById("save-webp-btn")?.addEventListener("click", async () => {
		const pngBlob = await exportToBlob();
		const bitmap = await createImageBitmap(pngBlob);
		const dims = getResizeDims();
		const ow = dims?.w ?? bitmap.width;
		const oh = dims?.h ?? bitmap.height;
		const oc = new OffscreenCanvas(ow, oh);
		oc.getContext("2d").drawImage(bitmap, 0, 0, ow, oh);
		const quality = getExportQuality();
		const webpBlob = await oc.convertToBlob({
			type: "image/webp",
			quality
		});
		const url = URL.createObjectURL(webpBlob);
		Object.assign(document.createElement("a"), {
			href: url,
			download: getExportFilename("webp")
		}).click();
		setTimeout(() => URL.revokeObjectURL(url), 5e3);
		editorDirty = false;
		showToast(`WebP saved (${Math.round(quality * 100)}%)`);
	});
	document.getElementById("save-jpg-btn")?.addEventListener("click", async () => {
		const pngBlob = await exportToBlob();
		const bitmap = await createImageBitmap(pngBlob);
		const dims = getResizeDims();
		const ow = dims?.w ?? bitmap.width;
		const oh = dims?.h ?? bitmap.height;
		const oc = new OffscreenCanvas(ow, oh);
		oc.getContext("2d").drawImage(bitmap, 0, 0, ow, oh);
		const quality = getExportQuality();
		const jpgBlob = await oc.convertToBlob({
			type: "image/jpeg",
			quality
		});
		const url = URL.createObjectURL(jpgBlob);
		Object.assign(document.createElement("a"), {
			href: url,
			download: getExportFilename("jpg")
		}).click();
		setTimeout(() => URL.revokeObjectURL(url), 5e3);
		editorDirty = false;
		showToast(`JPG saved (${Math.round(quality * 100)}%)`);
	});
	document.getElementById("undo-btn").addEventListener("click", undo);
	document.getElementById("redo-btn").addEventListener("click", redo);
	document.getElementById("delete-btn").addEventListener("click", deleteSelected);
	document.getElementById("duplicate-btn")?.addEventListener("click", duplicateSelected);
	document.getElementById("lock-btn")?.addEventListener("click", toggleLockSelected);
	document.getElementById("zoom-in-btn")?.addEventListener("click", () => adjustZoom(.1));
	document.getElementById("zoom-out-btn")?.addEventListener("click", () => adjustZoom(-.1));
	document.getElementById("hdr-zoom-in-btn")?.addEventListener("click", () => adjustZoom(.1));
	document.getElementById("hdr-zoom-out-btn")?.addEventListener("click", () => adjustZoom(-.1));
	document.getElementById("hdr-zoom-val")?.addEventListener("click", () => {
		if (!backgroundImage) return;
		cssZoom = 1;
		applyContainerZoom(1);
		const zStr = "100%";
		zoomEl.textContent = zStr;
		const hdrZoomVal = document.getElementById("hdr-zoom-val");
		if (hdrZoomVal) hdrZoomVal.textContent = zStr;
	});
	document.getElementById("done-btn")?.addEventListener("click", (e) => {
		e.stopPropagation();
		if (beautifyActive) {
			document.getElementById("beautifyPanel")?.classList.remove("open");
			document.getElementById("tool-beautify")?.classList.remove("active");
			beautifyActive = false;
		}
		if (cropperInstance) closeCropModal(false);
		setTool("select");
		openExportMenu();
	});
	document.getElementById("cropApplyBtn")?.addEventListener("click", applyCropModal);
	document.getElementById("cropCancelBtn")?.addEventListener("click", () => closeCropModal(true));
	setupTextFormatting();
	setupRotateControls();
}
function getExportTargetSize() {
	const quality = document.getElementById("exportQuality")?.value ?? "native";
	if (!imgNativeW || !imgNativeH) return null;
	const target = {
		hd: [1920, 1080],
		"4k": [3840, 2160]
	}[quality];
	if (!target) return null;
	const [targetW, targetH] = target;
	if (imgNativeW >= targetW || imgNativeH >= targetH) return null;
	const scale = Math.max(targetW / imgNativeW, targetH / imgNativeH);
	return {
		w: Math.round(imgNativeW * scale),
		h: Math.round(imgNativeH * scale)
	};
}
function getExportMultiplier() {
	const nativeM = imgNativeW > 0 ? imgNativeW / dispW : Math.max(1, 1 / fitScale);
	const target = getExportTargetSize();
	if (!target) return nativeM;
	return Math.max(nativeM, target.w / dispW, target.h / dispH);
}
function setupTextFormatting() {
	const group = document.getElementById("text-format-group");
	const boldBtn = document.getElementById("text-bold-btn");
	const italicBtn = document.getElementById("text-italic-btn");
	const sizeSlider = document.getElementById("fontSize");
	const sizeVal = document.getElementById("fontSizeVal");
	const fontSelect = document.getElementById("fontFamily");
	if (!group || !boldBtn || !italicBtn || !sizeSlider) return;
	canvas.on("selection:created", updateTextFormatUI);
	canvas.on("selection:updated", updateTextFormatUI);
	canvas.on("selection:cleared", () => {
		if (group) group.style.display = "none";
	});
	function updateTextFormatUI() {
		const obj = canvas.getActiveObject();
		if (!obj || obj.type !== "i-text" && obj.type !== "text") {
			group.style.display = "none";
			return;
		}
		group.style.display = "";
		boldBtn.classList.toggle("active", obj.fontWeight === "bold");
		italicBtn.classList.toggle("active", obj.fontStyle === "italic");
		sizeSlider.value = String(Math.round(obj.fontSize ?? 24));
		if (sizeVal) sizeVal.textContent = sizeSlider.value;
		if (fontSelect && obj.fontFamily) fontSelect.value = obj.fontFamily;
	}
	boldBtn.addEventListener("click", () => {
		const obj = canvas.getActiveObject();
		if (!obj) return;
		obj.set("fontWeight", obj.fontWeight === "bold" ? "normal" : "bold");
		boldBtn.classList.toggle("active", obj.fontWeight === "bold");
		canvas.renderAll();
		saveState();
	});
	italicBtn.addEventListener("click", () => {
		const obj = canvas.getActiveObject();
		if (!obj) return;
		obj.set("fontStyle", obj.fontStyle === "italic" ? "normal" : "italic");
		italicBtn.classList.toggle("active", obj.fontStyle === "italic");
		canvas.renderAll();
		saveState();
	});
	sizeSlider.addEventListener("input", () => {
		const val = parseInt(sizeSlider.value);
		if (sizeVal) sizeVal.textContent = String(val);
		const obj = canvas.getActiveObject();
		if (!obj) return;
		obj.set("fontSize", val);
		canvas.renderAll();
		saveState();
	});
	fontSelect?.addEventListener("change", () => {
		const obj = canvas.getActiveObject();
		if (!obj) return;
		obj.set("fontFamily", fontSelect.value);
		canvas.renderAll();
		saveState();
	});
}
function setupRotateControls() {
	const group = document.getElementById("rotate-group");
	const leftBtn = document.getElementById("rotate-left-btn");
	const rightBtn = document.getElementById("rotate-right-btn");
	if (!group || !leftBtn || !rightBtn) return;
	function showHide() {
		const obj = canvas.getActiveObject();
		if (group) group.style.display = obj ? "flex" : "none";
		updateLockButtonUI();
	}
	canvas.on("selection:created", showHide);
	canvas.on("selection:updated", showHide);
	canvas.on("selection:cleared", () => {
		if (group) group.style.display = "none";
	});
	leftBtn.addEventListener("click", () => {
		const obj = canvas.getActiveObject();
		if (!obj) return;
		obj.rotate(((obj.angle ?? 0) - 90 + 360) % 360);
		canvas.requestRenderAll();
		saveState();
	});
	rightBtn.addEventListener("click", () => {
		const obj = canvas.getActiveObject();
		if (!obj) return;
		obj.rotate(((obj.angle ?? 0) + 90) % 360);
		canvas.requestRenderAll();
		saveState();
	});
}
function adjustZoom(delta) {
	if (!backgroundImage) return;
	cssZoom = Math.min(10, Math.max(.1, Math.round((cssZoom + delta) * 100) / 100));
	applyContainerZoom(cssZoom);
	const zStr = `${Math.round(cssZoom * 100)}%`;
	zoomEl.textContent = zStr;
	const hdrZoomVal = document.getElementById("hdr-zoom-val");
	if (hdrZoomVal) hdrZoomVal.textContent = zStr;
}
var editorDirty = false;
function saveState() {
	undoStack.push(JSON.stringify(canvas.toJSON()));
	redoStack = [];
	if (undoStack.length > 50) undoStack.shift();
	editorDirty = true;
}
window.addEventListener("beforeunload", (e) => {
	if (!editorDirty) return;
	e.preventDefault();
});
function findBackgroundImage() {
	const objs = canvas.getObjects();
	if (objs.length > 0 && objs[0] instanceof ws) return objs[0];
	return null;
}
function restoreObjectInteractivity() {
	const isSelect = currentTool === "select";
	canvas.getObjects().forEach((obj) => {
		obj.selectable = obj === backgroundImage ? false : isSelect;
		obj.evented = obj === backgroundImage ? false : isSelect;
		if (obj !== backgroundImage) applyCleanShotStyle(obj);
	});
}
function undo() {
	if (undoStack.length <= 1) return;
	redoStack.push(undoStack.pop());
	canvas.loadFromJSON(undoStack[undoStack.length - 1]).then(() => {
		backgroundImage = findBackgroundImage();
		if (backgroundImage) backgroundImage.set({
			selectable: false,
			evented: false
		});
		restoreObjectInteractivity();
		canvas.renderAll();
	});
}
function redo() {
	if (!redoStack.length) return;
	const next = redoStack.pop();
	undoStack.push(next);
	canvas.loadFromJSON(next).then(() => {
		backgroundImage = findBackgroundImage();
		if (backgroundImage) backgroundImage.set({
			selectable: false,
			evented: false
		});
		restoreObjectInteractivity();
		canvas.renderAll();
	});
}
function deleteSelected() {
	canvas.getActiveObjects().forEach((o) => {
		if (o !== backgroundImage) canvas.remove(o);
	});
	canvas.discardActiveObject();
	canvas.renderAll();
	saveState();
}
async function duplicateSelected() {
	const active = canvas.getActiveObjects().filter((o) => o !== backgroundImage);
	if (!active.length) return;
	const clones = await Promise.all(active.map((o) => o.clone()));
	clones.forEach((clone, i) => {
		clone.set({
			left: (active[i].left ?? 0) + 16,
			top: (active[i].top ?? 0) + 16
		});
		canvas.add(clone);
	});
	canvas.discardActiveObject();
	if (clones.length === 1) canvas.setActiveObject(clones[0]);
	else {
		const selection = new gs(clones, { canvas });
		canvas.setActiveObject(selection);
	}
	canvas.renderAll();
	saveState();
}
function toggleLockSelected() {
	const active = canvas.getActiveObject();
	if (!active || active === backgroundImage) return;
	const nowLocked = !active.lockMovementX;
	active.set({
		lockMovementX: nowLocked,
		lockMovementY: nowLocked,
		lockScalingX: nowLocked,
		lockScalingY: nowLocked,
		lockRotation: nowLocked,
		hasControls: !nowLocked
	});
	canvas.renderAll();
	saveState();
	updateLockButtonUI();
}
function updateLockButtonUI() {
	const btn = document.getElementById("lock-btn");
	if (!btn) return;
	const locked = !!canvas.getActiveObject()?.lockMovementX;
	btn.classList.toggle("active", locked);
	const tip = btn.querySelector(".tip");
	if (tip) tip.textContent = locked ? "Unlock" : "Lock in place";
}
function setupKeyboardShortcuts() {
	document.addEventListener("keydown", (e) => {
		if (e.target.tagName === "TEXTAREA") return;
		const activeObj = canvas.getActiveObject();
		if (activeObj?.type === "i-text" && activeObj.isEditing) return;
		if (e.key === "Enter" && cropperInstance) {
			e.preventDefault();
			applyCropModal();
			return;
		}
		if (e.key === "Escape") {
			e.preventDefault();
			if (cropperInstance) closeCropModal(true);
			return;
		}
		if (cropperInstance) {
			const step = e.shiftKey ? 10 : 1;
			if (e.key === "ArrowLeft") {
				e.preventDefault();
				nudgeCropBox(-step, 0);
				return;
			}
			if (e.key === "ArrowRight") {
				e.preventDefault();
				nudgeCropBox(step, 0);
				return;
			}
			if (e.key === "ArrowUp") {
				e.preventDefault();
				nudgeCropBox(0, -step);
				return;
			}
			if (e.key === "ArrowDown") {
				e.preventDefault();
				nudgeCropBox(0, step);
				return;
			}
		}
		if ((e.metaKey || e.ctrlKey) && e.key === "z") {
			e.preventDefault();
			e.shiftKey ? redo() : undo();
			return;
		}
		if ((e.metaKey || e.ctrlKey) && e.key === "y") {
			e.preventDefault();
			redo();
			return;
		}
		if ((e.key === "Delete" || e.key === "Backspace") && activeObj) {
			e.preventDefault();
			deleteSelected();
			return;
		}
		if ((e.metaKey || e.ctrlKey) && e.key === "=") {
			e.preventDefault();
			adjustZoom(.1);
			return;
		}
		if ((e.metaKey || e.ctrlKey) && e.key === "-") {
			e.preventDefault();
			adjustZoom(-.1);
			return;
		}
		if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "d" && activeObj) {
			e.preventDefault();
			duplicateSelected();
			return;
		}
		if (!e.metaKey && !e.ctrlKey && !e.shiftKey) {
			const tool = keyToTool[e.key.toLowerCase()];
			if (tool) setTool(tool);
		}
	});
}
function showToast(message) {
	toast.textContent = message;
	toast.classList.add("show");
	setTimeout(() => toast.classList.remove("show"), 3e3);
}
function dataUrlToBlob(dataUrl) {
	const [header, b64] = dataUrl.split(",");
	const mime = header.match(/:(.*?);/)?.[1] ?? "image/png";
	const bytes = atob(b64);
	const arr = new Uint8Array(bytes.length);
	for (let i = 0; i < bytes.length; i++) arr[i] = bytes.charCodeAt(i);
	return new Blob([arr], { type: mime });
}
var beautifyActive = false;
var originalScreenshotUrl = null;
var collageImages = [];
var collageLayout = "row";
function setupBeautifier() {
	const panel = document.getElementById("beautifyPanel");
	const btn = document.getElementById("tool-beautify");
	if (!panel || !btn) return;
	btn.addEventListener("click", (e) => {
		e.stopPropagation();
		beautifyActive = !beautifyActive;
		panel.classList.toggle("open", beautifyActive);
		btn.classList.toggle("active", beautifyActive);
		if (beautifyActive) {
			toolNameEl.textContent = "Screenshot Beautifier";
			if (!originalScreenshotUrl && backgroundImage) {
				const multiplier = imgNativeW > 0 ? imgNativeW / dispW : Math.max(1, 1 / fitScale);
				const savedZ = cssZoom;
				if (savedZ !== 1) applyContainerZoom(1);
				originalScreenshotUrl = canvas.toDataURL({
					format: "png",
					quality: 1,
					multiplier
				});
				if (savedZ !== 1) applyContainerZoom(savedZ);
			}
		}
	});
	panel.querySelectorAll(".bf-bg-swatch").forEach((sw) => {
		sw.addEventListener("click", () => {
			panel.querySelectorAll(".bf-bg-swatch").forEach((s) => s.classList.remove("active"));
			sw.classList.add("active");
			applyBeautify(false);
		});
	});
	panel.querySelectorAll(".bf-frame-btn").forEach((b) => {
		b.addEventListener("click", () => {
			panel.querySelectorAll(".bf-frame-btn").forEach((x) => x.classList.remove("active"));
			b.classList.add("active");
			applyBeautify(false);
		});
	});
	panel.querySelectorAll(".bf-ratio-btn").forEach((b) => {
		b.addEventListener("click", () => {
			panel.querySelectorAll(".bf-ratio-btn").forEach((x) => x.classList.remove("active"));
			b.classList.add("active");
			applyBeautify(false);
		});
	});
	let beautifySliderDebounce = null;
	for (const [id, valId, suffix] of [
		[
			"bf-padding",
			"bf-padding-val",
			"px"
		],
		[
			"bf-radius",
			"bf-radius-val",
			"px"
		],
		[
			"bf-shadow",
			"bf-shadow-val",
			"px"
		],
		[
			"bf-shadow-opacity",
			"bf-shadow-opacity-val",
			"%"
		],
		[
			"bf-noise",
			"bf-noise-val",
			"%"
		]
	]) {
		const sl = document.getElementById(id);
		const vl = document.getElementById(valId);
		if (sl && vl) sl.addEventListener("input", () => {
			vl.textContent = sl.value + suffix;
			if (originalScreenshotUrl) {
				clearTimeout(beautifySliderDebounce);
				beautifySliderDebounce = setTimeout(() => {
					applyBeautify(false);
				}, 150);
			}
		});
	}
	document.getElementById("bf-apply-btn")?.addEventListener("click", () => applyBeautify(true));
	document.getElementById("bf-reset-btn")?.addEventListener("click", resetBeautify);
}
function loadImageElement(src) {
	const img = new Image();
	img.src = src;
	return new Promise((resolve) => {
		img.onload = () => resolve(img);
	});
}
async function buildCollageComposite(mainImg, extraDataUrls, layout, radius) {
	const allImgs = [mainImg, ...await Promise.all(extraDataUrls.map(loadImageElement))];
	const gap = Math.round(Math.max(mainImg.naturalWidth, mainImg.naturalHeight) * .025) || 16;
	let tileSizes;
	let totalW, totalH;
	if (layout === "row") {
		const targetH = mainImg.naturalHeight;
		tileSizes = allImgs.map((img) => {
			const scale = targetH / img.naturalHeight;
			return {
				w: Math.round(img.naturalWidth * scale),
				h: targetH
			};
		});
		totalW = tileSizes.reduce((sum, t) => sum + t.w, 0) + gap * (allImgs.length - 1);
		totalH = targetH;
	} else {
		const targetW = mainImg.naturalWidth;
		tileSizes = allImgs.map((img) => {
			const scale = targetW / img.naturalWidth;
			return {
				w: targetW,
				h: Math.round(img.naturalHeight * scale)
			};
		});
		totalW = targetW;
		totalH = tileSizes.reduce((sum, t) => sum + t.h, 0) + gap * (allImgs.length - 1);
	}
	const canvas = document.createElement("canvas");
	canvas.width = totalW;
	canvas.height = totalH;
	const ctx = canvas.getContext("2d");
	let cursor = 0;
	allImgs.forEach((img, i) => {
		const { w, h } = tileSizes[i];
		const x = layout === "row" ? cursor : 0;
		const y = layout === "row" ? 0 : cursor;
		ctx.save();
		if (radius > 0) {
			roundedRect(ctx, x, y, w, h, Math.min(radius, Math.min(w, h) / 2));
			ctx.clip();
		}
		ctx.drawImage(img, x, y, w, h);
		ctx.restore();
		cursor += (layout === "row" ? w : h) + gap;
	});
	return {
		canvas,
		w: totalW,
		h: totalH
	};
}
function renderCollageThumbs() {
	const container = document.getElementById("bf-collage-thumbs");
	const layoutRow = document.getElementById("bf-collage-layout-row");
	if (!container) return;
	container.innerHTML = "";
	collageImages.forEach((dataUrl, i) => {
		const thumb = document.createElement("div");
		thumb.className = "bf-collage-thumb";
		const img = document.createElement("img");
		img.src = dataUrl;
		const removeBtn = document.createElement("button");
		removeBtn.className = "bf-collage-thumb-remove";
		removeBtn.textContent = "×";
		removeBtn.addEventListener("click", () => {
			collageImages.splice(i, 1);
			renderCollageThumbs();
			if (originalScreenshotUrl) applyBeautify(false);
		});
		thumb.appendChild(img);
		thumb.appendChild(removeBtn);
		container.appendChild(thumb);
	});
	if (layoutRow) layoutRow.style.display = collageImages.length > 0 ? "flex" : "none";
}
function setupCollage() {
	const addBtn = document.getElementById("bf-collage-add-btn");
	const fileInput = document.getElementById("bf-collage-file-input");
	if (!addBtn || !fileInput) return;
	addBtn.addEventListener("click", () => fileInput.click());
	fileInput.addEventListener("change", async () => {
		const files = Array.from(fileInput.files || []);
		fileInput.value = "";
		if (!files.length || collageImages.length >= 2) return;
		const room = 2 - collageImages.length;
		const toRead = files.slice(0, room);
		const dataUrls = await Promise.all(toRead.map((file) => new Promise((resolve) => {
			const reader = new FileReader();
			reader.onload = () => resolve(reader.result);
			reader.readAsDataURL(file);
		})));
		collageImages.push(...dataUrls);
		renderCollageThumbs();
		if (originalScreenshotUrl) applyBeautify(false);
	});
	document.querySelectorAll(".bf-collage-layout-btn").forEach((b) => {
		b.addEventListener("click", () => {
			document.querySelectorAll(".bf-collage-layout-btn").forEach((x) => x.classList.remove("active"));
			b.classList.add("active");
			collageLayout = b.dataset.collageLayout;
			if (originalScreenshotUrl) applyBeautify(false);
		});
	});
}
function readCurrentBeautifySettings() {
	return {
		bg: document.querySelector(".bf-bg-swatch.active")?.dataset.bg || "none",
		padding: parseInt(document.getElementById("bf-padding").value) || 0,
		radius: parseInt(document.getElementById("bf-radius").value) || 0,
		shadow: parseInt(document.getElementById("bf-shadow").value) || 0,
		shadowOpacity: parseInt(document.getElementById("bf-shadow-opacity").value) || 0,
		noise: parseInt(document.getElementById("bf-noise").value) || 0,
		frame: document.querySelector(".bf-frame-btn.active")?.dataset.frame || "none"
	};
}
function applyBeautifyPreset(p) {
	const panel = document.getElementById("beautifyPanel");
	if (!panel) return;
	const swatch = panel.querySelector(`.bf-bg-swatch[data-bg="${CSS.escape(p.bg)}"]`);
	if (swatch) {
		panel.querySelectorAll(".bf-bg-swatch").forEach((s) => s.classList.remove("active"));
		swatch.classList.add("active");
	}
	const frameBtn = panel.querySelector(`.bf-frame-btn[data-frame="${CSS.escape(p.frame)}"]`);
	if (frameBtn) {
		panel.querySelectorAll(".bf-frame-btn").forEach((b) => b.classList.remove("active"));
		frameBtn.classList.add("active");
	}
	const setSlider = (id, valId, value, suffix) => {
		const sl = document.getElementById(id);
		const vl = document.getElementById(valId);
		if (sl) sl.value = String(value);
		if (vl) vl.textContent = value + suffix;
	};
	setSlider("bf-padding", "bf-padding-val", p.padding, "px");
	setSlider("bf-radius", "bf-radius-val", p.radius, "px");
	setSlider("bf-shadow", "bf-shadow-val", p.shadow, "px");
	setSlider("bf-shadow-opacity", "bf-shadow-opacity-val", p.shadowOpacity, "%");
	setSlider("bf-noise", "bf-noise-val", p.noise, "%");
	applyBeautify(false);
}
function setupBeautifyPresets() {
	const select = document.getElementById("bf-preset-select");
	const nameInput = document.getElementById("bf-preset-name");
	const saveBtn = document.getElementById("bf-preset-save-btn");
	if (!select || !nameInput || !saveBtn) return;
	function populate(presets) {
		select.innerHTML = "<option value=\"\">Custom</option>";
		for (const p of presets) {
			const opt = document.createElement("option");
			opt.value = p.name;
			opt.textContent = p.name;
			select.appendChild(opt);
		}
	}
	chrome.storage.sync.get("beautifyPresets").then((res) => {
		populate(res.beautifyPresets || []);
	});
	select.addEventListener("change", async () => {
		if (!select.value) return;
		const match = ((await chrome.storage.sync.get("beautifyPresets")).beautifyPresets || []).find((p) => p.name === select.value);
		if (match) applyBeautifyPreset(match);
	});
	saveBtn.addEventListener("click", async () => {
		const name = nameInput.value.trim();
		if (!name) {
			showToast("Enter a preset name first");
			return;
		}
		if (!backgroundImage) {
			showToast("Open Beautify with an image loaded first");
			return;
		}
		const presets = (await chrome.storage.sync.get("beautifyPresets")).beautifyPresets || [];
		const newPreset = {
			name,
			...readCurrentBeautifySettings()
		};
		const existingIndex = presets.findIndex((p) => p.name === name);
		if (existingIndex >= 0) presets[existingIndex] = newPreset;
		else presets.push(newPreset);
		await chrome.storage.sync.set({ beautifyPresets: presets });
		populate(presets);
		select.value = name;
		nameInput.value = "";
		showToast(`Saved preset "${name}"`);
	});
}
async function applyBeautify(showToastMsg = true) {
	if (!backgroundImage) {
		showToast("No image to beautify");
		return;
	}
	if (!originalScreenshotUrl) {
		const multiplier = imgNativeW > 0 ? imgNativeW / dispW : Math.max(1, 1 / fitScale);
		const savedZ = cssZoom;
		if (savedZ !== 1) applyContainerZoom(1);
		originalScreenshotUrl = canvas.toDataURL({
			format: "png",
			quality: 1,
			multiplier
		});
		if (savedZ !== 1) applyContainerZoom(savedZ);
	}
	const bgValue = document.querySelector(".bf-bg-swatch.active")?.dataset.bg || "none";
	const padding = parseInt(document.getElementById("bf-padding").value) || 0;
	const radius = parseInt(document.getElementById("bf-radius").value) || 0;
	const shadowBlur = parseInt(document.getElementById("bf-shadow").value) || 0;
	const shadowOpacity = parseInt(document.getElementById("bf-shadow-opacity").value) || 0;
	const noiseAmount = parseInt(document.getElementById("bf-noise").value) || 0;
	const frameType = document.querySelector(".bf-frame-btn.active")?.dataset.frame || "none";
	const ratioStr = document.querySelector(".bf-ratio-btn.active")?.dataset.ratio || "";
	const srcDataUrl = originalScreenshotUrl;
	const mainImg = new Image();
	mainImg.src = srcDataUrl;
	await new Promise((r) => {
		mainImg.onload = () => r();
	});
	let srcImg = mainImg;
	let srcW = mainImg.naturalWidth;
	let srcH = mainImg.naturalHeight;
	if (collageImages.length > 0) {
		const composite = await buildCollageComposite(mainImg, collageImages, collageLayout, radius);
		srcImg = composite.canvas;
		srcW = composite.w;
		srcH = composite.h;
	}
	const frameBarH = frameType !== "none" ? Math.round(Math.max(28, srcH * .035)) : 0;
	let outW = srcW + padding * 2;
	let outH = srcH + padding * 2 + frameBarH;
	if (ratioStr) {
		const ratio = parseFloat(ratioStr);
		if (ratio > 0) {
			if (outW / outH > ratio) outH = Math.round(outW / ratio);
			else outW = Math.round(outH * ratio);
		}
	}
	const oc = document.createElement("canvas");
	oc.width = outW;
	oc.height = outH;
	const ctx = oc.getContext("2d");
	if (bgValue === "none") {
		ctx.fillStyle = "transparent";
		ctx.clearRect(0, 0, outW, outH);
	} else if (bgValue.startsWith("linear-gradient")) {
		const colors = bgValue.match(/#[0-9a-fA-F]{6}/g) || ["#667eea", "#764ba2"];
		const grad = ctx.createLinearGradient(0, 0, outW, outH);
		grad.addColorStop(0, colors[0]);
		grad.addColorStop(1, colors[1] || colors[0]);
		ctx.fillStyle = grad;
		ctx.fillRect(0, 0, outW, outH);
	} else if (bgValue === "pattern:dots") {
		ctx.fillStyle = "#1a1a2e";
		ctx.fillRect(0, 0, outW, outH);
		ctx.fillStyle = "rgba(255,255,255,.35)";
		const spacing = 22;
		for (let py = spacing / 2; py < outH; py += spacing) for (let px = spacing / 2; px < outW; px += spacing) {
			ctx.beginPath();
			ctx.arc(px, py, 2.2, 0, Math.PI * 2);
			ctx.fill();
		}
	} else if (bgValue === "pattern:diagonal") {
		ctx.fillStyle = "#0c3483";
		ctx.fillRect(0, 0, outW, outH);
		ctx.strokeStyle = "rgba(255,255,255,.18)";
		ctx.lineWidth = 10;
		const step = 28;
		for (let sx = -outH; sx < outW; sx += step) {
			ctx.beginPath();
			ctx.moveTo(sx, outH);
			ctx.lineTo(sx + outH, 0);
			ctx.stroke();
		}
	} else {
		ctx.fillStyle = bgValue;
		ctx.fillRect(0, 0, outW, outH);
	}
	if (noiseAmount > 0) {
		const imageData = ctx.getImageData(0, 0, outW, outH);
		const data = imageData.data;
		const intensity = noiseAmount * 2.55;
		for (let i = 0; i < data.length; i += 4) {
			const noise = (Math.random() - .5) * intensity;
			data[i] += noise;
			data[i + 1] += noise;
			data[i + 2] += noise;
		}
		ctx.putImageData(imageData, 0, 0);
	}
	const imgX = Math.round((outW - srcW) / 2);
	const imgY = Math.round((outH - srcH - frameBarH) / 2) + frameBarH;
	if (shadowBlur > 0 && shadowOpacity > 0) {
		ctx.save();
		ctx.shadowColor = `rgba(0,0,0,${shadowOpacity / 100})`;
		ctx.shadowBlur = shadowBlur;
		ctx.shadowOffsetY = Math.round(shadowBlur * .3);
		if (radius > 0) {
			roundedRect(ctx, imgX, imgY, srcW, srcH, radius);
			ctx.fillStyle = "rgba(0,0,0,1)";
			ctx.fill();
		} else {
			ctx.fillStyle = "rgba(0,0,0,1)";
			ctx.fillRect(imgX, imgY, srcW, srcH);
		}
		ctx.restore();
	}
	ctx.save();
	if (radius > 0) {
		roundedRect(ctx, imgX, imgY, srcW, srcH, radius);
		ctx.clip();
	}
	ctx.drawImage(srcImg, imgX, imgY, srcW, srcH);
	ctx.restore();
	if (frameType === "macos") drawMacFrame(ctx, imgX, imgY - frameBarH, srcW, frameBarH, radius);
	else if (frameType === "browser") drawBrowserFrame(ctx, imgX, imgY - frameBarH, srcW, frameBarH, radius);
	else if (frameType === "windows") drawWindowsFrame(ctx, imgX, imgY - frameBarH, srcW, frameBarH, radius);
	else if (frameType === "phone") drawPhoneFrame(ctx, imgX, imgY - frameBarH, srcW, frameBarH, radius);
	await loadScreenshot(oc.toDataURL("image/png"), true);
	isBeautified = true;
	saveState();
	if (showToastMsg) showToast("Beautify applied");
}
function roundedRect(ctx, x, y, w, h, r) {
	ctx.beginPath();
	ctx.moveTo(x + r, y);
	ctx.lineTo(x + w - r, y);
	ctx.quadraticCurveTo(x + w, y, x + w, y + r);
	ctx.lineTo(x + w, y + h - r);
	ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
	ctx.lineTo(x + r, y + h);
	ctx.quadraticCurveTo(x, y + h, x, y + h - r);
	ctx.lineTo(x, y + r);
	ctx.quadraticCurveTo(x, y, x + r, y);
	ctx.closePath();
}
function drawMacFrame(ctx, x, y, w, h, radius) {
	ctx.save();
	ctx.beginPath();
	const r = Math.min(radius, 16);
	ctx.moveTo(x + r, y);
	ctx.lineTo(x + w - r, y);
	ctx.quadraticCurveTo(x + w, y, x + w, y + r);
	ctx.lineTo(x + w, y + h);
	ctx.lineTo(x, y + h);
	ctx.lineTo(x, y + r);
	ctx.quadraticCurveTo(x, y, x + r, y);
	ctx.closePath();
	ctx.fillStyle = "#E5E5E7";
	ctx.fill();
	const dotR = Math.max(5, Math.round(h * .18));
	const dotY = y + h / 2;
	const dotStartX = x + Math.round(h * .55);
	const gap = Math.round(dotR * 2.8);
	const dots = [
		{
			cx: dotStartX,
			color: "#FF5F57"
		},
		{
			cx: dotStartX + gap,
			color: "#FEBC2E"
		},
		{
			cx: dotStartX + gap * 2,
			color: "#28C840"
		}
	];
	for (const d of dots) {
		ctx.beginPath();
		ctx.arc(d.cx, dotY, dotR, 0, Math.PI * 2);
		ctx.fillStyle = d.color;
		ctx.fill();
	}
	ctx.restore();
}
function drawBrowserFrame(ctx, x, y, w, h, radius) {
	ctx.save();
	ctx.beginPath();
	ctx.moveTo(x + radius, y);
	ctx.lineTo(x + w - radius, y);
	ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
	ctx.lineTo(x + w, y + h);
	ctx.lineTo(x, y + h);
	ctx.lineTo(x, y + radius);
	ctx.quadraticCurveTo(x, y, x + radius, y);
	ctx.closePath();
	ctx.fillStyle = "#F0F0F0";
	ctx.fill();
	const dotR = Math.max(4, Math.round(h * .14));
	const dotY = y + h / 2;
	const dotStartX = x + Math.round(h * .5);
	const gap = Math.round(dotR * 2.8);
	const dots = [
		{ color: "#FF5F57" },
		{ color: "#FEBC2E" },
		{ color: "#28C840" }
	];
	for (let i = 0; i < dots.length; i++) {
		ctx.beginPath();
		ctx.arc(dotStartX + gap * i, dotY, dotR, 0, Math.PI * 2);
		ctx.fillStyle = dots[i].color;
		ctx.fill();
	}
	const barH = Math.round(h * .5);
	const barY = y + (h - barH) / 2;
	const barX = dotStartX + gap * 3 + dotR * 2;
	const barW = w - (barX - x) - Math.round(h * .5);
	if (barW > 40) {
		ctx.fillStyle = "#FFFFFF";
		ctx.beginPath();
		const barR = barH / 2;
		ctx.moveTo(barX + barR, barY);
		ctx.lineTo(barX + barW - barR, barY);
		ctx.quadraticCurveTo(barX + barW, barY, barX + barW, barY + barR);
		ctx.quadraticCurveTo(barX + barW, barY + barH, barX + barW - barR, barY + barH);
		ctx.lineTo(barX + barR, barY + barH);
		ctx.quadraticCurveTo(barX, barY + barH, barX, barY + barR);
		ctx.quadraticCurveTo(barX, barY, barX + barR, barY);
		ctx.closePath();
		ctx.fill();
		ctx.fillStyle = "#999";
		ctx.font = `${Math.round(barH * .6)}px -apple-system, sans-serif`;
		ctx.textBaseline = "middle";
		let displayUrl = "example.com";
		if (capturedPageUrl) try {
			const parsed = new URL(capturedPageUrl);
			displayUrl = parsed.hostname + (parsed.pathname !== "/" ? parsed.pathname : "");
		} catch {
			displayUrl = capturedPageUrl.slice(0, 60);
		}
		let urlText = (capturedPageUrl?.startsWith("https") ? "🔒 " : "") + displayUrl;
		const maxUrlW = barW - 16;
		while (ctx.measureText(urlText).width > maxUrlW && urlText.length > 10) urlText = urlText.slice(0, -2) + "…";
		ctx.fillText(urlText, barX + 8, barY + barH / 2);
	}
	ctx.restore();
}
function drawWindowsFrame(ctx, x, y, w, h, radius) {
	ctx.save();
	const r = Math.min(radius, 10);
	ctx.beginPath();
	ctx.moveTo(x + r, y);
	ctx.lineTo(x + w - r, y);
	ctx.quadraticCurveTo(x + w, y, x + w, y + r);
	ctx.lineTo(x + w, y + h);
	ctx.lineTo(x, y + h);
	ctx.lineTo(x, y + r);
	ctx.quadraticCurveTo(x, y, x + r, y);
	ctx.closePath();
	ctx.fillStyle = "#F3F3F3";
	ctx.fill();
	const iconSize = Math.max(9, Math.round(h * .3));
	const btnW = Math.round(h * 1.4);
	const iconY = y + h / 2;
	ctx.strokeStyle = "#333";
	ctx.lineWidth = Math.max(1, iconSize * .09);
	ctx.lineCap = "round";
	const closeX = x + w - btnW / 2 - Math.round(h * .2);
	ctx.beginPath();
	ctx.moveTo(closeX - iconSize / 2, iconY - iconSize / 2);
	ctx.lineTo(closeX + iconSize / 2, iconY + iconSize / 2);
	ctx.moveTo(closeX + iconSize / 2, iconY - iconSize / 2);
	ctx.lineTo(closeX - iconSize / 2, iconY + iconSize / 2);
	ctx.stroke();
	const maxX = closeX - btnW;
	ctx.strokeRect(maxX - iconSize / 2, iconY - iconSize / 2, iconSize, iconSize);
	const minX = maxX - btnW;
	ctx.beginPath();
	ctx.moveTo(minX - iconSize / 2, iconY + iconSize / 2);
	ctx.lineTo(minX + iconSize / 2, iconY + iconSize / 2);
	ctx.stroke();
	ctx.restore();
}
function drawPhoneFrame(ctx, x, y, w, h, radius) {
	ctx.save();
	const r = Math.min(radius, 22);
	ctx.beginPath();
	ctx.moveTo(x + r, y);
	ctx.lineTo(x + w - r, y);
	ctx.quadraticCurveTo(x + w, y, x + w, y + r);
	ctx.lineTo(x + w, y + h);
	ctx.lineTo(x, y + h);
	ctx.lineTo(x, y + r);
	ctx.quadraticCurveTo(x, y, x + r, y);
	ctx.closePath();
	ctx.fillStyle = "#0B0B0F";
	ctx.fill();
	const pillW = Math.round(w * .28);
	const pillH = Math.round(h * .4);
	const pillX = x + (w - pillW) / 2;
	const pillY = y + (h - pillH) / 2;
	const pillR = pillH / 2;
	ctx.fillStyle = "#000";
	ctx.beginPath();
	ctx.moveTo(pillX + pillR, pillY);
	ctx.lineTo(pillX + pillW - pillR, pillY);
	ctx.quadraticCurveTo(pillX + pillW, pillY, pillX + pillW, pillY + pillR);
	ctx.quadraticCurveTo(pillX + pillW, pillY + pillH, pillX + pillW - pillR, pillY + pillH);
	ctx.lineTo(pillX + pillR, pillY + pillH);
	ctx.quadraticCurveTo(pillX, pillY + pillH, pillX, pillY + pillR);
	ctx.quadraticCurveTo(pillX, pillY, pillX + pillR, pillY);
	ctx.closePath();
	ctx.fill();
	ctx.restore();
}
async function resetBeautify() {
	const panel = document.getElementById("beautifyPanel");
	if (originalScreenshotUrl) {
		const orig = originalScreenshotUrl;
		originalScreenshotUrl = null;
		await loadScreenshot(orig, true);
		isBeautified = false;
		if (panel) {
			panel.querySelectorAll(".bf-bg-swatch").forEach((s, idx) => s.classList.toggle("active", idx === 0));
			panel.querySelectorAll(".bf-frame-btn").forEach((s, idx) => s.classList.toggle("active", idx === 0));
			panel.querySelectorAll(".bf-ratio-btn").forEach((s, idx) => s.classList.toggle("active", idx === 0));
			const pad = document.getElementById("bf-padding");
			if (pad) {
				pad.value = "40";
				const v = document.getElementById("bf-padding-val");
				if (v) v.textContent = "40px";
			}
			const rad = document.getElementById("bf-radius");
			if (rad) {
				rad.value = "12";
				const v = document.getElementById("bf-radius-val");
				if (v) v.textContent = "12px";
			}
			const shd = document.getElementById("bf-shadow");
			if (shd) {
				shd.value = "30";
				const v = document.getElementById("bf-shadow-val");
				if (v) v.textContent = "30px";
			}
			const opc = document.getElementById("bf-shadow-opacity");
			if (opc) {
				opc.value = "40";
				const v = document.getElementById("bf-shadow-opacity-val");
				if (v) v.textContent = "40%";
			}
			const nse = document.getElementById("bf-noise");
			if (nse) {
				nse.value = "0";
				const v = document.getElementById("bf-noise-val");
				if (v) v.textContent = "0%";
			}
			collageImages = [];
			collageLayout = "row";
			panel.querySelectorAll(".bf-collage-layout-btn").forEach((s, idx) => s.classList.toggle("active", idx === 0));
			renderCollageThumbs();
		}
		saveState();
		showToast("Reset to original");
	} else showToast("Nothing to reset");
}
init();
setupBeautifier();
setupBeautifyPresets();
setupCollage();
//#endregion
