(function() {
	//#region src/ui/overlay-kit.ts
	/**
	* Shared visual language for everything the extension injects into a page.
	*
	* Injected UI cannot use a stylesheet the way popup.html can — it lands in a
	* hostile document whose own CSS may cascade over ours — so components are
	* built from inline styles and these tokens are the single place the values
	* live. Tokens mirror the popup's `:root` set so overlay, popup, editor, and
	* settings all read as one product.
	*
	* Icons are stroke-only SVG on `currentColor` (Feather geometry, 24×24 box), so
	* a button's colour flows into its glyph and nothing depends on emoji, whose
	* shape and colour vary per platform and cannot inherit weight or hue.
	*/
	/** Distinct family name — a page may ship its own "Archivo" at another weight. */
	var FONT_FAMILY = `'GoFully Archivo', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif`;
	var T = {
		surface: "#FFFFFF",
		surfaceAlt: "#F7F8FA",
		surfaceSunken: "#F1F3F7",
		border: "#E3E8EF",
		borderStrong: "#C8D0D9",
		text: "#101828",
		textMuted: "#475467",
		textFaint: "#667085",
		accent: "#1667F2",
		accentHover: "#1257D8",
		accentBg: "#EDF1FE",
		accentBorder: "#BDD0FB",
		success: "#027A48",
		successBg: "#ECFDF3",
		successBorder: "#A6F4C5",
		danger: "#B42318",
		dangerBg: "#FEF3F2",
		dangerBorder: "#FECDCA",
		warn: "#B54708",
		warnBg: "#FFFAEB",
		warnBorder: "#FEDF89",
		/** Dim applied outside a selection. Kept light so the page stays readable. */
		shade: "rgba(16, 24, 40, 0.28)",
		shadow: "0 4px 6px -2px rgba(16,24,40,0.03), 0 12px 16px -4px rgba(16,24,40,0.08)",
		shadowLg: "0 8px 8px -4px rgba(16,24,40,0.04), 0 20px 24px -4px rgba(16,24,40,0.10)",
		radius: "10px",
		radiusLg: "14px"
	};
	var FONT_STYLE_ID = "gofully-font";
	/**
	* Register Archivo for injected UI. The face ships with the extension, so it
	* resolves with no network request and survives pages whose CSP forbids remote
	* fonts. Safe to call repeatedly.
	*/
	function injectOverlayFont() {
		if (document.getElementById(FONT_STYLE_ID)) return;
		let src;
		try {
			src = chrome.runtime.getURL("assets/Archivo.woff2");
		} catch {
			return;
		}
		const style = document.createElement("style");
		style.id = FONT_STYLE_ID;
		style.textContent = `
    @font-face {
      font-family: 'GoFully Archivo';
      src: url('${src}') format('woff2-variations'),
           url('${src}') format('woff2');
      font-weight: 100 900;
      font-style: normal;
      font-display: swap;
    }
    @keyframes gf-pulse { 0%,100% { opacity: 1 } 50% { opacity: .3 } }
    @keyframes gf-in { from { opacity: 0; transform: translateY(4px) } to { opacity: 1; transform: none } }
  `;
		(document.head || document.documentElement).appendChild(style);
	}
	function removeOverlayFont() {
		document.getElementById(FONT_STYLE_ID)?.remove();
	}
	function svg(body, size = 14, width = 1.75) {
		return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="${width}" stroke-linecap="round" stroke-linejoin="round" style="display:block;flex-shrink:0" aria-hidden="true">${body}</svg>`;
	}
	var Icon = {
		play: (s = 14) => svg(`<polygon points="6 3 20 12 6 21 6 3" fill="currentColor" stroke="none"/>`, s),
		/** Manual mode. A mouse reads unambiguously at 13px, where a hand silhouette
		*  collapses into a blob and gets mistaken for the lock glyph. */
		mouse: (s = 14) => svg(`<rect x="6" y="3" width="12" height="18" rx="6"/><path d="M12 7v3"/>`, s),
		check: (s = 14) => svg(`<polyline points="20 6 9 17 4 12"/>`, s, 2.25),
		x: (s = 14) => svg(`<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>`, s, 2),
		stop: (s = 14) => svg(`<rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor" stroke="none"/>`, s),
		warning: (s = 14) => svg(`<path d="M12 9v4"/><path d="M12 17h.01"/><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/>`, s),
		crop: (s = 14) => svg(`<path d="M6 2v14a2 2 0 0 0 2 2h14"/><path d="M18 22V8a2 2 0 0 0-2-2H2"/>`, s),
		scroll: (s = 14) => svg(`<path d="M12 5v14"/><polyline points="7 14 12 19 17 14"/><polyline points="17 10 12 5 7 10"/>`, s),
		lock: (s = 14) => svg(`<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>`, s),
		unlock: (s = 14) => svg(`<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 7.5-2"/>`, s)
	};
	var TONES = {
		primary: {
			bg: T.accent,
			fg: "#FFFFFF",
			border: T.accent,
			hover: T.accentHover
		},
		success: {
			bg: T.success,
			fg: "#FFFFFF",
			border: T.success,
			hover: "#026A3E"
		},
		danger: {
			bg: T.danger,
			fg: "#FFFFFF",
			border: T.danger,
			hover: "#9A1D14"
		},
		neutral: {
			bg: T.surface,
			fg: T.text,
			border: T.border,
			hover: T.surfaceAlt
		},
		ghost: {
			bg: "transparent",
			fg: T.textFaint,
			border: "transparent",
			hover: T.surfaceAlt
		}
	};
	/** A button whose icon inherits the label colour, so tone changes stay in sync. */
	function makeButton(opts) {
		const tone = TONES[opts.tone ?? "neutral"];
		const b = document.createElement("button");
		b.type = "button";
		if (opts.title) b.title = opts.title;
		if (!opts.label && opts.title) b.setAttribute("aria-label", opts.title);
		Object.assign(b.style, {
			display: "inline-flex",
			alignItems: "center",
			justifyContent: "center",
			gap: opts.label && opts.icon ? "6px" : "0",
			background: tone.bg,
			color: tone.fg,
			border: `1px solid ${tone.border}`,
			borderRadius: "8px",
			padding: opts.small ? "5px 9px" : "7px 12px",
			font: `600 ${opts.small ? "11px" : "12px"}/1 ${FONT_FAMILY}`,
			letterSpacing: "-0.005em",
			cursor: "pointer",
			width: opts.block ? "100%" : "auto",
			flexShrink: "0",
			transition: "background .14s ease, border-color .14s ease",
			boxSizing: "border-box",
			textAlign: "center"
		});
		if (opts.icon) b.insertAdjacentHTML("beforeend", opts.icon);
		if (opts.label) {
			const span = document.createElement("span");
			span.textContent = opts.label;
			b.appendChild(span);
		}
		b.addEventListener("mouseenter", () => b.style.background = tone.hover);
		b.addEventListener("mouseleave", () => b.style.background = tone.bg);
		b.addEventListener("click", (e) => {
			e.stopPropagation();
			e.preventDefault();
			opts.onClick();
		});
		return b;
	}
	/** A floating light panel — the base surface for every injected control group. */
	function makePanel(extra = {}) {
		const d = document.createElement("div");
		Object.assign(d.style, {
			position: "fixed",
			background: T.surface,
			border: `1px solid ${T.border}`,
			borderRadius: T.radiusLg,
			boxShadow: T.shadowLg,
			color: T.text,
			fontFamily: FONT_FAMILY,
			boxSizing: "border-box",
			animation: "gf-in .18s ease"
		}, extra);
		return d;
	}
	function makeText(text, opts = {}) {
		const s = document.createElement("span");
		s.textContent = text;
		Object.assign(s.style, {
			font: `${opts.weight ?? "500"} ${opts.size ?? "12px"}/1.45 ${FONT_FAMILY}`,
			color: opts.color ?? T.textMuted,
			textAlign: opts.align ?? "left",
			letterSpacing: "-0.005em"
		});
		return s;
	}
	//#endregion
	//#region src/content/scrolling-area-ui.ts
	chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
		if (message.type === "START_SCROLLING_AREA_MODE") {
			startScrollingAreaUI(message.payload.tabId);
			sendResponse({ started: true });
			return true;
		}
		if (message.type === "SCROLLING_PROGRESS") {
			updateAutoProgress(message.payload?.current, message.payload?.total);
			return false;
		}
		if (message.type === "SCROLL_PROGRESS") {
			updateManualProgress(message.payload);
			return false;
		}
		if (message.type === "SCROLL_UI_HIDE") {
			setOwnUiVisible(false);
			sendResponse({ ok: true });
			return true;
		}
		if (message.type === "SCROLL_UI_SHOW") {
			setOwnUiVisible(true);
			sendResponse({ ok: true });
			return true;
		}
		if (message.type === "SCROLL_UI_VISIBILITY") {
			setOwnUiVisible(!message.hide);
			sendResponse({ ok: true });
			return true;
		}
		return false;
	});
	var crosshair = null;
	var selBox = null;
	var shades = [];
	var sizeBadge = null;
	var optionsPanel = null;
	var capturePanel = null;
	var previewImg = null;
	var frameCountEl = null;
	var heightEl = null;
	var statusEl = null;
	var speedWarnEl = null;
	var autoProgressEl = null;
	var pollTimer = null;
	var phase = "selecting";
	var captureMode = null;
	var currentRegion = null;
	var tabId = null;
	var startX = 0;
	var startY = 0;
	var isDragging = false;
	var selectedSpeed = "medium";
	function startScrollingAreaUI(tid) {
		cleanup();
		tabId = tid;
		phase = "selecting";
		injectOverlayFont();
		buildCrosshair();
	}
	function setOwnUiVisible(visible) {
		const v = visible ? "visible" : "hidden";
		for (const el of [
			capturePanel,
			selBox,
			optionsPanel,
			sizeBadge
		]) if (el) el.style.visibility = v;
		shades.forEach((s) => s.style.visibility = v);
	}
	function buildCrosshair() {
		crosshair = document.createElement("div");
		Object.assign(crosshair.style, {
			position: "fixed",
			inset: "0",
			width: "100vw",
			height: "100vh",
			zIndex: "2147483640",
			cursor: "crosshair",
			userSelect: "none",
			background: "transparent"
		});
		const hint = makePanel({
			position: "absolute",
			top: "50%",
			left: "50%",
			transform: "translate(-50%,-50%)",
			padding: "14px 20px",
			textAlign: "center",
			pointerEvents: "none"
		});
		hint.id = "gf-hint";
		const title = makeText("Drag to select the scroll region", {
			size: "13px",
			weight: "600",
			color: T.text
		});
		const sub = makeText("Esc to cancel", {
			size: "11px",
			color: T.textFaint
		});
		Object.assign(hint.style, {
			display: "flex",
			flexDirection: "column",
			gap: "3px",
			alignItems: "center"
		});
		hint.append(title, sub);
		crosshair.appendChild(hint);
		crosshair.addEventListener("mousedown", onDown);
		crosshair.addEventListener("mousemove", onMove);
		crosshair.addEventListener("mouseup", onUp);
		document.addEventListener("keydown", onKey, true);
		document.body.appendChild(crosshair);
	}
	function drawSelection(x, y, w, h) {
		const vw = window.innerWidth, vh = window.innerHeight;
		if (!selBox) {
			selBox = document.createElement("div");
			Object.assign(selBox.style, {
				position: "fixed",
				zIndex: "2147483641",
				boxSizing: "border-box",
				border: `1.5px solid ${T.accent}`,
				boxShadow: "0 0 0 1px rgba(255,255,255,0.85)",
				pointerEvents: "none"
			});
			document.body.appendChild(selBox);
		}
		Object.assign(selBox.style, {
			left: px(x),
			top: px(y),
			width: px(w),
			height: px(h)
		});
		const rects = [
			{
				left: 0,
				top: 0,
				width: vw,
				height: y
			},
			{
				left: 0,
				top: y,
				width: x,
				height: h
			},
			{
				left: x + w,
				top: y,
				width: Math.max(0, vw - x - w),
				height: h
			},
			{
				left: 0,
				top: y + h,
				width: vw,
				height: Math.max(0, vh - y - h)
			}
		];
		while (shades.length < 4) {
			const s = document.createElement("div");
			Object.assign(s.style, {
				position: "fixed",
				zIndex: "2147483639",
				background: T.shade,
				pointerEvents: "none"
			});
			shades.push(s);
			document.body.appendChild(s);
		}
		rects.forEach((r, i) => Object.assign(shades[i].style, {
			left: px(r.left),
			top: px(r.top),
			width: px(r.width),
			height: px(r.height)
		}));
	}
	function clearShades() {
		shades.forEach((s) => s.remove());
		shades = [];
	}
	function showSizeBadge(x, y, w, h) {
		if (!sizeBadge) {
			sizeBadge = document.createElement("div");
			Object.assign(sizeBadge.style, {
				position: "fixed",
				zIndex: "2147483642",
				pointerEvents: "none",
				background: T.accent,
				color: "#FFFFFF",
				font: `600 11px/1 ${FONT_FAMILY}`,
				fontVariantNumeric: "tabular-nums",
				padding: "4px 7px",
				borderRadius: "6px",
				whiteSpace: "nowrap",
				boxShadow: T.shadow
			});
			document.body.appendChild(sizeBadge);
		}
		sizeBadge.textContent = `${Math.round(w)} × ${Math.round(h)}`;
		sizeBadge.style.left = px(Math.max(2, x));
		sizeBadge.style.top = y > 26 ? px(y - 24) : px(y + 5);
	}
	function buildReadyUI() {
		crosshair?.remove();
		crosshair = null;
		document.getElementById("gf-hint")?.remove();
		const r = currentRegion;
		showSizeBadge(r.x, r.y, r.width, r.height);
		const panel = makePanel({
			padding: "14px",
			display: "flex",
			flexDirection: "column",
			gap: "12px",
			minWidth: "268px",
			zIndex: "2147483643",
			pointerEvents: "auto",
			visibility: "hidden"
		});
		const head = document.createElement("div");
		Object.assign(head.style, {
			display: "flex",
			alignItems: "center",
			gap: "8px"
		});
		const mark = document.createElement("span");
		Object.assign(mark.style, {
			display: "inline-flex",
			alignItems: "center",
			justifyContent: "center",
			width: "26px",
			height: "26px",
			borderRadius: "7px",
			background: T.accentBg,
			color: T.accent,
			flexShrink: "0"
		});
		mark.innerHTML = Icon.scroll(15);
		const heading = makeText("Scroll Capture", {
			size: "13px",
			weight: "700",
			color: T.text
		});
		head.append(mark, heading);
		const desc = makeText("Auto scrolls for you. Manual follows your own scrolling.", {
			size: "11px",
			color: T.textFaint
		});
		const speedRow = document.createElement("div");
		Object.assign(speedRow.style, {
			display: "flex",
			alignItems: "center",
			gap: "6px",
			padding: "8px",
			borderRadius: T.radius,
			background: T.surfaceAlt,
			border: `1px solid ${T.border}`
		});
		const speedLbl = makeText("Auto speed", {
			size: "11px",
			weight: "600",
			color: T.textMuted
		});
		speedLbl.style.marginRight = "auto";
		speedRow.appendChild(speedLbl);
		const segment = document.createElement("div");
		Object.assign(segment.style, {
			display: "flex",
			gap: "2px",
			padding: "2px",
			background: T.surfaceSunken,
			borderRadius: "8px"
		});
		const speeds = [
			{
				label: "Slow",
				value: "slow"
			},
			{
				label: "Med",
				value: "medium"
			},
			{
				label: "Fast",
				value: "fast"
			}
		];
		const segButtons = [];
		for (const { label, value } of speeds) {
			const b = document.createElement("button");
			b.type = "button";
			b.textContent = label;
			Object.assign(b.style, {
				border: "none",
				cursor: "pointer",
				borderRadius: "6px",
				padding: "4px 10px",
				font: `600 11px/1 ${FONT_FAMILY}`,
				background: "transparent",
				color: T.textMuted,
				transition: "background .14s, color .14s"
			});
			b.addEventListener("click", (e) => {
				e.stopPropagation();
				selectedSpeed = value;
				paintSegment();
			});
			segButtons.push(b);
			segment.appendChild(b);
		}
		const paintSegment = () => {
			segButtons.forEach((b, i) => {
				const on = speeds[i].value === selectedSpeed;
				b.style.background = on ? T.surface : "transparent";
				b.style.color = on ? T.text : T.textMuted;
				b.style.boxShadow = on ? "0 1px 2px rgba(16,24,40,0.06)" : "none";
			});
		};
		paintSegment();
		speedRow.appendChild(segment);
		const actions = document.createElement("div");
		Object.assign(actions.style, {
			display: "flex",
			gap: "8px"
		});
		const autoB = makeButton({
			label: "Auto",
			icon: Icon.play(13),
			tone: "primary",
			onClick: startAuto
		});
		const manB = makeButton({
			label: "Manual",
			icon: Icon.mouse(13),
			tone: "neutral",
			onClick: startManual
		});
		autoB.style.flex = "1";
		manB.style.flex = "1";
		const cancelB = makeButton({
			icon: Icon.x(14),
			tone: "ghost",
			onClick: cleanup,
			title: "Cancel"
		});
		actions.append(autoB, manB, cancelB);
		panel.append(head, desc, speedRow, actions);
		document.body.appendChild(panel);
		optionsPanel = panel;
		const box = panel.getBoundingClientRect();
		const m = 12;
		panel.style.left = px(clamp(r.x + r.width / 2 - box.width / 2, m, window.innerWidth - box.width - m));
		panel.style.top = px(clamp(r.y + r.height - box.height - 16, m, window.innerHeight - box.height - m));
		panel.style.visibility = "visible";
		phase = "ready";
	}
	function startAuto() {
		if (!currentRegion) return;
		captureMode = "auto";
		phase = "capturing";
		clearShades();
		sizeBadge?.remove();
		sizeBadge = null;
		optionsPanel?.remove();
		optionsPanel = null;
		if (selBox) selBox.style.border = `1.5px solid ${T.accentBorder}`;
		const panel = makePanel({
			padding: "12px 14px",
			display: "flex",
			flexDirection: "column",
			gap: "10px",
			minWidth: "196px",
			zIndex: "2147483647",
			pointerEvents: "auto"
		});
		const row = document.createElement("div");
		Object.assign(row.style, {
			display: "flex",
			alignItems: "center",
			gap: "8px"
		});
		statusEl = makeText("Auto-scrolling…", {
			size: "12px",
			weight: "600",
			color: T.text
		});
		frameCountEl = makeText("0", {
			size: "12px",
			weight: "600",
			color: T.textFaint
		});
		frameCountEl.style.marginLeft = "auto";
		frameCountEl.style.fontVariantNumeric = "tabular-nums";
		row.append(statusEl, frameCountEl);
		const track = document.createElement("div");
		Object.assign(track.style, {
			height: "5px",
			borderRadius: "3px",
			background: T.surfaceSunken,
			overflow: "hidden"
		});
		autoProgressEl = document.createElement("div");
		Object.assign(autoProgressEl.style, {
			height: "100%",
			width: "0%",
			background: T.accent,
			borderRadius: "3px",
			transition: "width .35s ease"
		});
		track.appendChild(autoProgressEl);
		const stopB = makeButton({
			label: "Stop",
			icon: Icon.stop(12),
			tone: "danger",
			onClick: cleanup,
			block: true
		});
		panel.append(row, track, stopB);
		placePanelClearOfRegion(panel, 210);
		document.body.appendChild(panel);
		capturePanel = panel;
		chrome.runtime.sendMessage({
			type: "SCROLLING_REGION_SELECTED",
			payload: {
				region: currentRegion,
				speed: selectedSpeed,
				tabId
			}
		});
	}
	function updateAutoProgress(current, total) {
		if (autoProgressEl && total > 0) autoProgressEl.style.width = `${Math.round(current / total * 100)}%`;
		if (frameCountEl) frameCountEl.textContent = total > 0 ? `${current} / ${total}` : String(current);
	}
	function startManual() {
		if (!currentRegion) return;
		captureMode = "manual";
		phase = "capturing";
		clearShades();
		sizeBadge?.remove();
		sizeBadge = null;
		optionsPanel?.remove();
		optionsPanel = null;
		if (selBox) {
			selBox.style.border = "none";
			selBox.style.boxShadow = "none";
		}
		buildCapturePanel();
		const excludeRight = placePanelClearOfRegion(capturePanel, 300);
		const captureRegion = excludeRight > 0 ? {
			...currentRegion,
			width: Math.max(100, currentRegion.width - excludeRight)
		} : currentRegion;
		chrome.runtime.sendMessage({
			type: "SCROLL_START",
			payload: { region: captureRegion }
		}, () => {
			pollTimer = window.setInterval(() => {
				chrome.runtime.sendMessage({ type: "SCROLL_POLL" });
			}, 200);
		});
	}
	var PANEL_W = 132;
	var PANEL_MARGIN = 14;
	/**
	* Keep the panel out of the capture region. When the selection leaves no room
	* on any side, the panel sits inside at the bottom-right and the returned width
	* is trimmed from the region so the panel is never photographed.
	*/
	function placePanelClearOfRegion(panel, panelH) {
		const r = currentRegion;
		const vw = window.innerWidth;
		const vh = window.innerHeight;
		const need = 160;
		panel.style.top = "auto";
		panel.style.bottom = "auto";
		panel.style.left = "auto";
		panel.style.right = "auto";
		const topFor = (h) => px(clamp(r.y, PANEL_MARGIN, Math.max(PANEL_MARGIN, vh - h - PANEL_MARGIN)));
		if (vw - (r.x + r.width) >= need) {
			panel.style.left = px(r.x + r.width + PANEL_MARGIN);
			panel.style.top = topFor(panelH);
			return 0;
		}
		if (r.x >= need) {
			panel.style.right = px(vw - r.x + PANEL_MARGIN);
			panel.style.top = topFor(panelH);
			return 0;
		}
		if (vh - (r.y + r.height) >= panelH) {
			panel.style.right = px(PANEL_MARGIN);
			panel.style.top = px(r.y + r.height + PANEL_MARGIN);
			return 0;
		}
		if (r.y >= panelH) {
			panel.style.right = px(PANEL_MARGIN);
			panel.style.bottom = px(vh - r.y + PANEL_MARGIN);
			return 0;
		}
		panel.style.right = px(PANEL_MARGIN);
		panel.style.bottom = px(PANEL_MARGIN);
		return 160;
	}
	function buildCapturePanel() {
		const panel = makePanel({
			width: `${PANEL_W}px`,
			padding: "12px",
			display: "flex",
			flexDirection: "column",
			gap: "10px",
			zIndex: "2147483647",
			pointerEvents: "auto"
		});
		const head = document.createElement("div");
		Object.assign(head.style, {
			display: "flex",
			alignItems: "center",
			gap: "6px"
		});
		const dot = document.createElement("span");
		Object.assign(dot.style, {
			width: "7px",
			height: "7px",
			borderRadius: "50%",
			background: T.danger,
			flexShrink: "0",
			animation: "gf-pulse 1.2s infinite"
		});
		const recLbl = makeText("Recording", {
			size: "10px",
			weight: "700",
			color: T.danger
		});
		recLbl.style.letterSpacing = "0.02em";
		head.append(dot, recLbl);
		const stats = document.createElement("div");
		Object.assign(stats.style, {
			display: "flex",
			flexDirection: "column",
			gap: "1px"
		});
		frameCountEl = makeText("Starting…", {
			size: "13px",
			weight: "700",
			color: T.text
		});
		frameCountEl.style.fontVariantNumeric = "tabular-nums";
		heightEl = makeText("", {
			size: "10px",
			color: T.textFaint
		});
		heightEl.style.fontVariantNumeric = "tabular-nums";
		statusEl = makeText("Scroll to capture", {
			size: "10px",
			color: T.textFaint
		});
		stats.append(frameCountEl, heightEl, statusEl);
		speedWarnEl = document.createElement("div");
		Object.assign(speedWarnEl.style, {
			display: "none",
			alignItems: "flex-start",
			gap: "5px",
			padding: "6px 7px",
			borderRadius: "8px",
			background: T.warnBg,
			border: `1px solid ${T.warnBorder}`,
			color: T.warn,
			font: `600 10px/1.35 ${FONT_FAMILY}`
		});
		speedWarnEl.innerHTML = `${Icon.warning(12)}<span>Scroll more slowly</span>`;
		const shot = document.createElement("div");
		Object.assign(shot.style, {
			borderRadius: "8px",
			overflow: "hidden",
			border: `1px solid ${T.border}`,
			background: T.surfaceSunken,
			display: "none"
		});
		previewImg = document.createElement("img");
		Object.assign(previewImg.style, {
			width: "100%",
			display: "block"
		});
		shot.appendChild(previewImg);
		previewImg.__wrap = shot;
		const footer = document.createElement("div");
		Object.assign(footer.style, {
			display: "flex",
			flexDirection: "column",
			gap: "5px"
		});
		footer.append(makeButton({
			label: "Done",
			icon: Icon.check(13),
			tone: "success",
			onClick: finishManual,
			block: true
		}), makeButton({
			label: "Cancel",
			tone: "ghost",
			onClick: cancelManual,
			block: true,
			small: true
		}));
		panel.append(head, stats, speedWarnEl, shot, footer);
		document.body.appendChild(panel);
		capturePanel = panel;
	}
	function updateManualProgress(payload) {
		if (!payload) return;
		const { frameCount, totalHeight, thumbDataUrl, tooFast, atLimit } = payload;
		if (frameCountEl) frameCountEl.textContent = `${frameCount} frame${frameCount === 1 ? "" : "s"}`;
		if (heightEl) heightEl.textContent = `${Math.round(totalHeight / window.devicePixelRatio)}px tall`;
		if (statusEl) {
			statusEl.textContent = atLimit ? "Maximum height reached" : tooFast ? "" : "Scroll to capture";
			statusEl.style.color = atLimit ? T.warn : T.textFaint;
		}
		if (speedWarnEl) speedWarnEl.style.display = tooFast && !atLimit ? "flex" : "none";
		if (atLimit) stopPoll();
		if (thumbDataUrl && previewImg) {
			previewImg.src = thumbDataUrl;
			const wrap = previewImg.__wrap;
			if (wrap) wrap.style.display = "block";
		}
	}
	function finishManual() {
		stopPoll();
		if (statusEl) statusEl.textContent = "Stitching…";
		chrome.runtime.sendMessage({ type: "SCROLL_FINISH" });
		setTimeout(cleanup, 600);
	}
	function cancelManual() {
		stopPoll();
		chrome.runtime.sendMessage({ type: "SCROLL_STOP" });
		cleanup();
	}
	function stopPoll() {
		if (pollTimer !== null) {
			clearInterval(pollTimer);
			pollTimer = null;
		}
	}
	function onDown(e) {
		if (phase !== "selecting") return;
		isDragging = true;
		startX = e.clientX;
		startY = e.clientY;
		document.getElementById("gf-hint")?.remove();
	}
	function onMove(e) {
		if (!isDragging) return;
		const x = Math.min(startX, e.clientX);
		const y = Math.min(startY, e.clientY);
		const w = Math.abs(e.clientX - startX);
		const h = Math.abs(e.clientY - startY);
		if (w > 4 || h > 4) {
			drawSelection(x, y, w, h);
			showSizeBadge(x, y, w, h);
		}
	}
	function onUp(e) {
		if (!isDragging) return;
		isDragging = false;
		const x = Math.min(startX, e.clientX);
		const y = Math.min(startY, e.clientY);
		const w = Math.abs(e.clientX - startX);
		const h = Math.abs(e.clientY - startY);
		if (w < 30 || h < 30) {
			cleanup();
			return;
		}
		currentRegion = {
			x,
			y,
			width: w,
			height: h
		};
		buildReadyUI();
	}
	function onKey(e) {
		if (e.key !== "Escape") return;
		e.stopPropagation();
		captureMode === "manual" ? cancelManual() : cleanup();
	}
	function cleanup() {
		stopPoll();
		crosshair?.remove();
		selBox?.remove();
		clearShades();
		sizeBadge?.remove();
		optionsPanel?.remove();
		capturePanel?.remove();
		document.getElementById("gf-hint")?.remove();
		removeOverlayFont();
		document.removeEventListener("keydown", onKey, true);
		crosshair = null;
		selBox = null;
		sizeBadge = null;
		optionsPanel = null;
		capturePanel = null;
		previewImg = null;
		frameCountEl = null;
		heightEl = null;
		statusEl = null;
		autoProgressEl = null;
		speedWarnEl = null;
		currentRegion = null;
		tabId = null;
		phase = "selecting";
		captureMode = null;
		isDragging = false;
	}
	function px(n) {
		return `${n}px`;
	}
	function clamp(n, min, max) {
		return Math.max(min, Math.min(max, n));
	}
	//#endregion
})();
